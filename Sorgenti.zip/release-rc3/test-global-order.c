#define main original_device_main
#include "../../outputs/fm1-tracker/tests/test_device.c"
#undef main
static void turn(int d){memset(&controls,0,sizeof controls);controls.encoders[2]=d;tracker_device_control();}
static void rec(void){memset(&controls,0,sizeof controls);controls.buttons=1U<<13;tracker_device_control();controls.buttons=0;tracker_device_control();}
int main(void){memset(store_flash,255,sizeof store_flash);tracker_device_init();controls.buttons=1U<<7;tracker_device_control();controls.buttons=0;tracker_device_control();
 const unsigned expected[]={0,1,2,3,14,4,5,6,7,8,9,10,11,12,13};
 for(unsigned p=0;p<15;p++){assert(tracker_ui_state(3)==expected[p]);turn(1);}
 for(int p=14;p>=0;p--){assert(tracker_ui_state(3)==expected[p]);turn(-1);}
 turn(4);assert(tracker_ui_state(3)==14);rec(); /* init confirmation only */
 turn(1);assert(tracker_ui_state(3)==4);rec(); /* moved away: load empty, no init */
 for(unsigned a=0;a<sizeof store_flash;a++)assert(store_flash[a]==255);
 assert(tracker_ui_state(15)==2&&tracker_ui_project()->bpm==120);
 turn(1);assert(tracker_ui_state(3)==5);rec();assert(tracker_ui_state(15)==1);
 assert(!tracker_ui_tempo(141));turn(-1);rec();assert(tracker_ui_project()->bpm==120);
 puts("PASS Global order: Project slot, Init, Load, Save; both directions; Init cancelled by movement; correct Load/Save actions");return 0;}
