from pathlib import Path
import json,hashlib,zipfile,shutil,html
R=Path(__file__).resolve().parents[2];W=Path(__file__).parent;S=R/'outputs/fm1-tracker';D=R/'outputs/Meighty-1.01-RC3';O=R/'outputs'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
guide='''MEIGHTY 1.01 RC3 / SUITE OFFLINE 1.4 — TIFFANY

IPHONE/IPAD SENZA MAC
Apri https://gfcalvi.github.io/meighty-fm1/ in MIDIWeb Browser con rete attiva.
Controlla Meighty 1.01 RC3 / Suite offline 1.4 e l’hash in Installazione.
Nel menu dell’app scegli Make Available Offline e attendi il completamento.
La singola pagina incorpora tutti e quattro gli strumenti e il firmware.
Richiama poi la copia offline, anche senza rete e senza Mac. Quando aggiorni,
riapri l’HTTPS e sostituisci la vecchia copia offline. Non usare File → Apri con.
Per prove in mobilità: modalità aereo, Wi-Fi spento, chiudi e riapri MIDIWeb.
Connetti FM-1 via USB dati e autorizza MIDI/SysEx. iPhone richiede ancora
il suo collaudo: le prove USB fisiche finora sono state eseguite sul Mac.

COSA INCLUDE RC3
Global: stato arancione più grande su fascia scura; ordine Project slot →
Init slot → Load slot → Save slot. Global mostra 1.01 RC3, USB Meighty.
Correzioni di RC2: identità USB standard, Save con errore esplicito per note
non valide, rotativo Phrase limitato a note 0–127/OFF/vuoto, Load di slot
realmente vuoti crea un progetto nuovo. Mantiene il motore audio a due core.

SLOT: RAM, SAVE, LOAD E INIT SONO AZIONI DIVERSE
Project slot seleziona la destinazione/sorgente: non carica e non salva.
Save slot + REC scrive la RAM nello slot selezionato. Load slot + REC
sostituisce la RAM con quel progetto: le modifiche non salvate si perdono.
Uno slot cancellato caricato con Load crea RAM nuova: per conservarla usa Save.
All’accensione viene ripristinato lo slot 1 se valido: per il 2–8 usa Load.

Se uno slot è corrotto o di un altro firmware, Load non lo cancella e Save
normale non sovrascrive dati estranei. Per ricominciare lì: Project slot →
numero desiderato → Init slot → REC, rilascio, REC entro 7 secondi.
Controlla il numero in ERASE SLOT n? REC AGAIN prima della seconda pressione.
Init cancella solo i 24 KiB di quel posto, anche dati di altri firmware:
conserva prima il loro backup se ti servono. Dopo SLOT n READY: SAVE,
modifica il progetto e usa Save slot. Gli altri sette posti non sono inizializzati.
New project invece azzera SOLO la RAM, richiede doppio REC e poi Save.

ESEMPIO SAVE/LOAD
Slot 2 → Init (solo se vuoi cancellarlo) → BPM 137 → Save slot + REC.
Cambia BPM in 141 senza salvare. Load slot + REC riporta 137.
Spegni e riaccendi, seleziona slot 2 e Load: ritrovi 137.
Questa sequenza è stata provata fisicamente su RC2 con confronto di tutti
i 11.940 byte, prima e dopo lo spegnimento. Gli otto indirizzi sono testati
in software; non tutti otto gli slot sono stati collaudati fisicamente.

PARTIRE DA UNA RIGA SONG
Da fermo: Song → ALGORITHM seleziona la riga → PLAY, restando in Song.
Durante PLAY: scegli la riga e REC accoda il salto.
La riga deve essere entro LEN, regolata con K3. OUTSIDE LEN indica che
devi aumentare prima la lunghezza. Un progetto nuovo ha LEN 1 (solo riga 00).

BACKUP E RECUPERO
Crea backup completo legge otto slot e copia in lavorazione (RAM).
Se tutto è valido produce .meighty. Se trova dati illeggibili o RAM invalida,
offre un ZIP PARZIALE con i brani leggibili, la RAM e il rapporto degli errori.
Una RAM non valida viene conservata raw senza correggerla silenziosamente:
è materiale di recupero, non un progetto pronto per il ripristino.
Gli slot illeggibili NON sono considerati vuoti. Nessuna cancellazione nel backup.
Premi Scarica il file o Condividi / Salva in File per conservarlo.
Il recupero parziale USB è stato provato fisicamente su RC2/Mac.

RIPRISTINO
Apri il backup, prepara il piano e conserva il backup preliminare della macchina.
Poi spunta la conferma e Ripristina e verifica. Senza backup preliminare
completo il piano non procede. Sostituisci applica tutti otto i posti, compresi
i vuoti; Unisci solo i brani presenti. Ogni scrittura viene riletta e verificata.
Per suonare il brano: Global → Project slot → Load. Non reinstalla il firmware.

COMPOSITORE E CONVERTITORE
Carica brano… su ciascuna riga apre il selettore file. Il menu Vuoto sceglie
invece un brano già importato. Estrai ogni slot o tutti in ZIP con indice;
componi set da zero a otto brani, anche non consecutivi. I file sorgenti restano
invariati. Formati: .meighty, progetti/banche precedenti, .rfm1state anche LZFSE,
.fm1save e dump M-Flasher. Non converte brani Bloomy in progetti Meighty.

INSTALLAZIONE E VERSIONI
La suite contiene la build RC3 candidata. L’hash deve coincidere con VERIFICHE.
RC2 è stata installata da Bloomy e poi sostituita da Bloomy via browser sul Mac,
senza M-Flasher. RC3 aggiorna anche i nomi USB del loader: il suo collaudo
fisico e i limiti aggiornati sono registrati in VERIFICHE.json.
Firmware Hub Tessera/Skiff e iPhone non sono dichiarati collaudati.
In caso di recupero, M-Flasher resta disponibile: conserva bootloader e impostazioni.

MAC/PC
Stesso HTTPS in Chrome/Edge; oppure Avvia-Meighty.command/.cmd con Python 3.
I launcher sono solo per computer e non servono su iOS.
Il PDF musicale è quello esistente; questa guida integra i nuovi comandi.
Il modulo RemoteFM1 Follow nel pacchetto Mac è storico: non contiene i nuovi
fix hardware degli slot. I suoi identificatori restano per leggere vecchi stati.
Nessun backup personale è incluso nei pacchetti pubblici.
'''
(D/'INIZIA-QUI.txt').write_text(guide)
page='<!doctype html><html lang="it"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Meighty RC3 · Guida</title><style>body{max-width:850px;margin:30px auto;padding:20px;background:#071e20;color:#f1f9f7;font:17px/1.6 system-ui}h1,a{color:#70dfd0}pre{white-space:pre-wrap;font:inherit}</style><h1>Meighty 1.01 RC3 · Suite offline 1.4</h1><a href="Meighty.html">Apri la suite</a><pre>'+html.escape(guide)+'</pre></html>'
(D/'LEGGIMI.html').write_text(page)
for name in ['Avvia-Meighty.py','Avvia-Meighty.command','Avvia-Meighty.cmd']:
 shutil.copy2(S/'toolsuite'/name,D/name)
prev=json.loads((O/'Meighty-1.01-RC2/VERIFICHE.json').read_text())
report={'date':'2026-11-09','release':'Meighty 1.01 RC3 / HW12','suite':'1.4','firmware':{'file':'Meighty-1.01-RC3.fwsc','sha256':sha(O/'Meighty-1.01-RC3.fwsc')},'status':'RC3_SOFTWARE_VERIFIED_PHYSICAL_INSTALL_PENDING','build':json.loads((S/'build/hardware-hw12/report.json').read_text()),'loader':json.loads((S/'build/loader-hw1/report.json').read_text()),'physical_rc2_roundtrip':prev.get('physical_rc2'),'physical_slot2_rc2':prev.get('physical_slot2'),'software_tests':{'logic_cases':786,'browser_interface':28,'browser_shell':5,'native_device':'PASS ASan/UBSan; Song selected-row start and live launch','global_order':(W/'global-order.log').read_text(),'usb':'PASS descriptors and update/SysEx flow; names Meighty','loader_and_ota':'See release test log'},'limits':['RC2 hardware evidence is not a claim all eight slots were physically tested.','RC3 final physical results will be recorded after installation.','iPhone MIDIWeb/offline and Firmware Hub Tessera/Skiff are pending user tests.','No personal backup payload included.','Existing musical PDF and historical RemoteFM1 Follow module retained.']}
(D/'VERIFICHE.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
# Preserve the tested RC2 archive, overlay only reviewed source changes.
overlay=['app/tracker/device.c','app/tracker/blue_ui.inc','app/tracker/commands.c','hardware/vendor/usb.c','web/tracker/Workbench.js','web/tracker/ProjectFiles.js','tests/test_usb_tracker.c','tools/Build-Meighty-RC3-Mac.py','tools/Build-Loader-Mac.py']
overlay += [str(p.relative_to(S)) for p in (S/'toolsuite').iterdir() if p.is_file()]
with zipfile.ZipFile(O/'Meighty-1.01-RC2/Sorgenti-RC2.zip') as old,zipfile.ZipFile(D/'Sorgenti.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for item in old.infolist():
  if item.filename not in {'fm1-tracker/'+n for n in overlay}:z.writestr(item,old.read(item.filename))
 for n in overlay:z.write(S/n,'fm1-tracker/'+n)
 for n in ['build-rc3-suite.py','release-rc3.py','test-global-order.c','global-order.log','status-branding.log','loader-rc3.log','build-rc3-final.log']:
  z.write(W/n,'release-rc3/'+n)
 z.write(D/'INIZIA-QUI.txt','release-rc3/INIZIA-QUI.txt')
assert zipfile.ZipFile(D/'Sorgenti.zip').testzip() is None
(D/'SHA256SUMS.txt').write_text('\n'.join(sha(p)+'  '+p.name for p in sorted(D.iterdir()) if p.is_file() and p.name!='SHA256SUMS.txt')+'\n')
for label in ['iOS-Offline','Mac-PC']:
 names={'Meighty.html','INIZIA-QUI.txt','LEGGIMI.html','Manuale-Meighty.pdf','LICENSE-Meighty.md','LICENSE-LZFSE.txt','Sorgenti.zip','VERIFICHE.json'}
 with zipfile.ZipFile(O/('Meighty-1.01-RC3-'+label+'.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(D.rglob('*')):
   if p.is_file() and (label=='Mac-PC' or p.name in names):z.write(p,'Meighty-1.01-RC3/'+str(p.relative_to(D)))
 with zipfile.ZipFile(O/('Meighty-1.01-RC3-'+label+'.zip')) as z:
  assert z.testzip() is None
  if label=='iOS-Offline':assert not any(n.endswith(('.command','.cmd','.py')) for n in z.namelist())
A=O/'Meighty-Hosting-Statico/dist';A.mkdir(parents=True,exist_ok=True)
for name in ['Meighty.html','INIZIA-QUI.txt','LEGGIMI.html','Manuale-Meighty.pdf','LICENSE-Meighty.md','LICENSE-LZFSE.txt','Sorgenti.zip','VERIFICHE.json']:shutil.copy2(D/name,A/name)
shutil.copy2(D/'Meighty.html',A/'index.html')
for name in ['Meighty-1.01-RC3.fwsc','Meighty-1.01-RC3-iOS-Offline.zip','Meighty-1.01-RC3-Mac-PC.zip']:shutil.copy2(O/name,A/name)
(A/'README.md').write_text('# Meighty 1.01 RC3 / Suite offline 1.4\n\nApri [la suite HTTPS](https://gfcalvi.github.io/meighty-fm1/) in MIDIWeb Browser e scegli **Make Available Offline**. Poi usa la copia offline senza Mac o rete.\n\nGlobal più leggibile, Init prima di Load/Save, nomi Meighty, correzioni USB e slot, recupero parziale dei backup. Guida INIZIA-QUI aggiornata. RC2: ciclo browser Bloomy → Meighty → Bloomy e Save/Load dello slot 2 con spegnimento collaudati sul Mac. RC3 e test iPhone: vedere VERIFICHE.json. Nessun salvataggio personale incluso.\n')
(A/'.nojekyll').write_text('')
public=['index.html','Meighty.html','README.md','INIZIA-QUI.txt','LEGGIMI.html','Manuale-Meighty.pdf','LICENSE-Meighty.md','LICENSE-LZFSE.txt','Sorgenti.zip','VERIFICHE.json','Meighty-1.01-RC3.fwsc','Meighty-1.01-RC3-iOS-Offline.zip','Meighty-1.01-RC3-Mac-PC.zip']
(O/'Meighty-Hosting-Statico/PUBBLICAZIONE.json').write_text(json.dumps({'provider':'GitHub Pages','repository':'https://github.com/gfcalvi/meighty-fm1','url':'https://gfcalvi.github.io/meighty-fm1/','status':'READY_NOT_PUBLISHED','firmware':'1.01 RC3','suite':'1.4','files':{n:sha(A/n) for n in public}},indent=2)+'\n')
stages={'assets':[n for n in public if n not in ['index.html','Meighty.html','README.md','Meighty-1.01-RC3-iOS-Offline.zip','Meighty-1.01-RC3-Mac-PC.zip']],'ios':['Meighty-1.01-RC3-iOS-Offline.zip'],'mac':['Meighty-1.01-RC3-Mac-PC.zip'],'pages':['index.html','Meighty.html','README.md']}
for group,names in stages.items():
 folder=W/('publish-rc3-'+group);folder.mkdir(exist_ok=True)
 for n in names:shutil.copy2(A/n,folder/n)
 print(group,len(names),sum((A/n).stat().st_size for n in names),'bytes')
print('RC3 firmware SHA256',sha(O/'Meighty-1.01-RC3.fwsc'))
