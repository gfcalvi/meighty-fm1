# Meighty HW9 — LED dei pulsanti

HW9 conserva il motore a due core di HW8 e aggiunge il collegamento fra stato dell’interfaccia e LED del pannello. Non cambia il percorso di sintesi, la frequenza audio, le tracce o il formato dei progetti. È una nuova candidata da installare solo dopo consenso; non è ancora collaudata fisicamente.

## Comportamento

- Il pulsante della pagina corrente rimane acceso anche dopo il rilascio, comprese le sottopagine Instrument.
- Le otto pagine Song, Chain, Phrase, Instrument, Table, Global, Mixer e Master FX accendono il rispettivo pulsante fisico.
- Il catalogo Instrument accende anche APP finché è aperto.
- PLAY resta verde durante la riproduzione e si spegne a trasporto fermo.
- I pulsanti premuti ricevono feedback luminoso durante la pressione; SAVE e REC sono azioni momentanee e non diventano pagine selezionate.

Il driver della matrice e la scansione sono quelli già presenti: mancava l’aggiornamento delle maschere LED. L’aggiornamento viene effettuato nel main insieme all’interfaccia, fuori dall’interrupt audio. Non si introduce una nuova attesa nel DSP.

Test host con ASAN/UBSAN: il dispatcher reale attiva le otto pagine dai pulsanti, verifica persistenza dopo rilascio, PLAY e apertura/chiusura catalogo. Per la verifica fisica occorre ancora installare il candidato.

## Stato di partenza

HW8 è installata: utente riporta MAX 2745 µs / LATE 0 e demo abbastanza pulita. Ogni traccia in Solo suona correttamente; il sovraccarico del piccolo altoparlante nel mix è plausibile, ma non misurato. Il margine CPU osservato è circa 157 µs e non qualifica tutte le combinazioni di suoni.

## Installazione

Usare Meighty-HW9.fwsc in M-Flasher, conservando bootloader e impostazioni e attendendo scrittura/rilettura verificata. Il piano dei settori deve essere controllato sul dispositivo collegato, senza riutilizzare il numero di settori di un altro passaggio. M-Flasher crea il backup locale prima della scrittura. Non usare The Firmware Hub per questo candidato.

Dopo il riavvio passare fra le pagine e verificare che il LED segua la selezione, aprire/chiudere APP in Instrument, provare PLAY/STOP e ascoltare la demo. La diagnostica OCT−/OCT+ continua a mostrare MEIGHTY 2 CORE; raccogliere MAX/LATE se l’audio cambia.

Build: `python3 tools/Build-Meighty-HW9-Mac.py`. Per ricostruire HW8 usare i sorgenti congelati nel suo ZIP, non l’albero di lavoro aggiornato.
