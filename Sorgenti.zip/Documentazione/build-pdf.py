from pathlib import Path
import re,html
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak,Preformatted,Table,TableStyle
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'output/pdf/Manuale-Meighty-Italiano.pdf'
OUT.parent.mkdir(parents=True,exist_ok=True)
font=Path('/System/Library/Fonts/Supplemental')
for n,f in [('Body','Arial.ttf'),('Bold','Arial Bold.ttf'),('Italic','Arial Italic.ttf'),('Mono','Andale Mono.ttf')]:pdfmetrics.registerFont(TTFont(n,str(font/f)))
pdfmetrics.registerFontFamily('Body',normal='Body',bold='Bold',italic='Italic',boldItalic='Bold')
teal=colors.HexColor('#087e83');ink=colors.HexColor('#163039');muted=colors.HexColor('#536870')
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='Text',fontName='Body',fontSize=10.3,leading=15,textColor=ink,spaceAfter=7))
for name,size,lead in [('H1',22,28),('H2',15,21),('H3',12,17)]:styles.add(ParagraphStyle(name=name,fontName='Bold',fontSize=size,leading=lead,textColor=teal,spaceBefore=15,spaceAfter=9,keepWithNext=True))
styles.add(ParagraphStyle(name='CodeBlock',fontName='Mono',fontSize=8.5,leading=12,backColor=colors.HexColor('#edf6f4'),borderPadding=9,spaceBefore=6,spaceAfter=12))
styles.add(ParagraphStyle(name='Cell',fontName='Body',fontSize=9,leading=12,textColor=ink))
styles.add(ParagraphStyle(name='CellHead',parent=styles['Cell'],fontName='Bold',textColor=colors.white))
def inline(s):
 s=html.escape(s.strip()).replace('–','-').replace('—','-').replace('−','-').replace('\u2011','-')
 s=re.sub(r'`([^`]+)`',r'<font name="Mono">\1</font>',s)
 s=re.sub(r'\*\*([^*]+)\*\*',r'<b>\1</b>',s)
 s=re.sub(r'\[([^\]]+)\]\((#[^)]+)\)',r'<link href="\2" color="#087e83">\1</link>',s)
 s=re.sub(r'\[([^\]]+)\]\((https?[^)]+)\)',r'<link href="\2">\1</link>',s)
 return s
FX=set(re.findall(r'^### ([A-Z][A-Z0-9]{2}) ',(ROOT/'Documentazione/Meighty-Manuale-Italiano.md').read_text(),re.M))
class Doc(SimpleDocTemplate):
 def beforeDocument(self):
  self.heading_number=0;self.last_outline=-1
 def afterFlowable(self,f):
  if isinstance(f,Paragraph) and f.style.name in ('H1','H2','H3'):
   requested={'H1':0,'H2':1,'H3':2}[f.style.name];level=min(requested,self.last_outline+1)
   self.last_outline=level;self.heading_number+=1
   title=f.getPlainText();key='heading-'+str(self.heading_number)
   self.canv.bookmarkPage(key);self.canv.addOutlineEntry(title,key,level=level,closed=level>0)
   if requested<2 and title not in ('Manuale utente in italiano','Indice'):self.notify('TOCEntry',(requested,title,self.page,key))
   if f.style.name=='H3':
    code=title.split()[0]
    if code in FX:self.canv.bookmarkPage('fx-'+code.lower())
    elif title=='Colonna vuota':self.canv.bookmarkPage('fx-none')

def page(c,d):
 c.saveState();w,h=A4;c.setStrokeColor(teal);c.setLineWidth(.7);c.line(51,h-39,w-51,h-39);c.setFont('Body',8);c.setFillColor(muted);c.drawString(51,h-29,'MEIGHTY  /  Manuale italiano');c.drawRightString(w-51,h-29,'Meighty 1.02');c.drawString(51,28,'12 novembre 2026');c.drawRightString(w-51,28,str(d.page));c.restoreState()
story=[Spacer(1,95),Paragraph('Meighty',ParagraphStyle(name='Cover',fontName='Bold',fontSize=42,leading=48,textColor=teal)),Spacer(1,18),Paragraph('Manuale utente in italiano',styles['H1']),Paragraph('Firmware 1.02<br/>Suite per Mac/PC e iOS offline',styles['Text']),Spacer(1,25),Paragraph('Dalla prima sequenza alle combinazioni di FX: strumenti, inviluppi, tabelle, evoluzione controllata, arrangiamento e gestione dei progetti.',styles['Text']),Spacer(1,28),Paragraph('Edizione aggiornata al 12 novembre 2026.<br/>Include tre voci su una traccia, editor a blocchi, tutti i comandi FX e i quattro tools per backup e progetti.',styles['Text']),PageBreak()]
toc=TableOfContents();toc.levelStyles=[ParagraphStyle(name='T0',fontName='Bold',fontSize=11,leading=16,spaceBefore=9,textColor=teal),ParagraphStyle(name='T1',fontName='Body',fontSize=9.5,leading=14,leftIndent=14,textColor=ink)]
story += [Paragraph('Indice',styles['H1']),toc,PageBreak()]
lines=(ROOT/'Documentazione/Meighty-Manuale-Italiano.md').read_text().splitlines();i=0;first=True
while i<len(lines):
 line=lines[i].strip();i+=1
 if not line:continue
 if line.startswith('```'):
  code=[]
  while i<len(lines) and not lines[i].startswith('```'):code.append(lines[i].replace('\t','    ').replace('–','-').replace('—','-').replace('−','-').replace('\u2011','-'));i+=1
  i+=1;story.append(Preformatted('\n'.join(code),styles['CodeBlock'],maxLineLength=88));continue
 m=re.match(r'^(#{1,3})\s+(.+)',line)
 if m:
  level=len(m[1]);text=m[2]
  if level==2 and text=='Tre voci su una traccia':story.append(PageBreak())
  if level==1 and text.lower().startswith('meighty'):continue
  if level==1:
   if not first:story.append(PageBreak())
   first=False
  story.append(Paragraph(inline(text),styles['H'+str(level)]));continue
 if '|' in line and not line.startswith(('>','- ')):
  rows=[line]
  while i<len(lines):
   if not lines[i].strip():
    if i+1<len(lines) and '|' in lines[i+1] and not lines[i+1].startswith('#'):i+=1;continue
    break
   if '|' not in lines[i]:break
   rows.append(lines[i].strip());i+=1
  raw=[[s.strip() for s in r.strip('|').split('|')] for r in rows if not re.fullmatch(r'[\s|:\-]+',r)]
  n=max(map(len,raw));width=A4[0]-102;cw=[width/n]*n
  if n==2:cw=[width*.30,width*.70]
  data=[[Paragraph(inline(x),styles['CellHead' if j==0 else 'Cell']) for x in r+['']*(n-len(r))] for j,r in enumerate(raw)]
  tab=Table(data,colWidths=cw,repeatRows=1,hAlign='LEFT');tab.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),teal),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#f1f7f6'),colors.white]),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,0),(-1,-1),.3,colors.HexColor('#d8e5e3'))]));story += [tab,Spacer(1,10)];continue
 if line.startswith('- '):line='• '+line[2:]
 story.append(Paragraph(inline(line),styles['Text']))
doc=Doc(str(OUT),pagesize=A4,rightMargin=51,leftMargin=51,topMargin=55,bottomMargin=49,title='Meighty 1.02 - Manuale utente italiano',author='Meighty',allowSplitting=True)
doc.multiBuild(story,onFirstPage=page,onLaterPages=page)
print(OUT)
