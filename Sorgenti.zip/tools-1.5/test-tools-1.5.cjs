const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root=__dirname+'/..',repo=root+'/Sorgenti/fm1-tracker/';
for(const f of ['sdk/WebUpdate.js','web/installer/InstallerCore.js','toolsuite/Formats.js','toolsuite/BackupFlow.js'])vm.runInThisContext(fs.readFileSync(repo+f,'utf8'));
const C=JSON.parse(fs.readFileSync(root+'/Verifiche/RC3/config-rc3.json'));
const F=MeightyFiles,B=MeightyBackup;let cases=0;
const ok=(v,msg)=>{assert(v,msg);cases++;};
const options={cores:C.cores,decoder:F.un64(C.decoder)};
async function logic(){
 const songPath=root+'/Suoni-e-progetti/FM1-M8-Berlin-School-V2/01-Oltre-le-dune.rfm1state';
 const original=await F.read(fs.readFileSync(songPath),options);
 const converted=await F.read(fs.readFileSync('/Users/gfcalvi/Library/CloudStorage/Dropbox/Apps/M-Vave Fm-1/Meighty Backup & Song/01-Oltre-le-dune-convertito.meighty'),options);
 ok(original.slots[0].sha256===converted.slots[0].sha256,'real Oltre le dune formats agree');
 ok(F.summary(original.slots[0]).bpm===98,'real song tempo');
 for(let target=0;target<8;target++)for(const old of ['empty','valid','corrupt','timeout']){
  const slots=Array(8).fill(null);slots[target]=original.slots[0];const plan=B.plan(F.model(slots),'merge',C.empty),reads=[],writes=[];
  const api={async read(i){reads.push(i);if(i!==target)throw Error('unrelated slot must not be read');if(old==='corrupt')throw Object.assign(Error('corrupt'),{status:3});if(old==='timeout')throw Error('timeout');if(old==='empty')throw Object.assign(Error('empty'),{status:7});return F.data(C.empty);},async write(i,d){writes.push(i);F.validate(d);}};
  if(old==='corrupt'||old==='timeout'){
   await assert.rejects(()=>B.protectTargets(api,plan));ok(writes.length===0,'failed preflight never writes');continue;
  }
  const before=await B.protectTargets(api,plan);ok(reads.length===1&&reads[0]===target,'only destination backed up');
  const body={targets:before.targets,backup:F.bank(before.model)};
  const raw={format:'Meighty-backup-destinazioni',version:1,...body,sha256:F.sha(new TextEncoder().encode(JSON.stringify(body)))};
  const round=await F.read(new TextEncoder().encode(JSON.stringify(raw)));
  const undo=B.plan(round,'replace',C.empty);ok(undo.length===1&&undo[0].slot===target,'scoped backup never clears unrelated slots');
  ok(undo[0].empty===(old==='empty'),'empty destination is restorable');
  const bad=JSON.parse(JSON.stringify(raw));bad.targets[0].slot=9;await assert.rejects(()=>F.read(new TextEncoder().encode(JSON.stringify(bad))));cases++;
  await B.restore(api,plan);ok(writes.length===1&&writes[0]===target,'only selected slot written');
 }
 // Reproduce the old failure: seven unreadable slots block full backup.
 const api={async read(i){if(i===1||i===255)return F.data(C.empty);throw Object.assign(Error('corrupt'),{status:3});}};
 await assert.rejects(()=>B.backup(api,C.empty));cases++;
 const one=Array(8).fill(null);one[1]=original.slots[0];const protectedOne=await B.protectTargets(api,B.plan(F.model(one),'merge',C.empty));ok(protectedOne.targets.length===1,'same device permits targeted restore');
 return original;
}
// Small DOM adapter tests real UI event handlers and state transitions. This is
// a deterministic unit test, not a claim of Safari/MIDIWeb hardware testing.
class El{
 constructor(tag='div'){this.tagName=tag.toUpperCase();this.children=[];this.dataset={};this.hidden=false;this.disabled=false;this.checked=false;this.value='';this.files=[];this.className='';this.textContent='';this.attributes={};}
 append(...xs){this.children.push(...xs);for(const x of xs)x.parentNode=this;}
 replaceChildren(...xs){this.children=[];this.append(...xs);}
 add(x){this.append(x);if(this.children.length===1)this.value=x.value;}
 setAttribute(k,v){this.attributes[k]=String(v);if(k.startsWith('data-'))this.dataset[k.slice(5)]=v;}
 addEventListener(k,f){this['on'+k]=f;}
 scrollIntoView(){} remove(){} click(){if(!this.disabled)return this.onclick?.();}
}
async function ui(original){
 const ids={},all=[];const html=fs.readFileSync(repo+'toolsuite/Suite.html.in','utf8');
 for(const match of html.matchAll(/<(\w+)\b([^>]*\bid="([^"]+)"[^>]*)>/g)){
  const e=new El(match[1]);e.id=match[3];e.hidden=/\bhidden\b/.test(match[2]);e.className=(match[2].match(/class="([^"]+)"/)||[])[1]||'';ids[e.id]=e;all.push(e);
 }
 for(const name of ['install','backup','slots'])ids[name].className='tab';
 for(let i=0;i<3;i++){const e=new El('button');e.className='connect';all.push(e);const d=new El('button');d.className='disconnect';all.push(d);}
 const walk=e=>[e,...e.children.flatMap(walk)];
 const list=()=>all.flatMap(walk);
 const select=q=>q.split(',').flatMap(s=>{s=s.trim();if(s.startsWith('#')){const [id,tag]=s.slice(1).split(' ');return tag?walk(ids[id]).filter(e=>tag==='input[type=file]'?e.type==='file':e.tagName===tag.toUpperCase()):[ids[id]];}if(s.startsWith('.'))return list().filter(e=>e.className.split(' ').includes(s.slice(1)));if(s==='[data-tab]')return [];return [];});
 global.window=global;global.parent=global;global.addEventListener=()=>{};
 global.document={getElementById:id=>ids[id]||list().find(e=>e.id===id),querySelectorAll:select,createElement:t=>new El(t),body:new El('body')};
 Object.defineProperty(global,'navigator',{configurable:true,value:{requestMIDIAccess:async()=>({})}});global.Option=class extends El{constructor(text,value){super('option');this.textContent=text;this.value=String(value);}};
 global.FileReader=class{readAsArrayBuffer(file){file.arrayBuffer().then(x=>{this.result=x;this.onload();},()=>this.onerror());}abort(){this.onabort?.();}};
 const slots=Array(8).fill(null),reads=[],writes=[];
 FM1M8Installer.Installer=class{constructor(){this.link={};this.identity=C.hardware.product;}async connect(){} async disconnect(){this.link=null;}};
 FM1M8Installer.Projects=class{async info(){}async metadata(){return{version:'1.01',build:12};}async read(i){reads.push(i);if(i===255)return F.data(C.empty);if(i!==1)throw Object.assign(Error('corrupt'),{status:3});if(!slots[i])throw Object.assign(Error('empty'),{status:7});return slots[i];}async write(i,d){writes.push(i);slots[i]=d;}};
 global.MEIGHTY_CONFIG={...C,tab:'backup'};ids.layout.value='0';ids.singleTarget.value='1';ids.setName.value='Test';
 vm.runInThisContext(fs.readFileSync(repo+'toolsuite/UI.js','utf8'));
 ok(!ids.restoreFile.disabled,'file input enabled without device');
 ok(!document.getElementById('slotFile2').hidden&&!document.getElementById('slotFile2').disabled,'native slot picker visible and enabled');
 await ids.writeRestore.click();ok(ids.status.textContent.includes('Premi prima'),'early restore explains missing step');
 await ids.prepareRestore.click();ok(ids.status.textContent.includes('Scegli prima'),'prepare without file explains');
 const file=new File([JSON.stringify(F.bank(original))],'Oltre-le-dune.meighty');ids.restoreFile.files=[file];ids.restoreFile.onchange();
 await new Promise(r=>setImmediate(r));
 ok(ids.restoreSummary.textContent.includes('Song 1'),'real file reaches restore UI');ok(!ids.restoreFile.disabled,'busy clears after file load');
 ok(ids.restoreHint.textContent.includes('Connetti'),'connection requirement visible');
 await ids.prepareRestore.click();ok(ids.status.textContent.includes('Collega prima'),'prepare offline explains connection');
 await select('.connect')[0].click();ok(ids.restoreHint.textContent.includes('Prepara'),'connect unlocks preparation');
 await ids.prepareRestore.click();ok(ids.restorePlan.textContent.startsWith('Slot 2'),'single-song target applied');ok(reads.join(',')==='1','unrelated corrupt slots never read');
 await ids.writeRestore.click();ok(writes.length===0&&ids.status.textContent.includes('spunta'),'consent required without silent disabled button');
 ids.restoreConsent.checked=true;ids.restoreConsent.onchange();await ids.writeRestore.click();
 ok(writes.join(',')==='1'&&F.sha(slots[1])===original.slots[0].sha256,'UI restores exact original song to slot 2');
 // Composer: visible picker -> library -> direct set to restore, no file roundtrip.
 const picker=document.getElementById('slotFile3');picker.files=[file];picker.onchange();await new Promise(r=>setImmediate(r));
 ok(ids.setCount.textContent.startsWith('1 brani'),'composer assigns one chosen position');
 await ids.restoreSet.click();ok(ids.restoreSummary.textContent.includes('Slot 3: Song 1'),'composer passes set into restore');
 await ids.prepareRestore.click();ok(ids.status.textContent.includes('Slot 3 corrotto'),'bad destination clearly requests Init');ok(writes.length===1,'bad destination never written');
 ids.restoreFile.files=[new File(['not json'],'broken.meighty')];ids.restoreFile.onchange();await new Promise(r=>setImmediate(r));
 ok(ids.status.className.includes('error')&&!ids.restoreFile.disabled,'bad file displays error and unlocks picker');
}
(async()=>{const original=await logic();await ui(original);console.log('PASS',cases,'checks: real Oltre le dune, targeted backup/restore, empty/corrupt/error cases, real UI handlers with DOM adapter. Browser/iPhone hardware tests NOT performed.');})().catch(e=>{console.error(e);process.exitCode=1;});
