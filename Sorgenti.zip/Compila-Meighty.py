#!/usr/bin/env python3
from pathlib import Path
import os,sys,subprocess
base=Path(__file__).resolve().parent
tmp=base/'Temporanei';tmp.mkdir(exist_ok=True)
env=dict(os.environ,FM1_JIELI_TOOLCHAIN=str(base/'Toolchain/jieli'),FM1_JIELI_RUNNER=str(base/'Toolchain/jieli_runner.py'),TMPDIR=str(tmp))
subprocess.run([sys.executable,str(base/'Sorgenti/fm1-tracker/tools/Build-Meighty-RC4-Mac.py')],env=env,check=True)
print('Firmware generato:',base/'Sorgenti/Meighty-1.01-RC4.fwsc')
