#define main original_device_test_main
#include "../../outputs/fm1-tracker/tests/test_device.c"
#undef main
static void knob(int delta){memset(&controls,0,sizeof controls);controls.encoders[3]=delta;tracker_device_control();}
int main(void){
 memset(store_flash,255,sizeof store_flash);tracker_device_init();
 tracker_ui_select(1,0,2,0,0);assert(!tracker_ui_set(1,0,2,0,127));
 knob(1);assert(tracker_ui_get(1,0,2,0)==TR_OFF);knob(1);assert(tracker_ui_get(1,0,2,0)==TR_EMPTY);knob(-1);assert(tracker_ui_get(1,0,2,0)==TR_OFF);knob(-2);assert(tracker_ui_get(1,0,2,0)==126);
 for(int i=-300;i<=300;i++){knob(i);unsigned n=tracker_ui_get(1,0,2,0);assert(n<=127||n>=254);assert(tracker_ui_project_valid(tracker_ui_project()));}
 puts("PASS 601 real Phrase knob edits: notes 0..127/OFF/empty, project remains valid");
 static uint8_t before[TEST_FLASH_BYTES];memcpy(before,store_flash,sizeof before);
 ((TrProject *)tracker_ui_project())->phrases[0].step[2].note=132;
 assert(tracker_ui_project_save(1)==-8&&tracker_ui_state(15)==8);assert(!memcmp(before,store_flash,sizeof before));
 assert(!tracker_ui_set(1,0,2,0,60));assert(!tracker_ui_project_save(1));assert(!tracker_ui_project_load(1));
 puts("PASS reproduced hardware note 132: Save reports invalid project, no writes; corrected note saves/loads");
 uint32_t base=sizeof store_flash-4096-16*3*4096;
 for(unsigned slot=0;slot<8;slot++){
  memset(store_flash,0x5a,sizeof store_flash);memcpy(before,store_flash,sizeof before);
  assert(!tracker_ui_select(7,0,0,0,0)&&!tracker_ui_set(7,0,0,3,slot));
  assert(tracker_ui_project_save(slot)==-5);assert(tracker_ui_project_load(slot)==-3);
  assert(tracker_ui_global_action(5)==1);assert(!memcmp(before,store_flash,sizeof before));
  assert(!tracker_ui_global_action(5));unsigned lo=base+slot*24576,hi=lo+24576;
  assert(!memcmp(before,store_flash,lo)&&!memcmp(before+hi,store_flash+hi,sizeof before-hi));
  for(unsigned a=lo;a<hi;a++)assert(store_flash[a]==255);
  assert(tracker_ui_project_valid(tracker_ui_project())&&tracker_ui_project()->bpm==120);
  assert(!tracker_ui_project_save(slot)&&!tracker_ui_project_load(slot));
 }
 puts("PASS all eight foreign/dirty slots: two confirmations, exact selected-slot erase, adjacent bytes untouched, Save/Load roundtrip");
 return 0;
}
