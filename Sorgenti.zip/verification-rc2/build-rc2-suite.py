from pathlib import Path
import hashlib,json
W=Path(__file__).resolve().parent;R=W.parents[1]
fw=R/'outputs/Meighty-1.01-RC2.fwsc'
digest=hashlib.sha256(fw.read_bytes()).hexdigest()
assert json.loads((R/'outputs/fm1-tracker/build/hardware-hw11/report.json').read_text())['sha256']==digest
s=(W/'build.py').read_text().replace("dest=O/'Meighty-1.01'","dest=O/'Meighty-1.01-RC2'").replace("Meighty-1.01.fwsc","Meighty-1.01-RC2.fwsc").replace('a2698a95dfc81c6977a602fe47ee4e0ce453731f328fe230b49a32dc6af16186',digest).replace("(W/'config.json')","(W/'config-rc2.json')")
s=s.replace("template=(repo/'toolsuite/Suite.html.in').read_text()","template=(repo/'toolsuite/Suite.html.in').read_text().replace('1.01','1.01 RC2')")
s=s.replace("shell=(repo/'toolsuite/Shell.html.in').read_text()","shell=(repo/'toolsuite/Shell.html.in').read_text().replace('1.01','1.01 RC2').replace('1.3','1.4 RC2')")
exec(compile(s,str(W/'build.py'),'exec'),{'__file__':str(W/'build.py'),'__name__':'__main__'})
