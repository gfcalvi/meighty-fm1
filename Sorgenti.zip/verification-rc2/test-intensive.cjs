const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
for(const f of ['sdk/WebUpdate.js','web/installer/InstallerCore.js','toolsuite/Formats.js','toolsuite/BackupFlow.js'])vm.runInThisContext(fs.readFileSync('outputs/fm1-tracker/'+f,'utf8'));
const F=MeightyFiles,B=MeightyBackup,empty=JSON.parse(fs.readFileSync('work/meighty-101/config.json')).empty;
const data=F.data(empty);let tests=0;
(async()=>{
for(let mask=0;mask<256;mask++){
 const reads=[],api={read:async i=>{reads.push(i);if(i===255||mask&(1<<i))return data.slice();throw Object.assign(Error('Vuoto'),{status:7});}};
 const m=await B.backup(api,empty);assert.equal(m.slots.length,8);assert(m.working);assert.deepEqual(reads,[0,1,2,3,4,5,6,7,255]);
 const copy=await F.read(F.output('meighty',m).bytes);assert(copy.working);tests++;
}
for(let mask=1;mask<256;mask++){
 const reads=[],api={read:async i=>{reads.push(i);if(i!==255&&(mask&(1<<i)))throw Object.assign(Error('Corrotto'),{status:3});return data.slice();}};
 await assert.rejects(()=>B.backup(api,empty),e=>{assert.equal(e.recovery.unreadable.length,mask.toString(2).replace(/0/g,'').length);assert(e.recovery.model.working);return true;});assert.equal(reads.length,9);tests++;
}
let corrupt=data.slice();corrupt[12]=132;
await assert.rejects(()=>B.backup({read:async i=>i===255?corrupt:data},empty),e=>{assert(e.recovery.workingRaw);assert.deepEqual(F.un64(e.recovery.workingRaw.data),corrupt);assert.equal(e.recovery.model.working,null);return true;});tests++;
for(let stop=0;stop<8;stop++){
 let reads=0;await assert.rejects(()=>B.backup({read:async i=>{reads++;if(i===stop)throw Error('USB disconnected');return data;}},empty),/interrotta/);assert.equal(reads,stop+1);tests++;
}
for(let mask=0;mask<256;mask++){
 const m=F.model(Array.from({length:8},(_,i)=>mask&(1<<i)?F.project(data,i):null));
 assert.equal(B.plan(m,'replace',empty).length,8);assert.equal(B.plan(m,'merge',empty).length,mask.toString(2).replace(/0/g,'').length);tests++;
}
const plan=B.plan(F.model(Array(8).fill(null)),'replace',empty);
for(let stop=0;stop<8;stop++){const writes=[];await assert.rejects(()=>B.restore({write:async i=>{writes.push(i);if(i===stop)throw Error('write verification failed');}},plan),/verification/);assert.deepEqual(writes,Array.from({length:stop+1},(_,i)=>i));tests++;}
await assert.rejects(()=>B.restore({write:async()=>assert.fail('must not write')},[plan[0],plan[0]]),/Piano/);tests++;
/* The Hub's exact identity parser rejects HW9's binary tail. A standard
 * NUL-padded identity must be accepted; telemetry belongs on a separate command. */
const hub=fs.readFileSync('work/meighty-101/hub.html','utf8');const code=hub.match(/function parseIdentity\(pkt\) \{[\s\S]*?\n\}/)[0];
vm.runInThisContext(hub.match(/function pack7\(data\) \{[\s\S]*?\n\}/)[0]+'\n'+hub.match(/function unpack7\(s\) \{[\s\S]*?\n\}/)[0]+'\n'+code);
const identity=new Uint8Array(27);identity.set(new TextEncoder().encode('FM-1_998201'));
const frame=id=>{const p=Uint8Array.from([0,89,17,27,0,0,...id,0]);return [240,...pack7(p),247];};
const old=identity.slice();old[16]=68;old[17]=9;assert.equal(parseIdentity(frame(old)),null);assert.equal(parseIdentity(frame(identity)).text,'FM-1_998201');tests++;
console.log('PASS '+tests+' intensive cases: 256 bank combinations, 255 corrupt-slot combinations, invalid RAM preservation, USB interruptions, 256 restore layouts, write failures, duplicate targets, actual Firmware Hub identity parser');
})().catch(e=>{console.error(e);process.exitCode=1;});
