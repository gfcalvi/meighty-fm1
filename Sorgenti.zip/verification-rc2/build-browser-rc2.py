from pathlib import Path
W=Path(__file__).resolve().parent
s=(W/'build-browser-tests.py').read_text().replace("D=R/'outputs/Meighty-1.01'","D=R/'outputs/Meighty-1.01-RC2'")
s=s.replace("async read(i){if(i===255)return", "async read(i){if(window.__readErrors?.[i])throw Object.assign(Error('USB/slot read error'),{status:window.__readErrors[i]==='disconnect'?undefined:window.__readErrors[i]});if(i===255&&window.__working)return window.__working.slice();if(i===255)return")
s=s.replace("(R/'work/meighty-101/config.json')","(R/'work/meighty-101/config-rc2.json')")
# Inject additional cases into the same actual browser/DOM test script.
original=(W.parents[0]/'meighty-100/browser-tests.js').read_text()
extra=(W/'browser-extra.js').read_text()
tests=original.replace("await test('Restore: scelta file",extra+"\nawait test('Restore: scelta file")
testpath=W/'browser-tests-rc2.js';testpath.write_text(tests)
s=s.replace("(W/'browser-tests.js').read_text()",repr(str(testpath))+" and Path("+repr(str(testpath))+").read_text()")
s=s.replace('Suite offline 1.3','Suite offline 1.4 RC2')
exec(compile(s,str(W/'build-browser-tests.py'),'exec'),{'__file__':str(W/'build-browser-tests.py'),'__name__':'__main__'})
