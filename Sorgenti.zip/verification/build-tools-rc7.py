from pathlib import Path
import json,base64,hashlib,zipfile,shutil
b=Path(__file__).resolve().parent.parent;r=b/'Sorgenti/fm1-tracker';o=b/'Candidata-RC7';o.mkdir(exist_ok=True)
fw=b/'Sorgenti/Meighty-1.01-RC7.fwsc';raw=fw.read_bytes();sha=hashlib.sha256(raw).hexdigest()
build=json.loads((r/'build/hardware-hw16/report.json').read_text());assert sha==build['sha256']
c=json.loads((b/'Verifiche/RC3/config-rc3.json').read_text());c.update(version='1.01 RC7',suiteVersion='2.0');c['hardware'].update(data=base64.b64encode(raw).decode(),sha256=sha)
empty=(b/'Verifiche/empty-rc6.bin').read_bytes();c['empty'].update(data=base64.b64encode(empty).decode(),sha256=hashlib.sha256(empty).hexdigest())
t=(r/'toolsuite/SimpleSuite.html.in').read_text()
for key,path in [('SDK','sdk/WebUpdate.js'),('INSTALLER','web/installer/InstallerCore.js'),('FORMATS','toolsuite/Formats.js'),('FLOW','toolsuite/BackupFlow.js'),('SIMPLEUI','toolsuite/SimpleUI.js')]:t=t.replace('/*'+key+'*/',(r/path).read_text())
t=t.replace('/*CONFIG*/',json.dumps(c,ensure_ascii=False,separators=(',',':')))
assert '<iframe' not in t and '/*CONFIG*/' not in t
for name in ['index.html','Meighty.html']:(o/name).write_text(t)
shutil.copy2(fw,o/fw.name)
for name in ['Ritorno-RC3.html','LICENSE-Meighty.md','LICENSE-LZFSE.txt','Avvia-Meighty.cmd','Avvia-Meighty.command']:shutil.copy2(b/'Candidata-RC5'/name,o/name)
(o/'Avvia-Meighty.py').write_text((b/'Candidata-RC5/Avvia-Meighty.py').read_text().replace('RC5','RC7'))
(o/'Avvia-Meighty.command').chmod(0o755)
guide='''MEIGHTY 1.01 RC7 / HW16 — TOOLS 2.0

FIRMWARE
Entrando in Chain da Song si apre la Chain della cella scelta; SELECT sceglie la Chain della nuova traccia e il numero Cxx è visibile in alto.
SELECT nella pagina Phrase segue la nuova traccia: durante PLAY la frase in esecuzione, da fermo la posizione Song/Chain selezionata. P-- / NO PHRASE indica una posizione non assegnata; K3 permette comunque la scelta manuale dal pool.
Slot sempre pronti: Load apre, Save salva, Clear svuota con una conferma.
S1–S8 sul display indica lo slot effettivamente aperto; S-- indica un progetto non associato.
La destinazione scelta in Global è distinta dal progetto aperto. SAVE fisico salva lo slot aperto; Save slot in Global salva nella destinazione scelta.
Uno slot senza un progetto valido si apre vuoto, senza scritture. Clear salva invece un progetto vuoto persistente.

TOOLS
Carica brani: scegli file e destinazione, premi Carica su FM-1. Salvataggio, verifica e apertura sono automatici. Poi PLAY.
Backup: Scarica backup, senza passaggi preliminari. Il backup non è obbligatorio per caricare un brano.
Converti / Set: importa, estrai, converti oppure costruisci una banca con zero–otto brani; le altre posizioni restano vuote.
Le operazioni sul dispositivo aprono il collegamento quando serve. Clear e sostituzione completa della banca chiedono una conferma.
Non c’è Init, Prepara o un backup obbligatorio. I log sono chiusi nei Dettagli tecnici.
Lo slot aperto sempre visibile è una funzione del firmware, non dei tools.

INSTALLAZIONE / iPHONE
Apri https://gfcalvi.github.io/meighty-fm1/ in Chrome Mac/PC o MIDIWeb Browser su iPhone/iPad USB-C.
Pagina Firmware → Installa RC7 → conferma. Non scollegare durante la scrittura.
Su MIDIWeb aggiorna Make Available Offline dopo aver caricato la nuova pagina HTTPS: sostituisce la vecchia copia; il Mac non serve in mobilità.
La gestione diretta degli slot richiede RC7/HW16. Il ritorno alla RC3 rimane in Ritorno-RC3.html.
Nel pacchetto iOS non servono launcher .command. Sul Mac il launcher richiede Python3; il sito HTTPS evita il launcher.

VERIFICHE E LIMITI
259 controlli client reale/dispatcher C su NOR simulata, inclusi tutti gli slot, riavvio, dati estranei e scritture interrotte. 95 controlli dei nuovi handler dei tools collegati allo stesso dispatcher.
Regressioni native editor/DSP, loader e OTA superate. I nuovi tools non sono ancora collaudati fisicamente su iPhone/Mac; il test hardware degli slot 2–8 resta da confermare.
Il manuale italiano completo aggiornato è incluso come Markdown. Nessuna nuova prova audio fisica è dichiarata.
'''
(o/'INIZIA-QUI.txt').write_text(guide)
(o/'README.md').write_text('# Meighty 1.01 RC7 / Tools 2.0\n\n'+guide)
import html
(o/'LEGGIMI.html').write_text('<!doctype html><meta charset="utf-8"><title>Meighty RC7</title><style>body{max-width:850px;margin:35px auto;padding:20px;font:17px/1.6 system-ui;background:#071e20;color:#edf9f6}pre{white-space:pre-wrap;font:inherit}a{color:#70dfd0}</style><a href="Meighty.html">Apri Meighty</a><pre>'+html.escape(guide)+'</pre>')
shutil.copy2(b/'Documentazione/Meighty-Manuale-Italiano.md',o/'Manuale-Meighty.md')
report={'firmware':'1.01 RC7','hardware':16,'suite':'2.0','sha256':sha,'native_client_checks':259,'ui_handler_checks':95,'regressions':'editor/DSP, loader and OTA pass','hardware_browser_validation':'pending; CoreMIDI client unavailable (-10833); no physical writes during these tests','loaded_slot_indicator':'firmware only','code_headroom_bytes':0x86ee0-build['image_bytes'],'navigation_regression':'all eight tracks, Song/Chain context, live follow, empty edit guard and Oltre LEV reproduction pass','inherited_slot_checks':'RC6 client/handler suites; no slot backend changes in RC7'}
(o/'VERIFICHE.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
for name in ['editor-rc7.log','direct-slots.log','simple-tools.log','loader-rc7.log','ota-rc7.log','phrase-navigation.log']:shutil.copy2(b/'Verifiche'/name,o/name)
with zipfile.ZipFile(o/'Sorgenti.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(r.rglob('*')):
  rel=p.relative_to(r)
  if p.is_file() and not any(x in rel.parts for x in ['build','.git','__pycache__']) and p.name!='.DS_Store':z.write(p,'fm1-tracker/'+str(rel))
 for name in ['test-direct-slots.cjs','test-simple-tools.cjs','build-tools-rc7.py']:z.write(b/'Verifiche'/name,'verification/'+name)
common=['Meighty.html','LEGGIMI.html','INIZIA-QUI.txt','Manuale-Meighty.md','LICENSE-Meighty.md','LICENSE-LZFSE.txt','VERIFICHE.json','Ritorno-RC3.html']
for label in ['iOS-Offline','Mac-PC']:
 with zipfile.ZipFile(o/('Meighty-1.01-RC7-'+label+'.zip'),'w',zipfile.ZIP_DEFLATED) as z:
  for name in common+([] if label=='iOS-Offline' else ['Avvia-Meighty.py','Avvia-Meighty.command','Avvia-Meighty.cmd',fw.name]):z.write(o/name,'Meighty/'+name)
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(o.iterdir()) if p.is_file() and p.name!='SHA256SUMS.txt'}
(o/'SHA256SUMS.txt').write_text(''.join(v+'  '+k+'\n' for k,v in hashes.items()))
print(json.dumps({'folder':str(o),'firmware_sha256':sha,'files':len(hashes),'page_bytes':len(t.encode())}))
