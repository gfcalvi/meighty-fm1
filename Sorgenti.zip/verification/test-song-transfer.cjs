const fs=require('fs'),vm=require('vm'),assert=require('assert'),{spawn}=require('child_process'),readline=require('readline');
const root=__dirname+'/..',repo=root+'/Sorgenti/fm1-tracker/';
for(const f of ['sdk/WebUpdate.js','web/installer/InstallerCore.js','toolsuite/Formats.js','toolsuite/BackupFlow.js'])vm.runInThisContext(fs.readFileSync(repo+f,'utf8'));
const F=MeightyFiles,B=MeightyBackup,C=JSON.parse(fs.readFileSync(root+'/Verifiche/RC3/config-rc3.json'));
const child=spawn(root+'/Verifiche/project-bridge',[],{stdio:['pipe','pipe','pipe']}),pending=[];let stderr='';
child.stderr.on('data',b=>stderr+=b);readline.createInterface({input:child.stdout}).on('line',s=>{const p=pending.shift();if(!p)throw Error('unsolicited bridge response');p.resolve(Uint8Array.from(Buffer.from(s,'hex')));});
child.on('exit',code=>{for(const p of pending)p.reject(Error('Bridge exited '+code+' '+stderr));});
const link={query(command,data=[]){return new Promise((resolve,reject)=>{pending.push({resolve,reject});child.stdin.write(Buffer.from([command,...data]).toString('hex')+'\n');});}};
const api=new FM1M8Installer.Projects(link);
(async()=>{
 const meta=await api.metadata();assert.equal(meta.build,14);console.log('Native metadata',meta);
 for(const [slug,bpm] of [['01-Oltre-le-dune',98],['02-Orbite-profonde',82]]){
  const m=await F.read(fs.readFileSync('/Users/gfcalvi/Library/CloudStorage/Dropbox/Apps/M-Vave Fm-1/Meighty Backup & Song/'+slug+'-convertito.meighty'));
  const p=m.slots.find(Boolean),original=await F.read(fs.readFileSync(root+'/Suoni-e-progetti/FM1-M8-Berlin-School-V2/'+slug+'.rfm1state'),{cores:C.cores,decoder:F.un64(C.decoder)});
  assert.equal(p.sha256,original.slots[0].sha256);assert.equal(F.summary(p).bpm,bpm);
  for(let slot=0;slot<8;slot++){
   await link.query(0xfe);const before=await api.read(255),slots=Array(8).fill(null);slots[slot]=p;
   const plan=B.plan(F.model(slots),'merge',C.empty),backup=await B.protectTargets(api,plan);assert(backup.targets[0].empty);
   const result=await B.restore(api,plan);assert.equal(result[0].sha256,p.sha256);
   assert.equal(F.sha(await api.read(slot)),p.sha256);
   // Reproduce the reported confusion with the old storage-only workflow.
   assert.equal(F.sha(await api.read(255)),F.sha(before),'writing storage alone must not change RAM');
   await api.activate(slot,p.sha256);assert.equal(F.sha(await api.read(255)),p.sha256);
   assert.equal(F.summary(F.project(await api.read(255))).bpm,bpm);
   const retained=await B.protectTargets(api,plan);assert.equal(retained.model.slots[slot].sha256,p.sha256);
   // A second write exercises the alternate generation, then activation again.
   const d=F.data(p);d[9266]=137;d[9267]=0;const changed=F.project(d,slot,p.name);
   plan[0].project=changed;await B.restore(api,plan);await api.activate(slot,changed.sha256);
   assert.equal(F.sha(await api.read(255)),changed.sha256);
  }
  console.log('PASS real song',slug,': all 8 slots, USB chunks/CRC, native NOR generations, exact readback, old RAM unchanged before activation, new RAM verified after activation');
 }
 await link.query(0xfe);const ram=F.sha(await api.read(255));await assert.rejects(()=>api.activate(8));assert.equal(F.sha(await api.read(255)),ram);
 const raw=await link.query(0x68,[8]);assert.equal(raw[0],9);assert.equal(F.sha(await api.read(255)),ram);
 console.log('PASS real JavaScript Projects client -> native firmware dispatcher: both songs and all slots. Simulated device only; no physical FM-1 accessed.');
 child.stdin.end();
})().catch(e=>{console.error(e,stderr);child.kill();process.exitCode=1;});
