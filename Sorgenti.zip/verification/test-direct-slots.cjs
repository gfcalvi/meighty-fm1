const fs=require('fs'),vm=require('vm'),assert=require('assert'),{spawn}=require('child_process'),readline=require('readline');
const root=__dirname+'/..',repo=root+'/Sorgenti/fm1-tracker/';
for(const f of ['sdk/WebUpdate.js','web/installer/InstallerCore.js','toolsuite/Formats.js','toolsuite/BackupFlow.js'])vm.runInThisContext(fs.readFileSync(repo+f,'utf8'));
const F=MeightyFiles,child=spawn(root+'/Verifiche/project-bridge-rc6',[],{stdio:['pipe','pipe','pipe']}),pending=[];let errors='',checks=0;
child.stderr.on('data',b=>errors+=b);readline.createInterface({input:child.stdout}).on('line',s=>{const p=pending.shift();if(!p)throw Error('Unexpected response');p.resolve(Uint8Array.from(Buffer.from(s,'hex')));});child.on('exit',code=>{for(const p of pending)p.reject(Error('Native bridge '+code+' '+errors));});
const link={query(cmd,data=[]){return new Promise((resolve,reject)=>{pending.push({resolve,reject});child.stdin.write(Buffer.from([cmd,...data]).toString('hex')+'\n');});}},api=new FM1M8Installer.Projects(link),eq=(a,b,m)=>{assert.deepStrictEqual(a,b,m);checks++;};
const songs=['01-Oltre-le-dune','02-Orbite-profonde'].map(n=>({name:n,data:new Uint8Array(fs.readFileSync(root+'/Suoni-e-progetti/FM1-M8-Berlin-School-V2/'+n+'.project.bin'))}));
(async()=>{
 eq((await api.metadata()).build,15);
 for(const [label,reset] of [['erased',0xfe],['foreign bytes / no Init',0xfd]]){
  await link.query(reset);const protectedBefore=Buffer.from(await link.query(0xf8)).toString('hex'),emptyBefore=Buffer.from(await link.query(0xf9)).toString('hex');
  for(let n=0;n<8;n++){await assert.rejects(()=>api.read(n),e=>e.status===7);const ram=await api.activate(n);assert(F.validate(ram));eq((await api.state()).loaded,n);}
  eq(Buffer.from(await link.query(0xf9)).toString('hex'),emptyBefore,'opening a logical empty slot never erases');
  // One machine, all slots populated consecutively, including slots 2–8.
  const expected=songs.map(s=>F.sha(s.data));let loaded=7;
  for(let n=0;n<8;n++){const s=songs[n%2],back=await api.write(n,s.data);eq(F.sha(back),expected[n%2]);eq((await api.state()).loaded,loaded,'storage write must not claim to be opened');await api.activate(n,expected[n%2]);loaded=n;eq((await api.state()).loaded,n);eq(F.sha(await api.read(255)),expected[n%2]);}
  await link.query(0xfa);eq((await api.state()).loaded,0);eq(F.sha(await api.read(255)),expected[0]);
  for(let n=0;n<8;n++){eq(F.sha(await api.read(n)),expected[n%2]);await api.activate(n,expected[n%2]);eq((await api.state()).loaded,n);}
  // This second generation erases a foreign alternate bank, not a blank fixture.
  for(let n=0;n<8;n++){const d=songs[n%2].data.slice();d[9266]=130+n;d[9267]=0;await api.write(n,d);eq(F.sha(await api.read(n)),F.sha(d));}
  // Interrupted writes retain the preceding generation in every slot.
  for(let n=0;n<8;n++){const before=F.sha(await api.read(n));for(let fail=0;fail<6;fail++){await link.query(0xfc,[fail]);await assert.rejects(()=>api.write(n,songs[(n+1)%2].data));await link.query(0xfc);eq(F.sha(await api.read(n)),before,'failed generation preserves previous song');}}
  await api.activate(7);const ramBefore=F.sha(await api.read(255));await api.clear(1);eq((await api.state()).loaded,7);eq(F.sha(await api.read(255)),ramBefore,'clearing another slot does not replace the open project');
  const empty=await api.read(1);eq(F.summary(F.project(empty)).bpm,120);fs.writeFileSync(root+'/Verifiche/empty-rc6.bin',empty);
  await api.activate(1);eq((await api.state()).loaded,1);eq(F.sha(await api.read(255)),F.sha(empty));
  await api.save(5);eq((await api.state()).loaded,5);eq(F.sha(await api.read(5)),F.sha(await api.read(255)));
  await api.write(5,songs[0].data);await api.activate(5);await api.clear(5,F.sha(empty));eq((await api.state()).loaded,5);eq(F.sha(await api.read(255)),F.sha(empty));
  eq(Buffer.from(await link.query(0xf8)).toString('hex'),protectedBefore,'bytes outside eight slot banks preserved');
  console.log('PASS',label,': consecutive slots1–8, reboot, alternate bank, 48 interrupted writes, exact data, Load/Save/Clear, active/inactive clear, protected data');
 }
 await link.query(0xfd);await api.write(0,songs[0].data);await api.write(0,songs[1].data);await link.query(0xf7,[0,1]);eq(F.sha(await api.read(0)),F.sha(songs[0].data),'bad newest CRC falls back to preceding generation');await api.activate(0);const repair=songs[0].data.slice();repair[9266]=143;await api.write(0,repair);eq(F.sha(await api.read(0)),F.sha(repair),'save repairs alternate generation without init');
 await api.write(1,songs[1].data);await link.query(0xf7,[1,0]);await assert.rejects(()=>api.read(1),e=>e.status===7);const untouched=Buffer.from(await link.query(0xf9)).toString('hex');await api.activate(1);eq(F.summary(F.project(await api.read(255))).bpm,120);eq(Buffer.from(await link.query(0xf9)).toString('hex'),untouched,'unreadable generation opens logically empty without erasing');await api.save(1);eq(F.sha(await api.read(1)),F.sha(await api.read(255)),'save makes unavailable legacy slot usable directly');
 const before=Buffer.from(await link.query(0xf9)).toString('hex');eq((await link.query(0x69,[0,0]))[0],9);eq((await link.query(0x69,[8,0xa5]))[0],9);eq(Buffer.from(await link.query(0xf9)).toString('hex'),before,'clear without correct confirmation marker cannot erase');
 console.log('PASS',checks,'assertions using real JS client and native C dispatcher; simulated NOR only.');child.stdin.end();
})().catch(e=>{console.error(e,errors);child.kill();process.exitCode=1;});
