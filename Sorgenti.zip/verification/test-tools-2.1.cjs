const fs=require('fs'),vm=require('vm'),assert=require('assert'),{spawn}=require('child_process'),readline=require('readline');
const root=__dirname+'/..',repo=root+'/Sorgenti/fm1-tracker/';
for(const f of ['sdk/WebUpdate.js','web/installer/InstallerCore.js','toolsuite/Formats.js','toolsuite/BackupFlow.js'])vm.runInThisContext(fs.readFileSync(repo+f,'utf8'));
const F=MeightyFiles,C=JSON.parse(fs.readFileSync(root+'/Verifiche/RC3/config-rc3.json'));C.empty=F.project(fs.readFileSync(root+'/Verifiche/empty-rc6.bin'));C.version='1.01 RC7';
const child=spawn(root+'/Verifiche/project-bridge-rc6',[],{stdio:['pipe','pipe','pipe']}),pending=[];let errors='',checks=0,connects=0;
child.stderr.on('data',b=>errors+=b);readline.createInterface({input:child.stdout}).on('line',s=>{const p=pending.shift();if(!p)throw Error('Unexpected response');p.resolve(Uint8Array.from(Buffer.from(s,'hex')));});child.on('exit',code=>{for(const p of pending)p.reject(Error('Bridge '+code+' '+errors));});
const writes=[],clears=[];const link={lost:false,query(cmd,data=[]){if(cmd===0x63)writes.push(data[0]);if(cmd===0x69)clears.push(data[0]);return new Promise((resolve,reject)=>{pending.push({resolve,reject});child.stdin.write(Buffer.from([cmd,...data]).toString('hex')+'\n');});}},api=new FM1M8Installer.Projects(link);
const ok=(v,m)=>{assert(v,m);checks++;},eq=(a,b,m)=>{assert.deepStrictEqual(a,b,m);checks++;};
class El{constructor(tag){this.tagName=tag.toUpperCase();this.children=[];this.dataset={};this.hidden=false;this.disabled=false;this.checked=false;this.value='';this.files=[];this.className='';this.textContent='';this.attributes={};}append(...a){this.children.push(...a);}replaceChildren(...a){this.children=[];this.value='';this.append(...a);}add(x){this.append(x);if(this.children.length===1)this.value=x.value;}setAttribute(k,v){this.attributes[k]=v;if(k.startsWith('data-'))this.dataset[k.slice(5)]=v;}scrollIntoView(){}remove(){}click(){if(!this.disabled)return this.onclick?.();}}
const ids={},roots=[],html=fs.readFileSync(repo+'toolsuite/SimpleSuite.html.in','utf8');
for(const m of html.matchAll(/<(\w+)\b([^>]*\bid="([^"]+)"[^>]*)>/g)){const e=new El(m[1]);e.id=m[3];e.hidden=/\bhidden\b/.test(m[2]);e.className=(m[2].match(/class="([^"]+)"/)||[])[1]||'';ids[e.id]=e;roots.push(e);}
for(const name of ['songs','backup','files','install']){ids[name].className='page';const e=new El('button');e.dataset.page=name;roots.push(e);}
const walk=e=>[e,...e.children.flatMap(walk)],list=()=>roots.flatMap(walk),downloads=[],blobs=new Map();let serial=0;
global.window=global;global.parent=global;global.addEventListener=()=>{};
global.document={getElementById:id=>ids[id]||list().find(x=>x.id===id),querySelectorAll:q=>q==='[data-page]'?list().filter(x=>x.dataset.page):q==='.page'?Object.values(ids).filter(x=>x.className==='page'):q==='button,input,select'?list().filter(x=>['BUTTON','INPUT','SELECT'].includes(x.tagName)):[],createElement:tag=>{const e=new El(tag);if(tag==='a')e.click=()=>downloads.push({name:e.download,blob:blobs.get(e.href)});return e;},body:new El('body')};
Object.defineProperty(global,'navigator',{configurable:true,value:{requestMIDIAccess:async()=>({})}});
global.Option=class extends El{constructor(text,value){super('option');this.textContent=text;this.value=String(value);}};
global.FileReader=class{readAsArrayBuffer(file){file.arrayBuffer().then(x=>{this.result=x;this.onload();},()=>this.onerror());}abort(){this.onabort?.();}};
URL.createObjectURL=b=>{const u='blob:test-'+serial++;blobs.set(u,b);return u;};URL.revokeObjectURL=u=>blobs.delete(u);
const originalTimeout=setTimeout;global.setTimeout=(fn,n,...a)=>originalTimeout(fn,n,...a).unref();
FM1M8Installer.Installer=class{constructor(){this.link=link;this.identity=C.hardware.product;}async connect(){connects++;link.lost=false;}async install(){throw Error('No physical install in tests');}};
global.MEIGHTY_CONFIG=C;ids.layout.value='0';ids.convertFormat.value='meighty';ids.setName.value='Test set';
vm.runInThisContext(fs.readFileSync(repo+'toolsuite/SimpleUI.js','utf8'));
const file=n=>new File([fs.readFileSync('/Users/gfcalvi/Library/CloudStorage/Dropbox/Apps/M-Vave Fm-1/Meighty Backup & Song/'+n+'-convertito.meighty')],n+'.meighty');
async function choose(id,f){document.getElementById(id).files=[f];await document.getElementById(id).onchange();}
async function downloaded(){return F.read(new Uint8Array(await downloads.at(-1).blob.arrayBuffer()),{cores:C.cores,decoder:F.un64(C.decoder)});}
async function zipEntries(){const b=new Uint8Array(await downloads.at(-1).blob.arrayBuffer()),v=new DataView(b.buffer),out={};let at=0;while(v.getUint32(at,true)===0x04034b50){const size=v.getUint32(at+18,true),nl=v.getUint16(at+26,true),extra=v.getUint16(at+28,true),name=new TextDecoder().decode(b.subarray(at+30,at+30+nl)),start=at+30+nl+extra,data=b.slice(start,start+size);eq(F.crc(data),v.getUint32(at+14,true),'ZIP entry CRC');out[name]=data;at=start+size;}return out;}
(async()=>{
 await link.query(0xfd);
 const order=Array.from(html.matchAll(/data-page="([^"]+)"/g),m=>m[1]);eq(order,['install','backup','files','songs'],'four requested tabs');
 for(const id of ['openSlot','saveSlot','clearSlot','deviceSlot','prepareRestore','bankMode','songFile'])ok(!ids[id],'removed redundant control '+id);
 ok(!ids.technical.open,'technical log collapsed');await ids.loadSet.click();ok(ids.status.className.includes('error')&&connects===0,'empty selection never connects or writes');
 const files=[file('01-Oltre-le-dune'),file('02-Orbite-profonde')],models=await Promise.all(files.map(async f=>F.read(new Uint8Array(await f.arrayBuffer())))),hashes=models.map(m=>m.slots[0].sha256),expected=[];
 // Same page handlers and native file inputs, every destination individually.
 for(let n=0;n<8;n++){await ids.clearSet.click();await choose('setFile'+n,files[n%2]);const at=writes.length;await ids.loadSet.click();eq(writes.slice(at),[n],'only requested destination written');eq(F.sha(await api.read(n)),hashes[n%2]);eq((await api.state()).loaded,n);ok(ids.status.textContent.includes('Caricati slot '+(n+1)),'success names actual destination');ok(ids.confirmBox.hidden,'no extra confirmation sequence');expected[n]=hashes[n%2];}
 eq(connects,1);eq(downloads.length,0,'no mandatory backup');eq(clears,[],'no automatic Clear');
 // A single song in slot2 leaves all seven occupied neighbors byte-identical.
 await ids.clearSet.click();await choose('setFile1',files[0]);const at=writes.length;await ids.loadSet.click();expected[1]=hashes[0];eq(writes.slice(at),[1]);for(let n=0;n<8;n++)eq(F.sha(await api.read(n)),expected[n],'slot2-only neighbor preservation');
 // Backup, single song and sparse set use exactly the same destination grid.
 const slots=Array(8).fill(null);slots[1]=models[1].slots[0];slots[6]=models[0].slots[0];const bankFile=new File([JSON.stringify(F.bank(F.model(slots)))],'sparse.meighty');
 await choose('restoreFiles',bankFile);ok(ids.setCount.textContent.startsWith('2 slot'));const start=writes.length;await ids.loadSet.click();eq(writes.slice(start),[1,6]);expected[1]=hashes[1];expected[6]=hashes[0];for(let n=0;n<8;n++)eq(F.sha(await api.read(n)),expected[n],'null slots bypassed');eq(clears,[]);
 await ids.exportSet.click();let set=await downloaded();eq(set.slots.filter(Boolean).length,2);eq(set.slots[1].sha256,hashes[1]);eq(set.slots[6].sha256,hashes[0]);
 await ids.backupBank.click();const backup=await downloaded();eq(backup.slots.filter(Boolean).length,8);ok(!!backup.working);eq(backup.slots.map(x=>x.sha256),expected);
 // Extraction and conversion are independent of the restore selection.
 const count=ids.setCount.textContent;await choose('sourceFiles',bankFile);eq(ids.setCount.textContent,count);await ids.extractAll.click();const extracted=await zipEntries(),index=JSON.parse(new TextDecoder().decode(extracted['Indice-slot.json']));eq(index.length,8);eq(index.filter(x=>x.file).length,2);eq(ids.sourceSlots.children.length,8);
 const withRAM=new File([JSON.stringify(F.bank(backup))],'with-ram.meighty');await choose('convertFile',withRAM);ids.convertFormat.value='state';await ids.convert.click();const converted=await zipEntries();ok(Object.keys(converted).some(n=>n.endsWith('.rfm1state')));eq(JSON.parse(new TextDecoder().decode(converted['Progetto-in-lavorazione.fm1tracker.json'])).sha256,backup.working.sha256);eq(ids.setCount.textContent,count);
 await choose('convertFile',files[0]);ids.convertFormat.value='legacy';await ids.convert.click();eq((await downloaded()).slots[0].sha256,hashes[0]);
 await choose('convertFile',new File(['bad'],'bad.meighty'));const dl=downloads.length;await ids.convert.click();eq(downloads.length,dl,'bad conversion cannot reuse preceding file');ok(ids.status.className.includes('error'));
 // Error/retry retains the requested selection but does not falsely open it.
 await ids.clearSet.click();await choose('setFile4',files[1]);const ram=F.sha(await api.read(255));await link.query(0xfc,[0]);await ids.loadSet.click();await link.query(0xfc);ok(ids.status.className.includes('error'));eq(F.sha(await api.read(255)),ram);await ids.loadSet.click();expected[4]=hashes[1];eq((await api.state()).loaded,4);
 // Invalid replacement clears that local choice, never sends the stale song.
 await choose('setFile4',new File(['broken'],'broken.meighty'));const wc=writes.length;await ids.loadSet.click();eq(writes.length,wc);ok(ids.status.className.includes('error'));
 await choose('restoreFiles',files[0]);ok(ids.setCount.textContent.startsWith('1 slot'));await choose('restoreFiles',new File(['bad'],'broken.meighty'));await ids.loadSet.click();eq(writes.length,wc,'invalid bank cannot reuse old selection');
 // Multi-file import fills two positions; excess files commit no hidden state.
 ids.restoreFiles.files=files;await ids.restoreFiles.onchange();ok(ids.setCount.textContent.startsWith('2 slot'));ids.restoreFiles.files=Array(9).fill(files[0]);await ids.restoreFiles.onchange();ok(ids.status.className.includes('error'));await ids.loadSet.click();eq(writes.length,wc,'oversized import is atomic');
 // A full backup restores eight populated slots without Clear or initialization.
 await choose('restoreFiles',withRAM);const full=writes.length;await ids.loadSet.click();eq(writes.slice(full),[0,1,2,3,4,5,6,7]);eq(clears,[]);eq((await api.state()).loaded,0);for(let n=0;n<8;n++)eq(F.sha(await api.read(n)),backup.slots[n].sha256);
 ok(!ids.technical.open);console.log('PASS',checks,'checks: requested four tabs, no slot-management block, real UI -> Projects client -> native C; slots1–8, sparse slot2/7 preserve neighbors, null slots never clear, full backup, extraction, independent conversion, error/retry/invalid file/atomic excess import. Browser/physical USB not tested.');child.stdin.end();
})().catch(e=>{console.error(e,errors,ids.status.textContent);child.kill();process.exitCode=1;});
