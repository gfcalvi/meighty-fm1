from pathlib import Path
import json, base64, hashlib, shutil, html, re, zipfile

ROOT = Path(__file__).resolve().parents[2]
SRC = Path(__file__).parent
OUT = ROOT / 'Release-1.02'
OUT.mkdir(exist_ok=True)
firmware = ROOT / 'Sorgenti/Meighty-1.02.fwsc'
assert hashlib.sha256(firmware.read_bytes()).hexdigest() == '488b293b084de05563e439ac91b756b80dc3192fddf6421e1578430f5681d9f5'
config = json.loads((SRC / 'config.json').read_text())
config['hardware']['data'] = base64.b64encode(firmware.read_bytes()).decode()
page = (SRC / 'SimpleSuite.html.in').read_text()
for token, filename in [('SDK','WebUpdate.js'), ('INSTALLER','InstallerCore.js'), ('FORMATS','Formats.js'), ('FLOW','BackupFlow.js'), ('SIMPLEUI','SimpleUI.js')]:
    page = page.replace('/*'+token+'*/', (SRC/filename).read_text().replace('</script', '<\\/script'))
page = page.replace('/*CONFIG*/', json.dumps(config, separators=(',', ':')))
for filename in ['index.html', 'Meighty.html']:
    (OUT/filename).write_text(page)
shutil.copy2(firmware, OUT/firmware.name)
shutil.copy2(ROOT/'output/pdf/Manuale-Meighty-Italiano.pdf', OUT/'Manuale-Meighty.pdf')
shutil.copy2(OUT/'Manuale-Meighty.pdf', ROOT/'Documentazione/Meighty-Manuale-Italiano.pdf')
manual = (ROOT/'Documentazione/Meighty-Manuale-Italiano.md').read_text()
(OUT/'Manuale-Meighty.md').write_text(manual)

def inline(text):
    text = html.escape(text)
    text = re.sub(r'\*\*(.*?)\*\*', r'<strong>\1</strong>', text)
    text = re.sub(r'`([^`]+)`', r'<code>\1</code>', text)
    return re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="\2">\1</a>', text)

parts = []; code = False; table = False
for line in manual.splitlines():
    if line.startswith('```'):
        if table: parts.append('</table>'); table = False
        parts.append('</pre>' if code else '<pre>'); code = not code
        continue
    if code: parts.append(html.escape(line)); continue
    if line.startswith('|'):
        if re.match(r'^\|[ :|\-]+$', line): continue
        if not table: parts.append('<table>'); table = True
        parts.append('<tr>'+''.join('<td>'+inline(x.strip())+'</td>' for x in line.strip('|').split('|'))+'</tr>')
        continue
    if table: parts.append('</table>'); table = False
    match = re.match(r'^(#{1,6}) (.*)', line)
    if match:
        n = len(match[1]); title = match[2]
        fx = re.match(r'^([A-Z0-9]{3}) ', title) if n == 3 else None
        anchor = 'fx-'+fx[1].lower() if fx else ('fx-none' if title == 'Colonna vuota' else re.sub(r'[^a-z0-9-]', '', title.lower().replace(' ', '-')))
        parts.append(f'<h{n} id="{anchor}">'+inline(title)+f'</h{n}>')
    elif line.strip(): parts.append('<p>'+inline(line)+'</p>')
style = 'body{max-width:960px;margin:auto;padding:24px;font:17px/1.6 system-ui;color:#173639;background:#f7fcfb}h1,h2,h3{color:#087e83}table{border-collapse:collapse;width:100%;font-size:14px}td{border:1px solid #c5d9d7;padding:8px}tr:nth-child(odd){background:#e9f4f2}pre{white-space:pre-wrap;background:#e9f4f2;padding:16px;font-size:14px}a{color:#087e83}'
(OUT/'Manuale-Meighty.html').write_text('<!doctype html><html lang="it"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Manuale Meighty 1.02</title><style>'+style+'</style><a href="index.html">Strumenti Meighty</a>'+ '\n'.join(parts)+'</html>')
guide = '''Meighty 1.02

Apri https://gfcalvi.github.io/meighty-fm1/

iPhone/iPad: usa MIDIWeb Browser, scegli Make Available Offline e collega FM-1 via USB. Dopo la preparazione non servono rete, Mac o Wi-Fi. Scarica separatamente il manuale PDF in File.

Mac/PC: apri lo stesso indirizzo in Chrome o Edge e collega FM-1 via USB.

Firmware installa Meighty. Backup ed estrazione conserva gli otto slot e permette di estrarre i brani. Conversione lavora sui file senza collegamento. Ripristino / Caricamento scrive soltanto gli slot selezionati e apre il primo trasferito; gli altri restano invariati.

Sul dispositivo, Global sceglie lo slot destinazione; Load apre, Save salva, Clear azzera con conferma. Lo slot effettivamente aperto resta indicato sul display. Un Load da slot vuoto apre un progetto nuovo.

Per la polifonia scegli Global → Poly 3 track. Il manuale contiene comandi, esempi e limiti.
'''
for filename in ['INIZIA-QUI.txt', 'README.md']: (OUT/filename).write_text(guide)
(OUT/'LEGGIMI.html').write_text('<!doctype html><html lang="it"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Meighty 1.02 — Guida</title><style>'+style+'</style><a href="index.html">Apri gli strumenti</a><pre>'+html.escape(guide)+'</pre></html>')
archive = ROOT/'Archivio/Prima-della-release/Pacchetti/Candidata-Poly3-A13'
for path in archive.glob('LICENSE*'): shutil.copy2(path, OUT/path.name)
demo = json.loads((archive/'Poly3-Pad-one-track.meighty').read_text())
for item in demo.get('slots', []):
    if item: item['name'] = 'Pad su una traccia'
if demo.get('working'): demo['working']['name'] = 'Pad su una traccia'
(OUT/'Pad-una-traccia.meighty').write_text(json.dumps(demo, ensure_ascii=False, indent=2))
with zipfile.ZipFile(OUT/'Sorgenti.zip', 'w', zipfile.ZIP_DEFLATED) as target:
    for folder in [ROOT/'Sorgenti/meighty-1.02', SRC]:
        for path in folder.rglob('*'):
            rel = path.relative_to(folder)
            if not path.is_file() or any(x in rel.parts for x in ['.git', '__pycache__', 'node_modules']): continue
            if 'build' in rel.parts and str(rel) != 'build/loader-hw1/ota.bin': continue
            target.write(path, 'Sorgenti/'+folder.name+'/'+str(rel))
    for path in [ROOT/'Documentazione/Meighty-Manuale-Italiano.md', ROOT/'Documentazione/build-pdf.py']:
        target.write(path, 'Documentazione/'+path.name)
common = [p for p in OUT.iterdir() if p.is_file() and p.suffix != '.zip' and p.name != 'SHA256SUMS.txt'] + [OUT/'Sorgenti.zip']
for platform in ['iOS-Offline', 'Mac-PC']:
    with zipfile.ZipFile(OUT/f'Meighty-1.02-{platform}.zip', 'w', zipfile.ZIP_DEFLATED) as target:
        for path in common: target.write(path, path.name)
(OUT/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in sorted(OUT.iterdir()) if p.is_file() and p.name != 'SHA256SUMS.txt'))
print('Release prepared:', OUT)
