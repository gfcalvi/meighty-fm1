/* SPDX-License-Identifier: GPL-3.0-only WITH GPL-3.0-linking-exception */
#include "tracker.h"
#include <string.h>
#ifdef FM1_AUDIO_PROFILE
#include "fm1_time.h"
extern volatile unsigned tr_profile_active;
extern uint32_t tr_profile_ticks[12];
#define PROF_BEGIN(n) uint32_t n=tr_profile_active?fm1_ticks():0
#define PROF_END(n,k) do{if(tr_profile_active)tr_profile_ticks[k]+=fm1_ticks()-(n);}while(0)
#else
#define PROF_BEGIN(n)
#define PROF_END(n,k)
#endif
#include "tables.inc"
/* Experiment: let the compiler inline internal audio helpers while keeping
 * every outlined helper in RAM. Public SDK entry points retain their ABI. */
#if defined(FM1_COMPACT_DSP) && !defined(FM1_HOST_TEST)
#define TR_AUDIO_LOCAL __attribute__((section(".volatile_ram_code")))
#else
#define TR_AUDIO_LOCAL FM1_AUDIO_CODE
#endif
_Static_assert(sizeof(TrStep)==6,"compact step");
_Static_assert(sizeof(TrTableRow)==8,"compact table row");
/* Exact division by 255 through a reciprocal; all uint32_t inputs.
 * 0x80808081 / 2^39 rounds upward by < 1/(255*2^32).
 * Signed wrapper preserves C truncation, including INT32_MIN. */
static inline __attribute__((always_inline)) uint32_t tr_u255(uint32_t n){return (uint32_t)(((uint64_t)n*0x80808081ULL)>>39);}
static inline __attribute__((always_inline)) int32_t tr_i255(int32_t n){uint32_t a=n<0?0U-(uint32_t)n:(uint32_t)n;uint32_t q=tr_u255(a);return n<0?-(int32_t)q:(int32_t)q;}
/* Arithmetic shifts explicitly preserve signed division's truncation to zero.
 * Audio products are bounded; negative bias cannot overflow either type. */
static inline __attribute__((always_inline)) int32_t tr_q64(int64_t n,unsigned k){return (int32_t)((n+(n<0?((INT64_C(1)<<k)-1):0))>>k);}
static inline __attribute__((always_inline)) int32_t tr_q32(int32_t n,unsigned k){return (n+(n<0?((INT32_C(1)<<k)-1):0))>>k;}
static inline __attribute__((always_inline)) uint32_t tr_u65025(uint32_t n){uint32_t q=(uint32_t)(((uint64_t)n*2164359683ULL)>>47);return q-(q*65025U>n);}
static inline __attribute__((always_inline)) int bounded(int v,int lo,int hi) { return v<lo?lo:v>hi?hi:v; }
#include "sound.inc"
void tr_project_init(TrProject *p) {
 memset(p,0,sizeof *p);tr_project_mixer_defaults(p);tr_sound_defaults(p);p->bpm=120;p->song_length=1;
 memset(p->song,TR_EMPTY,sizeof p->song);
 for(unsigned a=0;a<TR_PHRASES;a++)for(unsigned r=0;r<16;r++){p->phrases[a].step[r].note=TR_EMPTY;p->phrases[a].step[r].instrument=TR_EMPTY;}
 for(unsigned c=0;c<TR_CHAINS;c++){memset(p->chains[c].phrase,TR_EMPTY,16);p->chains[c].length=1;}
 for(unsigned i=0;i<TR_INSTRUMENTS;i++){TrInstrument *a=&p->instruments[i];a->table=TR_EMPTY;a->volume=192;a->cutoff=128;a->pulse=128;a->decay=4;a->attack=32;a->sample=i%8;a->model=i%5;}
 for(unsigned i=0;i<TR_TABLES;i++){p->tables[i].length=16;for(unsigned r=0;r<16;r++)p->tables[i].row[r].velocity=255;}
}
void tr_init(Tracker *t) {
 memset(t,0,sizeof *t);tr_project_init(&t->project);t->song_launch=TR_EMPTY;tr_effects_reset(t);t->rng=0x816234ab;
}
FM1_AUDIO_CODE unsigned tr_instrument_source(const Tracker *t,unsigned i,unsigned ch){unsigned source=t->project.instrument_source[i%32];return source?source==2:ch>=4;}
FM1_AUDIO_CODE int tr_set_sample(Tracker *t,unsigned slot,const TrSample *s) {
 if(slot>=TR_SAMPLES||!s||!s->data||!s->frames||s->frames>65535||
    (s->rate!=22050&&s->rate!=32000)||s->root>127)return -1;
 for(unsigned c=0;c<8;c++)if(t->voice[c].sample_mode&&t->project.instruments[t->voice[c].instrument].sample==slot)t->voice[c].active=0;
 t->samples[slot]=*s;return 0;
}

static TR_AUDIO_LOCAL uint32_t tr_random(TrVoice *v) {
 uint32_t x=v->rng;x^=x<<13;x^=x>>17;x^=x<<5;return v->rng=x;
}
static TR_AUDIO_LOCAL int tr_chance(TrVoice *v,unsigned value,unsigned maximum) {
 if(!value)return 0;if(value>=maximum)return 1;return tr_random(v)%maximum<value;
}
static TR_AUDIO_LOCAL uint8_t tr_random_value(TrVoice *v,uint8_t base,uint8_t range) {
 int hi=(int)(range>>4),lo=(int)(range&15);
 int h=(base>>4)+(hi?(int)(tr_random(v)%(unsigned)(hi*2+1))-hi:0);
 int l=(base&15)+(lo?(int)(tr_random(v)%(unsigned)(lo*2+1))-lo:0);
 return (uint8_t)((bounded(h,0,15)<<4)|bounded(l,0,15));
}
const char *tr_scale_name(unsigned n){static const char *names[]={"CHROMATIC","MAJ/IONIAN","DORIAN","PHRYGIAN","LYDIAN","MIXOLYDIAN","MIN/AEOLIAN","LOCRIAN","MIN PENT","MAJ PENT"};return n<10?names[n]:"?";}
FM1_AUDIO_CODE int tr_global_note(const TrProject *p,int note){
 static const uint16_t masks[] FM1_AUDIO_DATA={0xfff,0xab5,0x6ad,0x5ab,0xad5,0x6b5,0x5ad,0x56b,0x4a9,0x295};
 note=bounded(note,0,127);unsigned scale=p->global_scale<10?p->global_scale:0,mask=masks[scale],root=p->global_root%12;
 int quantized=note;while(quantized>=0&&!(mask&(1U<<((unsigned)(quantized+12-(int)root)%12))))--quantized;
 if(quantized<0){quantized=0;while(!(mask&(1U<<((unsigned)(quantized+12-(int)root)%12))))++quantized;}return quantized;
}
static TR_AUDIO_LOCAL void pitch(Tracker *t,unsigned ch,int note) {
 TrVoice *v=&t->voice[ch];note+=v->transpose+t->transpose;
 unsigned mode=v->scale&15,key=v->scale>>4;
 if(mode==1||mode==2) {
  unsigned mask=mode==1?0xab5U:0x5adU;
  while(note>0&&!(mask&(1U<<((unsigned)(note+120-(int)key)%12U))))--note;
 }
 if(mode!=1&&mode!=2)note=tr_global_note(&t->project,note);
 uint32_t target=increments[bounded(note,0,127)],sample_target=0;
 if(tr_instrument_source(t,v->instrument,ch)) {
  TrSample *sample=&t->samples[t->project.instruments[v->instrument].sample%TR_SAMPLES];
  if(sample->data) {
   uint64_t ratio=((uint64_t)target*sample->rate*65536U)/(32000ULL*increments[sample->root]);
   sample_target=(uint32_t)(ratio>0xffffffffU?0xffffffffU:ratio);
  }
 }
 if(!v->glide||!v->increment) {
  v->increment=target;v->sample_step=sample_target;v->glide_left=0;
 } else if(target!=v->target||sample_target!=v->sample_target) {
  uint32_t duration=(32000U*60U)/((uint32_t)bounded(t->project.bpm,30,300)*24U)*v->glide;
  if(!duration)duration=1;v->glide_left=duration;
  v->glide_step=(int32_t)(((int64_t)target-v->increment)/duration);
  v->sample_glide_step=(int32_t)(((int64_t)sample_target-v->sample_step)/duration);
 }
 v->target=target;v->sample_target=sample_target;
}
static TR_AUDIO_LOCAL void fire(Tracker *t,unsigned ch) {
 TrVoice *v=&t->voice[ch];TrInstrument *i=&t->project.instruments[v->instrument];
 v->sample_mode=(uint8_t)tr_instrument_source(t,v->instrument,ch);
 if(!v->engine_prepared)engine_start(t,v);v->engine_prepared=0;
 v->active=1;v->phase=0;v->envelope=0;v->attacking=1;v->filter=0;sound_start(t,v);
 if(tr_instrument_source(t,v->instrument,ch)) {
  TrSample *s=&t->samples[i->sample%TR_SAMPLES];
  if(!s->data||!s->frames){v->active=0;return;}
  v->index=(s->frames*(uint32_t)v->start)/256U;
  uint32_t count=v->length?(s->frames*(uint32_t)v->length)/255U:s->frames;
  v->end=v->index+count;if(v->end>s->frames)v->end=s->frames;v->position=0;
 }
}
static TR_AUDIO_LOCAL void tr_next_phrase(Tracker *t,TrVoice *v,unsigned ch) {
 v->step=0;++v->loops;
 unsigned c=t->project.song[v->song][ch];
 if(c<TR_CHAINS&&++v->chain<t->project.chains[c].length&&v->chain<16)return;
 v->chain=0;if(++v->song>=t->project.song_length||v->song>=TR_SONG)v->song=0;
}
static TR_AUDIO_LOCAL TrStep *cell(Tracker *t,TrVoice *v,unsigned ch) {
 if(v->song>=t->project.song_length||v->song>=TR_SONG)return 0;
 unsigned c=t->project.song[v->song][ch];if(c>=TR_CHAINS)return 0;
 TrChain *chain=&t->project.chains[c];if(v->chain>=chain->length||v->chain>=16)return 0;
 unsigned p=chain->phrase[v->chain];if(p>=TR_PHRASES)return 0;
 return &t->project.phrases[p].step[v->step];
}
static TR_AUDIO_LOCAL void tr_table_start(TrVoice *v,unsigned id) {
 v->table_id=(uint8_t)id;v->table_active=id<TR_TABLES;v->table_row=v->table_wait=0;
 v->table_hold=0;v->table_loops=0;v->table_jump=TR_EMPTY;++v->table_generation;
 for(unsigned n=0;n<16;n++)v->table_hops[n]=0;
 for(unsigned n=0;n<3;n++) {
  v->table_lanes[n].running=0;v->table_lanes[n].limited=0;
  v->table_lanes[n].last.command=FX_NONE;v->table_lanes[n].last.value=0;
 }
}
static TR_AUDIO_LOCAL void tr_apply(Tracker *t,unsigned ch,TrFx f,int table) {
 TrVoice *v=&t->voice[ch];unsigned x=f.value;
 switch(f.command) {
 case FX_LEV:case FX_PAN:case FX_DSN:case FX_RSN:t->effects.override[ch][f.command-FX_LEV]=(int16_t)x;break;
 case FX_KIL:v->kill_left=(uint16_t)x;break;
 case FX_OFF:if(!x){if(t->project.sound[v->instrument][0])tr_release(t,v);else v->attacking=0;}else v->kill_left=(uint16_t)x;break;
 case FX_HOP:if(table) {
  unsigned times=x>>4,row=v->table_row;
  if(!times||v->table_hops[row]<times){++v->table_hops[row];v->table_jump=(uint8_t)(x&15);}
  else v->table_hops[row]=0;
 }else if(x==255){v->stopped=1;v->active=0;}else v->hop=(uint8_t)(x&15);break;
 case FX_JMP:if(table)v->table_jump=(uint8_t)(x&15);else v->jump=(uint8_t)(x&15);break;
 case FX_SNG:if(!table)v->song_jump=(uint8_t)((v->song+(int8_t)x+TR_SONG)%TR_SONG);break;
 case FX_RET:v->ret_value=(uint8_t)x;v->ret_period=(uint8_t)(x&15);v->ret_once=(uint8_t)(x&15?0:x>>4);v->ret_clock=0;break;
 case FX_PORT:v->glide=(uint8_t)x;break;
 case FX_CUT:v->cutoff=(uint8_t)x;break;
 case FX_VOL:v->volume=(uint8_t)x;break;
 case FX_PWM:v->pulse=(uint8_t)x;break;
 case FX_TIM:v->engine_live[0]=x;v->engine_override|=1;break;case FX_COL:v->engine_live[1]=x;v->engine_override|=2;break;
 case FX_FAI:v->engine_live[0]=x;v->engine_override|=1;break;case FX_FAL:v->engine_live[2]=x&7;v->engine_override|=4;break;case FX_FBK:v->engine_live[3]=x;v->engine_override|=8;break;
 case FX_WTP:v->engine_live[0]=x;v->engine_override|=1;break;case FX_WT2:v->engine_live[1]=x;v->engine_override|=2;break;case FX_DTN:v->engine_live[4]=x;v->engine_override|=16;break;case FX_OSM:v->engine_live[5]=x;v->engine_override|=32;break;case FX_SYN:v->engine_live[6]=!!x;v->engine_override|=64;break;
 case FX_OR1:case FX_OR2:case FX_OR3:case FX_OR4:v->engine_live[7]=x;v->engine_ratios[f.command-FX_OR1]=x%15;v->engine_override|=(uint16_t)(1U<<(7+f.command-FX_OR1));break;
 case FX_MDL:v->model=(uint8_t)(x%TR_MODELS);engine_start(t,v);break;
 case FX_START:v->start=(uint8_t)x;break;
 case FX_LENGTH:v->length=(uint8_t)x;break;
 case FX_PIT:v->transpose=(int8_t)bounded(v->transpose+(int8_t)x,-96,96);break;
 case FX_PBN:v->bend=(int8_t)x;break;
 case FX_PVB:v->vibrato=(uint8_t)x;break;
 case FX_ARP:v->arp=(uint8_t)x;v->arp_pos=0;v->arp_clock=0;break;
 case FX_ARC:v->arp_rate=(uint8_t)(x&15);break;
 case FX_TBL:if(x<TR_TABLES)tr_table_start(v,x);break;
 case FX_THO:v->table_jump=(uint8_t)(x&15);break;
 case FX_TIC:v->table_rate=(uint8_t)x;v->table_hold=!x;break;
 case FX_STP:v->table_active=0;break;
 case FX_TPO:t->project.bpm=(uint16_t)bounded((int)x,30,255);break;
 case FX_TSP:t->transpose=(int8_t)x;break;
 case FX_SCA:v->scale=(uint8_t)x;break;
 case FX_SCG:for(unsigned n=0;n<8;n++)t->voice[n].scale=(uint8_t)x;break;
 case FX_INS:if(x<TR_INSTRUMENTS){v->instrument=(uint8_t)x;fire(t,ch);}break;
 default:break;
 }
}
/* Evaluate a bounded command list on a local copy. Stored Phrase/Table data never mutates.
 * Gates are resolved before side effects, so a right-hand CHN can suppress HOP. */
static TR_AUDIO_LOCAL void tr_commands(Tracker *t,unsigned ch,TrFx *fx,unsigned count,
 TrLane *lanes,int table,int *note,int *instrument,int *velocity,int *note_allowed) {
 TrVoice *v=&t->voice[ch];uint8_t gate[3]={1,1,1};int allow=1,trigger=0;
 unsigned loops=table?v->table_loops:v->loops;
 for(unsigned f=0;f<count;f++)if(fx[f].command==FX_SED)v->rng=0x9e3779b9U^((uint32_t)fx[f].value*0x10101U);
 for(unsigned f=0;f<count;f++) {
  TrFx c=fx[f];unsigned left=c.value>>4,right=c.value&15;
  if(c.command==FX_CND){unsigned a=left,b=right;allow=allow&&a&&b&&a<=b&&loops%b==a-1;}
  if(c.command==FX_PRV)allow=allow&&(v->previous==!!c.value);
  if(c.command==FX_CHA||c.command==FX_NTH) {
   int l,r;
   if(c.command==FX_CHA){l=tr_chance(v,table?c.value:left,table?255:15);r=tr_chance(v,right,15);}
   else {l=!left||loops%left==0;r=!right||loops%right==0;}
   *note_allowed&=l;for(unsigned j=0;j<f;j++)gate[j]&=(uint8_t)l;
   if(!table)for(unsigned j=f+1;j<count;j++)gate[j]&=(uint8_t)r;
  }
  if(c.command==FX_CHN){int pass=tr_chance(v,c.value,255);if(f)gate[f-1]&=(uint8_t)pass;else *note_allowed&=pass;}
 }
 if(!allow){*note_allowed=0;if(!table)v->previous=0;return;}
 if(!table)v->previous=(uint8_t)*note_allowed;
 for(unsigned f=0;f<count;f++)if(gate[f]&&fx[f].command==FX_RNL) {
  if(f)fx[f-1].value=tr_random_value(v,fx[f-1].value,fx[f].value);
  else {
   if(table||(*note>=0&&*note<128))*note=bounded(*note+(int)(tr_random(v)%(unsigned)((fx[f].value>>4)*2+1))-(fx[f].value>>4),table?-96:0,table?96:127);
   if(table)*velocity=bounded(*velocity+(int)(tr_random(v)%(unsigned)((fx[f].value&15)*2+1))-(fx[f].value&15),0,255);
   else if(*instrument>=0&&*instrument<TR_INSTRUMENTS)*instrument=bounded(*instrument+(int)(tr_random(v)%(unsigned)((fx[f].value&15)*2+1))-(fx[f].value&15),0,TR_INSTRUMENTS-1);
  }
 }
 /* Establish note/instrument before parameter commands so VOL/CUT override defaults. */
 if(*note_allowed&&!table) {
  if(*instrument>=0&&*instrument<TR_INSTRUMENTS)v->instrument=(uint8_t)*instrument;
  if(*note==TR_OFF){tr_release(t,v);v->table_active=0;v->ret_period=v->ret_once=0;}
  if(*note>=0&&*note<128) {
   TrInstrument *i=&t->project.instruments[v->instrument];v->note=(uint8_t)*note;
   v->volume=i->volume;v->cutoff=i->cutoff;v->pulse=i->pulse;v->model=i->model;engine_start(t,v);v->engine_prepared=1;
   v->start=v->length=0;v->kill_left=65535;v->ret_period=v->ret_once=0;
   tr_table_start(v,i->table);v->table_rate=1;
   v->table_transpose=0;v->pitch_accum=0;
   trigger=1;
  }
 } else if(table&&*note_allowed){v->table_transpose=(int8_t)*note;v->volume=(uint8_t)*velocity;}
 for(unsigned f=0;f<count;f++) {
  if(!gate[f])continue;
  TrLane *l=&lanes[f];TrFx c=fx[f];
  if(c.command==FX_REP){l->delta=(int8_t)c.value;l->running=c.value&&l->last.command;l->limited=0;}
  else if(c.command==FX_RTO){l->limit=c.value;l->limited=1;}
  else if(c.command==FX_RND){if(l->last.command){c=l->last;c.value=tr_random_value(v,c.value,fx[f].value);tr_apply(t,ch,c,table);}continue;}
  else if(c.command==FX_NONE){/* Empty lane continues its repeater. */}
  else if(c.command!=FX_CHA&&c.command!=FX_CHN&&c.command!=FX_CND&&c.command!=FX_PRV&&c.command!=FX_NTH&&c.command!=FX_SED&&c.command!=FX_RNL) {
   l->running=0;l->last=c;tr_apply(t,ch,c,table);continue;
  } else continue;
  if(l->running) {
   int value=(int)l->last.value+l->delta;
   int limit=l->limited?l->limit:l->delta>0?255:0;
   if((l->delta>0&&value>=limit)||(l->delta<0&&value<=limit)){value=limit;l->running=0;}
   l->last.value=(uint8_t)bounded(value,0,255);tr_apply(t,ch,l->last,table);
  }
 }
 if(trigger&&!v->stopped) {
  fire(t,ch);
  for(unsigned f=0;f<count;f++)if(gate[f]&&fx[f].command==FX_OFF&&!fx[f].value){if(t->project.sound[v->instrument][0])tr_release(t,v);else v->attacking=0;}
 }
}
static TR_AUDIO_LOCAL void tr_row(Tracker *t,unsigned ch,TrStep s) {
 TrVoice *v=&t->voice[ch];int note=s.note,instrument=s.instrument,velocity=v->volume,allowed=1;
 v->hop=v->jump=v->song_jump=TR_EMPTY;
 tr_commands(t,ch,s.fx,2,v->lanes,0,&note,&instrument,&velocity,&allowed);
}
static TR_AUDIO_LOCAL void tr_reset_voices(Tracker *t,unsigned song_row) {
 for(unsigned ch=0;ch<8;ch++) {
  TrVoice *v=&t->voice[ch];volatile unsigned char *b=(volatile unsigned char *)v;
  for(unsigned n=0;n<sizeof *v;n++)b[n]=0;
  v->kill_left=65535;v->noise=0x1234567U+ch;v->rng=0x816234abU+ch*12345U;
  v->volume=192;v->cutoff=128;v->pulse=128;v->arp_rate=1;v->table_rate=1;
  v->hop=v->jump=v->song_jump=v->table_jump=TR_EMPTY;
  v->song=(uint8_t)song_row;
 }
}
FM1_AUDIO_CODE void tr_transport(Tracker *t,int playing) {
 tr_effects_reset(t);t->playing=!!playing;t->song_launch=TR_EMPTY;t->clock=0;t->ticks=0;t->transpose=0;tr_reset_voices(t,0);
}
int tr_song_start(Tracker *t,unsigned song_row){if(song_row>=t->project.song_length||song_row>=TR_SONG)return -1;tr_transport(t,1);for(unsigned ch=0;ch<8;ch++)t->voice[ch].song=(uint8_t)song_row;return 0;}
int tr_song_launch(Tracker *t,unsigned song_row){if(!t->playing||song_row>=t->project.song_length||song_row>=TR_SONG)return -1;t->song_launch=(uint8_t)song_row;return 0;}
FM1_AUDIO_CODE void tr_tick(Tracker *t) {
 if(!t->playing)return;
 if(t->song_launch!=TR_EMPTY&&t->ticks%6==0){unsigned target=t->song_launch;t->song_launch=TR_EMPTY;if(target<t->project.song_length&&target<TR_SONG){tr_reset_voices(t,target);t->transpose=0;}}
 for(unsigned ch=0;ch<8;ch++) {
  TrVoice *v=&t->voice[ch];if(v->stopped)continue;
  if(v->pending&&v->delay&&!--v->delay){v->pending=0;tr_row(t,ch,v->deferred);}
  if(v->tick==0) {
   TrStep *s=cell(t,v,ch);
   if(s) {
    unsigned delay=0;for(unsigned f=0;f<2;f++)if(s->fx[f].command==FX_DEL)delay=s->fx[f].value;
    if(delay&&delay<6){v->deferred=*s;v->delay=(uint8_t)delay;v->pending=1;}
    else if(!delay)tr_row(t,ch,*s);
   }else{v->active=0;v->table_active=0;v->previous=0;}
  }
  if(v->ret_period||v->ret_once) {
   if(++v->ret_clock>(v->ret_period?v->ret_period:v->ret_once)) {
    v->ret_clock=1;
    int ramp=(v->ret_value>>4);if(v->ret_period)v->volume=(uint8_t)bounded(v->volume+(ramp<8?-(ramp+1):(ramp-7))*8,0,255);
    if(v->active)fire(t,ch);v->ret_once=0;
   }
  }
  if(v->active&&v->table_active&&!v->table_hold&&v->table_id<TR_TABLES) {
   if(v->table_wait)--v->table_wait;
   else {
    TrTable *a=&t->project.tables[v->table_id];TrTableRow row=a->row[v->table_row];
    unsigned generation=v->table_generation;
    int note=row.transpose,inst=v->instrument,vel=row.velocity,allowed=1;
    tr_commands(t,ch,row.fx,3,v->table_lanes,1,&note,&inst,&vel,&allowed);
    if(v->table_generation!=generation){/* New table starts on row zero next tick. */}
    else if(v->table_jump!=TR_EMPTY){if(v->table_jump<=v->table_row)++v->table_loops;v->table_row=v->table_jump;v->table_jump=TR_EMPTY;}
    else if(++v->table_row>=a->length||v->table_row>=16){v->table_row=0;++v->table_loops;}
    v->table_wait=(uint8_t)(v->table_rate?v->table_rate-1:255);
   }
  }
  if(v->kill_left!=65535){if(!v->kill_left){v->active=0;v->table_active=0;v->kill_left=65535;}else --v->kill_left;}
  int arp=v->arp_pos==1?v->arp>>4:v->arp_pos==2?v->arp&15:0;
  v->pitch_accum=(int16_t)bounded(v->pitch_accum+v->bend,-96*16,96*16);
  v->vibrato_phase=(uint8_t)(v->vibrato_phase+(v->vibrato>>4));
  int vib=(int)wavetable[v->vibrato_phase]*(v->vibrato&15)/32768/4;
  pitch(t,ch,(int)v->note+v->table_transpose+arp+v->pitch_accum/16+vib);
  if(v->arp&&++v->arp_clock>=(v->arp_rate?v->arp_rate:1)){v->arp_clock=0;v->arp_pos=(uint8_t)((v->arp_pos+1)%3);}
  if(++v->tick>=6) {
   v->tick=0;
   if(v->song_jump!=TR_EMPTY&&v->song_jump<t->project.song_length){v->song=v->song_jump;v->chain=v->step=0;++v->loops;}
   else if(v->hop!=TR_EMPTY){unsigned row=v->hop;tr_next_phrase(t,v,ch);v->step=(uint8_t)row;}
   else if(v->jump!=TR_EMPTY){if(v->jump<=v->step)++v->loops;v->step=v->jump;}
   else if(++v->step>=16)tr_next_phrase(t,v,ch);
   v->hop=v->jump=v->song_jump=TR_EMPTY;
  }
 }
 ++t->ticks;
}
static TR_AUDIO_LOCAL int32_t voice_sample_at(Tracker *t,unsigned ch,TrVoice *v) {
 (void)ch;
 if(!v->active)return 0;
 TrInstrument *i=&t->project.instruments[v->instrument];
 if(v->glide_left) {
  v->increment=(uint32_t)((int64_t)v->increment+v->glide_step);
  v->sample_step=(uint32_t)((int64_t)v->sample_step+v->sample_glide_step);
  if(!--v->glide_left){v->increment=v->target;v->sample_step=v->sample_target;}
 }
 PROF_BEGIN(pmod);if(!(v->mod_clock++&31))sound_modulate(t,v);uint32_t inc=sound_pitch_cached(v,v->increment,0);if((v->mod_clock&31)==1)engine_control(t,v,inc);
 PROF_END(pmod,9);PROF_BEGIN(psyn);int32_t x=0;
 if(!v->sample_mode) {
  v->phase+=inc;
  switch(v->model%TR_MODELS) {
   case 0:x=(int32_t)(v->phase>>16)-32768;break;
   case 1:x=(v->phase>>24)<v->pulse?24576:-24576;break;
   case 2:x=wavetable[v->phase>>24];break;
   case 3:x=(v->phase>>31)&1U?24000:-24000;break;
   case 5:case 6:case 7:x=braids_sample(t,v,inc);break;
   case 8:case 9:case 10:case 11:case 12:x=braids_analog_sample(t,v,inc);break;
   case 13:case 14:case 15:x=braids_drum_sample(t,v,inc);break;
   case 16:x=fm4_sample(t,v,inc);break;case 17:x=dual_sample(t,v,inc);break;
   default: {
    uint32_t n=v->noise;n^=n<<13;n^=n>>17;n^=n<<5;v->noise=n;
    x=(int32_t)(n&65535U)-32768;break;
   }
  }
 } else {
  TrSample *s=&t->samples[i->sample%TR_SAMPLES];
  if(!s->data||v->index>=v->end){v->active=0;return 0;}
  uint32_t next=v->index+1<v->end?v->index+1:v->index;
  x=s->data[v->index]+tr_q64((int64_t)(s->data[next]-s->data[v->index])*(v->position&65535U),16);
  uint64_t pos=(uint64_t)v->position+sound_pitch_cached(v,v->sample_step,1);
  v->index+=(uint32_t)(pos>>16);v->position=(uint32_t)pos&65535U;
 }
 PROF_END(psyn,10);PROF_BEGIN(pfilter);int32_t filtered=sound_envelope_filter(t,v,x);PROF_END(pfilter,11);return filtered;
}
#include "effects.inc"
static TR_AUDIO_LOCAL void tr_sample_clock(Tracker *t){
 if(t->playing){if(!t->ticks)tr_tick(t);t->clock+=(uint32_t)bounded(t->project.bpm,30,300)*24U;if(t->clock>=TR_RATE*60U){t->clock-=TR_RATE*60U;tr_tick(t);}}
}
static TR_AUDIO_LOCAL void tr_mix_sample(Tracker *t,int32_t preview,unsigned channel,int16_t out[2],const TrRender *work,unsigned frame){
 int32_t dry[2]={0,0},sends[4]={0,0,0,0};unsigned meter_decay=!(++t->effects.meter_clock&63U);
 for(unsigned c=0;c<8;c++){
  PROF_BEGIN(pvoice);int32_t x=work?work->sample[c][frame]:(t->playing?voice_sample_at(t,c,&t->voice[c]):0);int32_t px=c==channel?preview:0;PROF_END(pvoice,c);
  for(unsigned f=0;f<4;f++){int target=(int)mix_value_hot(t,c,f)*256;if(f==0&&((t->project.mute_mask&(1U<<c))||(t->project.solo_mask&&!(t->project.solo_mask&(1U<<c)))))target=0;int delta=target-t->effects.mix_now[c][f];t->effects.mix_now[c][f]+=bounded(delta,-512,512);}
  int level=(unsigned)t->effects.mix_now[c][0]>>8,pan=(unsigned)t->effects.mix_now[c][1]>>8,ds=(unsigned)t->effects.mix_now[c][2]>>8,rs=(unsigned)t->effects.mix_now[c][3]>>8;
  x=tr_i255(x*level)/4;px=tr_i255(px*level)/4;
  /* Post-fader dry signal, before pan/master/FX. Capture short hits across LCD frames. */
  int32_t metered=x+px,amplitude=metered<0?-metered*4:metered*4;if(amplitude>32767)amplitude=32767;
  if((unsigned)amplitude>t->effects.peaks[c]){t->effects.peaks[c]=(uint16_t)amplitude;t->effects.peak_hold[c]=32;}
  else if(meter_decay){if(t->effects.peak_hold[c])--t->effects.peak_hold[c];else t->effects.peaks[c]=(uint16_t)(t->effects.peaks[c]*63U/64U);}
  /* No pan/send state changes below: a zero dry voice adds exactly zero. */
  if(!x&&!px)continue;
  pan=bounded(pan+(work?work->pan[c][frame]:t->voice[c].mod_pan),0,255);
  int32_t l=tr_q32(x*(pan<=128?256:((255-pan)*2+((255-pan)>=64))),8),rr=tr_q32(x*(pan>=128?256:pan*2),8);
  if(px){int pp=bounded((int)((unsigned)t->effects.mix_now[c][1]>>8)+t->preview_pan,0,255);l+=tr_q32(px*(pp<=128?256:((255-pp)*2+((255-pp)>=64))),8);rr+=tr_q32(px*(pp>=128?256:pp*2),8);}
  dry[0]+=l;dry[1]+=rr;sends[0]+=tr_i255(l*ds);sends[1]+=tr_i255(rr*ds);sends[2]+=tr_i255(l*rs);sends[3]+=tr_i255(rr*rs);
 }
 for(unsigned f=0;f<4;f++)t->effects.accum[f]+=sends[f];
 if(++t->effects.decimate==4){int32_t wet[2];PROF_BEGIN(pfx);tr_effects_sample(t,t->effects.accum[0]/4,t->effects.accum[1]/4,t->effects.accum[2]/4,t->effects.accum[3]/4,wet);PROF_END(pfx,8);for(unsigned c=0;c<2;c++){t->effects.previous_wet[c]=t->effects.wet[c];t->effects.wet[c]=wet[c];}memset(t->effects.accum,0,sizeof t->effects.accum);t->effects.decimate=0;}
 int gain_delta=(int)t->project.master[7]*256-(int)t->effects.master_gain;t->effects.master_gain=(unsigned)((int)t->effects.master_gain+bounded(gain_delta,-512,512));
 for(unsigned c=0;c<2;c++){int32_t wet=t->effects.previous_wet[c]+(t->effects.wet[c]-t->effects.previous_wet[c])*(int)t->effects.decimate/4;int32_t sum=dry[c]+wet;unsigned mag=sum<0?0U-(unsigned)sum:(unsigned)sum;
 /* |sum| is bounded by eight 16-bit voices plus bounded FX. Shift the
  * unsigned product first: floor(floor(n/256)/255) == floor(n/65280). */
 unsigned scaled=tr_u255((unsigned)(((uint64_t)mag*t->effects.master_gain)>>8));
 /* Exact rational limiter, without a signed 64-bit divide per channel:
  * floor(a*K/(K+a)) = K - ceil(K*K/(K+a)), K=32767. */
 unsigned den=32767U+scaled;int32_t limit=(int32_t)(32767U-(1073676289U+den-1U)/den);
 out[c]=(int16_t)(sum<0?-limit:limit);}
}
FM1_AUDIO_CODE void tr_sample_stereo(Tracker *t,int32_t preview,unsigned channel,int16_t out[2]){
 tr_sample_clock(t);tr_mix_sample(t,preview,channel,out,0,0);
}
static TR_AUDIO_LOCAL void tr_render_voices(TrRender *w,unsigned first,unsigned end){
 Tracker *t=w->tracker;
 for(unsigned c=first;c<end;c++)for(unsigned f=0;f<w->frames;f++){
  w->sample[c][f]=t->playing?voice_sample_at(t,c,&t->voice[c]):0;
  w->pan[c][f]=(int16_t)t->voice[c].mod_pan;
 }
}
static TR_AUDIO_LOCAL void tr_render_worker(void *arg){tr_render_voices((TrRender *)arg,4,8);}
/* Split before every sequencer tick. No worker executes commands or writes
 * shared mixer/FX state; CPU0 joins before mixing, advancing ticks or returning. */
FM1_AUDIO_CODE void tr_render_stereo(Tracker *t,TrVoice *preview,unsigned channel,int16_t *out,unsigned frames,TrRender *w){
 while(frames){
  w->preview[0]=tr_audition_sample(t,preview,channel);w->preview_pan[0]=t->preview_pan;
  tr_sample_clock(t);
  unsigned n=frames<TR_RENDER_CHUNK?frames:TR_RENDER_CHUNK;
  unsigned step=(unsigned)bounded(t->project.bpm,30,300)*24U;
  if(t->playing){unsigned until=1+(TR_RATE*60U-1-t->clock)/step;if(n>until)n=until;}
  w->tracker=t;w->frames=n;
  int submitted=w->submit&&w->join?w->submit(tr_render_worker,w):0;
  tr_render_voices(w,0,submitted?4:8);
  for(unsigned f=1;f<n;f++){w->preview[f]=tr_audition_sample(t,preview,channel);w->preview_pan[f]=t->preview_pan;}
  if(submitted)w->join();
  for(unsigned f=0;f<n;f++){t->preview_pan=w->preview_pan[f];tr_mix_sample(t,w->preview[f],channel,out+f*2,w,f);}
  if(t->playing)t->clock+=(n-1)*step;
  out+=n*2;frames-=n;
 }
}
FM1_AUDIO_CODE int16_t tr_sample(Tracker *t){int16_t out[2];tr_sample_stereo(t,0,8,out);return (int16_t)(((int32_t)out[0]+out[1])/2);}

void tr_demo(Tracker *t) {
 for(unsigned c=0;c<8;c++) {
  t->project.song[0][c]=c;t->project.chains[c].phrase[0]=c;
  for(unsigned s=0;s<16;s+=4) {
   TrStep *a=&t->project.phrases[c].step[s];a->note=c<4?48+c*7+s/4:60;a->instrument=c;
  }
 }
}

void tr_audition_on(Tracker *t,TrVoice *preview,unsigned ch,unsigned instrument,unsigned note){
 if(ch>=8||instrument>=32||note>127)return;
 TrVoice saved=t->voice[ch];TrVoice *v=&t->voice[ch];memset(v,0,sizeof *v);
 v->instrument=(uint8_t)instrument;v->note=(uint8_t)note;v->noise=0x1234567;v->kill_left=65535;
 const TrInstrument *i=&t->project.instruments[instrument];v->volume=i->volume;v->cutoff=i->cutoff;v->model=i->model;v->pulse=i->pulse;
 pitch(t,ch,(int)note);fire(t,ch);*preview=*v;t->voice[ch]=saved;
}
FM1_AUDIO_CODE int32_t tr_audition_sample(Tracker *t,TrVoice *preview,unsigned ch){int32_t x=voice_sample_at(t,ch,preview);t->preview_pan=(int16_t)preview->mod_pan;return x;}

int tr_wavetable_preview(unsigned bank,unsigned position,unsigned phase){return wt_wave(bank,(uint32_t)(phase&65535)<<16,0,position>255?255:position);}
