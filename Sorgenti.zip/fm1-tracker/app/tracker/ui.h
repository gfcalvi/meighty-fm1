/* SPDX-License-Identifier: GPL-3.0-only WITH GPL-3.0-linking-exception */
#ifndef TRACKER_UI_H
#define TRACKER_UI_H
#include "tracker.h"
int tracker_ui_get(unsigned page,unsigned object,unsigned row,unsigned field);
int tracker_ui_set(unsigned page,unsigned object,unsigned row,unsigned field,int value);
int tracker_ui_select(unsigned page,unsigned track,unsigned row,unsigned field,unsigned object);
unsigned tracker_ui_state(unsigned index);
unsigned tracker_ui_button_lights(void);
unsigned tracker_ui_voice(unsigned track,unsigned index);
void tracker_ui_play(int playing);
int tracker_ui_project_save(unsigned slot);
int tracker_ui_slot_export(unsigned slot,TrProject *out);
int tracker_ui_slot_import(unsigned slot,const TrProject *p);
int tracker_ui_project_load(unsigned slot);
void tracker_ui_project_restore(void);
int tracker_ui_global_action(unsigned action);
int tracker_ui_tempo(unsigned bpm);
int tracker_ui_length(unsigned rows);
void tracker_ui_demo(unsigned demo);
const TrProject *tracker_ui_project(void);
int tracker_ui_project_valid(const TrProject *p);
int tracker_ui_project_apply(const TrProject *p);
unsigned tracker_ui_preset_count(void);
const char *tracker_ui_preset_name(unsigned preset);
unsigned tracker_ui_preset_pcm(unsigned preset);
int tracker_ui_preset_match(unsigned instrument);
int tracker_ui_preset_load(unsigned instrument,unsigned preset);
int tracker_ui_audition(int note);
const char *tracker_ui_instrument_name(unsigned instrument);
void tracker_ui_diagnostic(const char *const *lines,unsigned count);
#endif

void tracker_ui_notice(const char *title,const char *detail);
