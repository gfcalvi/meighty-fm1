/* SPDX-License-Identifier: GPL-3.0-only WITH GPL-3.0-linking-exception */
#include "tracker.h"
#include <string.h>
/* Control-side metadata: never touched by the audio ISR. */
static const struct {const char *name,*help;} commands[FX_COUNT]={
 {"---","No command; active lane REP continues"},
 {"DEL","Defer entire row 0-5 ticks"},{"KIL","Kill voice after XX ticks"},
 {"HOP","Next phrase row Y; FF stops this track"},
 {"CHA","M8-style left/right chance X/Y, 0-F"},
 {"RND","Randomize remembered FX in this lane"},
 {"REP","Repeat remembered FX with signed increment"},
 {"PSL","Glide toward subsequent note; 00 disables"},
 {"CND","Extension: A:B loop condition, nibbles"},
 {"PRV","Extension: previous row condition 00/01"},
 {"CUT","Absolute lowpass coefficient 00-FF"},
 {"STA","PCM region start, fraction XX/256"},
 {"LEN","PCM region length; 00 means remainder"},
 {"RET","Retrigger every Y ticks, X volume ramp"},
 {"RNL","Randomize immediate left FX or note/instrument"},
 {"SED","Reset this track PRNG to seed XX"},
 {"RTO","Set current lane REP stopping bound"},
 {"VOL","Absolute voice volume 00-FF"},
 {"PIT","Relative signed semitone offset"},
 {"ARP","Three-note arpeggio: base, +X, +Y"},
 {"ARC","Arpeggio tick rate Y; X reserved"},
 {"TBL","Select and restart table 00-0F"},
 {"THO","Jump table to row low nibble"},
 {"TIC","Table row duration 01-FF ticks"},
 {"TPO","Set BPM 1E-FF"},
 {"JMP","Extension: local phrase jump to row Y"},
 {"SNG","Signed relative song row jump"},
 {"INS","Change instrument and retrigger voice"},
 {"OFF","00 starts decay; nonzero schedules kill"},
 {"CHN","pico-style chance of immediate left, 00-FF"},
 {"PBN","Signed pitch drift, 1/16 semitone per tick"},
 {"PVB","Tick vibrato: speed X, depth Y"},
 {"PWM","Absolute pulse width 00-FF"},
 {"MDL","Model 00-11 hex; engine parameters reload on model change"},
 {"SCA","Key X, scale Y: 0 chromatic 1 major 2 minor"},
 {"SCG","Set SCA for all eight tracks"},
 {"TSP","Global signed semitone transpose"},
 {"STP","Stop current table"},
 {"NTH","Adapted: left every X loops, right every Y"},
 {"LEV","Track mixer level 00-FF; runtime override"},
 {"PAN","Track pan: 00 left, 80 centre, FF right"},
 {"DSN","Post-fader send to master delay 00-FF"},
 {"RSN","Post-fader send to master reverb 00-FF"},
 {"TIM","Braids TIMBRE or FM4 INDEX or WT position 1, 00-FF"},
 {"COL","Braids COLOR or WT position 2, 00-FF"},
 {"FAI","FM4 modulation index 00-FF"},{"FAL","FM4 algorithm 00-07"},{"FBK","FM4 operator 4 feedback 00-FF"},
 {"WTP","Dual wavetable position oscillator 1, 00-FF"},{"WT2","Dual wavetable position oscillator 2, 00-FF"},
 {"DTN","Dual OSC2 detune: 80 centre, 00-FF signed bias"},{"OSM","Dual oscillator mix: 00 OSC1, FF OSC2"},{"SYN","Dual hard sync: 00 OFF, nonzero ON"},
 {"OR1","FM4 operator 1 ratio index 00-0E"},{"OR2","FM4 operator 2 ratio index 00-0E"},{"OR3","FM4 operator 3 ratio index 00-0E"},{"OR4","FM4 operator 4 ratio index 00-0E"}
};
const char *tr_fx_name(unsigned c){return c<FX_COUNT?commands[c].name:"???";}
const char *tr_fx_help(unsigned c){return c<FX_COUNT?commands[c].help:"Unknown command";}
void tr_evolving_demo(Tracker *t){
 tr_demo(t);
 /* A filter sweep evolves on empty rows; a later RTO caps the ramp. */
 t->project.phrases[0].step[0].fx[0]=(TrFx){FX_CUT,0x20};
 t->project.phrases[0].step[1].fx[0]=(TrFx){FX_REP,4};
 t->project.phrases[0].step[2].fx[0]=(TrFx){FX_RTO,0xc0};
 /* A seeded melody; seed at row zero, later rows draw an evolving sequence. */
 for(unsigned n=0;n<16;n+=4){
  TrStep *s=&t->project.phrases[1].step[n];s->fx[0]=(TrFx){FX_RNL,0x30};
  if(!n)s->fx[1]=(TrFx){FX_SED,0x2a};
 }
 for(unsigned n=0;n<16;n+=4){
  t->project.phrases[2].step[n].fx[0]=(TrFx){FX_ARP,0x37};
  t->project.phrases[2].step[n].fx[1]=(TrFx){FX_CND,0x12};
  t->project.phrases[4].step[n].fx[0]=(TrFx){FX_CHN,0xc0};
  t->project.phrases[5].step[n].fx[0]=(TrFx){FX_RET,0x22};
 }
}
void tr_berlin_demo(Tracker *t){
 TrProject *p=&t->project;p->bpm=108;p->song_length=16;p->global_scale=6;p->global_root=2;
 const char *names[]={"DUSK BASS","CLOCKWORK ARP","GLASS ECHO","HORIZON PAD","CR78 KICK","MP45 SNARE","CR78 HAT","MINIPOPS FX"};
 unsigned samples[]={0,0,0,0,0,4,2,6};unsigned arp[]={0,7,12,15,7,19,12,7,0,12,7,15,19,7,12,22};
 for(unsigned c=0;c<8;c++){strcpy(p->instrument_names[c],names[c]);p->instrument_source[c]=c<4?1:2;TrInstrument *i=&p->instruments[c];i->model=c==2?5:c==3?1:0;i->sample=samples[c];i->volume=c>=4?170:130;i->cutoff=c==0?82:c==3?95:210;i->attack=c==3?8:255;i->decay=c==3?1:18;
 p->mixer[c]=(TrMix){210,(uint8_t)(c==1?75:c==2?185:128),(uint8_t)(c==1?95:c==2?145:c==7?100:0),(uint8_t)(c==3?160:c==2?100:c>=5?45:25)};
 if(c<4){p->sound[c][0]=1;p->sound[c][1]=c==3?95:0;p->sound[c][2]=c==3?90:35;p->sound[c][3]=c==3?160:0;p->sound[c][4]=c==3?100:22;p->sound[c][6]=1;}
 if(c<2){p->cutoff_env[c][0]=1;p->cutoff_env[c][2]=45;p->cutoff_env[c][5]=175;}}
 p->master[0]=4;p->master[1]=155;p->master[2]=1;p->master[3]=110;p->master[4]=210;p->master[5]=110;p->master[6]=110;p->master[7]=200;p->reverb_mode=1;
 for(unsigned section=0;section<4;section++)for(unsigned c=0;c<8;c++){unsigned id=section*8+c;p->chains[id].length=1;p->chains[id].phrase[0]=id;
 for(unsigned s=0;s<16;s++){TrStep *a=&p->phrases[id].step[s];unsigned hit=c==0?s%4==0:c==1?1:c==2?s%4==2:c==3?s==0:c==4?s==0||s==8:c==5?s==4||s==12:c==6?s%2==0:s==6||s==14;if(!hit)continue;a->instrument=c;a->note=c==0?38+(section==2?5:section==3?10:0):c==1?50+arp[(s+section*3)%16]:c==2?74+arp[(s/4+section)%16]%12:c==3?50+(section==2?5:section==3?10:0):60;if(c==1)a->fx[0]=(TrFx){FX_CUT,(uint8_t)(70+s*8)};if(c==7)a->fx[0]=(TrFx){FX_PAN,(uint8_t)(s==6?45:210)};}}
 for(unsigned bar=0;bar<16;bar++)for(unsigned c=0;c<8;c++)p->song[bar][c]=bar<(c==0?0:c==1?2:c==2?6:c==3?0:c==4?4:c==5?8:c==6?6:12)?TR_EMPTY:(uint8_t)((bar/4)*8+c);
}
/* Four bars of immediately playable percussion, eight independent mono lanes. */
void tr_drum_demo(Tracker *t){
 TrProject *p=&t->project;p->bpm=112;p->song_length=4;p->global_scale=0;p->global_root=0;
 const unsigned sample[]={21,23,8,11,12,14,19,28};
 const char *names[]={"CR78 KICK","CR78 SNARE","CR78 CLOSED HAT","CR78 RIM","CR78 BONGO HI","CR78 CONGA LO","CR78 TAMBOURINE","MP45 SMALL SNR"};
 const unsigned level[]={230,195,130,145,140,165,100,110};
 for(unsigned c=0;c<8;c++){
  TrInstrument *i=&p->instruments[c];i->sample=(uint8_t)sample[c];i->volume=220;i->cutoff=250;i->attack=255;i->decay=1;i->table=TR_EMPTY;p->instrument_source[c]=2;strcpy(p->instrument_names[c],names[c]);
  p->mixer[c]=(TrMix){level[c],(uint8_t)(c==2?165:c==4?65:c==5?190:c==6?105:128),0,(uint8_t)(c==1?45:c==3?30:15)};
  for(unsigned bar=0;bar<4;bar++){
   unsigned id=bar*8+c;p->song[bar][c]=(uint8_t)id;p->chains[id].phrase[0]=(uint8_t)id;p->chains[id].length=1;
   for(unsigned s=0;s<16;s++){
    unsigned hit=c==0?(s==0||s==8||(bar%2&&s==10)):c==1?(s==4||s==12):c==2?(s%2==0):c==3?(s==6||s==14):c==4?(s==3||s==11):c==5?(s==7||s==15):c==6?(s%4==2):bar==3&&(s==13||s==14||s==15);
    if(hit){TrStep *a=&p->phrases[id].step[s];a->note=60;a->instrument=(uint8_t)c;if(c==2)a->fx[0]=(TrFx){FX_VOL,(uint8_t)(s%4?135:210)};}
   }
  }
 }
 p->master[3]=0;p->master[6]=80;p->master[7]=235;
}
/* Multi-engine Berlin variation: all eight lanes audible from bar one. */
void tr_engine_demo(Tracker *t){tr_berlin_demo(t);TrProject *p=&t->project;p->song_length=4;p->global_scale=0;const unsigned models[]={16,17,9,12,13,14,15,8};const char *names[]={"FM4 PULSE BASS","WT CLOCKWORK","BRAIDS MORPH","BRAIDS SYNC","BRAIDS KICK","BRAIDS SNARE","BRAIDS CYMBAL","BRAIDS CSAW"};
 for(unsigned c=0;c<8;c++){tr_sound_reset(p,c);p->instrument_source[c]=1;p->instruments[c].model=(uint8_t)models[c];p->instruments[c].volume=c<4?160:180;p->instruments[c].cutoff=220;p->instruments[c].attack=255;p->instruments[c].decay=1;strcpy(p->instrument_names[c],names[c]);uint8_t *s=p->sound[c];s[0]=1;s[1]=c==3?50:0;s[2]=c==4?120:c>=5?100:65;s[3]=c>=4?0:140;s[4]=c==3?100:42;s[7]=c==4?160:130;s[8]=c==5?160:90;s[6]=1;p->engine[c][29]=140;if(c==0){s[7]=155;p->engine[c][0]=4;p->engine[c][1]=30;}if(c>=4)p->instruments[c].cutoff=255;
 for(unsigned bar=0;bar<4;bar++)p->song[bar][c]=(uint8_t)c;}
 for(unsigned n=0;n<16;n++){if(p->phrases[4].step[n].note<128)p->phrases[4].step[n].note=36;if(p->phrases[5].step[n].note<128)p->phrases[5].step[n].note=48;}
 p->phrases[0].step[1].fx[0]=(TrFx){FX_FAI,80};p->phrases[0].step[2].fx[0]=(TrFx){FX_REP,12};p->phrases[1].step[0].fx[1]=(TrFx){FX_WTP,20};p->phrases[1].step[1].fx[1]=(TrFx){FX_REP,13};p->phrases[2].step[2].fx[0]=(TrFx){FX_TIM,180};p->phrases[3].step[4].fx[0]=(TrFx){FX_COL,210};
}
