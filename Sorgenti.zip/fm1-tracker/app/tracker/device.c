/* SPDX-License-Identifier: GPL-3.0-only WITH GPL-3.0-linking-exception
 * Font and board integration derived from M-VAVE FM1 Open. */
#include "tracker.h"
#include "ui.h"
#include "fm1_device.h"
#include "fm1_engine_control.h"
#include "instrument.h"
#include <string.h>
#include <stdio.h>
#include <stddef.h>
static Tracker tracker;
static volatile uint8_t ready;
static uint32_t rate_phase,previous_buttons,previous_keys,last_frame;
static int16_t last_sample[2];
static unsigned view,track,row,field,object;
static unsigned ui_revision;
/* Song/Phrase follow playback until a deliberate row/value edit. Page key resumes. */
static unsigned follow_edit_mask;
static TrVoice audition;static unsigned audition_channel;
static uint8_t last_instrument[8]={0,1,2,3,4,5,6,7};
static int audition_key=-1;
static char previous_lines[12][22];
static uint16_t pixels[240*10];
#include "rhythm_bank.inc"
#include "font.inc"
#include "presets.inc"
#include "atmosphere.inc"
static unsigned preset_family(unsigned p){unsigned n=0;while(n+1<sizeof preset_family_starts/sizeof preset_family_starts[0]&&p>=preset_family_starts[n+1])++n;return n;}
static void project_reset_ram(unsigned whole);
#include "project_store.inc"
static unsigned preset_open,preset_index;
static void migrate_sources(void){
 for(unsigned i=0;i<32;i++)if(!tracker.project.instrument_source[i]){
  unsigned pcm=i>=4&&i<8;
  for(unsigned p=0;p<sizeof factory_presets/sizeof factory_presets[0];p++)if(!strcmp(tracker.project.instrument_names[i],factory_presets[p].name)){pcm=factory_presets[p].pcm;break;}
  tracker.project.instrument_source[i]=(uint8_t)(pcm+1);
 }
}

static const unsigned instrument_order[74]={70,0,16,17,7,1,2,3,14,15,4,5,6,9,10,11,12,13,32,33,34,35,36,37,18,19,20,21,22,23,24,71,72,25,26,27,28,29,30,31,73,74,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69};
/* Presentation/navigation order; semantic field IDs stay stable for clients. */
static const unsigned global_order[15]={0,1,2,3,14,4,5,6,7,8,9,10,11,12,13};
static unsigned global_position(unsigned f){for(unsigned n=0;n<15;n++)if(global_order[n]==f)return n;return 0;}
static unsigned instrument_position(unsigned f){for(unsigned n=0;n<74;n++)if(instrument_order[n]==f)return n;return 0;}
static int instrument_active(unsigned f){unsigned pcm=tr_instrument_source(&tracker,object,track),m=tracker.project.instruments[object].model;
 return f==0?!pcm:f==7?pcm:(f==16||f==17)?!pcm&&m>=5:f==4?!pcm&&m==1:f>=71?!pcm&&m==17:1;
}
static unsigned instrument_move(unsigned f,int delta){int pos=instrument_position(f),lo=pos>=42?(tracker.project.instruments[object].model==17?68:42):pos>=13?13:0,hi=pos>=42?(tracker.project.instruments[object].model==17?73:67):pos>=13?41:12;
 while(delta){int step=delta>0?1:-1,next=pos+step;while(next>=lo&&next<=hi&&!instrument_active(instrument_order[next]))next+=step;if(next<lo||next>hi)break;pos=next;delta-=step;}return instrument_order[pos];
}
static int clamp(int v,int lo,int hi){return v<lo?lo:v>hi?hi:v;}
/* 21 columns, antialiased Barlow Condensed, seven scrolling rows. Two 10px
 * strips retain the original 4800-byte staging buffer. */
static uint16_t blend(uint16_t ink,uint16_t paper,unsigned a){
 unsigned r=(((ink>>11)&31)*a+((paper>>11)&31)*(15-a))/15;
 unsigned g=(((ink>>5)&63)*a+((paper>>5)&63)*(15-a))/15;
 unsigned b=((ink&31)*a+(paper&31)*(15-a))/15;return (uint16_t)((r<<11)|(g<<5)|b);
}
static const uint16_t accents[8]={0x5fff,0xff6e,0xd53f,0x7fed,0x5fff,0xff6e,0xd53f,0x7fed};
static void line(unsigned n,const char *s,unsigned first,unsigned width,unsigned playing) {
 char padded[22];unsigned len=(unsigned)strlen(s);if(len>21)len=21;
 memset(padded,' ',21);memcpy(padded,s,len);padded[21]=0;
 static unsigned styles[12];static uint8_t quiet_cache[12];
 uint8_t quiet=view==0?(uint8_t)(tracker.project.mute_mask|(tracker.project.solo_mask?(uint8_t)~tracker.project.solo_mask:0)):0;
 unsigned style=first|(width<<5)|(playing<<10)|(view<<11)|(track<<14);
 if(!memcmp(previous_lines[n],padded,22)&&styles[n]==style&&quiet_cache[n]==quiet)return;
 styles[n]=style;quiet_cache[n]=quiet;memcpy(previous_lines[n],padded,22);
 for(unsigned strip=0;strip<2;strip++) {
  for(unsigned sy=0;sy<10;sy++)for(unsigned x=0;x<240;x++) {
   unsigned y=strip*10+sy,col=x>=4?(x-4)/11:21,gx=x>=4?(x-4)%11:10;
   unsigned alpha=0;char c=col<21?padded[col]:' ';
   if(c>=32&&c<127){unsigned k=y*11+gx;unsigned packed=(n>=10?tracker_font_small:tracker_font)[(unsigned)c-32][k/2];alpha=k%2?packed&15:packed>>4;}
   uint16_t paper=n==0?0x18e5:n==2?0x18c4:n==11?0x1083:(n&1)?0x0842:0;
   uint16_t ink=n==0?0xbdf7:n==2?0xc638:0xffff;
   if(n==1){ink=accents[track];paper=0x1084;}
   if(n==2&&view==0){ink=accents[(track/4)*4+(col/5>3?3:col/5)];paper=0x1084;}
   if(n>=3&&n<=9){
    if(view==0){unsigned t=col/5;if(t<4){ink=accents[(track/4)*4+t];const uint16_t backgrounds[]={0x0926,0x20e2,0x1886,0x0924};paper=backgrounds[t];if(gx==10&&col%5==4)paper=0;}}
    else if(view==1){if(col<3)ink=0xff6e;else if(col>=4&&col<6)ink=0xd53f;else if(col>=7)ink=0x5fff;}
    else if(view==2&&col>=9)ink=0x5fff;
    else if(view==3){ink=col>=14?0xff6e:0x5fff;}
    else if(view==4){unsigned param=(unsigned)clamp((int)instrument_position(field)-3,0,2)+n-3;const uint16_t colors[]={0x5fff,0xd53f,0xff6e,0xd53f,0x7fed,0xff6e,0xff6e,0xfdb8,0xfdb8};ink=col>=15?0xffff:colors[param];paper=(n&1)?0x1084:0x0843;if(x<3)paper=colors[param];}
    else if(view==6){unsigned param=(unsigned)clamp((int)field-3,0,1)+n-3;ink=col>=15?0xffff:param<4?0x5fff:0xd53f;}
    if(playing){paper=0x0244;ink=0xbff6;}
   }
   if(n>=10){ink=accents[col/5>3?3:col/5];paper=0x18e5;}
   if(view==0&&n>=2&&n<=9&&col/5<4&&(quiet&(1U<<((track/4)*4+col/5)))){ink=blend(ink,0,5);paper=blend(paper,0,8);}
   if(width&&col>=first&&col<first+width){paper=0x52b0;ink=0xffff;}
   pixels[sy*240+x]=alpha==15?ink:alpha?blend(ink,paper,alpha):paper;
  }
  (void)fm1_screen_blit(0,n*20+strip*10,240,10,pixels,2400);
 }
}
static void mix_rect(unsigned x,unsigned y,unsigned w,unsigned h,uint16_t color,unsigned top){
 for(unsigned yy=y;yy<y+h;yy++)if(yy>=top&&yy<top+10&&yy<240)for(unsigned xx=x;xx<x+w&&xx<240;xx++)pixels[(yy-top)*240+xx]=color;
}
static void mix_text(unsigned x,unsigned y,const char *text,uint16_t color,unsigned top){
 for(unsigned c=0;text[c];c++)for(unsigned yy=0;yy<20;yy++)if(y+yy>=top&&y+yy<top+10)for(unsigned xx=0;xx<11;xx++)if(x+c*11+xx<240){unsigned ch=(unsigned char)text[c];if(ch<32||ch>=127)continue;unsigned k=yy*11+xx,packed=tracker_font_small[ch-32][k/2],alpha=k%2?packed&15:packed>>4;unsigned index=(y+yy-top)*240+x+c*11+xx;if(alpha)pixels[index]=blend(color,pixels[index],alpha);}
}
static void draw_navigation(void){const unsigned pages[]={0,3,1,4,2,5,6,7};const char *names[]={"SG","CH","PH","IN","TB","MX","FX","GL"};for(unsigned top=0;top<20;top+=10){memset(pixels,0,sizeof pixels);for(unsigned n=0;n<8;n++){mix_rect(n*30,0,29,20,pages[n]==view?0x52b0:0x18e5,top);mix_text(n*30+4,1,names[n],pages[n]==view?0xffff:0xbdf7,top);}(void)fm1_screen_blit(0,top,240,10,pixels,2400);}}
static void draw_mixer(void){
 for(unsigned top=40;top<200;top+=10){memset(pixels,0,sizeof pixels);
  for(unsigned c=0;c<8;c++){unsigned x=c*30,level=tr_mixer_value(&tracker,c,0),pan=tr_mixer_value(&tracker,c,1),ds=tr_mixer_value(&tracker,c,2),rs=tr_mixer_value(&tracker,c,3);uint16_t color=accents[c];
   mix_rect(x,40,29,160,c==track?0x20e8:0x0842,top);if(c==track){mix_rect(x,40,1,160,0xbd1f,top);mix_rect(x+28,40,1,160,0xbd1f,top);}
   char name[3]={'T',(char)('1'+c),0};mix_text(x+4,42,name,color,top);
   mix_text(x+4,62,"M",tracker.project.mute_mask&(1U<<c)?0xfa88:0x4a69,top);mix_text(x+16,62,"S",tracker.project.solo_mask&(1U<<c)?0xff6e:0x4a69,top);
   mix_rect(x+9,85,11,80,0x2947,top);unsigned fill=level*76/255;mix_rect(x+11,163-fill,7,fill,(tracker.project.mute_mask&(1U<<c))?0x6b4d:color,top);mix_rect(x+7,162-fill,15,3,0xffff,top);
   unsigned peak=tracker.effects.peaks[c]*76U/32767U;mix_rect(x+23,163-peak,3,peak,peak>70?0xf986:0x7fed,top);
   mix_rect(x+3,174,23,1,0x6b4d,top);mix_rect(x+3+pan*20/255,172,3,5,0xff6e,top);
   mix_rect(x+3,183,23,4,0x2147,top);mix_rect(x+3,183,ds*23/255,4,0x5fff,top);mix_rect(x+3,192,23,4,0x2147,top);mix_rect(x+3,192,rs*23/255,4,0xd53f,top);
  }(void)fm1_screen_blit(0,top,240,10,pixels,2400);
 }
}
#include "mod_ui.inc"
#include "synth_ui.inc"
#include "engine_ui.inc"
static void edit(int d) {
 if(!d)return;
 TrProject *p=&tracker.project;
 if(view==0) {
  uint8_t *v=&p->song[row][track];*v=(uint8_t)clamp((*v==255?-1:*v)+d,-1,TR_CHAINS-1);
 } else if(view==1) {
  TrStep *s=&p->phrases[object%TR_PHRASES].step[row];
  if(field==0){int note=s->note==TR_EMPTY?129:s->note==TR_OFF?128:clamp(s->note,0,127);note=clamp(note+d,0,129);s->note=(uint8_t)(note==129?TR_EMPTY:note==128?TR_OFF:note);return;}
  uint8_t *v=field==0?&s->note:field==1?&s->instrument:
   field==2?&s->fx[0].command:field==3?&s->fx[0].value:
   field==4?&s->fx[1].command:&s->fx[1].value;
  int max=field==1?TR_INSTRUMENTS-1:(field==2||field==4)?FX_COUNT-1:255;
  *v=(uint8_t)clamp((int)*v+d,0,max);
 } else if(view==2) {
  TrTableRow *s=&p->tables[object%TR_TABLES].row[row];
  if(field==0)s->transpose=(int8_t)clamp(s->transpose+d,-96,96);
  else {uint8_t *v=field==1?&s->velocity:field%2==0?&s->fx[(field-2)/2].command:&s->fx[(field-3)/2].value;
   *v=(uint8_t)clamp(*v+d,0,field>1&&field%2==0?FX_COUNT-1:255);}
 } else if(view==3) {
  TrChain *c=&p->chains[object%TR_CHAINS];
  if(field==0)c->phrase[row]=(uint8_t)clamp((c->phrase[row]==255?-1:c->phrase[row])+d,-1,TR_PHRASES-1);
  else c->length=(uint8_t)clamp(c->length+d,1,16);
 } else {
  if((field==0||field==4)&&tr_instrument_source(&tracker,object,track))return;
  if(field>=9){int value=tracker_ui_get(4,object,0,field);int max=field==70?4:(field==9||field==32)?1:field==15||field==19||field==26?3:field==38?7:field>=40&&field<64&&(field-40)%6==0?14:field==64||field==65?3:field==66?48:field==69?1:255;tracker_ui_set(4,object,0,field,clamp(value+d,0,max));return;}
  if(field==8){int source=(int)tr_instrument_source(&tracker,object,track);p->instrument_source[object]=(uint8_t)(clamp(source+d,0,1)+1);return;}
  TrInstrument *i=&p->instruments[object%TR_INSTRUMENTS];
  uint8_t *v=field==0?&i->model:field==1?&i->table:field==2?&i->volume:field==3?&i->cutoff:
   field==4?&i->pulse:field==5?&i->attack:field==6?&i->decay:&i->sample;
  if(field==1)*v=(uint8_t)clamp((*v==255?-1:*v)+d,-1,TR_TABLES-1);
  else if(field==0){int lo=i->model<5?0:i->model<16?5:i->model,hi=i->model<5?4:i->model<16?15:i->model;*v=(uint8_t)clamp(*v+d,lo,hi);}else *v=(uint8_t)clamp(*v+d,0,field==7?TR_SAMPLES-1:255);
 }
}
static void note_label(unsigned n,char out[4]) {
 static const char names[]="C-C#D-D#E-F-F#G-G#A-A#B-";
 if(n>127){memcpy(out,n==254?"OFF":"---",4);return;}
 out[0]=names[(n%12)*2];out[1]=names[(n%12)*2+1];out[2]=(char)('0'+n/12-1);out[3]=0;
}
void tracker_device_init(void) {
 ready=0;audition.active=0;tr_init(&tracker);tr_berlin_demo(&tracker);migrate_sources();
 load_rhythm_bank();
 memset(previous_lines,0,sizeof previous_lines);fm1_screen_fill(0,0,240,240,0);
 rate_phase=0;last_sample[0]=last_sample[1]=0;ready=1;
}
#ifdef FM1_BLOCK_RENDER
static TrRender device_render;
static int16_t device_chunk[TR_RENDER_CHUNK*2];
#endif
void tracker_device_worker(int (*submit)(void (*job)(void *),void *arg),void (*join)(void)){
#ifdef FM1_BLOCK_RENDER
 device_render.submit=submit;device_render.join=join;
#else
 (void)submit;(void)join;
#endif
}
/* OCT presses can arrive on different UI frames. A completed diagnostics
 * chord restores the masks from before its first press and consumes releases. */
int tracker_device_diagnostic_buttons(unsigned buttons){
 static unsigned seen,active;static uint8_t mute,solo;
 unsigned oct=buttons&3U;
 if(!seen&&oct){mute=tracker.project.mute_mask;solo=tracker.project.solo_mask;seen=1;}
 if(oct==3U&&!active){tracker.project.mute_mask=mute;tracker.project.solo_mask=solo;active=1;}
 if(active){previous_buttons=buttons;if(!oct)seen=active=0;return 1;}
 if(!oct)seen=0;
 return 0;
}
FM1_AUDIO_CODE void tracker_device_render(int32_t *out,unsigned frames) {
#ifdef FM1_BLOCK_RENDER
 while(frames){
  unsigned n=frames<TR_RENDER_CHUNK?frames:TR_RENDER_CHUNK;
  unsigned count=(rate_phase+TR_RATE*n)/44100U,at=0;
  if(ready&&count)tr_render_stereo(&tracker,&audition,audition_channel,device_chunk,count,&device_render);
  for(unsigned f=0;f<n;f++){
   if(ready){rate_phase+=TR_RATE;if(rate_phase>=44100){rate_phase-=44100;last_sample[0]=device_chunk[at*2];last_sample[1]=device_chunk[at*2+1];at++;}}
   else last_sample[0]=last_sample[1]=0;
   out[f*2]=(int32_t)last_sample[0]*256;out[f*2+1]=(int32_t)last_sample[1]*256;
  }
  out+=n*2;frames-=n;
 }
#else
 for(unsigned f=0;f<frames;f++) {
  if(ready){rate_phase+=TR_RATE;if(rate_phase>=44100){rate_phase-=44100;tr_sample_stereo(&tracker,tr_audition_sample(&tracker,&audition,audition_channel),audition_channel,last_sample);}}
  else last_sample[0]=last_sample[1]=0;
  out[f*2]=(int32_t)last_sample[0]*256;out[f*2+1]=(int32_t)last_sample[1]*256;
 }
#endif
 if(tracker.playing)for(unsigned t=0;t<8;t++)last_instrument[t]=tracker.voice[t].instrument;
}
#include "blue_ui.inc"
void tracker_device_control(void) {
 if(!ready)return;
 struct fm1_controls c;fm1_controls_read(&c);
 uint32_t pressed=c.buttons&~previous_buttons,keys=c.keys&~previous_keys;
 unsigned previous_view=view;
 if(project_reset_pending){unsigned changed=pressed&~(1U<<13);for(unsigned n=0;n<7;n++)changed|=c.encoders[n]!=0;if(keys||changed||view!=7||field!=project_reset_pending+9||fm1_millis()-project_reset_time>7000)project_reset_cancel();}
 previous_buttons=c.buttons;previous_keys=c.keys;
 /* Read knobs outside the interrupt exclusion window. All edits are scalar. */
 groove_master_update(c.knob);
 /* Dedicated panel keys select Song, Chain, Phrase, Instrument, Table. */
 const unsigned direct_pages[5]={0,3,1,4,2};
 for(unsigned i=0;i<5;i++)if(pressed&(1U<<(i+2))){if(i==3&&view==4&&!preset_open){field=instrument_position(field)>=42?8:instrument_position(field)>=13?(tracker.project.instruments[object].model==17?64:tracker.project.instruments[object].model==16?38:8):9;}else{view=direct_pages[i];row=object=0;field=view==4?8:0;}}
 if(pressed&(1U<<11)){view=6;field=0;}
 if(pressed&(1U<<7)){view=7;field=0;}
 if(pressed&(1U<<8)){view=5;field=0;}
 if(c.encoders[6]){view=(unsigned)clamp((int)view+c.encoders[6],0,7);field=0;row=0;}
 if(view<=1){if(previous_view!=view||(pressed&(1U<<(view==0?2:4))))follow_edit_mask&=~(1U<<view);if(c.encoders[1]||c.encoders[3]||(view==1&&(c.encoders[4]||keys)))follow_edit_mask|=1U<<view;}
 track=(unsigned)clamp((int)track+c.encoders[0],0,7);
 if(view<=4)row=(unsigned)clamp((int)row+c.encoders[1],0,view==0?31:15);
 if(view<=4&&!preset_open){if(view==4)field=instrument_move(field,c.encoders[2]);else field=(unsigned)clamp((int)field+c.encoders[2],0,view==0?0:view==1?5:view==3?1:7);}
 if(view==0)track=(unsigned)clamp((int)track+c.encoders[2],0,7);
 else if(view<=4&&!preset_open)object=(unsigned)clamp((int)object+c.encoders[4],0,view==1?63:view==2?15:31);
 if(view==4&&field>=71&&(!instrument_active(field)))field=field<73?18:25;
 if(view==4&&field>=38&&field<70){unsigned m=tracker.project.instruments[object].model;if(m<16)field=70;else if(m==17&&field<64)field=64;else if(m==16&&field>=64)field=38;}
 if(view!=4)preset_open=0;
 if(view==4&&((pressed&(1U<<10))||c.encoders[5])){
  if(!preset_open){int match=tracker_ui_preset_match(object);preset_index=match>=0?(unsigned)match:0;}
  if(pressed&(1U<<10))preset_open=!preset_open;
  if(c.encoders[5])preset_open=1;
 }
 if(preset_open){
  preset_index=(unsigned)clamp((int)preset_index+c.encoders[2]+c.encoders[5],0,(int)tracker_ui_preset_count()-1);
  if(c.encoders[3]){unsigned family=(unsigned)clamp((int)preset_family(preset_index)+c.encoders[3],0,(int)(sizeof preset_family_starts/sizeof preset_family_starts[0])-1);preset_index=preset_family_starts[family];}
  object=(unsigned)clamp((int)object+c.encoders[4],0,31);
  if(pressed&(1U<<13)){tracker_ui_preset_load(object,preset_index);preset_open=0;}
  c.encoders[2]=c.encoders[3]=c.encoders[4]=c.encoders[5]=0;
 }
 if(view==0){
  if(pressed&1U)tracker_ui_set(5,0,track,4,!(tracker.project.mute_mask&(1U<<track)));
  if(pressed&2U)tracker_ui_set(5,0,track,5,!(tracker.project.solo_mask&(1U<<track)));
 }
 if(view==5){
  for(unsigned f=0;f<4;f++)if(c.encoders[f+2])tracker_ui_set(5,0,track,f,clamp((int)tr_mixer_value(&tracker,track,f)+c.encoders[f+2],0,255));
  if(pressed&(1U<<13))tracker_ui_set(5,0,track,4,!(tracker.project.mute_mask&(1U<<track)));
  if(pressed&(1U<<10))tracker_ui_set(5,0,track,5,!(tracker.project.solo_mask&(1U<<track)));
  for(unsigned n=0;n<8;n++)if(keys&(1U<<n))tracker_ui_set(5,0,n,4,!(tracker.project.mute_mask&(1U<<n)));
 }else if(view==6){
  field=(unsigned)clamp((int)field+c.encoders[2]+c.encoders[1],0,8);
  const int max[]={17,240,1,255,224,255,255,255,1};
  if(c.encoders[3])tracker_ui_set(6,0,0,field,clamp(tracker_ui_get(6,0,0,field)+c.encoders[3],0,max[field]));
  if(c.encoders[4])tracker_ui_set(6,0,0,3,clamp((int)tracker.project.master[3]+c.encoders[4],0,255));
  if(c.encoders[5])tracker_ui_set(6,0,0,6,clamp((int)tracker.project.master[6]+c.encoders[5],0,255));
 }
 if(view==7){field=global_order[clamp((int)global_position(field)+c.encoders[2]+c.encoders[1],0,14)];if(c.encoders[3]&&(field<4||(field>=7&&field<=11))){int max=field==0?300:field==1?9:field==2?11:field==3?7:field==7?3:15;tracker_ui_set(7,0,0,field,clamp(tracker_ui_get(7,0,0,field)+c.encoders[3],field==0?30:0,max));}if(pressed&(1U<<13)){if(field>=4&&field<=6)tracker_ui_global_action(field-4);else if(field>=12)tracker_ui_global_action(field-9);}}
 if(view==7){if(c.encoders[4])tracker_ui_global_action(0);else if(c.encoders[5])tracker_ui_global_action(1);}
 uint32_t irq=fm1_device_irq_save();
 if(view==0)tracker.project.song_length=(uint8_t)clamp(tracker.project.song_length+c.encoders[4],1,32);
 if(pressed&(1U<<12)){audition.active=0;if(tracker.playing)tr_transport(&tracker,0);else{follow_edit_mask=0;if(view==0)(void)tr_song_start(&tracker,row);else tr_transport(&tracker,1);}}
 if(view==0&&tracker.playing&&(pressed&(1U<<13))&&!tr_song_launch(&tracker,row))follow_edit_mask&=~1U;

 if((view<=4&&c.encoders[3])||(view==0&&c.encoders[4]))++ui_revision;
 if(view<=4)edit(c.encoders[3]);

 if(view==1&&pressed&(1U<<13)) {
  TrStep *s=&tracker.project.phrases[object].step[row];s->note=60;s->instrument=track;
 }
 if(view!=5&&keys)for(unsigned n=0;n<27;n++)if(keys&(1U<<n)){
  audition_key=(int)n;tracker_ui_audition(53+(int)n);
  if(view==1){TrStep *s=&tracker.project.phrases[object].step[row];s->note=(uint8_t)(53+n);s->instrument=audition.instrument;}
  break;
 }
 if(audition_key>=0&&!(c.keys&(1U<<(unsigned)audition_key))){
  audition_key=-1;for(unsigned n=0;n<27;n++)if(c.keys&(1U<<n)){audition_key=(int)n;tracker_ui_audition(53+(int)n);break;}
  if(audition_key<0)tracker_ui_audition(-1);
 }
 TrVoice *voice=&tracker.voice[track];
 unsigned playing=tracker.playing,display_play=TR_EMPTY;
 unsigned chain=tracker.project.song[voice->song][track];
 unsigned phrase=chain<TR_CHAINS&&voice->chain<16?tracker.project.chains[chain].phrase[voice->chain]:TR_EMPTY;
 if(playing&&view<=1&&!(follow_edit_mask&(1U<<view))){if(view==0)row=voice->song;else if(phrase<TR_PHRASES){object=phrase;row=voice->step;}}
 if(view==0)display_play=voice->song;
 else if(view==1&&phrase==object)display_play=voice->step;
 else if(view==3&&chain==object)display_play=voice->chain;
 else if(view==2&&voice->table_active&&voice->table_id==object)display_play=voice->table_row;
 fm1_device_irq_restore(irq);
 if(pressed&(1U<<9))tracker_ui_project_save(project_slot);
 uint32_t now=fm1_millis();if(now-last_frame<50)return;last_frame=now;
 draw_deep_blue(playing,display_play);return;
 static unsigned rendered_view=99,rendered_mod=99;unsigned mod_view=view==4?(instrument_position(field)>=42?2:instrument_position(field)>=13?1:0):0;if(rendered_view!=view||rendered_mod!=mod_view){memset(previous_lines,0,sizeof previous_lines);rendered_view=view;rendered_mod=mod_view;}
 char b[64];
 if(preset_open){
  line(0,"INSTRUMENT PRESETS",0,0,0);snprintf(b,sizeof b,"PRESET -> INST %02X",object);line(1,b,0,0,0);
  snprintf(b,sizeof b,"%s  REC TO LOAD",tracker_ui_preset_pcm(preset_index)?"PCM":"SYN");line(2,b,0,0,0);
  unsigned top=(unsigned)clamp((int)preset_index-3,0,(int)tracker_ui_preset_count()-7);
  for(unsigned n=0;n<7;n++){snprintf(b,sizeof b,"%02X %s",top+n,tracker_ui_preset_name(top+n));line(n+3,b,0,top+n==preset_index?21:0,0);}
  line(10,"K1/K4 PRESET K3 SLOT",0,0,0);line(11,"REC LOAD  ARP BACK",0,0,0);return;
 }
 const char *names[]={"SONG","PHRASE","TABLE","CHAIN","INSTRUMENT","MIXER","MASTER FX","GLOBAL"};
 draw_navigation();
 snprintf(b,sizeof b,"%s %02X T%u %s",names[view],object,track+1,playing?"PLAY":"STOP");
 /* INSTRUMENT has a shorter label so transport fits at full font size. */
 if(view==4)snprintf(b,sizeof b,"INST %02X T%u %s",object,track+1,playing?"PLAY":"STOP");
 if(view==5)snprintf(b,sizeof b,"MIX T%u %02X %02X %02X %02X",track+1,tr_mixer_value(&tracker,track,0),tr_mixer_value(&tracker,track,1),tr_mixer_value(&tracker,track,2),tr_mixer_value(&tracker,track,3));
 if(view==6)snprintf(b,sizeof b,"MASTER EFFECTS");
 if(view==7)snprintf(b,sizeof b,"GLOBAL SETTINGS");
 line(1,b,0,0,0);
 if(view==7){line(2,global_status,0,0,0);const char *params[]={"BPM","SCALE","ROOT","PROJECT SLOT","LOAD SLOT","SAVE SLOT","MASTER FX"};const char *roots[]={"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};for(unsigned f=0;f<7;f++){char value[16];if(f==0)snprintf(value,sizeof value,"%u",tracker.project.bpm);else if(f==1)snprintf(value,sizeof value,"%s",tr_scale_name(tracker.project.global_scale));else if(f==2)snprintf(value,sizeof value,"%s",roots[tracker.project.global_root]);else if(f==3)snprintf(value,sizeof value,"%u",project_slot+1);else snprintf(value,sizeof value,"REC");snprintf(b,sizeof b,f<3?"%-8s %s":"%-13s %s",params[f],value);line(3+f,b,0,f==field?21:0,0);}line(10,"K1   K2   K3   K4",0,0,0);line(11,"FLD  VAL  LOAD SAVE",0,0,0);return;}
 if(view==5){draw_mixer();line(10,"K1   K2   K3   K4",0,0,0);line(11,"LEV  PAN  DLY  REV",0,0,0);return;}
 if(view==4&&instrument_position(field)>=42){draw_engine_panel();line(10,"K1   K2   K3   K4",0,0,0);line(11,"FLD  VAL  INST PRE",0,0,0);return;}
 if(view==4&&instrument_position(field)>=13){draw_modulations();line(10,"K1   K2   K3   K4",0,0,0);line(11,"FLD  VAL  INST PRE",0,0,0);return;}
 if(view==4){draw_synth_panel();line(10,"K1   K2   K3   K4",0,0,0);line(11,"FLD  VAL  INST PRE",0,0,0);return;}
 if(view==6){
  line(2,tracker.project.reverb_mode?"DELAY + AMBIENT":"DELAY + ROOM",0,0,0);unsigned top=(unsigned)clamp((int)field-3,0,2);
  const char *params[]={"DELAY TIME","FEEDBACK","PING PONG","DELAY RETURN","REVERB DECAY","REVERB DAMP","REVERB RETURN","MASTER LEVEL","REVERB TYPE"};
  for(unsigned n=0;n<7;n++){unsigned f=top+n;char value[9];if(f==8)snprintf(value,sizeof value,"%s",tracker.project.reverb_mode?"AMBIENT":"ROOM");else if(f==0)snprintf(value,sizeof value,"%s",tr_delay_name(tracker.project.master[f]));else if(f==2)snprintf(value,sizeof value,"%s",tracker.project.master[f]?"ON":"OFF");else snprintf(value,sizeof value,"%02X",tracker.project.master[f]);snprintf(b,sizeof b,"%-13s %s",params[f],value);line(n+3,b,14,f==field?7:0,0);}
  line(10,"K1   K2   K3   K4",0,0,0);line(11,"FLD  VAL  DRET RRET",0,0,0);return;
 }
 unsigned instrument_bank=view==4&&instrument_position(field)>=13?13:0;
 unsigned cursor=view==4?instrument_position(field)-instrument_bank:row;
 unsigned start=(unsigned)clamp((int)cursor-3,0,view==0?25:view==4?(instrument_bank?12:6):9),bank=track/4,fxbank=field>=6?1:0;
 if(view==0)snprintf(b,sizeof b,"T%u   T%u   T%u   T%u",bank*4+1,bank*4+2,bank*4+3,bank*4+4);
 else if(view==1)snprintf(b,sizeof b,"NTE IN FX1   FX2");
 else if(view==2)snprintf(b,sizeof b,"ROW PIT VL FX%u   FX%u",fxbank+1,fxbank+2);
 else if(view==3)snprintf(b,sizeof b,"ROW  PHRASE   LENGTH");
 else snprintf(b,sizeof b,"%u/2 %s",instrument_bank?2:1,tracker_ui_instrument_name(object));
 line(2,b,0,0,0);
 for(unsigned n=0;n<7;n++) {
  unsigned j=start+n,first=0,width=0,selected=j==row;
  if(view==0){uint8_t *v=&tracker.project.song[j][bank*4];
   char ids[4][3];for(unsigned t=0;t<4;t++){if(v[t]==255)memcpy(ids[t],"--",3);else snprintf(ids[t],3,"%02X",v[t]);}
   snprintf(b,sizeof b,"%s   %s   %s   %s",ids[0],ids[1],ids[2],ids[3]);
   if(selected){first=(track%4)*5;width=2;}
  }else if(view==1){TrStep *v=&tracker.project.phrases[object%64].step[j];char note[4];note_label(v->note,note);
   snprintf(b,sizeof b,"%s %02X %s%02X %s%02X",note,v->instrument,tr_fx_name(v->fx[0].command),v->fx[0].value,tr_fx_name(v->fx[1].command),v->fx[1].value);
   const unsigned pos[]={0,4,7,10,13,16},w[]={3,2,3,2,3,2};
   if(selected){first=pos[field];width=w[field];}
  }else if(view==2){TrTableRow *v=&tracker.project.tables[object%16].row[j];
   snprintf(b,sizeof b,"%02X%+03d %02X %s%02X %s%02X",j,v->transpose,v->velocity,tr_fx_name(v->fx[fxbank].command),v->fx[fxbank].value,tr_fx_name(v->fx[fxbank+1].command),v->fx[fxbank+1].value);
   if(selected){first=field==0?2:field==1?6:9+((field-2)/2-fxbank)*6+(field%2?3:0);width=field==1||field%2?2:3;}
  }else if(view==3){snprintf(b,sizeof b,"%02X   %02X       %02X",j,tracker.project.chains[object%32].phrase[j],tracker.project.chains[object%32].length);
   if(selected){first=field?14:5;width=2;}
  }else{TrInstrument *v=&tracker.project.instruments[object%32];
   const char *params[]={"MODEL","TABLE","VOLUME","CUTOFF","PULSE WIDTH","LEGACY ATTACK","LEGACY DECAY","SAMPLE SLOT","SOURCE","ADSR ENABLE","ENV ATTACK","ENV DECAY","ENV SUSTAIN","ENV RELEASE","RESONANCE","FILTER TYPE","TIMBRE","COLOR","LFO1 RATE","LFO1 SHAPE","LFO1 PHASE","LFO1 > PAN","LFO1 > PITCH","LFO1 > CUT","LFO1 > AMP","LFO2 RATE","LFO2 SHAPE","LFO2 PHASE","LFO2 > PAN","LFO2 > PITCH","LFO2 > CUT","LFO2 > AMP"};
   unsigned f=instrument_order[j+instrument_bank];unsigned pcm=tr_instrument_source(&tracker,object,track);char value[12];int val=tracker_ui_get(4,object,0,f);
   if(f==8)snprintf(value,sizeof value,"%s",pcm?"SAMPLE":"SYNTH");
   else if(f==0)snprintf(value,sizeof value,"%s",pcm?"PCM":tr_model_name(v->model));
   else if(f==9)snprintf(value,sizeof value,"%s",val?"ON":"LEGACY");
   else if(f==15){const char *types[]={"LEGACY","LP","BP","HP"};snprintf(value,sizeof value,"%s",types[val]);}
   else if(f==19||f==26){const char *shapes[]={"SINE","TRI","SQUARE","SAW"};snprintf(value,sizeof value,"%s",shapes[val]);}
   else if((f>=21&&f<=24)||f>=28)snprintf(value,sizeof value,"%+d",val-128);
   else if(f==4&&pcm)snprintf(value,sizeof value,"--");
   else snprintf(value,sizeof value,"%02X",val);
   snprintf(b,sizeof b,"%-12s %s",params[f],value);if(f==field){first=13;width=8;}

  }
  line(n+3,b,first,width,playing&&j==display_play&&view!=4);
 }
 /* Physical K1..K4 are encoders 2..5; SELECT/ALGORITHM are separate. */
 line(10,"K1   K2   K3   K4",0,0,0);
 
 const char *phrase_fields[]={"NOTE","INST","FX1","VAL1","FX2","VAL2"};
 const char *table_fields[]={"PITCH","VEL","FX1","VAL1","FX2","VAL2","FX3","VAL3"};
 const char *inst_fields[]={"MODEL","TABLE","VOLUME","CUTOFF","PULSE WIDTH","LEGACY ATTACK","LEGACY DECAY","SAMPLE SLOT","SOURCE","ADSR ENABLE","ENV ATTACK","ENV DECAY","ENV SUSTAIN","ENV RELEASE","RESONANCE","FILTER TYPE","TIMBRE","COLOR","LFO1 RATE","LFO1 SHAPE","LFO1 PHASE","LFO1 > PAN","LFO1 > PITCH","LFO1 > CUT","LFO1 > AMP","LFO2 RATE","LFO2 SHAPE","LFO2 PHASE","LFO2 > PAN","LFO2 > PITCH","LFO2 > CUT","LFO2 > AMP"};
 const char *f=view==1?phrase_fields[field]:view==2?table_fields[field]:view==4?inst_fields[field]:view==3?(field?"LEN":"PHR"):"--";
 const char *ids[]={"SONG","PHR","TABLE","CHAIN","INST"};
 snprintf(b,sizeof b,"%-5.5s%-5.5s%-5.5s--",view==0?"TRK":"FLD",view==0?"CHN":f,view==0?"LEN":ids[view]);line(11,b,0,0,0);
}

/* Shared control boundary for the native panel and the web workbench. */
#include "ui.h"
static int ui_valid(unsigned p,unsigned o,unsigned r,unsigned f) {
 if(p>7||r>31)return 0;
 if(p==7)return r==0&&f<15;
 if(p==5)return r<8&&f<6;
 if(p==6)return r==0&&f<9;
 if(p==0)return f<8;
 if(r>=16)return 0;
 return p==1?o<64&&f<6:p==2?o<16&&f<8:p==3?o<32&&f<2:o<32&&f<75;
}
int tracker_ui_get(unsigned p,unsigned o,unsigned r,unsigned f) {
 if(!ui_valid(p,o,r,f))return -999;
 const TrProject *a=&tracker.project;
 if(p==7&&f>=7&&f<=11)return blue_palette_get(f);
 if(p==7)return f==0?a->bpm:f==1?a->global_scale:f==2?a->global_root:f==3?(int)project_slot:0;
 if(p==5)return f<4?(int)tr_mixer_value(&tracker,r,f):f==4?!!(a->mute_mask&(1U<<r)):!!(a->solo_mask&(1U<<r));
 if(p==6)return f==8?a->reverb_mode:a->master[f];
 if(p==0)return a->song[r][f];
 if(p==1){const TrStep *s=&a->phrases[o].step[r];return f==0?s->note:f==1?s->instrument:f%2==0?s->fx[(f-2)/2].command:s->fx[(f-3)/2].value;}
 if(p==2){const TrTableRow *s=&a->tables[o].row[r];return f==0?s->transpose:f==1?s->velocity:f%2==0?s->fx[(f-2)/2].command:s->fx[(f-3)/2].value;}
 if(p==3)return f?a->chains[o].length:a->chains[o].phrase[r];
 const TrInstrument *i=&a->instruments[o];
 if(f==70)return tr_instrument_source(&tracker,o,track)?1:i->model<5?0:i->model<16?2:i->model==16?3:4;
 if(f>=71)return a->wt_lfo[o][f-71];
 if(f>=38)return a->engine[o][f-38];
 if(f>=32)return a->cutoff_env[o][f-32];
 if(f==17&&i->model==16)return a->engine[o][1];
 if(f>=9)return a->sound[o][f-9];
 if(f==8)return (int)tr_instrument_source(&tracker,o,track);
 return f==0?i->model:f==1?i->table:f==2?i->volume:f==3?i->cutoff:f==4?i->pulse:f==5?i->attack:f==6?i->decay:i->sample;
}
int tracker_ui_set(unsigned p,unsigned o,unsigned r,unsigned f,int value) {
 if(!ui_valid(p,o,r,f))return -1;
 int min=0,max=255,sentinel=0;
 if(p==7){if((f>=4&&f<=6)||f>=12)return -2;const int bounds[]={300,9,11,7};max=f<4?bounds[f]:f==7?3:15;if(!f)min=30;}
 if(p==5&&f>=4)max=1;
 if(p==6){const int bounds[]={17,240,1,255,224,255,255,255,1};max=bounds[f];}
 if(p==0){max=31;sentinel=1;}
 else if(p==1){if(f==0){max=127;sentinel=2;}else if(f==1){max=31;sentinel=1;}else if(f%2==0)max=FX_COUNT-1;}
 else if(p==2){if(f==0){min=-96;max=96;}else if(f>=2&&f%2==0)max=FX_COUNT-1;}
 else if(p==3){if(!f){max=63;sentinel=1;}else{min=1;max=16;}}
 else if(p==4){if(f==70)max=4;else if(f==0)max=TR_MODELS-1;else if(f==9||f==32)max=1;else if(f==15||f==19||f==26)max=3;else if(f==1){max=15;sentinel=1;}else if(f==7)max=TR_SAMPLES-1;else if(f==8)max=1;else if(f>=38){unsigned ef=f-38;max=ef==0?7:ef>=2&&ef<26&&(ef-2)%6==0?14:ef==26||ef==27?3:ef==28?48:ef==31?1:255;}}
 if((value<min||value>max)&&!(sentinel&&value==255)&&!(sentinel==2&&value==254))return -2;
 unsigned irq=fm1_device_irq_save();
 TrProject *a=&tracker.project;
 if(p==7){if(f>=7)blue_palette_set(f,(unsigned)value);else if(!f)a->bpm=(uint16_t)value;else if(f==1)a->global_scale=(uint8_t)value;else if(f==2)a->global_root=(uint8_t)value;else project_slot=(unsigned)value;}
 else if(p==5){if(f<4){((uint8_t *)&a->mixer[r])[f]=(uint8_t)value;tracker.effects.override[r][f]=-1;}else{uint8_t *mask=f==4?&a->mute_mask:&a->solo_mask;*mask=(uint8_t)((*mask&~(1U<<r))|(value?(1U<<r):0));}}
 else if(p==6){if(f==8)a->reverb_mode=(uint8_t)value;else a->master[f]=(uint8_t)value;}
 else if(p==0)a->song[r][f]=(uint8_t)value;
 else if(p==1){TrStep *s=&a->phrases[o].step[r];if(f==0)s->note=(uint8_t)value;else if(f==1)s->instrument=(uint8_t)value;else if(f%2==0)s->fx[(f-2)/2].command=(uint8_t)value;else s->fx[(f-3)/2].value=(uint8_t)value;}
 else if(p==2){TrTableRow *s=&a->tables[o].row[r];if(!f)s->transpose=(int8_t)value;else if(f==1)s->velocity=(uint8_t)value;else if(f%2==0)s->fx[(f-2)/2].command=(uint8_t)value;else s->fx[(f-3)/2].value=(uint8_t)value;}
 else if(p==3){if(!f)a->chains[o].phrase[r]=(uint8_t)value;else a->chains[o].length=(uint8_t)value;}
 else if(f==70){a->instrument_source[o]=value==1?2:1;if(value!=1){const uint8_t models[]={0,0,5,16,17};unsigned m=a->instruments[o].model;if(!((value==0&&m<5)||(value==2&&m>=5&&m<16)))a->instruments[o].model=models[value];}}
 else if(f>=71)a->wt_lfo[o][f-71]=(uint8_t)value;
 else if(f>=38)a->engine[o][f-38]=(uint8_t)value;
 else if(f>=32)a->cutoff_env[o][f-32]=(uint8_t)value;
 else if(f==17&&a->instruments[o].model==16)a->engine[o][1]=(uint8_t)value;
 else if(f>=9)a->sound[o][f-9]=(uint8_t)value;
 else if(f==8)a->instrument_source[o]=(uint8_t)(value+1);
 else{TrInstrument *i=&a->instruments[o];uint8_t *v=f==0?&i->model:f==1?&i->table:f==2?&i->volume:f==3?&i->cutoff:f==4?&i->pulse:f==5?&i->attack:f==6?&i->decay:&i->sample;*v=(uint8_t)value;}
 if(!(p==7&&f==3))++ui_revision;fm1_device_irq_restore(irq);last_frame=0;return 0;
}
int tracker_ui_select(unsigned p,unsigned t,unsigned r,unsigned f,unsigned o) {
 if(t>=8||!ui_valid(p,o,r,p==0?t:f))return -1;
 view=p;track=p==5?r:t;row=r;field=p==0?0:f;object=o;if(p<=1)follow_edit_mask|=1U<<p;last_frame=0;return 0;
}
unsigned tracker_ui_state(unsigned i) {
 switch(i){case 0:return view;case 1:return track;case 2:return view==5?track:view>=6?0:row;case 3:return field;case 4:return object;
 case 5:return tracker.project.bpm;case 6:return tracker.playing;case 7:return tracker.ticks;case 8:return tracker.project.song_length;case 9:return ui_revision;case 10:return audition.active;case 11:return audition.instrument;case 12:return audition.note;case 13:return audition_channel;case 14:return project_slot;case 15:return store_result;case 16:return store_serial;case 17:return preset_open;case 18:return preset_index;case 19:return tracker.playing&&view<=1&&!(follow_edit_mask&(1U<<view));default:return 0;}
}
/* Physical IDs match fm1_controls.buttons and the HAL's LED helper. */
unsigned tracker_ui_button_lights(void){
 static const uint8_t page_button[8]={2,4,6,3,5,8,11,7};
 unsigned lights=1U<<page_button[view&7U];
 if(view==4&&preset_open)lights|=1U<<10;
 if(tracker.playing)lights|=1U<<12;
 return lights;
}
unsigned tracker_ui_voice(unsigned t,unsigned i) {
 if(t>=8)return 0;TrVoice *v=&tracker.voice[t];
 switch(i){case 0:return v->step;case 1:return v->song;case 2:return v->chain;case 3:return v->note;case 4:return v->active;case 5:return v->loops;case 6:return v->volume;
 case 7:{unsigned c=tracker.project.song[v->song][t];return c<TR_CHAINS&&v->chain<16?tracker.project.chains[c].phrase[v->chain]:TR_EMPTY;}
 case 8:return tracker.project.song[v->song][t];case 9:return v->table_active?v->table_id:TR_EMPTY;case 10:return v->table_row;
 default:return 0;}
}
void tracker_ui_play(int playing) {if(tracker.playing)for(unsigned t=0;t<8;t++)last_instrument[t]=tracker.voice[t].instrument;audition.active=0;unsigned irq=fm1_device_irq_save();if(playing)follow_edit_mask=0;tr_transport(&tracker,playing);fm1_device_irq_restore(irq);last_frame=0;}
void tracker_ui_demo(unsigned demo) {
 ready=0;audition.active=0;tr_init(&tracker);
 if(demo==4)tr_engine_demo(&tracker);
 else if(demo==3)tr_drum_demo(&tracker);
 else if(demo==2)tr_berlin_demo(&tracker);
 else if(demo)tr_evolving_demo(&tracker);
 else for(unsigned t=0;t<8;t++){tracker.project.song[0][t]=(uint8_t)t;tracker.project.chains[t].phrase[0]=(uint8_t)t;}
 load_rhythm_bank();
 migrate_sources();tr_transport(&tracker,0);++ui_revision;rate_phase=0;last_sample[0]=last_sample[1]=0;ready=1;last_frame=0;
}
/* RAM-only operations: never touch a saved bank until an explicit Save. */
static void project_reset_ram(unsigned whole){
 ready=0;audition.active=0;audition_key=-1;tr_transport(&tracker,0);
 if(whole){uint8_t a=tracker.project.sound_padding,b=tracker.project.global_padding;tr_init(&tracker);tracker.project.sound_padding=a;tracker.project.global_padding=b;for(unsigned i=0;i<32;i++){tracker.project.instrument_source[i]=1;snprintf(tracker.project.instrument_names[i],16,"Init %02X",i);}load_rhythm_bank();}
 else {memset(tracker.project.song,TR_EMPTY,sizeof tracker.project.song);tracker.project.song_length=1;tr_effects_reset(&tracker);}
 row=object=track=0;for(unsigned n=0;n<8;n++)last_instrument[n]=0;
 rate_phase=0;last_sample[0]=last_sample[1]=0;++ui_revision;last_frame=0;ready=1;
}
const TrProject *tracker_ui_project(void){return &tracker.project;}
int tracker_ui_project_valid(const TrProject *p) {
 if(!p||p->reverb_mode>1||p->mixer_version!=1||p->master[0]>17||p->master[1]>240||p->master[2]>1||p->master[4]>224)return 0;
 if(!p||p->global_scale>9||p->global_root>11||p->bpm<30||p->bpm>300||!p->song_length||p->song_length>TR_SONG)return 0;
 for(unsigned r=0;r<TR_SONG;r++)for(unsigned t=0;t<8;t++)if(p->song[r][t]>=TR_CHAINS&&p->song[r][t]!=TR_EMPTY)return 0;
 for(unsigned c=0;c<TR_CHAINS;c++){
  if(!p->chains[c].length||p->chains[c].length>16)return 0;
  for(unsigned n=0;n<16;n++)if(p->chains[c].phrase[n]>=TR_PHRASES&&p->chains[c].phrase[n]!=TR_EMPTY)return 0;
 }
 for(unsigned a=0;a<TR_PHRASES;a++)for(unsigned r=0;r<16;r++){
  const TrStep *s=&p->phrases[a].step[r];
  if((s->note>127&&s->note<TR_OFF)||(s->instrument>=TR_INSTRUMENTS&&s->instrument!=TR_EMPTY))return 0;
  for(unsigned f=0;f<2;f++)if(s->fx[f].command>=FX_COUNT)return 0;
 }
 for(unsigned a=0;a<TR_TABLES;a++){
  if(!p->tables[a].length||p->tables[a].length>16)return 0;
  for(unsigned r=0;r<16;r++){const TrTableRow *s=&p->tables[a].row[r];if(s->transpose< -96||s->transpose>96)return 0;for(unsigned f=0;f<3;f++)if(s->fx[f].command>=FX_COUNT)return 0;}
 }
 for(unsigned a=0;a<TR_INSTRUMENTS;a++){if(p->cutoff_env[a][0]>1)return 0;const uint8_t *snd=p->sound[a];if(snd[0]>1||snd[6]>3||snd[10]>3||snd[17]>3)return 0;if(p->instrument_source[a]>2||!memchr(p->instrument_names[a],0,16))return 0;const uint8_t *e=p->engine[a];if(e[0]>7||e[26]>3||e[27]>3||e[28]>48||e[31]>1)return 0;for(unsigned k=0;k<4;k++)if(e[2+k*6]>14)return 0;const TrInstrument *i=&p->instruments[a];if(i->model>=TR_MODELS||i->sample>=TR_SAMPLES||(i->table>=TR_TABLES&&i->table!=TR_EMPTY))return 0;}
 return 1;
}
int tracker_ui_project_apply(const TrProject *p){
 if(!tracker_ui_project_valid(p))return -1;
 ready=0;audition.active=0;tr_transport(&tracker,0);tracker.project=*p;migrate_sources();tr_effects_reset(&tracker);rate_phase=0;last_sample[0]=last_sample[1]=0;++ui_revision;ready=1;last_frame=0;return 0;
}

int tracker_ui_tempo(unsigned bpm){if(bpm<30||bpm>300)return -1;tracker.project.bpm=(uint16_t)bpm;++ui_revision;return 0;}
int tracker_ui_length(unsigned rows){if(!rows||rows>32)return -1;tracker.project.song_length=(uint8_t)rows;++ui_revision;return 0;}

unsigned tracker_ui_preset_count(void){return sizeof factory_presets/sizeof factory_presets[0];}
const char *tracker_ui_preset_name(unsigned p){return p<tracker_ui_preset_count()?factory_presets[p].name:"CUSTOM";}
unsigned tracker_ui_preset_pcm(unsigned p){return p<tracker_ui_preset_count()?factory_presets[p].pcm:0;}
int tracker_ui_preset_match(unsigned i){if(i>=32)return -1;for(unsigned n=0;n<TR_ATMOS_COUNT;n++){unsigned p=TR_ATMOS_FIRST+n;const TrAtmosphere *a=&atmosphere_presets[n];const uint8_t *e=tracker.project.engine[i],*ops=p>=147&&p<167?atmosphere_fm_operators[p-147]:atmosphere_default_operators;if(tracker.project.instrument_source[i]==1&&!memcmp(&tracker.project.instruments[i],&factory_presets[p].patch,sizeof(TrInstrument))&&!memcmp(tracker.project.sound[i],a->sound,sizeof a->sound)&&!memcmp(tracker.project.cutoff_env[i],a->cutoff_env,sizeof a->cutoff_env)&&!memcmp(e,a->engine,2)&&!memcmp(e+2,ops,24)&&!memcmp(e+26,a->engine+2,6)&&!memcmp(tracker.project.wt_lfo[i],a->wt_lfo,sizeof a->wt_lfo))return (int)p;}for(unsigned p=0;p<TR_ATMOS_FIRST;p++)if((!tracker.project.instrument_source[i]||tracker.project.instrument_source[i]==factory_presets[p].pcm+1)&&!memcmp(&tracker.project.instruments[i],&factory_presets[p].patch,sizeof(TrInstrument)))return (int)p;return -1;}
int tracker_ui_preset_load(unsigned i,unsigned p){if(i>=32||p>=tracker_ui_preset_count())return -1;unsigned irq=fm1_device_irq_save();tr_sound_reset(&tracker.project,i);tracker.project.instruments[i]=factory_presets[p].patch;
 if(p>=24&&p<30){uint8_t *s=tracker.project.sound[i];s[0]=1;s[1]=p==27?48:3;s[2]=72;s[3]=p==24?0:160;s[4]=44;s[6]=1;s[5]=p==26?160:50;s[7]=p==25?230:p==28?170:100;s[8]=p==28?210:150;
 if(p==27||p==29){s[9]=s[16]=100;s[12]=190;s[14]=180;s[20]=132;s[21]=176;}}
 if(p>=63&&p<TR_ATMOS_FIRST){uint8_t *snd=tracker.project.sound[i],*e=tracker.project.engine[i];snd[0]=1;snd[1]=2;snd[2]=70;snd[3]=p>=68&&p<=70?0:190;snd[4]=60;snd[7]=140;snd[8]=110;snd[6]=1;snd[5]=40;
 if(p==68||p==69){snd[2]=p==68?120:95;tracker.project.instruments[i].cutoff=255;}
 if(p==70){snd[2]=135;snd[8]=90;}if(p==71||p==73||p==74){e[0]=p==74?4:0;e[1]=p==73?50:14;for(unsigned k=0;k<4;k++){e[2+k*6]=k?3+k:1;e[3+k*6]=k?160:255;e[4+k*6]=0;e[5+k*6]=p==71?60:100;e[6+k*6]=k?0:180;e[7+k*6]=70;}snd[7]=p==73?170:110;snd[4]=110;}
 if(p==72||p==75||p==76){e[26]=p==76?3:0;e[27]=p==75?1:2;e[29]=142;e[30]=128;snd[1]=p==72?45:3;snd[4]=100;}}
 if(p>=TR_ATMOS_FIRST){const TrAtmosphere *a=&atmosphere_presets[p-TR_ATMOS_FIRST];memcpy(tracker.project.sound[i],a->sound,sizeof a->sound);memcpy(tracker.project.cutoff_env[i],a->cutoff_env,sizeof a->cutoff_env);memcpy(tracker.project.engine[i],a->engine,2);memcpy(tracker.project.engine[i]+26,a->engine+2,6);if(p>=147&&p<167)memcpy(tracker.project.engine[i]+2,atmosphere_fm_operators[p-147],24);memcpy(tracker.project.wt_lfo[i],a->wt_lfo,sizeof a->wt_lfo);}
 preset_open=0;tracker.project.instrument_source[i]=(uint8_t)(factory_presets[p].pcm+1);snprintf(tracker.project.instrument_names[i],16,"%s",factory_presets[p].name);++ui_revision;fm1_device_irq_restore(irq);last_frame=0;return 0;}

const char *tracker_ui_instrument_name(unsigned i){
 if(i>=32)return "INVALID";if(tracker.project.instrument_names[i][0])return tracker.project.instrument_names[i];
 int preset=tracker_ui_preset_match(i);if(preset>=0)return tracker_ui_preset_name((unsigned)preset);
 static char fallback[16];snprintf(fallback,sizeof fallback,"%s %02X",tracker.project.instrument_source[i]==2?"PCM":tr_model_name(tracker.project.instruments[i].model),i);return fallback;
}
int tracker_ui_audition(int note){
 if(note< -1||note>127)return -1;unsigned irq=fm1_device_irq_save();
 if(note<0)tr_release(&tracker,&audition);
 else{unsigned inst=view==4?object:tracker.playing?tracker.voice[track].instrument:last_instrument[track];
  if(view==1){for(int n=(int)row;n>=0;n--)if(tracker.project.phrases[object].step[n].instrument<32){inst=tracker.project.phrases[object].step[n].instrument;break;}}
  audition_channel=track;

  tr_audition_on(&tracker,&audition,audition_channel,inst,(unsigned)note);
 }fm1_device_irq_restore(irq);return 0;
}

void tracker_ui_notice(const char *title,const char *detail){for(unsigned top=0;top<240;top+=10){for(unsigned i=0;i<2400;i++)pixels[i]=B_BG;blue_text(12,65,title,&blue_title,B_ACC,top);blue_text(12,111,detail,&blue_body,B_FG,top);(void)fm1_screen_blit(0,top,240,10,pixels,2400);}last_frame=0;}

/* Read-only compact diagnostic panel. Lines are already formatted by the target. */
void tracker_ui_diagnostic(const char *const *lines,unsigned count){if(count>11)count=11;for(unsigned top=0;top<240;top+=10){for(unsigned i=0;i<2400;i++)pixels[i]=B_BG;blue_text(10,5,"HW5 AUDIO PROFILE",&blue_title,B_ACC,top);for(unsigned j=0;j<count;j++)blue_text(10,33+j*18,lines[j],&blue_small,j<2?B_VALUE:B_FG,top);(void)fm1_screen_blit(0,top,240,10,pixels,2400);}last_frame=0;}
