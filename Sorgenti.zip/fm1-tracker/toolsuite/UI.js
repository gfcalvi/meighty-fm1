/* GPL-3.0-only WITH GPL-3.0-linking-exception. Local UI; no external requests. */
(()=>{'use strict';
const C=MEIGHTY_CONFIG,F=MeightyFiles,$=id=>document.getElementById(id),E=new TextEncoder();
let busy=false,installer=null,connected=false,pkg=null,incoming=null,prepared=null,sources=[],library=[],firmwareInfo='';
const choices=Array(8).fill('');
let output=null;
// Same MIDIWeb iframe bridge as the verified Bloomy suite.
if(parent!==window&&typeof parent.navigator.requestMIDIAccess==='function')Object.defineProperty(navigator,'requestMIDIAccess',{configurable:true,value:options=>parent.navigator.requestMIDIAccess(options)});
function suiteBusy(on){if(parent!==window)parent.postMessage({meightyBusy:!!on},'*');}
window.addEventListener('message',async e=>{if(e.source!==parent||!e.data?.meightyDeactivate||busy)return;try{await installer?.disconnect();connected=false;prepared=null;identities();sync();parent.postMessage({meightyReleased:true},'*');}catch(err){status(err.message,true);}});
window.addEventListener('beforeunload',e=>{if(busy){e.preventDefault();e.returnValue='Trasferimento in corso';}});

function status(s,error=false,pct){$('status').textContent=s;$('status').className='status'+(error?' error':'');$('progress').hidden=pct===undefined;if(pct!==undefined)$('progress').value=pct;if(error)$('status').scrollIntoView({block:'nearest'});}
function sync(){
 const live=connected&&installer?.identity===C.hardware.product;
 document.querySelectorAll('.connect').forEach(b=>b.disabled=busy||connected||!navigator.requestMIDIAccess);
 document.querySelectorAll('.disconnect').forEach(b=>b.disabled=busy||!connected);
 ['readBank','readWorking'].forEach(id=>$(id).disabled=busy||!live);
 $('prepareRestore').disabled=busy;
 $('writeRestore').disabled=busy;
 $('restoreHint').textContent=busy?'Operazione in corso: attendi il messaggio finale.':!incoming?'Scegli prima un file: il caricamento non richiede FM-1.':!live?'File pronto. Premi Connetti FM-1 in questa pagina.':!prepared?'FM-1 collegato. Premi 1. Prepara il ripristino.':!$('restoreConsent').checked?'Conserva il backup delle destinazioni, poi spunta la conferma.':'Pronto: premi 2. Ripristina e verifica.';
 $('writeFirmware').disabled=busy||!connected||!pkg||!$('saved').checked||!$('consent').checked;
 ['convert','extractAll'].forEach(id=>$(id).disabled=busy||!sources.length);
 $('extractWorking').disabled=busy||!selectedSource()?.model.working;
 ['sourceFiles','restoreFile','restoreMode','layout','sourceChoice','convertFormat','setName','tiffany','clearSet','exportSet','exportSetState'].forEach(id=>$(id).disabled=busy);
 document.querySelectorAll('#composer input[type=file]').forEach(x=>x.disabled=busy);
 document.querySelectorAll('#composer select,#sourceSlots button,#composer button').forEach(b=>b.disabled=busy||b.dataset.empty==='true');
}
async function run(fn){if(busy)return;busy=true;suiteBusy(true);sync();try{await fn();}catch(e){status(e.message||String(e),true);}finally{busy=false;suiteBusy(false);if(installer&&!installer.link)connected=false;sync();}}
function readFile(file){return new Promise((resolve,reject)=>{if(file.size>4*1048576)return reject(Error('Il file supera 4 MiB.'));const r=new FileReader(),timer=setTimeout(()=>{r.abort();reject(Error('Lettura del file scaduta. Scarica il file da iCloud/Dropbox in File prima di riprovare.'));},20000);r.onload=()=>{clearTimeout(timer);resolve(new Uint8Array(r.result));};r.onerror=()=>{clearTimeout(timer);reject(Error('Lettura del file non riuscita.'));};r.onabort=()=>{clearTimeout(timer);reject(Error('Lettura del file annullata.'));};r.readAsArrayBuffer(file);});}
function options(){return{cores:C.cores,decoder:F.un64(C.decoder),base:Number($('layout').value)||undefined};}
function safeName(n){return String(n||'Meighty').replace(/[^\p{L}\p{N} _.-]/gu,'_').replace(/^\.+/,'').trim().slice(0,70)||'Meighty';}
function canShare(bytes,name,type){try{return !!(navigator.canShare&&navigator.share&&navigator.canShare({files:[new File([bytes],name,{type})]}));}catch(_){return false;}}
function saveOutput(){if(!output)return;const url=URL.createObjectURL(new Blob([output.bytes],{type:output.type})),a=document.createElement('a');a.href=url;a.download=output.name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),120000);}
function download(bytes,name,type='application/octet-stream'){
 const clean=String(name).replace(/[^\p{L}\p{N} _.-]/gu,'_').replace(/^\.+/,'').trim().slice(0,220)||'Meighty.meighty';
 output={bytes:new Uint8Array(bytes),name:clean,type};$('resultName').textContent=clean+' · '+bytes.length.toLocaleString('it-IT')+' byte';$('result').hidden=false;$('resultShare').hidden=!canShare(bytes,clean,type);$('result').scrollIntoView({block:'nearest'});
}
$('resultDownload').onclick=()=>{try{saveOutput();}catch(e){status('Download non riuscito: '+e.message,true);}};
$('resultShare').onclick=async()=>{if(!output)return;try{await navigator.share({files:[new File([output.bytes],output.name,{type:output.type})],title:'Salvataggio Meighty'});}catch(e){if(e.name!=='AbortError')status('Condivisione non disponibile: usa Scarica il file.',true);}};

const jsonBytes=j=>E.encode(JSON.stringify(j,null,2));
const jsonBytesCompact=j=>E.encode(JSON.stringify(j));
const progress=(f,s)=>status(s,false,Math.round(f*100));
function tab(name){document.querySelectorAll('.tab').forEach(s=>s.hidden=s.id!==name);document.querySelectorAll('[data-tab]').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.tab===name)));}
document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>tab(b.dataset.tab));
function identities(){document.querySelectorAll('.identity').forEach(x=>x.textContent=connected?'Collegato: '+installer.identity+(firmwareInfo?' · '+firmwareInfo:''):'Nessuno strumento collegato');}
document.querySelectorAll('.connect').forEach(b=>b.onclick=()=>run(async()=>{
 const access=await navigator.requestMIDIAccess({sysex:true});installer=new FM1M8Installer.Installer(access,pkg,(s,n)=>status(s,false,n),{reconnect:60000,writeIdle:180000,idle:20000,settle:800});
 await installer.connect();connected=true;prepared=null;firmwareInfo='';identities();
 if(installer.identity===C.hardware.product){const api=new FM1M8Installer.Projects(installer.link);await api.info();if(api.metadata){try{const m=await api.metadata();firmwareInfo='Meighty '+m.version+' · HW'+m.build;identities();}catch(e){firmwareInfo='versione non rilevata';identities();}}status('Meighty collegato. Connessione verificata, nessuna scrittura eseguita.');}
 else status('Collegato '+installer.identity+'. Per conservare i dati di questo firmware usa il suo backup prima di installare Meighty.');
}));
document.querySelectorAll('.disconnect').forEach(b=>b.onclick=()=>run(async()=>{await installer?.disconnect();connected=false;prepared=null;identities();status('Porta MIDI liberata.');}));
['saved','consent','restoreConsent'].forEach(id=>$(id).onchange=sync);
$('writeFirmware').onclick=()=>run(async()=>{if(!connected||!$('saved').checked||!$('consent').checked)return;await installer.install();connected=false;identities();status('Trasferimento concluso. Verifica avvio e audio sul display dell’FM-1.',false,100);});
const api=()=>{if(!connected||installer.identity!==C.hardware.product)throw Error('Collega prima un FM-1 con Meighty.');return new FM1M8Installer.Projects(installer.link);};
$('readBank').onclick=()=>run(async()=>{$('result').hidden=true;output=null;try{const m=await MeightyBackup.backup(api(),C.empty,progress);download(jsonBytes(F.bank(m)),'Meighty-backup-'+new Date().toISOString().slice(0,10)+'.meighty');status('Backup verificato. Premi Scarica il file oppure Condividi / Salva in File.',false,100);}catch(e){if(e.recovery){const {model:m,unreadable,workingRaw}=e.recovery,files=[];if(workingRaw)files.push({name:"RAM-NON-VALIDA-da-recuperare.fm1tracker.json",bytes:jsonBytes(workingRaw)});m.slots.forEach((p,i)=>{if(p)files.push({name:'Slot-'+(i+1)+'.fm1tracker.json',bytes:jsonBytes(p)});});if(m.working)files.push({name:'In-lavorazione.fm1tracker.json',bytes:jsonBytes(m.working)});files.push({name:'LEGGIMI-recupero.txt',bytes:E.encode(e.message+'\nQuesto ZIP NON è un backup completo. Nessuno slot illeggibile è stato cancellato o sostituito.\n')},{name:'Slot-illeggibili.json',bytes:jsonBytes(unreadable)});download(zip(files),'Meighty-recupero-PARZIALE.zip','application/zip');}throw e;}});
$('readWorking').onclick=()=>run(async()=>{$('result').hidden=true;output=null;const d=await api().read(255);let p;try{p=F.project(d,255,'In lavorazione');}catch(e){p=FM1M8Installer.projectFile(d,255);download(jsonBytes(p),'Meighty-RAM-NON-VALIDA-da-recuperare.fm1tracker.json');status('RAM conservata senza modifiche, ma contiene parametri non validi: '+e.message+'. Questo è un file di recupero, non un progetto pronto per il ripristino.',true);return;}download(jsonBytes(p),'Meighty-in-lavorazione.fm1tracker.json');status('Progetto in lavorazione esportato. Non è stato scritto in uno slot.');});
function invalidate(){prepared=null;$('restoreConsent').checked=false;$('restorePlan').textContent='';sync();}
function showIncoming(m,keepPositions=false){incoming=m;invalidate();const songs=m.slots.filter(Boolean);if(m.working)songs.push(m.working);$('singleTargetBox').hidden=songs.length!==1||!!m.restoreTargets||keepPositions;$('restoreMode').value='merge';$('restoreSummary').textContent=incoming.slots.map((p,i)=>'Slot '+(i+1)+': '+(p?p.name:'vuoto')).join(' · ')+(m.working?' · RAM: '+m.working.name:'');sync();}
$('restoreFile').onchange=()=>{incoming=null;invalidate();run(async()=>{const file=$('restoreFile').files[0];if(!file)return;showIncoming(await F.read(await readFile(file),options()));status('File aperto e verificato. Scegli la destinazione e collega FM-1. Nessuna scrittura eseguita.');});};
$('singleTarget').onchange=invalidate;
$('restoreMode').onchange=invalidate;
$('prepareRestore').onclick=()=>run(async()=>{
 prepared=null;$('restoreConsent').checked=false;if(!incoming)throw Error('Scegli prima un backup o un brano con il selettore file.');
 const device=api();let m=incoming;
 if(!$('singleTargetBox').hidden){const song=incoming.slots.find(Boolean)||incoming.working,slots=Array(8).fill(null),n=Number($('singleTarget').value);slots[n]=F.project(F.data(song),n,song.name);m=F.model(slots);}
 const steps=MeightyBackup.plan(m,$('restoreMode').value,C.empty);if(!steps.length)throw Error('Nessun brano da caricare. Scegli un file con brani oppure Sostituisci tutto il set.');
 const before=await MeightyBackup.protectTargets(device,steps,progress);
 const body={targets:before.targets,backup:F.bank(before.model)};download(jsonBytes({format:'Meighty-backup-destinazioni',version:1,...body,sha256:F.sha(jsonBytesCompact(body))}),'Meighty-prima-del-ripristino-slot-'+before.targets.map(t=>t.slot).join('-')+'.meighty');
 prepared=steps;
 $('restorePlan').textContent=prepared.map(s=>'Slot '+(s.slot+1)+' → '+(s.empty?'progetto vuoto':s.project.name)).join('\n')||'Nessuno slot da modificare.';
 status('Backup delle sole destinazioni pronto. Scaricalo e conservalo, poi spunta la conferma. Gli altri slot e la RAM restano invariati.');
});
$('writeRestore').onclick=()=>run(async()=>{if(!prepared)throw Error('Premi prima 1. Prepara il ripristino. Seleziona il file e collega FM-1.');if(!$('restoreConsent').checked)throw Error('Conserva il backup delle destinazioni e spunta la conferma prima di scrivere.');const device=api(),plan=prepared;prepared=null;$('restoreConsent').checked=false;await MeightyBackup.restore(device,plan,progress);status('Slot riletti e verificati. Per suonare un brano scegli Global → Project slot → Load sull’FM-1.',false,100);});
function selectedSource(){return sources[Number($('sourceChoice').value)||0];}
function paintSources(){
 const sel=$('sourceChoice');sel.replaceChildren();sources.forEach((s,i)=>sel.add(new Option(s.name,i)));
 $('libraryInfo').textContent=sources.length+' file · '+library.length+' progetti disponibili';paintSource();paintComposer();
}
function songLine(p,i,downloadFn){
 const row=document.createElement('div');row.className='song';const num=document.createElement('span');num.className='slot';num.textContent=String(i+1).padStart(2,'0');row.append(num);
 const title=document.createElement('span');title.textContent=p?p.name:'Vuoto';if(!p)title.className='empty';row.append(title);
 const btn=document.createElement('button');btn.textContent='Estrai';btn.disabled=!p;btn.dataset.empty=String(!p);btn.onclick=downloadFn;row.append(btn);
 if(p){const info=F.summary(p),small=document.createElement('div');small.className='small';small.textContent=info.bpm+' BPM · '+info.rows+' righe Song';row.append(small);}return row;
}
function paintSource(){
 $('sourceSlots').replaceChildren();const s=selectedSource();if(s)s.model.slots.forEach((p,i)=>$('sourceSlots').append(songLine(p,i,()=>download(jsonBytes(p),'Slot-'+(i+1)+'-'+p.name+'.fm1tracker.json'))));sync();
}
$('sourceChoice').onchange=paintSource;
async function importFiles(files,target=null){
 files=Array.from(files);if(files.length+sources.length>32)throw Error('Apri al massimo 32 file per sessione.');
 let errors=[],added=[];
 for(const file of files){try{
  const m=await F.read(await readFile(file),options()),source={name:file.name,model:m};sources.push(source);
  m.slots.forEach((p,i)=>{if(p){const id=String(library.length);library.push({id,p,source:file.name,slot:i});added.push(id);if(target===null&&sources.length===1)choices[i]=id;}});
  if(m.working){const id=String(library.length);library.push({id,p:m.working,source:file.name,slot:255});added.push(id);}
 }catch(e){errors.push(file.name+': '+e.message);}}
 if(target!==null&&added.length===1)choices[target]=added[0];
 paintSources();status(errors.length?errors.join('\n'):!added.length?'Il file non contiene brani salvati né una copia in lavorazione. Gli slot restano vuoti.':target!==null&&added.length===1?'Brano caricato nello slot '+(target+1)+'. Gli altri slot sono invariati.':target!==null?'Il file contiene '+added.length+' brani: scegli quello desiderato nel menu dello slot '+(target+1)+'.':'File verificati. Estrai i brani o selezionali nel tuo set.',!!errors.length);
}
$('sourceFiles').onchange=()=>run(()=>importFiles($('sourceFiles').files));
function getSet(){const slots=choices.map((id,i)=>{if(id==='')return null;const entry=library.find(x=>x.id===id);if(!entry)throw Error('Selezione del set non valida.');const p=F.project(F.data(entry.p),i,entry.p.name);return $('tiffany').checked?F.tiffany(p):p;});return F.model(slots);}
function paintComposer(){
 $('composer').replaceChildren();for(let i=0;i<8;i++){
  const row=document.createElement('div');row.className='song';const num=document.createElement('span');num.className='slot';num.textContent=String(i+1).padStart(2,'0');row.append(num);
  const select=document.createElement('select');select.setAttribute('aria-label','Brano nello slot '+(i+1));select.add(new Option('Vuoto',''));
  for(const entry of library)select.add(new Option(entry.source+' · '+(entry.slot===255?'RAM':'slot '+(entry.slot+1))+' · '+entry.p.name,entry.id));
  select.value=choices[i];select.onchange=()=>{choices[i]=select.value;b.dataset.empty=String(select.value==='');b.disabled=busy||select.value==='';paintCount();};row.append(select);
  const actions=document.createElement('div');actions.className='row';
  const input=document.createElement('input');input.type='file';input.id='slotFile'+(i+1);input.setAttribute('aria-label','Carica brano nello slot '+(i+1));input.onchange=()=>{const files=Array.from(input.files);if(files.length)run(()=>importFiles(files,i));};actions.append(input);
  const b=document.createElement('button');b.textContent='Esporta brano';b.disabled=choices[i]==='';b.dataset.empty=String(b.disabled);b.onclick=()=>{const p=getSet().slots[i];download(jsonBytes(p),'Slot-'+(i+1)+'-'+p.name+'.fm1tracker.json');};actions.append(b);row.append(actions);$('composer').append(row);
 }
 paintCount();sync();
}
function paintCount(){$('setCount').textContent=choices.filter(x=>x!=='').length+' brani · '+choices.filter(x=>x==='').length+' posti vuoti';}
$('clearSet').onclick=()=>{choices.fill('');paintComposer();status('Selezione del nuovo set svuotata. I file originali sono conservati.');};
function exportModel(kind,m,name){const o=F.output(kind,m,{target:C.remote,emulator:C.emulator,name,dropWorking:$('dropWorking').checked});download(o.bytes,name+o.ext);status('File generato e verificato. Premi Scarica il file o Condividi / Salva in File.');}
$('exportSet').onclick=()=>run(async()=>exportModel('meighty',getSet(),$('setName').value));
$('exportSetState').onclick=()=>run(async()=>exportModel('state',getSet(),$('setName').value));
$('restoreSet').onclick=()=>{showIncoming(getSet(),true);tab('backup');status('Set pronto per FM-1. Collega lo strumento in questa pagina e premi 1. Prepara il ripristino.');};
$('convert').onclick=()=>run(async()=>{const s=selectedSource();if(s)exportModel($('convertFormat').value,s.model,safeName(s.name.replace(/\.[^.]+$/,''))+'-convertito');});
$('extractWorking').onclick=()=>{const p=selectedSource()?.model.working;if(p)download(jsonBytes(p),'Meighty-in-lavorazione.fm1tracker.json');};
/* ZIP "stored": standard CRC32 and UTF-8 names, no library/network required. */
function zip(files){
 const chunks=[],directory=[];let at=0;
 for(const f of files){const name=E.encode(f.name),sum=F.crc(f.bytes),h=new Uint8Array(30+name.length),v=new DataView(h.buffer);v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint16(6,0x800,true);v.setUint16(12,33,true);v.setUint32(14,sum,true);v.setUint32(18,f.bytes.length,true);v.setUint32(22,f.bytes.length,true);v.setUint16(26,name.length,true);h.set(name,30);chunks.push(h,f.bytes);
  const c=new Uint8Array(46+name.length),w=new DataView(c.buffer);w.setUint32(0,0x02014b50,true);w.setUint16(4,20,true);w.setUint16(6,20,true);w.setUint16(8,0x800,true);w.setUint16(14,33,true);w.setUint32(16,sum,true);w.setUint32(20,f.bytes.length,true);w.setUint32(24,f.bytes.length,true);w.setUint16(28,name.length,true);w.setUint32(42,at,true);c.set(name,46);directory.push(c);at+=h.length+f.bytes.length;
 }
 const dirSize=directory.reduce((n,b)=>n+b.length,0),end=new Uint8Array(22),v=new DataView(end.buffer);v.setUint32(0,0x06054b50,true);v.setUint16(8,files.length,true);v.setUint16(10,files.length,true);v.setUint32(12,dirSize,true);v.setUint32(16,at,true);const out=new Uint8Array(at+dirSize+22);let p=0;for(const b of [...chunks,...directory,end]){out.set(b,p);p+=b.length;}return out;
}
$('extractAll').onclick=()=>run(async()=>{
 const s=selectedSource();if(!s)return;const files=[],index=[];
 s.model.slots.forEach((p,i)=>{const name=p?'Slot-'+String(i+1).padStart(2,'0')+'-'+safeName(p.name)+'.fm1tracker.json':null;index.push({slot:i+1,name:p?.name||null,file:name});if(p)files.push({name,bytes:jsonBytes(p)});});
 files.push({name:'Indice-degli-8-slot.json',bytes:jsonBytes(index)},{name:'Backup-completo.meighty',bytes:jsonBytes(F.bank(s.model))});
 download(zip(files),'Meighty-slot-estratti.zip','application/zip');status('ZIP pronto: ogni brano ha il suo file; l’indice indica anche gli slot vuoti.');
});
globalThis.MeightyUI={zip};
try{pkg=FM1M8Installer.prepare(C.hardware);$('firmwareHash').textContent=pkg.sha256;status('Meighty '+C.version+' · pacchetto verificato. Scegli uno strumento.');}catch(e){status(e.message,true);}
paintComposer();tab(C.tab||'install');
if(C.section){$('innerNav').hidden=true;document.querySelector('header').hidden=true;document.querySelector('footer').hidden=true;
 if(C.section==='convert'){$('setCard').hidden=true;$('sourceSlots').hidden=true;$('extractAll').hidden=true;$('extractWorking').hidden=true;}
 if(C.section==='projects')$('conversion').hidden=true;
 document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>parent.postMessage({meightyTab:b.dataset.tab},'*'));
}sync();
})();
