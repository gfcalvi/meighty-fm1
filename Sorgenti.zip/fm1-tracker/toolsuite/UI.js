/* GPL-3.0-only WITH GPL-3.0-linking-exception. Local UI; no external requests. */
(()=>{'use strict';
const C=MEIGHTY_CONFIG,F=MeightyFiles,$=id=>document.getElementById(id),E=new TextEncoder();
let busy=false,installer=null,connected=false,pkg=null,incoming=null,prepared=null,sources=[],library=[];
const choices=Array(8).fill('');
let output=null;
// Same MIDIWeb iframe bridge as the verified Bloomy suite.
if(parent!==window&&typeof parent.navigator.requestMIDIAccess==='function')Object.defineProperty(navigator,'requestMIDIAccess',{configurable:true,value:options=>parent.navigator.requestMIDIAccess(options)});
function suiteBusy(on){if(parent!==window)parent.postMessage({meightyBusy:!!on},'*');}
window.addEventListener('message',async e=>{if(e.source!==parent||!e.data?.meightyDeactivate||busy)return;try{await installer?.disconnect();connected=false;prepared=null;identities();sync();parent.postMessage({meightyReleased:true},'*');}catch(err){status(err.message,true);}});
window.addEventListener('beforeunload',e=>{if(busy){e.preventDefault();e.returnValue='Trasferimento in corso';}});

function status(s,error=false,pct){$('status').textContent=s;$('status').className='status'+(error?' error':'');$('progress').hidden=pct===undefined;if(pct!==undefined)$('progress').value=pct;}
function sync(){
 const live=connected&&installer?.identity===C.hardware.product;
 document.querySelectorAll('.connect').forEach(b=>b.disabled=busy||connected||!navigator.requestMIDIAccess);
 document.querySelectorAll('.disconnect').forEach(b=>b.disabled=busy||!connected);
 ['readBank','readWorking'].forEach(id=>$(id).disabled=busy||!live);
 $('prepareRestore').disabled=busy||!live||!incoming;
 $('writeRestore').disabled=busy||!live||!prepared||!$('restoreConsent').checked;
 $('writeFirmware').disabled=busy||!connected||!pkg||!$('saved').checked||!$('consent').checked;
 ['convert','extractAll'].forEach(id=>$(id).disabled=busy||!sources.length);
 $('extractWorking').disabled=busy||!selectedSource()?.model.working;
 ['sourceFiles','restoreFile','restoreMode','layout','sourceChoice','convertFormat','setName','tiffany','clearSet','exportSet','exportSetState'].forEach(id=>$(id).disabled=busy);
 document.querySelectorAll('#composer select,#sourceSlots button,#composer button').forEach(b=>b.disabled=busy||b.dataset.empty==='true');
}
async function run(fn){if(busy)return;busy=true;suiteBusy(true);sync();try{await fn();}catch(e){status(e.message||String(e),true);}finally{busy=false;suiteBusy(false);if(installer&&!installer.link)connected=false;sync();}}
function readFile(file){return new Promise((resolve,reject)=>{if(file.size>4*1048576)return reject(Error('Il file supera 4 MiB.'));const r=new FileReader();r.onload=()=>resolve(new Uint8Array(r.result));r.onerror=()=>reject(Error('Lettura del file non riuscita.'));r.readAsArrayBuffer(file);});}
function options(){return{cores:C.cores,decoder:F.un64(C.decoder),base:Number($('layout').value)||undefined};}
function safeName(n){return String(n||'Meighty').replace(/[^\p{L}\p{N} _.-]/gu,'_').replace(/^\.+/,'').trim().slice(0,70)||'Meighty';}
function canShare(bytes,name,type){try{return !!(navigator.canShare&&navigator.share&&navigator.canShare({files:[new File([bytes],name,{type})]}));}catch(_){return false;}}
function saveOutput(){if(!output)return;const url=URL.createObjectURL(new Blob([output.bytes],{type:output.type})),a=document.createElement('a');a.href=url;a.download=output.name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),120000);}
function download(bytes,name,type='application/octet-stream'){
 const clean=String(name).replace(/[^\p{L}\p{N} _.-]/gu,'_').replace(/^\.+/,'').trim().slice(0,220)||'Meighty.meighty';
 output={bytes:new Uint8Array(bytes),name:clean,type};$('resultName').textContent=clean+' · '+bytes.length.toLocaleString('it-IT')+' byte';$('result').hidden=false;$('resultShare').hidden=!canShare(bytes,clean,type);$('result').scrollIntoView({block:'nearest'});
}
$('resultDownload').onclick=()=>{try{saveOutput();}catch(e){status('Download non riuscito: '+e.message,true);}};
$('resultShare').onclick=async()=>{if(!output)return;try{await navigator.share({files:[new File([output.bytes],output.name,{type:output.type})],title:'Salvataggio Meighty'});}catch(e){if(e.name!=='AbortError')status('Condivisione non disponibile: usa Scarica il file.',true);}};

const jsonBytes=j=>E.encode(JSON.stringify(j,null,2));
const progress=(f,s)=>status(s,false,Math.round(f*100));
function tab(name){document.querySelectorAll('.tab').forEach(s=>s.hidden=s.id!==name);document.querySelectorAll('[data-tab]').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.tab===name)));}
document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>tab(b.dataset.tab));
function identities(){document.querySelectorAll('.identity').forEach(x=>x.textContent=connected?'Collegato: '+installer.identity:'Nessuno strumento collegato');}
document.querySelectorAll('.connect').forEach(b=>b.onclick=()=>run(async()=>{
 const access=await navigator.requestMIDIAccess({sysex:true});installer=new FM1M8Installer.Installer(access,pkg,(s,n)=>status(s,false,n),{reconnect:60000,writeIdle:180000,idle:20000,settle:800});
 await installer.connect();connected=true;prepared=null;identities();
 if(installer.identity===C.hardware.product){await new FM1M8Installer.Projects(installer.link).info();status('Meighty collegato. Connessione verificata, nessuna scrittura eseguita.');}
 else status('Collegato '+installer.identity+'. Per conservare i dati di questo firmware usa il suo backup prima di installare Meighty.');
}));
document.querySelectorAll('.disconnect').forEach(b=>b.onclick=()=>run(async()=>{await installer?.disconnect();connected=false;prepared=null;identities();status('Porta MIDI liberata.');}));
['saved','consent','restoreConsent'].forEach(id=>$(id).onchange=sync);
$('writeFirmware').onclick=()=>run(async()=>{if(!connected||!$('saved').checked||!$('consent').checked)return;await installer.install();connected=false;identities();status('Trasferimento concluso. Verifica avvio e audio sul display dell’FM-1.',false,100);});
const api=()=>{if(!connected||installer.identity!==C.hardware.product)throw Error('Collega prima un FM-1 con Meighty.');return new FM1M8Installer.Projects(installer.link);};
$('readBank').onclick=()=>run(async()=>{const m=await MeightyBackup.backup(api(),C.empty,progress);download(jsonBytes(F.bank(m)),'Meighty-backup-'+new Date().toISOString().slice(0,10)+'.meighty');status('Backup verificato. Premi Scarica il file oppure Condividi / Salva in File.',false,100);});
$('readWorking').onclick=()=>run(async()=>{const p=F.project(await api().read(255),255,'In lavorazione');download(jsonBytes(p),'Meighty-in-lavorazione.fm1tracker.json');status('Progetto in lavorazione esportato. Non è stato scritto in uno slot.');});
function invalidate(){prepared=null;$('restoreConsent').checked=false;$('restorePlan').textContent='';sync();}
$('restoreFile').onchange=()=>{incoming=null;invalidate();run(async()=>{const file=$('restoreFile').files[0];if(!file)return;incoming=await F.read(await readFile(file),options());$('restoreSummary').textContent=incoming.slots.map((p,i)=>'Slot '+(i+1)+': '+(p?p.name:'vuoto')).join(' · ');status('Backup aperto e verificato. La macchina non è stata modificata.');});};
$('restoreMode').onchange=invalidate;
$('prepareRestore').onclick=()=>run(async()=>{
 prepared=null;$('restoreConsent').checked=false;if(!incoming)return;
 const before=await MeightyBackup.backup(api(),C.empty,progress);
 download(jsonBytes(F.bank(before)),'Meighty-prima-del-ripristino.meighty');
 prepared=MeightyBackup.plan(incoming,$('restoreMode').value,C.empty);
 $('restorePlan').textContent=prepared.map(s=>'Slot '+(s.slot+1)+' → '+(s.empty?'progetto vuoto':s.project.name)).join('\n')||'Nessuno slot da modificare.';
 status('Backup di sicurezza pronto. Premi Scarica il file o Condividi, conservalo, poi conferma il piano di ripristino.');
});
$('writeRestore').onclick=()=>run(async()=>{if(!prepared||!$('restoreConsent').checked)return;const plan=prepared;prepared=null;$('restoreConsent').checked=false;await MeightyBackup.restore(api(),plan,progress);status('Slot riletti e verificati. Per suonare un brano scegli Global → Project slot → Load sull’FM-1.',false,100);});
function selectedSource(){return sources[Number($('sourceChoice').value)||0];}
function paintSources(){
 const sel=$('sourceChoice');sel.replaceChildren();sources.forEach((s,i)=>sel.add(new Option(s.name,i)));
 $('libraryInfo').textContent=sources.length+' file · '+library.length+' progetti disponibili';paintSource();paintComposer();
}
function songLine(p,i,downloadFn){
 const row=document.createElement('div');row.className='song';const num=document.createElement('span');num.className='slot';num.textContent=String(i+1).padStart(2,'0');row.append(num);
 const title=document.createElement('span');title.textContent=p?p.name:'Vuoto';if(!p)title.className='empty';row.append(title);
 const btn=document.createElement('button');btn.textContent='Estrai';btn.disabled=!p;btn.dataset.empty=String(!p);btn.onclick=downloadFn;row.append(btn);
 if(p){const info=F.summary(p),small=document.createElement('div');small.className='small';small.textContent=info.bpm+' BPM · '+info.rows+' righe Song';row.append(small);}return row;
}
function paintSource(){
 $('sourceSlots').replaceChildren();const s=selectedSource();if(s)s.model.slots.forEach((p,i)=>$('sourceSlots').append(songLine(p,i,()=>download(jsonBytes(p),'Slot-'+(i+1)+'-'+p.name+'.fm1tracker.json'))));sync();
}
$('sourceChoice').onchange=paintSource;
$('sourceFiles').onchange=()=>run(async()=>{
 const files=Array.from($('sourceFiles').files);if(files.length+sources.length>32)throw Error('Apri al massimo 32 file per sessione.');
 let errors=[];
 for(const file of files){try{
  const m=await F.read(await readFile(file),options()),source={name:file.name,model:m};sources.push(source);
  m.slots.forEach((p,i)=>{if(p){const id=String(library.length);library.push({id,p,source:file.name,slot:i});if(sources.length===1)choices[i]=id;}});
  if(m.working)library.push({id:String(library.length),p:m.working,source:file.name,slot:255});
 }catch(e){errors.push(file.name+': '+e.message);}}
 paintSources();status(errors.length?errors.join('\n'):'File verificati. Estrai i brani o selezionali nel tuo set.',!!errors.length);
});
function getSet(){const slots=choices.map((id,i)=>{if(id==='')return null;const entry=library.find(x=>x.id===id);if(!entry)throw Error('Selezione del set non valida.');const p=F.project(F.data(entry.p),i,entry.p.name);return $('tiffany').checked?F.tiffany(p):p;});return F.model(slots);}
function paintComposer(){
 $('composer').replaceChildren();for(let i=0;i<8;i++){
  const row=document.createElement('div');row.className='song';const num=document.createElement('span');num.className='slot';num.textContent=String(i+1).padStart(2,'0');row.append(num);
  const select=document.createElement('select');select.setAttribute('aria-label','Brano nello slot '+(i+1));select.add(new Option('Vuoto',''));
  for(const entry of library)select.add(new Option(entry.source+' · '+(entry.slot===255?'RAM':'slot '+(entry.slot+1))+' · '+entry.p.name,entry.id));
  select.value=choices[i];select.onchange=()=>{choices[i]=select.value;paintComposer();};row.append(select);
  const b=document.createElement('button');b.textContent='Esporta brano';b.disabled=choices[i]==='';b.dataset.empty=String(b.disabled);b.onclick=()=>{const p=getSet().slots[i];download(jsonBytes(p),'Slot-'+(i+1)+'-'+p.name+'.fm1tracker.json');};row.append(b);$('composer').append(row);
 }
 $('setCount').textContent=choices.filter(x=>x!=='').length+' brani · '+choices.filter(x=>x==='').length+' posti vuoti';sync();
}
$('clearSet').onclick=()=>{choices.fill('');paintComposer();status('Selezione del nuovo set svuotata. I file originali sono conservati.');};
function exportModel(kind,m,name){const o=F.output(kind,m,{target:C.remote,emulator:C.emulator,name,dropWorking:$('dropWorking').checked});download(o.bytes,name+o.ext);status('File generato e verificato. Premi Scarica il file o Condividi / Salva in File.');}
$('exportSet').onclick=()=>run(async()=>exportModel('meighty',getSet(),$('setName').value));
$('exportSetState').onclick=()=>run(async()=>exportModel('state',getSet(),$('setName').value));
$('convert').onclick=()=>run(async()=>{const s=selectedSource();if(s)exportModel($('convertFormat').value,s.model,safeName(s.name.replace(/\.[^.]+$/,''))+'-convertito');});
$('extractWorking').onclick=()=>{const p=selectedSource()?.model.working;if(p)download(jsonBytes(p),'Meighty-in-lavorazione.fm1tracker.json');};
/* ZIP "stored": standard CRC32 and UTF-8 names, no library/network required. */
function zip(files){
 const chunks=[],directory=[];let at=0;
 for(const f of files){const name=E.encode(f.name),sum=F.crc(f.bytes),h=new Uint8Array(30+name.length),v=new DataView(h.buffer);v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint16(6,0x800,true);v.setUint16(12,33,true);v.setUint32(14,sum,true);v.setUint32(18,f.bytes.length,true);v.setUint32(22,f.bytes.length,true);v.setUint16(26,name.length,true);h.set(name,30);chunks.push(h,f.bytes);
  const c=new Uint8Array(46+name.length),w=new DataView(c.buffer);w.setUint32(0,0x02014b50,true);w.setUint16(4,20,true);w.setUint16(6,20,true);w.setUint16(8,0x800,true);w.setUint16(14,33,true);w.setUint32(16,sum,true);w.setUint32(20,f.bytes.length,true);w.setUint32(24,f.bytes.length,true);w.setUint16(28,name.length,true);w.setUint32(42,at,true);c.set(name,46);directory.push(c);at+=h.length+f.bytes.length;
 }
 const dirSize=directory.reduce((n,b)=>n+b.length,0),end=new Uint8Array(22),v=new DataView(end.buffer);v.setUint32(0,0x06054b50,true);v.setUint16(8,files.length,true);v.setUint16(10,files.length,true);v.setUint32(12,dirSize,true);v.setUint32(16,at,true);const out=new Uint8Array(at+dirSize+22);let p=0;for(const b of [...chunks,...directory,end]){out.set(b,p);p+=b.length;}return out;
}
$('extractAll').onclick=()=>run(async()=>{
 const s=selectedSource();if(!s)return;const files=[],index=[];
 s.model.slots.forEach((p,i)=>{const name=p?'Slot-'+String(i+1).padStart(2,'0')+'-'+safeName(p.name)+'.fm1tracker.json':null;index.push({slot:i+1,name:p?.name||null,file:name});if(p)files.push({name,bytes:jsonBytes(p)});});
 files.push({name:'Indice-degli-8-slot.json',bytes:jsonBytes(index)},{name:'Backup-completo.meighty',bytes:jsonBytes(F.bank(s.model))});
 download(zip(files),'Meighty-slot-estratti.zip','application/zip');status('ZIP pronto: ogni brano ha il suo file; l’indice indica anche gli slot vuoti.');
});
globalThis.MeightyUI={zip};
try{pkg=FM1M8Installer.prepare(C.hardware);$('firmwareHash').textContent=pkg.sha256;status('Meighty 1.00 · pacchetto verificato. Scegli uno strumento.');}catch(e){status(e.message,true);}
paintComposer();tab(C.tab||'install');
if(C.section){$('innerNav').hidden=true;document.querySelector('header').hidden=true;document.querySelector('footer').hidden=true;
 if(C.section==='convert'){$('setCard').hidden=true;$('sourceSlots').hidden=true;$('extractAll').hidden=true;$('extractWorking').hidden=true;}
 if(C.section==='projects')$('conversion').hidden=true;
 document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>parent.postMessage({meightyTab:b.dataset.tab},'*'));
}sync();
})();
