/* GPL-3.0-only WITH GPL-3.0-linking-exception. Data only, no firmware commands. */
globalThis.MeightyBackup=(()=>{'use strict';
const F=MeightyFiles;
async function backup(api,empty,onProgress=()=>{}){
 const slots=[];
 for(let i=0;i<8;i++){onProgress(i/9,'Lettura slot '+(i+1)+' di 8');try{const d=await api.read(i);slots.push(F.sha(d)===empty.sha256?null:F.project(d,i));}catch(e){if(e.status===7)slots.push(null);else throw e;}}
 onProgress(8/9,'Lettura progetto in lavorazione');const working=F.project(await api.read(255),255,'In lavorazione');onProgress(1,'Backup verificato');return F.model(slots,working);
}
function plan(m,mode,empty){
 m=F.model(m.slots,m.working);F.data(empty);
 return m.slots.flatMap((p,i)=>p?[{slot:i,project:p,empty:false}]:mode==='replace'?[{slot:i,project:F.project(F.data(empty),i,'Vuoto'),empty:true}]:[]);
}
async function restore(api,steps,onProgress=()=>{}){
 /* Validate the whole plan before the first write, including unique targets. */
 const seen=new Set();for(const s of steps){if(!Number.isInteger(s.slot)||s.slot<0||s.slot>7||seen.has(s.slot))throw Error('Piano slot non valido.');seen.add(s.slot);F.data(s.project);}
 for(let i=0;i<steps.length;i++){const s=steps[i];onProgress(i/steps.length,'Scrittura e verifica slot '+(s.slot+1));await api.write(s.slot,F.data(s.project));}
 onProgress(1,'Ripristino completato e verificato');
}
return{backup,plan,restore};
})();
