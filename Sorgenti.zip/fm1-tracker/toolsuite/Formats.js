/* GPL-3.0-only WITH GPL-3.0-linking-exception. Meighty offline interchange. */
globalThis.MeightyFiles=(()=>{'use strict';
const E=new TextEncoder(),D=new TextDecoder(),SIZE=11940,FLASH=1048576,MAGIC=0x31505254;
const fail=s=>{throw Error(s);},u32=(b,o)=>new DataView(b.buffer,b.byteOffset,b.byteLength).getUint32(o,true);
const wr=(b,o,n)=>new DataView(b.buffer,b.byteOffset,b.byteLength).setUint32(o,n,true);
const sha=b=>FM1M8Installer.sha256(b);
function crc(b){let c=0xffffffff;for(const x of b){c^=x;for(let n=0;n<8;n++)c=(c>>>1)^(0xedb88320&-(c&1));}return(c^0xffffffff)>>>0;}
function b64(b){let s='';for(let i=0;i<b.length;i+=8192)s+=String.fromCharCode(...b.subarray(i,i+8192));return btoa(s);}
function un64(s){if(typeof s!=='string'||s.length%4||/[^A-Za-z0-9+/=]/.test(s))fail('Base64 non valido.');let b;try{b=Uint8Array.from(atob(s),c=>c.charCodeAt(0));}catch(_){fail('Base64 non valido.');}if(b64(b)!==s)fail('Base64 non canonico.');return b;}
function normalize(raw){
 if(![10788,11812,SIZE].includes(raw.length))fail('Versione progetto non supportata: '+raw.length+' byte.');
 const p=new Uint8Array(SIZE);p.set(raw);
 if(raw.length===10788)for(let n=0;n<32;n++){
  let at=10788+n*32;p[at+1]=24;
  for(let k=0;k<4;k++)p.set([1+k,k?150:255,0,64,200,48],at+2+k*6);
  p[at+27]=1;p[at+28]=24;p[at+29]=p[at+30]=128;
 }
 if(raw.length<SIZE)p.fill(128,11812);
 validate(p);return p;
}
function validate(p){
 const ck=(ok,s)=>{if(!ok)fail('Progetto non valido: '+s);};ck(p.length===SIZE,'dimensione');
 const v=new DataView(p.buffer,p.byteOffset,p.byteLength),bpm=v.getUint16(9266,true);
 ck(bpm>=30&&bpm<=300&&p[6944]>=1&&p[6944]<=32,'tempo o lunghezza Song');
 ck(p[9854]===1&&p[10784]<=1&&p[10786]<=9&&p[10787]<=11,'mixer/scala');
 ck(p[9846]<=17&&p[9847]<=240&&p[9848]<=1&&p[9850]<=224,'effetti master');
 for(let i=6688;i<6944;i++)ck(p[i]<32||p[i]===255,'Chain Song');
 for(let c=0;c<32;c++){let a=6144+c*17;ck(p[a+16]>=1&&p[a+16]<=16,'lunghezza Chain');for(let k=0;k<16;k++)ck(p[a+k]<64||p[a+k]===255,'Phrase Chain');}
 for(let a=0;a<6144;a+=6){ck(p[a]<=127||p[a]>=254,'nota');ck(p[a+1]<32||p[a+1]===255,'strumento');ck(p[a+2]<57&&p[a+4]<57,'FX Phrase');}
 for(let t=0;t<16;t++){let a=6945+t*129;ck(p[a+128]>=1&&p[a+128]<=16,'lunghezza Table');for(let k=0;k<16;k++){let r=a+k*8,x=p[r]>127?p[r]-256:p[r];ck(x>=-96&&x<=96&&p[r+2]<57&&p[r+4]<57&&p[r+6]<57,'riga Table');}}
 for(let n=0;n<32;n++){
  let i=9009+n*8,s=9856+n*23,e=10788+n*32;
  ck(p[i]<18&&p[i+7]<33&&(p[i+1]<16||p[i+1]===255),'motore/campione/Table');
  ck(p[9780+n]<=2&&p.subarray(9268+n*16,9284+n*16).includes(0),'sorgente/nome');
  ck(p[10592+n*6]<=1&&p[s]<=1&&p[s+6]<=3&&p[s+10]<=3&&p[s+17]<=3,'inviluppi/LFO');
  ck(p[e]<=7&&p[e+26]<=3&&p[e+27]<=3&&p[e+28]<=48&&p[e+31]<=1,'FM4/wavetable');
  for(let k=0;k<4;k++)ck(p[e+2+k*6]<=14,'rapporto FM4');
 }
 return p;
}
function project(raw,slot=0,name=''){const p=normalize(raw);return{format:'FM1-Tracker-A03',schema:1,slot,name:String(name||'Song '+(slot+1)).slice(0,80),data:b64(p),sha256:sha(p)};}
function data(p){if(!p||p.format!=='FM1-Tracker-A03'||p.schema!==1)fail('Serve un progetto Meighty.');const b=un64(p.data);if(sha(b)!==p.sha256)fail('SHA-256 del progetto errato.');return normalize(b);}
function model(slots,working=null){if(!Array.isArray(slots)||slots.length!==8)fail('La banca deve contenere esattamente 8 slot.');return{slots:slots.map((p,i)=>p===null?null:project(data(p),i,p.name)),working:working?project(data(working),255,working.name||'In lavorazione'):null};}
function bank(m){m=model(m.slots,m.working);const body={projectBytes:SIZE,slots:m.slots,working:m.working};return{format:'Meighty-backup',version:1,...body,sha256:sha(E.encode(JSON.stringify(body)))};}
function parseJSON(j){
 if(j.format==='Meighty-backup-destinazioni'){
  if(sha(E.encode(JSON.stringify({targets:j.targets,backup:j.backup})))!==j.sha256)fail('Integrità del backup delle destinazioni non valida.');
  if(j.version!==1||!Array.isArray(j.targets)||!j.targets.length)fail('Backup delle destinazioni non valido.');
  const seen=new Set();for(const t of j.targets){if(!Number.isInteger(t.slot)||t.slot<1||t.slot>8||seen.has(t.slot)||typeof t.empty!=='boolean')fail('Destinazioni del backup non valide.');seen.add(t.slot);}
  const m=parseJSON(j.backup);if(m.slots.some((p,i)=>p&&!seen.has(i+1)))fail('Contenuto fuori dalle destinazioni dichiarate.');
  for(const t of j.targets)if(t.empty!==!m.slots[t.slot-1])fail('Contenuto delle destinazioni incoerente.');
  m.restoreTargets=j.targets;return m;
 }
 if(j.format==='Meighty-backup'){
  const body={projectBytes:j.projectBytes,slots:j.slots,working:j.working};
  if(j.version!==1||j.projectBytes!==SIZE||sha(E.encode(JSON.stringify(body)))!==j.sha256)fail('Integrità o versione del backup Meighty non valida.');return model(j.slots,j.working);
 }
 if(j.format==='FM1-M8-bank'){if(j.schema!==1)fail('Versione banca legacy non supportata.');j.slots?.forEach((p,i)=>{if(p&&p.slot!==i)fail('Ordine slot legacy incoerente.');});return model(j.slots);}
 if(j.format==='FM1-Tracker-A03'){const slots=Array(8).fill(null);const i=Number.isInteger(j.slot)&&j.slot>=0&&j.slot<8?j.slot:0;slots[i]=project(data(j),i,j.name);return model(slots);}
 fail('Formato JSON non riconosciuto. Un backup Bloomy non è un progetto Meighty.');
}
function flashWrite(m,base=0xaf000){
 m=model(m.slots);const b=new Uint8Array(FLASH).fill(255);
 m.slots.forEach((p,i)=>{if(!p)return;const d=data(p),at=base+i*0x6000;[MAGIC,1,SIZE,1,crc(d),0].forEach((x,k)=>wr(b,at+k*4,x));b.set(d,at+24);});return b;
}
function flashRead(b,chosenBase){
 if(b.length!==FLASH)fail('Immagine flash: attesi 1048576 byte.');
 const scan=base=>{let valid=0,foreign=0;const slots=[];
  for(let i=0;i<8;i++){
   const good=[];let occupied=false;
   for(let k=0;k<2;k++){
    const at=base+i*0x6000+k*0x3000,part=b.subarray(at,at+0x3000);if(part.some(x=>x!==255))occupied=true;
    if(u32(b,at)!==MAGIC||u32(b,at+4)!==1||u32(b,at+20)!==0)continue;
    const n=u32(b,at+8);if(![10788,11812,SIZE].includes(n))continue;
    const d=b.subarray(at+24,at+24+n);if(crc(d)!==u32(b,at+16))continue;
    try{good.push({gen:u32(b,at+12),data:normalize(d)});}catch(_){}
   }
   if(good.length){let best=good[0];if(good[1]&&((good[1].gen-best.gen)|0)>0)best=good[1];slots.push(project(best.data,i));valid++;}
   else{slots.push(null);if(occupied)foreign++;}
  }return{base,slots,valid,foreign};
 };
 const options=[0xaf000,0xb6000].map(scan);let pick=chosenBase?options.find(x=>x.base===chosenBase):null;
 if(!pick){const good=options.filter(x=>x.valid);if(good.length>1)fail('Sono presenti due mappe valide: scegli esplicitamente hardware/RemoteFM1 oppure Emulator storico.');pick=good[0]||options.find(x=>!x.foreign);}
 if(!pick||pick.foreign)fail('Slot corrotti o dati di un altro firmware: la conversione è stata fermata.');
 return model(pick.slots);
}
async function decompress(body,wasm){
 const {instance}=await WebAssembly.instantiate(wasm,{wasi_snapshot_preview1:{fd_close:()=>8,fd_write:()=>8,fd_seek:()=>8,proc_exit:()=>fail('Errore LZFSE')}}),x=instance.exports;
 x._initialize?.();const a=x.malloc(body.length),b=x.malloc(FLASH+1);if(!a||!b)fail('Memoria LZFSE insufficiente.');
 try{new Uint8Array(x.memory.buffer).set(body,a);const n=x.decode_flash(b,FLASH+1,a,body.length);if(n!==FLASH)fail('Stato LZFSE non valido.');return new Uint8Array(x.memory.buffer,b,n).slice();}finally{x.free(a);x.free(b);}
}
async function read(bytes,options={}){
 const b=new Uint8Array(bytes);if(!b.length||b.length>4*FLASH)fail('Dimensione file non valida.');
 if(D.decode(b.subarray(0,8))==='RFM1STAT'){
  const n=u32(b,8);if(n<1||n>65536||12+n>b.length)fail('Manifest stato non valido.');
  const meta=JSON.parse(D.decode(b.subarray(12,12+n))),s=meta.state;
  if(meta.format!==1||s?.firmwareID!=='fm1_m8'||s.kind!=='wasm'||!(options.cores||[]).includes(s.sha256))fail('Questo stato non appartiene a un core Meighty qualificato.');
  if(s.flashSize!==FLASH||meta.flashBytes!==b.length-12-n)fail('Dimensione stato incoerente.');
  const flash=meta.flashEncoding==='none'?b.slice(12+n):meta.flashEncoding==='lzfse'?await decompress(b.subarray(12+n),options.decoder):fail('Compressione non supportata.');
  if(sha(flash)!==s.flashSHA256)fail('SHA-256 dello stato errato.');return flashRead(flash,options.base);
 }
 if(b.length===FLASH)return flashRead(b,options.base);
 let j;try{j=JSON.parse(D.decode(b).replace(/^\uFEFF/,''));}catch(_){fail('Formato non riconosciuto: scegli un backup Meighty, progetto, stato o .fm1save.');}
 if(j.format==='fm1-emulator-save'){
  if(j.version!==1||!Array.isArray(j.sectors)||j.sectors.length>256)fail('Salvataggio Emulator non valido.');
  if(j.package){const pkg=un64(j.package);if(sha(pkg)!==j.hash)fail('SHA-256 del firmware nello stato Emulator errato.');}
  const flash=new Uint8Array(FLASH).fill(255),seen=new Set();
  for(const s of j.sectors){if(!Number.isInteger(s.at)||s.at<0||s.at%4096||s.at>FLASH-4096||seen.has(s.at))fail('Settori Emulator sovrapposti o fuori limite.');const d=un64(s.data);if(d.length!==4096)fail('Settore Emulator troncato.');seen.add(s.at);flash.set(d,s.at);}
  return flashRead(flash,options.base);
 }
 return parseJSON(j);
}
function stateWrite(m,target,name){
 const flash=flashWrite(m),state={id:'meighty-set',name:name||'Meighty set',firmwareID:'fm1_m8',firmwareName:target.name,kind:'wasm',version:target.version,sha256:target.sha256,date:Date.now()/1000,flashSize:FLASH,flashSHA256:sha(flash),master:512,transpose:0,keyTouch:false,origin:'app'};
 const meta=E.encode(JSON.stringify({format:1,state,flashEncoding:'none',flashBytes:FLASH})),b=new Uint8Array(12+meta.length+FLASH);b.set(E.encode('RFM1STAT'));wr(b,8,meta.length);b.set(meta,12);b.set(flash,12+meta.length);return b;
}
function emulatorWrite(m,firmware){
 const flash=flashWrite(m,0xb6000),sectors=[];
 for(let i=0;i<8;i++)for(let k=0;k<3;k++){const at=0xb6000+i*0x6000+k*4096;if(m.slots[i])sectors.push({at,data:b64(flash.subarray(at,at+4096))});}
 return E.encode(JSON.stringify({format:'fm1-emulator-save',version:1,name:'Meighty set',hash:firmware.sha256,package:firmware.data,sectors}));
}
function output(kind,m,options={}){
 m=model(m.slots,m.working);if(m.working&&kind!=='meighty'&&!options.dropWorking)fail('Il formato scelto conserva gli slot salvati, non la RAM: salva prima il progetto in uno slot o conferma l’esclusione della RAM.');
 if(kind==='meighty')return{bytes:E.encode(JSON.stringify(bank(m))),ext:'.meighty'};
 if(kind==='legacy')return{bytes:E.encode(JSON.stringify({format:'FM1-M8-bank',schema:1,slots:m.slots})),ext:'.fm1bank.json'};
 if(kind==='state')return{bytes:stateWrite(m,options.target,options.name),ext:'.rfm1state'};
 if(kind==='save')return{bytes:emulatorWrite(m,options.emulator),ext:'.fm1save'};
 fail('Formato di uscita non disponibile.');
}
function summary(p){const d=data(p);return{bpm:d[9266]+256*d[9267],rows:d[6944],scale:d[10786],root:d[10787],name:p.name};}
function tiffany(p){const d=data(p);d[9855]=0x2a;d[10785]=0x57;return project(d,p.slot,p.name);}
return{SIZE,FLASH,sha,crc,b64,un64,normalize,validate,project,data,model,bank,read,output,flashWrite,flashRead,summary,tiffany};
})();
