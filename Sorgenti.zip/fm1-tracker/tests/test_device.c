/* SPDX-License-Identifier: GPL-3.0-only WITH GPL-3.0-linking-exception */
#include "tracker/tracker.h"
#include "tracker/ui.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static struct fm1_controls controls;
static unsigned draws,irq_depth;
#ifndef TEST_FLASH_BYTES
#define TEST_FLASH_BYTES 536576
#endif
static uint8_t store_flash[TEST_FLASH_BYTES];static int flash_fail=-1;
uint32_t fm1_flash_size(void){return sizeof store_flash;}
int fm1_flash_read(uint32_t at,void *data,size_t n){assert(!irq_depth);if(at>sizeof store_flash||n>sizeof store_flash-at)return -1;memcpy(data,store_flash+at,n);return 0;}
int fm1_flash_erase(uint32_t at){assert(!irq_depth);if(at%4096||at>sizeof store_flash-4096)return -1;if(flash_fail==0)return -1;if(flash_fail>0)--flash_fail;memset(store_flash+at,255,4096);return 0;}
int fm1_flash_write(uint32_t at,const void *data,size_t n){assert(!irq_depth);if(at>sizeof store_flash||n>sizeof store_flash-at)return -1;if(flash_fail==0)return -1;if(flash_fail>0)--flash_fail;const uint8_t *src=data;for(size_t i=0;i<n;i++)if((store_flash[at+i]&src[i])!=src[i])return -1;memcpy(store_flash+at,data,n);return 0;}
static uint16_t framebuffer[240*240];
uint32_t fm1_device_irq_save(void){return irq_depth++;}
void fm1_device_irq_restore(uint32_t s){assert(irq_depth==s+1);irq_depth=s;}
void fm1_controls_read(struct fm1_controls *c){*c=controls;memset(controls.encoders,0,sizeof controls.encoders);}
int groove_master_update(unsigned adc){(void)adc;return 0;}
uint32_t fm1_millis(void){static uint32_t n;n+=50;return n;}
void fm1_screen_fill(unsigned x,unsigned y,unsigned w,unsigned h,uint16_t rgb){(void)rgb;assert(!irq_depth&&x+w<=240&&y+h<=240);}
int fm1_screen_blit(unsigned x,unsigned y,unsigned w,unsigned h,const uint16_t *p,size_t n){assert(!irq_depth&&p&&x+w<=240&&y+h<=240&&n>=w*h);for(unsigned row=0;row<h;row++)for(unsigned col=0;col<w;col++)framebuffer[(y+row)*240+x+col]=p[row*w+col];draws++;return 0;}
static void capture(const char *name){
 char path[128];snprintf(path,sizeof path,"build/tracker-host/lcd-%s.ppm",name);
 FILE *f=fopen(path,"wb");assert(f);fprintf(f,"P6\n240 240\n255\n");
 for(unsigned n=0;n<240*240;n++){unsigned v=framebuffer[n];fputc(((v>>11)&31)*255/31,f);fputc(((v>>5)&63)*255/63,f);fputc((v&31)*255/31,f);}fclose(f);
}

/* Exercise the actual hardware dispatcher against simulated transactional NOR. */
static uint32_t ms;static int tr_flash_ok=1,tr_recovery=1,abuf[1],isr_alnk0;
static uint8_t ota_dec[640],protocol_pending;static unsigned protocol_size;
static void fm1_audio_stop(void){}static void fm1_audio_init(void *a,int b,int c,int d){(void)a;(void)b;(void)c;(void)d;}
static uint32_t ota_rd32(const uint8_t *p){return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static void ota_wr32(uint8_t *p,uint32_t n){for(unsigned i=0;i<4;i++)p[i]=n>>(i*8);}
static unsigned ota_pack7(const uint8_t *p,unsigned n,uint8_t *o){memcpy(o,p,n);return n;}
static unsigned ota_take(void){if(!protocol_pending)return 0;protocol_pending=0;return protocol_size;}
static unsigned test_identity_replies;
static void __attribute__((unused)) ota_reply_identity(void){++test_identity_replies;}
static int ota_wire_send(const uint8_t *p,unsigned n){(void)p;(void)n;return 0;}
#ifdef TEST_HARDWARE_DIAGNOSTICS
#define FM1_AUDIO_DIAGNOSTICS 1
#define FM1_CLK_CON2 6u
static unsigned emu_max_ticks=24000,tr_audio_late=3,emu_misses=4,tr_master_gain=2048;
static uint8_t test_diag_reply[27];
static void ota_send_msg(unsigned cmd,const uint8_t *p,unsigned n){assert(cmd==17&&n==27);memcpy(test_diag_reply,p,n);}
#endif
#include "../hardware/projects.inc"
static unsigned project_request(unsigned cmd,const void *p,unsigned n){ota_dec[2]=cmd;if(n)memcpy(ota_dec+6,p,n);protocol_pending=1;protocol_size=n+7;tr_project_service();return tr_project_reply[6];}
static void test_project_protocol(void){
 static TrProject original,received,previous;original=*tracker_ui_project();assert(!tracker_ui_slot_export(6,&previous));
 assert(project_request(0x60,0,0)==0&&tr_project_reply[7]==1&&tr_project_reply[8]==8);
 uint8_t q[264]={255};assert(project_request(0x61,q,1)==0);assert(ota_rd32(tr_project_reply+7)==sizeof original);
 for(unsigned at=0;at<sizeof original;at+=256){unsigned n=sizeof original-at;if(n>256)n=256;ota_wr32(q,at);q[4]=n;q[5]=n>>8;assert(!project_request(0x62,q,6));memcpy((uint8_t *)&received+at,tr_project_reply+7,n);}
 assert(!memcmp(&original,&received,sizeof original));
 q[0]=6;ota_wr32(q+1,sizeof original);ota_wr32(q+5,tr_project_crc(&original,sizeof original));assert(!project_request(0x63,q,9));
 ota_wr32(q,1);q[4]=0;assert(project_request(0x64,q,5)==9);assert(project_request(0x65,0,0)==10);assert(!tracker_ui_slot_export(6,&received));assert(!memcmp(&previous,&received,sizeof previous));
 q[0]=6;ota_wr32(q+1,sizeof original);ota_wr32(q+5,tr_project_crc(&original,sizeof original));assert(!project_request(0x63,q,9));
 for(unsigned at=0;at<sizeof original;at+=256){unsigned n=sizeof original-at;if(n>256)n=256;ota_wr32(q,at);memcpy(q+4,(uint8_t *)&original+at,n);assert(!project_request(0x64,q,n+4));}
 assert(!project_request(0x65,0,0));assert(!tracker_ui_slot_export(6,&received));assert(!memcmp(&original,&received,sizeof original));assert(!memcmp(&original,tracker_ui_project(),sizeof original));
 q[0]=255;assert(!project_request(0x61,q,1));ms+=30001;ota_wr32(q,0);q[4]=1;q[5]=0;assert(project_request(0x62,q,6)==9);
 q[0]=8;assert(project_request(0x61,q,1)==4);
 puts("PASS physical project protocol: snapshot/chunks, ordered writes, failed commit preservation, slot readback, timeout, bounds");
}

int main(void){memset(store_flash,255,sizeof store_flash);
#ifdef TEST_HARDWARE_DIAGNOSTICS
 ota_dec[2]=17;protocol_pending=1;protocol_size=7;tr_project_service();
 assert(test_identity_replies==1);
 assert(project_request(0x67,0,0)==0&&tr_project_reply[7]==1&&tr_project_reply[10]==FM1_AUDIO_DIAG_VERSION);
 assert(ota_rd32(tr_project_reply+11)==1000&&ota_rd32(tr_project_reply+15)==3&&ota_rd32(tr_project_reply+19)==4);
 emu_max_ticks=0xffffffffu;tr_audio_late=emu_misses=0xffffffffu;assert(!project_request(0x67,0,0));
 assert(ota_rd32(tr_project_reply+15)==0xffffffffu&&ota_rd32(tr_project_reply+19)==0xffffffffu);
 puts("PASS standard identity dispatcher; diagnostics moved to 0x67 with full-width counters");
#endif
 int32_t out[256];tracker_device_render(out,128);for(unsigned n=0;n<256;n++)assert(!out[n]);
 tracker_device_init();for(unsigned i=0;i<32;i++)assert(tracker_ui_project()->instrument_source[i]>0);controls.buttons=1U<<12;tracker_device_control();controls.buttons=0;
 long long energy=0;
 for(unsigned b=0;b<350;b++){
  tracker_device_render(out,128);for(unsigned n=0;n<256;n++){assert(out[n]>=-8388608&&out[n]<=8388607);energy+=out[n]<0?-(long long)out[n]:out[n];}
 }
 assert(energy>100000);
 for(unsigned page=0;page<5;page++){
  controls.encoders[6]=1;tracker_device_control();
  if(page==0){
   FILE *image=fopen("build/tracker-host/phrase.ppm","wb");assert(image);fprintf(image,"P6\n240 240\n255\n");
   for(unsigned n=0;n<240*240;n++){unsigned v=framebuffer[n];fputc(((v>>11)&31)*255/31,image);fputc(((v>>5)&63)*255/63,image);fputc((v&31)*255/31,image);}fclose(image);
  }
  controls.encoders[1]=15;controls.encoders[2]=7;controls.encoders[3]=1;tracker_device_control();
 }
 controls.buttons=1U<<12;tracker_device_control();tracker_device_render(out,128);
 /* A resampler may retain one final internal sample until its next crossing. */
 tracker_device_render(out,128);for(unsigned n=0;n<256;n++)assert(!out[n]);
 assert(draws>19&&!irq_depth);
 assert(tracker_ui_set(1,0,0,0,64)==0&&tracker_ui_get(1,0,0,0)==64);
 assert(tracker_ui_set(1,0,0,0,128)<0&&tracker_ui_get(1,0,0,0)==64);
 assert(tracker_ui_set(2,0,0,0,-12)==0&&tracker_ui_get(2,0,0,0)==-12);
 assert(tracker_ui_set(2,0,0,2,FX_COUNT)<0);
 tracker_ui_play(1);assert(tracker_ui_tempo(130)==0&&tracker_ui_state(6)==1);
 TrProject valid=*tracker_ui_project(),bad=valid;bad.bpm=0;
 assert(tracker_ui_project_apply(&bad)<0&&tracker_ui_state(6)==1);
 assert(tracker_ui_project_apply(&valid)==0&&tracker_ui_state(6)==0);
const unsigned pages[]={0,3,1,4,2};
 for(unsigned i=0;i<5;i++){
  controls.buttons=0;tracker_device_control();
  controls.buttons=1U<<(i+2);tracker_device_control();
  assert(tracker_ui_state(0)==pages[i]);
 }
controls.buttons=0;tracker_device_control();tracker_ui_demo(1);
 const char *screens[]={"song","phrase","table","chain","instrument"};
 for(unsigned p=0;p<5;p++){
  assert(tracker_ui_select(p,7,p==0?31:p==4?0:12,p==2?7:p==4?7:0,0)==0);
  tracker_device_control();capture(screens[p]);
 }
 /* Native selected-note background and antialiased coverage are present. */
 assert(tracker_ui_select(1,0,0,0,0)==0);tracker_device_control();capture("phrase-top");
 assert(framebuffer[88*240+5]!=framebuffer[88*240+43]);
 unsigned partial=0;for(unsigned y=89;y<106;y++)for(unsigned x=7;x<37;x++)if(framebuffer[y*240+x]!=framebuffer[88*240+5]&&framebuffer[y*240+x]!=framebuffer[88*240+43])partial++;assert(partial>10);
 assert(tracker_ui_select(0,0,0,0,0)==0);controls.encoders[2]=2;controls.encoders[4]=1;tracker_device_control();assert(tracker_ui_state(1)==2&&tracker_ui_state(8)==2);capture("song-top");
 assert(tracker_ui_select(1,0,8,0,0)==0);tracker_device_control();capture("phrase-scroll");
assert(tracker_ui_select(4,0,0,0,0)==0);controls.encoders[4]=1;tracker_device_control();assert(tracker_ui_state(4)==1&&tracker_ui_state(3)==0);capture("instrument-id1");
assert(tracker_ui_preset_count()==177);
 TrProject before=*tracker_ui_project();assert(tracker_ui_preset_load(32,0)<0&&tracker_ui_preset_load(0,177)<0);assert(!memcmp(&before,tracker_ui_project(),sizeof before));
 for(unsigned p=0;p<177;p++){
  assert(tracker_ui_preset_load(0,p)==0&&tracker_ui_preset_match(0)==(int)p);
  TrProject patch=*tracker_ui_project();unsigned ch=tracker_ui_preset_pcm(p)?4:0;
  memset(patch.song,255,sizeof patch.song);patch.song[0][ch]=0;patch.song_length=1;patch.chains[0].phrase[0]=0;patch.chains[0].length=1;
  memset(patch.phrases[0].step,0,sizeof patch.phrases[0].step);for(unsigned n=0;n<16;n++){patch.phrases[0].step[n].note=255;patch.phrases[0].step[n].instrument=255;}
  patch.phrases[0].step[0].note=60;patch.phrases[0].step[0].instrument=0;
  assert(tracker_ui_project_apply(&patch)==0);tracker_ui_play(1);long long sound=0;
  for(unsigned block=0;block<100;block++){tracker_device_render(out,128);for(unsigned n=0;n<256;n++){assert(out[n]>=-8388608&&out[n]<=8388607);sound+=out[n]<0?-(long long)out[n]:out[n];}}
  assert(sound>10000);tracker_ui_play(0);
 }
 assert(tracker_ui_project_apply(&before)==0);assert(tracker_ui_select(4,0,0,0,0)==0);controls.buttons=1U<<10;tracker_device_control();capture("preset-browser");controls.buttons=0;tracker_device_control();controls.encoders[2]=2;tracker_device_control();controls.buttons=1U<<13;tracker_device_control();assert(tracker_ui_preset_match(0)==2);capture("preset-loaded");controls.buttons=0;tracker_device_control();TrInstrument neighbor=tracker_ui_project()->instruments[1];controls.encoders[5]=1;tracker_device_control();assert(tracker_ui_state(17)==1&&tracker_ui_state(18)==3&&tracker_ui_preset_match(0)==2);controls.buttons=1U<<13;tracker_device_control();assert(tracker_ui_state(17)==0&&tracker_ui_preset_match(0)==3&&tracker_ui_state(4)==0);assert(!memcmp(&neighbor,&tracker_ui_project()->instruments[1],sizeof neighbor));controls.buttons=0;tracker_device_control();
/* Preview is audible while stopped, releases cleanly, and owns no sequence voice. */
 tracker_ui_play(0);assert(tracker_ui_select(4,0,0,0,1)==0);assert(tracker_ui_preset_load(1,10)==0);
 assert(!strcmp(tracker_ui_instrument_name(1),"GLASS PLUCK"));assert(tracker_ui_set(4,1,0,3,100)==0);assert(!strcmp(tracker_ui_instrument_name(1),"GLASS PLUCK"));
 TrProject named=*tracker_ui_project();unsigned ticks=tracker_ui_state(7);assert(tracker_ui_audition(60)==0&&tracker_ui_state(11)==1);long long preview_energy=0;
 for(unsigned block=0;block<80;block++){tracker_device_render(out,128);for(unsigned n=0;n<256;n++)preview_energy+=out[n]<0?-(long long)out[n]:out[n];}
 assert(preview_energy>10000&&tracker_ui_state(6)==0&&tracker_ui_state(7)==ticks&&!memcmp(&named,tracker_ui_project(),sizeof named));
 tracker_ui_audition(-1);tracker_device_render(out,128);tracker_device_render(out,128);for(unsigned n=0;n<256;n++)assert(out[n]==0);
 /* Song previews the last sequenced instrument even after STOP resets voices. */
 named.song[0][0]=0;named.song_length=1;named.chains[0].phrase[0]=0;named.chains[0].length=1;named.phrases[0].step[0].note=60;named.phrases[0].step[0].instrument=3;
 assert(tracker_ui_project_apply(&named)==0);tracker_ui_play(1);tracker_device_render(out,128);tracker_ui_play(0);tracker_ui_select(0,0,0,0,0);tracker_ui_audition(64);assert(tracker_ui_state(11)==3);tracker_ui_audition(-1);
 tracker_ui_select(4,0,0,0,1);controls.keys=1;tracker_device_control();assert(tracker_ui_state(10)==1&&tracker_ui_state(11)==1);controls.keys=0;tracker_device_control();assert(tracker_ui_state(10)==0);capture("small-footer-named");
/* Source belongs to the instrument: PCM on track 1, synth on track 8. */
 Tracker route;tr_init(&route);static const int16_t constant_pcm[64]={10000,10000,10000,10000,10000,10000,10000,10000,10000,10000,10000,10000,10000,10000,10000,10000};
 TrSample pcm={constant_pcm,64,32000,60};assert(tr_set_sample(&route,0,&pcm)==0);
 route.project.instruments[0].volume=255;route.project.instruments[0].attack=255;route.project.instruments[0].cutoff=255;route.project.instruments[0].model=0;route.project.instruments[0].sample=0;
 route.project.song[0][0]=0;route.project.chains[0].phrase[0]=0;route.project.phrases[0].step[0].note=60;route.project.phrases[0].step[0].instrument=0;
 route.project.instrument_source[0]=2;tr_transport(&route,1);assert(tr_sample(&route)>0&&route.voice[0].sample_mode==1);
 route.project.song[0][0]=255;route.project.song[0][7]=0;route.project.instrument_source[0]=1;tr_transport(&route,1);assert(tr_sample(&route)<0&&route.voice[7].sample_mode==0);
 assert(tracker_ui_select(4,0,0,8,1)==0);assert(tracker_ui_set(4,1,0,8,2)<0);assert(tracker_ui_set(4,1,0,8,1)==0&&tracker_ui_get(4,1,0,8)==1);tracker_ui_audition(60);assert(tracker_ui_state(10)==1);tracker_ui_audition(-1);tracker_device_control();capture("source-sample");
 assert(tracker_ui_set(4,1,0,8,0)==0);assert(tracker_ui_set(4,1,0,0,1)==0);tracker_device_control();capture("source-synth");
 puts("PASS: per-instrument SYNTH/PCM routing on opposite track families and source bounds");
 puts("PASS: isolated keyboard audition, note release, stopped transport, retained Song instrument, persistent preset names");
puts("PASS: 177 named presets, valid bounds, audio on SYN/PCM tracks, native ARP/K1/REC loader");
tracker_ui_demo(1);tracker_ui_select(5,0,0,0,0);tracker_device_control();controls.encoders[2]=-30;controls.encoders[3]=-40;controls.encoders[4]=120;controls.encoders[5]=80;tracker_device_control();assert(tracker_ui_get(5,0,0,0)==225&&tracker_ui_get(5,0,0,1)==88&&tracker_ui_get(5,0,0,2)==120&&tracker_ui_get(5,0,0,3)==80);
 controls.buttons=0;tracker_device_control();controls.buttons=1U<<13;tracker_device_control();assert(tracker_ui_get(5,0,0,4)==1);controls.buttons=0;tracker_device_control();controls.buttons=1U<<10;tracker_device_control();assert(tracker_ui_get(5,0,0,5)==1);controls.buttons=0;tracker_device_control();capture("mixer");
 assert(tracker_ui_select(6,0,0,0,0)==0);assert(tracker_ui_set(6,0,0,0,11)==0&&tracker_ui_set(6,0,0,1,241)<0);tracker_device_control();capture("master-fx");
 TrProject fx_saved=*tracker_ui_project();assert(tracker_ui_project_apply(&fx_saved)==0&&tracker_ui_get(6,0,0,0)==11&&tracker_ui_get(5,0,0,2)==120&&tracker_ui_get(5,0,0,4)==1&&tracker_ui_get(5,0,0,5)==1);
 puts("PASS: native Mixer K1-K4, mute/solo, Master FX division, saved mixer/FX roundtrip");
assert(tracker_ui_preset_load(31,29)==0);assert(tracker_ui_select(4,0,0,8,31)==0);controls.buttons=0;tracker_device_control();capture("instrument-sound");
 controls.buttons=1U<<5;tracker_device_control();assert(tracker_ui_state(3)==9&&tracker_ui_state(4)==31);controls.buttons=0;tracker_device_control();capture("instrument-adsr");
 controls.buttons=1U<<13;tracker_device_control();assert(tracker_ui_state(3)==9&&tracker_ui_state(4)==31);controls.buttons=0;tracker_device_control();
 controls.buttons=1U<<5;tracker_device_control();assert(tracker_ui_state(3)==70&&tracker_ui_state(4)==31);controls.buttons=0;tracker_device_control();
 assert(tracker_ui_select(4,0,0,25,31)==0);tracker_device_control();capture("instrument-lfo");
 puts("PASS: Instrument button cycles two native pages, preserves slot, REC does not switch, full modulation UI bounds");
tracker_ui_demo(1);assert(tracker_ui_select(0,6,0,0,0)==0);controls.buttons=0;tracker_device_control();uint16_t lit_header[240*20];memcpy(lit_header,framebuffer+40*240,sizeof lit_header);controls.buttons=1U;tracker_device_control();assert(tracker_ui_get(5,0,6,4)==1);assert(memcmp(lit_header,framebuffer+40*240,sizeof lit_header));controls.buttons=0;tracker_device_control();controls.buttons=2U;tracker_device_control();assert(tracker_ui_get(5,0,6,5)==1&&tracker_ui_state(1)==6);controls.buttons=0;tracker_device_control();capture("song-mute-solo");
 controls.buttons=3U;tracker_device_control();assert(tracker_ui_get(5,0,6,4)==0&&tracker_ui_get(5,0,6,5)==0);controls.buttons=0;tracker_device_control();
 puts("PASS: Song OCT-minus mute/OCT-plus solo, toggle off, selected track 7, shared mixer masks");
assert(tracker_ui_select(4,0,0,32,31)==0);assert(tracker_ui_set(4,31,0,32,1)==0&&tracker_ui_set(4,31,0,32,2)<0);assert(tracker_ui_set(4,31,0,37,210)==0);tracker_device_control();capture("cutoff-envelope");
 tracker_ui_audition(60);tracker_device_render(out,128);tracker_device_control();capture("modulation-live");tracker_ui_audition(-1);
 controls.buttons=1U<<5;tracker_device_control();controls.buttons=0;tracker_device_control();capture("instrument-main-restored");assert(tracker_ui_state(3)==70);assert(tracker_ui_get(4,31,0,37)==210);
 assert(tracker_ui_set(6,0,0,8,1)==0&&tracker_ui_set(6,0,0,8,2)<0);assert(tracker_ui_select(6,0,0,8,0)==0);tracker_device_control();capture("ambient-master");
 puts("PASS: native cutoff envelope dashboard, live preview marker, main page redraw, ambient mode bounds");
controls.buttons=0;tracker_device_control();controls.buttons=1U<<7;tracker_device_control();assert(tracker_ui_state(0)==7);controls.buttons=0;tracker_device_control();assert(tracker_ui_set(7,0,0,0,147)==0&&tracker_ui_set(7,0,0,1,8)==0&&tracker_ui_set(7,0,0,2,9)==0);capture("global");
 controls.buttons=1U<<8;tracker_device_control();assert(tracker_ui_state(0)==5);controls.buttons=0;tracker_device_control();controls.buttons=1U<<11;tracker_device_control();assert(tracker_ui_state(0)==6);controls.buttons=0;tracker_device_control();
 assert(tracker_ui_select(1,0,0,0,0)==0);controls.encoders[5]=10;tracker_device_control();assert(tracker_ui_project()->bpm==147);
 assert(tracker_ui_project_save(0)==0);assert(tracker_ui_tempo(151)==0&&tracker_ui_project_save(0)==0);assert(tracker_ui_tempo(180)==0&&tracker_ui_project_load(0)==0&&tracker_ui_project()->bpm==151);assert(tracker_ui_project()->global_scale==8&&tracker_ui_project()->global_root==9);
 /* Fail each erase/write/commit boundary: the preceding committed generation survives. */
 uint8_t flash_before[sizeof store_flash];memcpy(flash_before,store_flash,sizeof flash_before);for(int fail=0;fail<6;fail++){memcpy(store_flash,flash_before,sizeof flash_before);flash_fail=fail;assert(tracker_ui_tempo(177)==0);assert(tracker_ui_project_save(0)<0);flash_fail=-1;assert(tracker_ui_project_load(0)==0&&tracker_ui_project()->bpm==151);assert(tracker_ui_tempo(179)==0&&tracker_ui_project_save(0)==0&&tracker_ui_project_load(0)==0&&tracker_ui_project()->bpm==179);}
 memcpy(store_flash,flash_before,sizeof flash_before);uint32_t base=sizeof store_flash-4096-16*3*4096;memset(store_flash+base+2*3*4096,0,2*3*4096);assert(!tracker_ui_project_load(1)&&tracker_ui_state(20)==1&&tracker_ui_project()->song[0][0]==TR_EMPTY);assert(!tracker_ui_tempo(179)&&!tracker_ui_project_save(1));assert(store_flash[base+2*3*4096]!=0);assert(!tracker_ui_project_load(1)&&tracker_ui_project()->bpm==179);assert(!tracker_ui_project_load(7)&&tracker_ui_state(14)==7&&tracker_ui_project()->bpm==120);
 assert(tracker_ui_select(7,0,0,0,0)==0&&tracker_ui_set(7,0,0,3,7)==0);unsigned before_save_bpm=tracker_ui_project()->bpm;controls.buttons=0;tracker_device_control();controls.encoders[3]=1;controls.buttons=1U<<9;tracker_device_control();controls.buttons=0;tracker_device_control();assert(tracker_ui_tempo(30)==0&&tracker_ui_project_load(7)==0&&tracker_ui_project()->bpm==before_save_bpm+1);
 assert(tracker_ui_select(7,0,0,0,0)==0&&tracker_ui_set(7,0,0,3,6)==0);assert(tracker_ui_tempo(163)==0);controls.buttons=0;tracker_device_control();controls.encoders[5]=1;tracker_device_control();assert(tracker_ui_state(15)==1);assert(tracker_ui_tempo(88)==0);controls.encoders[4]=-1;tracker_device_control();assert(tracker_ui_project()->bpm==163&&tracker_ui_state(15)==2);puts("PASS: Global K3 load and K4 save roundtrip");
 puts("PASS: Global GLO/HOME mixer/SEQ FX, global-only BPM, transactional project generations, interrupted saves and direct reuse of legacy slot bytes");
/* New wavetable destinations are reachable in Modulations, not the engine page. */
assert(tracker_ui_set(4,0,0,70,4)==0);assert(tracker_ui_select(4,0,0,24,0)==0);controls.buttons=0;controls.encoders[2]=1;tracker_device_control();assert(tracker_ui_state(3)==71);assert(tracker_ui_set(4,0,0,71,190)==0);assert(tracker_ui_set(4,0,0,72,66)==0);tracker_device_control();capture("lfo-wavetable");assert(tracker_ui_project_save(5)==0);assert(tracker_ui_set(4,0,0,71,128)==0);assert(tracker_ui_project_load(5)==0);assert(tracker_ui_get(4,0,0,71)==190&&tracker_ui_get(4,0,0,72)==66);
/* Main navigation excludes controls belonging to other sound sources. */
assert(tracker_ui_set(4,0,0,70,1)==0);assert(tracker_ui_select(4,0,0,70,0)==0);controls.encoders[2]=1;tracker_device_control();assert(tracker_ui_state(3)==7);
assert(tracker_ui_set(4,0,0,70,3)==0);assert(tracker_ui_select(4,0,0,17,0)==0);controls.encoders[2]=1;tracker_device_control();assert(tracker_ui_state(3)==1);
assert(tracker_ui_select(4,0,0,38,0)==0);int alg=tracker_ui_get(4,0,0,38);controls.encoders[3]=1;tracker_device_control();assert(tracker_ui_get(4,0,0,38)==(alg<7?alg+1:7));
assert(tracker_ui_select(4,0,0,45,0)==0);controls.encoders[2]=1;tracker_device_control();assert(tracker_ui_state(3)==46); /* OP1 release -> OP2 ratio */
puts("PASS: contextual synth/sample navigation and distinct FM4 algorithm/operator controls");
assert(tracker_ui_select(4,0,0,70,0)==0);assert(tracker_ui_set(4,0,0,70,3)==0&&tracker_ui_get(4,0,0,0)==16);controls.buttons=0;tracker_device_control();controls.buttons=1U<<5;tracker_device_control();assert(tracker_ui_state(3)==9);controls.buttons=0;tracker_device_control();controls.buttons=1U<<5;tracker_device_control();assert(tracker_ui_state(3)==38);controls.buttons=0;tracker_device_control();capture("engine-fm4");controls.buttons=1U<<5;tracker_device_control();assert(tracker_ui_state(3)==70);controls.buttons=0;tracker_device_control();assert(tracker_ui_set(4,0,0,70,4)==0);controls.buttons=1U<<5;tracker_device_control();controls.buttons=0;tracker_device_control();controls.buttons=1U<<5;tracker_device_control();assert(tracker_ui_state(3)==64);controls.buttons=0;tracker_device_control();capture("engine-wavetable");assert(tracker_ui_project_valid(tracker_ui_project()));puts("PASS: native family selection and three-page FM4/dual cycle with slot preserved");
puts("PASS: device adapter, 44.1 kHz output, controls, five views, LCD bounds, stop");
 memset(store_flash,255,sizeof store_flash);for(unsigned slot=0;slot<8;slot++){assert(tracker_ui_tempo(100+slot)==0);assert(tracker_ui_project_save(slot)==0);}for(unsigned slot=0;slot<8;slot++){assert(tracker_ui_project_load(slot)==0);assert(tracker_ui_project()->bpm==100+slot);}
#if TEST_FLASH_BYTES == 0x49000
 assert(0x97000u+sizeof store_flash-4096u-16u*12288u==0xaf000u);assert(0x97000u+sizeof store_flash<=0xe0000u);puts("PASS: all eight hardware slots persist independently below OTA staging");
#endif
 /* Palette controls must persist without changing musical parameters or slot selection. */
 assert(tracker_ui_set(7,0,0,7,0)==0&&tracker_ui_get(7,0,0,7)==0);
 unsigned palette_slot=tracker_ui_state(14),palette_bpm=tracker_ui_project()->bpm;
 for(unsigned f=8;f<12;f++){assert(tracker_ui_set(7,0,0,f,(int)f-3)==0);assert(tracker_ui_get(7,0,0,f)==(int)f-3);}
 assert(tracker_ui_get(7,0,0,7)==4&&tracker_ui_state(14)==palette_slot&&tracker_ui_project()->bpm==palette_bpm);
 assert(tracker_ui_set(7,0,0,11,16)<0&&tracker_ui_set(7,0,0,7,4)<0);
 assert(tracker_ui_project_save(4)==0);assert(tracker_ui_set(7,0,0,7,1)==0);assert(tracker_ui_project_load(4)==0);
 for(unsigned f=8;f<12;f++)assert(tracker_ui_get(7,0,0,f)==(int)f-3);
 assert(tracker_ui_select(7,0,0,7,0)==0);controls.buttons=0;controls.encoders[2]=4;tracker_device_control();assert(tracker_ui_state(3)==11);
 controls.encoders[3]=1;tracker_device_control();assert(tracker_ui_get(7,0,0,11)==9);capture("palette-custom");
 puts("PASS: palette bounds, Global navigation, custom colours persist, project layout and tempo unchanged");
 test_project_protocol();
 tracker_ui_demo(4);assert(tracker_ui_select(5,0,0,0,0)==0);tracker_ui_audition(60);
 for(unsigned b=0;b<80;b++)tracker_device_render(out,128);controls.buttons=0;tracker_device_control();
 unsigned meter_lit=0;for(unsigned n=0;n<10;n++)meter_lit+=framebuffer[(169-n*9)*240+30]!=((35>>3)<<11|(61>>2)<<5|(88>>3));assert(meter_lit);capture("mixer-preview-meter");
 tracker_ui_play(0);tracker_device_control();for(unsigned n=0;n<10;n++)assert(framebuffer[(169-n*9)*240+30]==((35>>3)<<11|(61>>2)<<5|(88>>3)));
 puts("PASS: mixer LED column displays keyboard audition and clears on Stop");
 /* Slots are ready by definition. Clear is one confirmed persistent action. */
 memset(store_flash+base+2*3*4096,255,2*3*4096);
 tracker_ui_demo(2);assert(!tracker_ui_project_save(0));assert(!tracker_ui_set(7,0,0,3,1));
 static TrProject reset_before,reset_saved;static uint8_t reset_flash_before[TEST_FLASH_BYTES];
 reset_before=*tracker_ui_project();memcpy(reset_flash_before,store_flash,sizeof store_flash);
 assert(!tracker_ui_project_load(1)&&tracker_ui_state(14)==1&&tracker_ui_state(20)==1);
 for(unsigned n=0;n<sizeof tracker_ui_project()->song;n++)assert(((const uint8_t *)tracker_ui_project()->song)[n]==255);
 assert(!memcmp(reset_flash_before,store_flash,sizeof store_flash));
 assert(!tracker_ui_project_load(0));assert(!tracker_ui_set(7,0,0,3,1));
 assert(tracker_ui_state(20)==0);assert(!tracker_ui_select(7,0,0,14,0));controls.buttons=0;tracker_device_control();
 controls.buttons=1U<<13;tracker_device_control();assert(!memcmp(&reset_before,tracker_ui_project(),sizeof reset_before));assert(!memcmp(reset_flash_before,store_flash,sizeof store_flash));capture("clear-slot-confirm");
 controls.buttons=0;controls.encoders[2]=-1;tracker_device_control();assert(!memcmp(reset_flash_before,store_flash,sizeof store_flash));
 assert(!tracker_ui_select(7,0,0,14,0));controls.buttons=0;tracker_device_control();controls.buttons=1U<<13;tracker_device_control();controls.buttons=0;
 for(unsigned n=0;n<160;n++)tracker_device_control();
 controls.buttons=1U<<13;tracker_device_control();assert(!memcmp(reset_flash_before,store_flash,sizeof store_flash));
 controls.buttons=0;tracker_device_control();controls.buttons=1U<<13;tracker_device_control();controls.buttons=0;tracker_device_control();
 assert(tracker_ui_state(20)==0&&tracker_ui_state(14)==1);assert(!memcmp(&reset_before,tracker_ui_project(),sizeof reset_before));
 assert(!tracker_ui_slot_export(1,&reset_saved));assert(reset_saved.bpm==120&&reset_saved.song_length==1&&tracker_ui_project_valid(&reset_saved));
 assert(!tracker_ui_slot_export(0,&reset_saved)&&!memcmp(&reset_saved,&reset_before,sizeof reset_saved));
 assert(!tracker_ui_project_load(1)&&tracker_ui_state(20)==1);controls.buttons=0;tracker_device_control();capture("loaded-slot-two");
 for(unsigned page=0;page<8;page++){assert(!tracker_ui_select(page,0,0,page==4?70:0,0));controls.buttons=0;tracker_device_control();assert(tracker_ui_state(20)==1);if(page==4)capture("instrument-slot-two");}
 assert(!tracker_ui_tempo(137)&&!tracker_ui_project_save(1));assert(!tracker_ui_slot_clear(1));assert(tracker_ui_state(20)==1&&tracker_ui_project()->bpm==120);
 assert(!tracker_ui_slot_export(1,&reset_saved)&&!memcmp(&reset_saved,tracker_ui_project(),sizeof reset_saved));
 tracker_ui_audition(60);long long init_energy=0;for(unsigned b=0;b<20;b++){tracker_device_render(out,128);for(unsigned n=0;n<256;n++)init_energy+=out[n]<0?-(long long)out[n]:out[n];}assert(init_energy>0);
 puts("PASS: empty Load without init/erase; persistent Clear slot confirmation, cancellation and timeout; clearing inactive slot preserves RAM; active Clear updates RAM; loaded slot differs from selected destination");
 tracker_ui_demo(2);assert(!tracker_ui_length(4));assert(!tracker_ui_select(0,0,2,0,0));controls.buttons=0;tracker_device_control();
 controls.buttons=1U<<12;tracker_device_control();assert(tracker_ui_state(6));for(unsigned ch=0;ch<8;ch++)assert(tracker_ui_voice(ch,1)==2&&tracker_ui_voice(ch,2)==0&&tracker_ui_voice(ch,0)==0);
 controls.buttons=0;tracker_device_control();for(unsigned n=0;n<30;n++)tracker_device_render(out,128);
 assert(!tracker_ui_select(0,0,1,0,0));controls.buttons=1U<<13;tracker_device_control();capture("song-live-launch");
 unsigned before_tick=tracker_ui_state(7);for(unsigned n=0;n<300&&tracker_ui_state(7)<before_tick+7;n++)tracker_device_render(out,128);
 for(unsigned ch=0;ch<8;ch++)assert(tracker_ui_voice(ch,1)==1);
 tracker_ui_play(0);assert(!tracker_ui_select(0,0,7,0,0));controls.buttons=0;tracker_device_control();controls.buttons=1U<<12;tracker_device_control();assert(!tracker_ui_state(6));capture("song-outside-length");
 /* Exact tick-boundary semantics, preserving clock, FX tails and saved project. */
 static Tracker launch;tr_init(&launch);launch.project.song_length=4;reset_before=launch.project;
 assert(!tr_song_start(&launch,3));for(unsigned ch=0;ch<8;ch++)assert(launch.voice[ch].song==3);
 launch.clock=123;launch.ticks=2;launch.effects.valid=10;launch.effects.delay[0][0]=1234;
 assert(!tr_song_launch(&launch,2));for(unsigned i=0;i<4;i++){tr_tick(&launch);for(unsigned ch=0;ch<8;ch++)assert(launch.voice[ch].song==3);}
 tr_tick(&launch);assert(launch.ticks==7&&launch.clock==123&&launch.effects.valid==10&&launch.effects.delay[0][0]==1234);
 for(unsigned ch=0;ch<8;ch++)assert(launch.voice[ch].song==2&&launch.voice[ch].chain==0&&launch.voice[ch].step==0&&launch.voice[ch].tick==1);
 assert(!memcmp(&reset_before,&launch.project,sizeof reset_before));assert(tr_song_start(&launch,4)<0&&tr_song_launch(&launch,32)<0);
 assert(!tr_song_launch(&launch,0)&&!tr_song_launch(&launch,1)&&launch.song_launch==1);tr_transport(&launch,0);assert(launch.song_launch==255&&!launch.playing);
 assert(tr_song_launch(&launch,1)<0);assert(!tr_song_start(&launch,0)&&launch.ticks==0&&launch.clock==0);
 puts("PASS: Song PLAY starts selected row on all eight tracks; live REC launches on next global six-tick boundary, preserves clock/FX tails/project; latest request wins, invalid rows refused, Stop cancels queue");
 /* Follow the real audio clock across scroll windows and changing Phrase IDs. */
 static TrProject follow_project;follow_project=*tracker_ui_project();follow_project.bpm=300;follow_project.song_length=32;memset(follow_project.song,255,sizeof follow_project.song);
 for(unsigned n=0;n<32;n++){follow_project.song[n][0]=(uint8_t)n;follow_project.chains[n].length=2;follow_project.chains[n].phrase[0]=0;follow_project.chains[n].phrase[1]=1;}
 for(unsigned p=0;p<2;p++)for(unsigned n=0;n<16;n++)follow_project.phrases[p].step[n]=(TrStep){n?255:(uint8_t)(48+p*7),n?255:0,{{0,0},{0,0}}};
 assert(!tracker_ui_project_apply(&follow_project));assert(!tracker_ui_select(0,0,0,0,0));controls.buttons=0;tracker_device_control();controls.buttons=1U<<12;tracker_device_control();controls.buttons=0;tracker_device_control();
 for(unsigned n=0;n<450&&tracker_ui_voice(0,1)<12;n++){for(unsigned b=0;b<16;b++)tracker_device_render(out,128);tracker_device_control();assert(tracker_ui_state(19)&&tracker_ui_state(2)==tracker_ui_voice(0,1));}
 assert(tracker_ui_voice(0,1)>=12);unsigned marker=0;for(unsigned y=66;y<210;y++)marker+=framebuffer[y*240]!=((9>>3)<<11|(21>>2)<<5|(37>>3));assert(marker==15);capture("follow-song");
 controls.encoders[1]=5;tracker_device_control();unsigned edit_row=tracker_ui_state(2);assert(!tracker_ui_state(19));for(unsigned n=0;n<40;n++){tracker_device_render(out,128);tracker_device_control();assert(tracker_ui_state(2)==edit_row);}capture("follow-song-edit");
 controls.buttons=1U<<2;tracker_device_control();controls.buttons=0;tracker_device_control();assert(tracker_ui_state(19)&&tracker_ui_state(2)==tracker_ui_voice(0,1));
 controls.buttons=1U<<4;tracker_device_control();controls.buttons=0;tracker_device_control();unsigned seen_last=0,seen_phrase0=0,seen_phrase1=0;
 for(unsigned n=0;n<80;n++){for(unsigned b=0;b<16;b++)tracker_device_render(out,128);tracker_device_control();assert(tracker_ui_state(19)&&tracker_ui_state(2)==tracker_ui_voice(0,0)&&tracker_ui_state(4)==tracker_ui_voice(0,7));seen_last|=tracker_ui_state(2)==15;seen_phrase0|=tracker_ui_state(4)==0;seen_phrase1|=tracker_ui_state(4)==1;if(tracker_ui_state(2)>=12)capture("follow-phrase");}
 assert(seen_last&&seen_phrase0&&seen_phrase1);marker=0;for(unsigned y=89;y<209;y++)marker+=framebuffer[y*240]!=((9>>3)<<11|(21>>2)<<5|(37>>3));assert(marker==15);
 controls.encoders[4]=1;tracker_device_control();unsigned edit_phrase=tracker_ui_state(4);assert(!tracker_ui_state(19));for(unsigned n=0;n<40;n++){tracker_device_render(out,128);tracker_device_control();assert(tracker_ui_state(4)==edit_phrase);}
 controls.buttons=1U<<4;tracker_device_control();controls.buttons=0;tracker_device_control();assert(tracker_ui_state(19)&&tracker_ui_state(4)==tracker_ui_voice(0,7));tracker_ui_play(0);
 assert(!tracker_ui_preset_load(31,176));static uint16_t badge[57*25];
 for(unsigned k=0;k<5;k++){unsigned fields[]={70,9,25,32,64};assert(!tracker_ui_select(4,0,0,fields[k],31));tracker_device_control();for(unsigned y=0;y<25;y++){if(!k)memcpy(badge+y*57,framebuffer+(y+2)*240+178,57*sizeof(uint16_t));else assert(!memcmp(badge+y*57,framebuffer+(y+2)*240+178,57*sizeof(uint16_t)));}if(!k)capture("instrument-I1F");if(k==1)capture("instrument-I1F-env");if(k==2)capture("instrument-I1F-lfo");if(k==4)capture("instrument-I1F-engine");}
 assert(!tracker_ui_select(4,0,0,70,0));tracker_device_control();unsigned different=0;for(unsigned y=0;y<25;y++)different+=memcmp(badge+y*57,framebuffer+(y+2)*240+178,57*sizeof(uint16_t))!=0;assert(different);capture("instrument-I00");
 puts("PASS: real LCD Song follows beyond row 12; Phrase follows row 0F and changes object across Chain; manual edit holds position, page key resumes, all Instrument pages share prominent I1F badge distinct from I00");
 return 0;
}
