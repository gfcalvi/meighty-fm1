/* Test-only stdio bridge: real project protocol and transactional NOR fixture.
 * No hardware access. FE resets the simulated machine; not a firmware command. */
#define main original_device_main
#include "test_device.c"
#undef main
int main(void){
 memset(store_flash,255,sizeof store_flash);tracker_device_init();
 char line[2048];uint8_t payload[640];
 while(fgets(line,sizeof line,stdin)){
  size_t count=strcspn(line,"\r\n")/2;unsigned cmd=0,value=0;
  if(!count||count>sizeof payload+1)return 2;
  if(sscanf(line,"%2x",&cmd)!=1)return 2;
  for(size_t i=1;i<count;i++){if(sscanf(line+i*2,"%2x",&value)!=1)return 2;payload[i-1]=(uint8_t)value;}
  if(cmd==0xfe){memset(store_flash,255,sizeof store_flash);tracker_device_init();puts("00");fflush(stdout);continue;}
  if(cmd==17){const char id[27]="FM-1_998201";for(unsigned i=0;i<sizeof id;i++)printf("%02x",(uint8_t)id[i]);putchar('\n');fflush(stdout);continue;}
  ++ms;project_request(cmd,payload,(unsigned)count-1);
  unsigned n=tr_project_reply[3]|((unsigned)tr_project_reply[4]<<8);
  for(unsigned i=0;i<n;i++)printf("%02x",tr_project_reply[6+i]);putchar('\n');fflush(stdout);
 }
 return 0;
}
