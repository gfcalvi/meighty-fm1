from pathlib import Path
import json,hashlib,zipfile,shutil,os
R=Path(__file__).resolve().parents[2];D=R/'outputs/Meighty-1.00';S=R/'outputs/fm1-tracker/toolsuite'
guide='''MEIGHTY 1.00 — SUITE OFFLINE 1.2 / TIFFANY

UNA SOLA PAGINA: Meighty.html
Contiene Installazione, Backup/Restore, Convertitore, Progetti/slot.
Stesso metodo della suite Bloomy Offline 1.2, con colori Tiffany.
Firmware identico a HW9 già collaudata: non reinstallarlo per aggiornare gli strumenti.

IPHONE/IPAD: HTTPS → MAKE AVAILABLE OFFLINE
1. Apri la suite Meighty dall’indirizzo HTTPS dell’hosting statico in MIDIWeb.
   Usa lo stesso servizio predisposto per Bloomy. Non occorre il Mac.
2. Verifica Meighty 1.00 / Suite offline 1.2 e SHA in Installazione.
3. Scegli Make Available Offline e attendi il completamento.
   Basta questa sola pagina: tutti e quattro gli strumenti sono incorporati.
4. Richiama la copia offline dall’app, senza PC e senza rete.
   Per aggiornare, riapri l’indirizzo HTTPS e sostituisci la copia offline.
Non usare File → Apri con MIDIWeb: questo percorso aveva fallito con Bloomy.

USO QUOTIDIANO SENZA PC E SENZA RETE
Richiama la copia offline da MIDIWeb. Non riaprire l’indirizzo del Mac spento.
Prova modalità aereo, Wi-Fi spento, chiusura e riapertura completa dell’app.
Collega FM-1 via USB dati soltanto per Installazione e Backup/Restore.
Convertitore e Progetti/slot lavorano su file già scaricati sul telefono.
Scarica il file, oppure usa Condividi / Salva in File quando disponibile.
I selettori non filtrano le estensioni: il contenuto viene comunque verificato.

Il metodo offline è quello provato dall’utente con Bloomy, compreso
Backup/Restore. Il trasferimento Meighty richiede il proprio collaudo fisico.
Il nuovo percorso iniziale usa hosting statico HTTPS, come deciso per Bloomy.
Lo ZIP è una copia di distribuzione: non importa da solo una pagina
nell’archivio offline di MIDIWeb. L’indirizzo definitivo verrà registrato
quando sarà completata la pubblicazione sul servizio scelto per Bloomy.

MAC / PC
Avvia-Meighty.command sul Mac, Avvia-Meighty.cmd su Windows: Python 3,
poi Chrome/Edge su http://127.0.0.1:8799/Meighty.html.
Il server è solo locale, salvo l’opzione esplicita Avvia-iPhone.command.

BACKUP, RIPRISTINO E OTTO SLOT
Backup completo: otto progetti salvati + copia RAM separata.
Prima di ripristinare viene preparato un backup della macchina:
scaricalo/conservalo, verifica il piano e spunta la conferma nella pagina.
Sostituisci applica tutto il set: anche i posti vuoti, scritti come New Project.
Unisci aggiorna soltanto i posti occupati, conservando gli altri.
Non reinstalla il firmware. Per suonare poi: Global → Project slot → Load.

Estrai singolarmente ogni brano oppure tutti in ZIP con indice degli 8 posti.
Componi set da zero a otto brani, anche in posizioni non consecutive.
Esempio: brani solo negli slot 1, 3, 8; scegli Vuoto negli altri cinque.
I file originali non cambiano. La palette Tiffany è opzionale per i nuovi set.

CONVERSIONE
.meighty, vecchie banche/progetti, .rfm1state anche LZFSE, .fm1save e dump
M-Flasher. Non converte brani Bloomy in Meighty. I formati che non conservano
la RAM separata richiedono una scelta esplicita prima di escluderla.
Il modulo RemoteFM1 incluso è Follow già esistente, non un nuovo core 1.00.

Guide e sorgenti sono documenti di supporto nello ZIP: non sono necessari
accanto alla pagina salvata. Il manuale musicale PDF è quello già esistente;
questa guida sostituisce le vecchie istruzioni di accesso iOS.
'''
(D/'INIZIA-QUI.txt').write_text(guide)
import html
page='''<!doctype html><html lang="it"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Meighty · Guida suite offline</title><style>body{max-width:850px;margin:30px auto;padding:20px;background:#071e20;color:#f1f9f7;font:17px/1.6 system-ui}h1{color:#70dfd0}pre{white-space:pre-wrap;font:inherit}a{color:#70dfd0}</style><h1>Meighty · Suite offline 1.2</h1><p><a href="Meighty.html">Apri la suite</a></p><pre>'''+html.escape(guide)+'''</pre></html>'''
(D/'LEGGIMI.html').write_text(page);(S/'LEGGIMI.html').write_text(page)
for n in ['Avvia-Meighty.py','Avvia-Meighty.command','Avvia-Meighty.cmd','Avvia-iPhone.command']:shutil.copy2(S/n,D/n)
for n in ['Avvia-Meighty.command','Avvia-iPhone.command']:os.chmod(D/n,0o755)
m=json.loads((D/'VERIFICHE.json').read_text());m['toolsRevision']='1.2';m['iosReference']='Current Bloomy Offline 1.2: one embedded-page suite; parent navigator MIDI bridge; Make Available Offline; initial HTTPS static hosting then saved offline. LAN is optional development fallback. File open-with failed and is not recommended.'
m['softwareTests'] += ['Same verified Bloomy shell and iframe MIDI permissions, with TIFFANY colors','No extension filters, no native confirm, explicit download/share result buttons']
m['softwareTests']=list(dict.fromkeys(m['softwareTests']))
m['browserSuiteTests']={'interface':{'passed':21,'failed':0},'shell':{'passed':5,'failed':0},'deviceTransport':'mocked; no physical writes'}
(D/'VERIFICHE.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
# Overlay only the new tool sources on the frozen hardware source archive.
with zipfile.ZipFile(R/'outputs/Meighty-HW9-Sorgenti.zip') as old,zipfile.ZipFile(D/'Sorgenti.zip','w',zipfile.ZIP_DEFLATED) as z:
 for item in old.infolist():
  if not item.filename.startswith('fm1-tracker/toolsuite/'):z.writestr(item,old.read(item.filename))
 for p in S.iterdir():
  if p.is_file():z.write(p,'fm1-tracker/toolsuite/'+p.name)
 for n in ['build.py','finalize-suite.py','revise-suite.py','https-mode.py','config.json','test.cjs','test_lzfse.cjs','Empty.project.bin','browser-tests.js','build-browser-tests.py']:
  z.write(R/'work/meighty-100'/n,'release-1.00/'+n)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m['files']={str(p.relative_to(D)):sha(p) for p in sorted(D.rglob('*')) if p.is_file() and p.name not in ['MANIFEST.json','SHA256SUMS']}
(D/'MANIFEST.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
(D/'SHA256SUMS').write_text(''.join(sha(p)+'  '+str(p.relative_to(D))+'\n' for p in sorted(D.rglob('*')) if p.is_file() and p.name!='SHA256SUMS'))
iosNames={'Meighty.html','INIZIA-QUI.txt','LEGGIMI.html','Manuale-Meighty.pdf','LICENSE-Meighty.md','LICENSE-LZFSE.txt','VERIFICHE.json','Sorgenti.zip'}
for label in ['Mac-PC','iOS-Offline']:
 with zipfile.ZipFile(R/'outputs'/('Meighty-1.00-'+label+'.zip'),'w',zipfile.ZIP_DEFLATED) as z:
  selected=[p for p in sorted(D.rglob('*')) if p.is_file() and (label=='Mac-PC' or p.name in iosNames)]
  for p in selected:z.write(p,'Meighty-1.00/'+str(p.relative_to(D)))
  if label=='iOS-Offline':
   z.writestr('Meighty-1.00/SHA256SUMS',''.join(sha(p)+'  '+str(p.relative_to(D))+'\n' for p in selected))
 with zipfile.ZipFile(R/'outputs'/('Meighty-1.00-'+label+'.zip')) as z:
  assert z.testzip() is None
  if label=='iOS-Offline':assert not any(n.endswith(('.command','.cmd','.py')) for n in z.namelist())
assert sha(D/'Meighty-1.00.fwsc')=='a602086c0fb00d3ddbeceb66227914fa7d953b4f6ab858325199bdfddade49f7'
print('PASS unified suite packages; iOS contains no launcher; HW9 unchanged')
