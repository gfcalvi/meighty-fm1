from pathlib import Path
import re
R=Path(__file__).resolve().parents[2]; S=R/'outputs/fm1-tracker/toolsuite'
B=Path('/Users/gfcalvi/Documents/Codex/Loom-8/Strumenti/Suite-source/shell.html')
s=B.read_text().replace('Bloomy','Meighty').replace('bloomy','meighty').replace('1.0 ·','1.00 ·')
for a,b in {'#071725':'#071e20','#e1f3ff':'#f1f9f7','#26506a':'#315254','#a3bfd2':'#b4cfcc','#3b708e':'#527e7b','#d8f2ff':'#e3f7f3','#102b40':'#143a3b','#80d6ff':'#70dfd0','#062339':'#092d2d'}.items():s=s.replace(a,b)
s=s.replace('tre slot','otto slot').replace('tre sezioni','quattro sezioni')
a=s.index('<section class="welcome"');b=s.index('</section>',a)+len('</section>')
s=s[:a]+'''<section class="welcome" id="home"><h2>Il tuo banco di lavoro Meighty</h2><p>Installazione, Backup/Restore, Convertitore e Progetti/slot sono incorporati in <b>questa sola pagina</b>. Nessuna login, nessuno script o firmware da scaricare durante l’uso. I file restano sul dispositivo.</p><ol><li><b>Backup:</b> conserva gli otto slot e una copia separata del progetto in lavorazione.</li><li><b>Installazione:</b> firmware Meighty 1.00 incorporato, identico a HW9 già collaudata; non serve reinstallarla per usare questa suite.</li><li><b>Convertitore:</b> backup .meighty, banche precedenti, stati RemoteFM1, FM-1 Emulator e dump M-Flasher. I formati Bloomy non sono progetti Meighty.</li><li><b>Progetti / slot:</b> estrai ciascun brano o tutti in ZIP e componi un set con <b>da zero a otto brani</b>. Anche gli slot intermedi possono restare vuoti.</li></ol><h2>iPhone: lo stesso percorso di Bloomy</h2><ol><li>Per la prima apertura, sul Mac avvia <b>Avvia-iPhone.command</b>. Mac e iPhone devono essere sulla stessa Wi-Fi. In MIDIWeb apri l’indirizzo mostrato dal launcher.</li><li>Verifica il titolo <b>Meighty 1.00 · Suite offline 1.2</b> e SHA-256 nella scheda Installazione.</li><li>Nel menu di MIDIWeb scegli <b>Make Available Offline</b>. Una sola copia contiene tutti e quattro gli strumenti.</li><li>Al termine arresta il server. Puoi spegnere il Mac. Richiama la copia offline da MIDIWeb, anche senza rete; usa file già scaricati in File.</li></ol><p class="note">Il percorso File → Apri con MIDIWeb aveva fallito con Bloomy: non è la procedura da seguire. Il metodo della pagina unica, apertura offline e Backup/Restore Bloomy sono stati confermati dall’utente su iPhone. Il trasferimento Meighty richiede ancora il suo collaudo fisico: non basta che il firmware HW9 funzioni per considerarlo già verificato.</p><h2>File e conferme</h2><p>I selettori non filtrano le estensioni, come nella suite Bloomy corretta: seleziona il file desiderato, il contenuto viene verificato. Ogni risultato offre <b>Scarica</b> e, se disponibile, <b>Condividi / Salva in File</b>. Le conferme sono visibili nella pagina; nessun popup nativo necessario.</p><p>Ripristino <b>Sostituisci</b>: applica tutto il set, salvando progetti vuoti nei posti inutilizzati. <b>Unisci</b>: scrive solo i brani presenti e conserva gli altri. Prima viene creato un backup della macchina. Ripristinare progetti non reinstalla il firmware.</p><h2>Mac / PC</h2><p>Avvia-Mac.command oppure Avvia-PC.cmd: server locale Python 3, poi Chrome/Edge. Avvia-iPhone.command serve sul Mac soltanto a trasferire inizialmente la pagina; non si esegue su iOS. Guide, manuale e sorgenti sono nello ZIP, non occorrono durante l’uso offline.</p><p id="env"></p></section>'''+s[b:]
# Close outgoing idle MIDI connections before enabling another tool.
s=s.replace('function select(tab){','async function select(tab){')
s=s.replace('activeTab=tab;document.querySelectorAll', '''if(tab!==activeTab&&frames[activeTab]){const outgoing=frames[activeTab];document.querySelectorAll('[data-tab]').forEach(b=>b.disabled=true);try{await new Promise((resolve,reject)=>{const timer=setTimeout(()=>{window.removeEventListener('message',done);reject(Error('Porta MIDI non liberata. Torna allo strumento e premi Disconnetti.'));},5000);function done(e){if(e.source!==outgoing.contentWindow||e.data?.meightyReleased!==true)return;clearTimeout(timer);window.removeEventListener('message',done);resolve();}window.addEventListener('message',done);outgoing.contentWindow.postMessage({meightyDeactivate:true},'*');});}catch(e){document.getElementById('env').textContent=e.message;return;}finally{document.querySelectorAll('[data-tab]').forEach(b=>b.disabled=false);}}activeTab=tab;document.querySelectorAll''')
(S/'Shell.html.in').write_text(s)
t=(S/'Suite.html.in').read_text();t=re.sub(r' accept="[^"]*"','',t)
t=t.replace('Su iPhone/iPad apri questo HTML in MIDIWeb Browser con la stessa procedura locale usata per Bloomy, poi collega il cavo USB dati.','Su iPhone/iPad richiama la suite salvata con Make Available Offline in MIDIWeb Browser, poi collega il cavo USB dati.')
t=t.replace('<nav aria-label="Strumenti">','<nav id="innerNav" aria-label="Strumenti">')
t=t.replace('<h3>Converti gli otto slot salvati</h3>','<div id="conversion"><h3>Converti gli otto slot salvati</h3>')
t=t.replace('<button id="convert">Converti e scarica</button></div>','<button id="convert">Prepara conversione</button></div></div>')
t=t.replace('<div class="card"><h2>3. Componi il tuo set</h2>','<div class="card" id="setCard"><h2>3. Componi il tuo set</h2>')
t=t.replace('<main>','''<section id="result" class="card" hidden aria-label="File pronto"><h2>File pronto</h2><p id="resultName"></p><div class="row"><button id="resultDownload" class="primary">Scarica il file</button><button id="resultShare">Condividi / Salva in File</button></div><p class="small">Salva il file prima di un ripristino. La condivisione annullata non elimina il risultato.</p></section><main>''')
(S/'Suite.html.in').write_text(t)
u=(S/'UI.js').read_text()
u=u.replace("const choices=Array(8).fill('');",'''const choices=Array(8).fill('');
let output=null;
// Same MIDIWeb iframe bridge as the verified Bloomy suite.
if(parent!==window&&typeof parent.navigator.requestMIDIAccess==='function')Object.defineProperty(navigator,'requestMIDIAccess',{configurable:true,value:options=>parent.navigator.requestMIDIAccess(options)});
function suiteBusy(on){if(parent!==window)parent.postMessage({meightyBusy:!!on},'*');}
window.addEventListener('message',async e=>{if(e.source!==parent||!e.data?.meightyDeactivate||busy)return;try{await installer?.disconnect();connected=false;prepared=null;identities();sync();parent.postMessage({meightyReleased:true},'*');}catch(err){status(err.message,true);}});
window.addEventListener('beforeunload',e=>{if(busy){e.preventDefault();e.returnValue='Trasferimento in corso';}});
''')
u=u.replace('busy=true;sync();try{','busy=true;suiteBusy(true);sync();try{').replace('busy=false;if(installer','busy=false;suiteBusy(false);if(installer')
a=u.index('function download(');b=u.index('\nconst jsonBytes',a)
u=u[:a]+'''function canShare(bytes,name,type){try{return !!(navigator.canShare&&navigator.share&&navigator.canShare({files:[new File([bytes],name,{type})]}));}catch(_){return false;}}
function saveOutput(){if(!output)return;const url=URL.createObjectURL(new Blob([output.bytes],{type:output.type})),a=document.createElement('a');a.href=url;a.download=output.name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),120000);}
function download(bytes,name,type='application/octet-stream'){
 const clean=String(name).replace(/[^\\p{L}\\p{N} _.-]/gu,'_').replace(/^\\.+/,'').trim().slice(0,220)||'Meighty.meighty';
 output={bytes:new Uint8Array(bytes),name:clean,type};$('resultName').textContent=clean+' · '+bytes.length.toLocaleString('it-IT')+' byte';$('result').hidden=false;$('resultShare').hidden=!canShare(bytes,clean,type);$('result').scrollIntoView({block:'nearest'});
}
$('resultDownload').onclick=()=>{try{saveOutput();}catch(e){status('Download non riuscito: '+e.message,true);}};
$('resultShare').onclick=async()=>{if(!output)return;try{await navigator.share({files:[new File([output.bytes],output.name,{type:output.type})],title:'Salvataggio Meighty'});}catch(e){if(e.name!=='AbortError')status('Condivisione non disponibile: usa Scarica il file.',true);}};
''' +u[b:]
u=u.replace("status('Backup verificato. Conserva il file scaricato in File o Download.'", "status('Backup verificato. Premi Scarica il file oppure Condividi / Salva in File.'")
u=u.replace("status('Backup di sicurezza verificato e scaricato. Conserva il file, poi conferma il piano di ripristino.');","status('Backup di sicurezza pronto. Premi Scarica il file o Condividi, conservalo, poi conferma il piano di ripristino.');")
u=u.replace("status('File generato e verificato localmente. Salvalo in File o Download.');","status('File generato e verificato. Premi Scarica il file o Condividi / Salva in File.');")
# Embedded pages expose a single task; navigation belongs to the parent shell.
u=u.replace("paintComposer();tab(C.tab||'install');sync();",'''paintComposer();tab(C.tab||'install');
if(C.section){$('innerNav').hidden=true;document.querySelector('header').hidden=true;document.querySelector('footer').hidden=true;
 if(C.section==='convert'){$('setCard').hidden=true;$('sourceSlots').hidden=true;$('extractAll').hidden=true;$('extractWorking').hidden=true;}
 if(C.section==='projects')$('conversion').hidden=true;
 document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>parent.postMessage({meightyTab:b.dataset.tab},'*'));
}sync();''')
(S/'UI.js').write_text(u)
print('Prepared Bloomy-derived shell, top-level MIDI bridge, inline results/share and unrestricted file pickers')
