const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const repo=path.resolve(__dirname,'../../outputs/fm1-tracker'),c=JSON.parse(fs.readFileSync(__dirname+'/config.json'));
for(const f of ['sdk/WebUpdate.js','web/installer/InstallerCore.js','toolsuite/Formats.js'])vm.runInThisContext(fs.readFileSync(repo+'/'+f,'utf8'));
const raw=fs.readFileSync(__dirname+'/state-none.bin'),n=raw.readUInt32LE(8),meta=JSON.parse(raw.subarray(12,12+n)),body=fs.readFileSync(__dirname+'/flash.lzfse');meta.flashEncoding='lzfse';meta.flashBytes=body.length;
const m=Buffer.from(JSON.stringify(meta)),h=Buffer.alloc(12);h.write('RFM1STAT');h.writeUInt32LE(m.length,8);const packed=Buffer.concat([h,m,body]);
(async()=>{const options={cores:c.cores,decoder:MeightyFiles.un64(c.decoder)};const a=await MeightyFiles.read(packed,options),b=await MeightyFiles.read(raw,options);assert.deepEqual(a,b);console.log('PASS compressed LZFSE RemoteFM1 state → exact same sparse 8 slots as uncompressed state, using bundled Apple decoder offline');})().catch(e=>{console.error(e);process.exitCode=1;});
