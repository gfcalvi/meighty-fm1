from pathlib import Path
import json,base64,hashlib,struct,shutil,sys
R=Path(__file__).resolve().parents[2];O=R/'outputs';repo=O/'fm1-tracker';W=Path(__file__).parent;dest=O/'Meighty-1.00';dest.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();b64=lambda b:base64.b64encode(b).decode()
sys.path.insert(0,str(repo/'emulator'));import fm1pkg_make as P
def firmware(p):
 raw=p.read_bytes();im=b''.join(raw[i*48:i*48+47] for i in range(20))+raw[960:];h=bytearray(im[:64]);P.enc(h,0,64);loader=None
 for i in range(struct.unpack_from('<H',h,8)[0]):
  e=bytearray(im[64+i*80:144+i*80]);P.enc(e,0,80)
  if struct.unpack_from('<H',e)[0]==100:
   at,n=struct.unpack_from('<II',e,8);loader=im[at:at+n]
 assert loader
 product=''.join(chr((raw[i*48+47]-i-1)&255) for i in range(20) if raw[i*48+47]!=125)
 return dict(product=product,sha256=sha(raw),loader_sha256=sha(loader),loaderIdentity='ota-FM-1_700',data=b64(raw))
def manifest(p):
 b=p.read_bytes();at=8
 def leb():
  nonlocal at
  v=shift=0
  while True:
   q=b[at];at+=1;v|=(q&127)<<shift
   if not q&128:return v
   shift+=7
 while at<len(b):
  kind=b[at];at+=1;n=leb();end=at+n
  if kind==0:
   k=leb();name=b[at:at+k];at+=k
   if name==b'rfm1':return json.loads(b[at:end])
  at=end
 raise ValueError('Missing RFM1 manifest')
hw=firmware(O/'Meighty-HW9.fwsc');assert hw['sha256']=='a602086c0fb00d3ddbeceb66227914fa7d953b4f6ab858325199bdfddade49f7'
emu=firmware(O/'FM1-M8-MultiEngine-INTERACTIVE.fwsc')
raw=(W/'Empty.project.bin').read_bytes();assert len(raw)==11940 and set(raw[6688:6944])=={255}
empty=dict(format='FM1-Tracker-A03',schema=1,slot=0,name='Vuoto',data=b64(raw),sha256=sha(raw))
module=O/'fm1_m8-follow-20261105.rfm1';m=manifest(module);remote={k:m[k] for k in ['version','name']};remote['sha256']=sha(module.read_bytes())
cores=[]
for p in O.glob('*.rfm1'):
 try:
  if manifest(p)['id']=='fm1_m8':cores.append(sha(p.read_bytes()))
 except (ValueError,KeyError,IndexError):pass
decoder=Path('/Users/gfcalvi/Documents/Codex/Loom-8/Sito-1.0/site-assets/song-remote/lzfse.wasm')
cfg=dict(version='1.00',hardware=hw,emulator=emu,empty=empty,remote=remote,cores=sorted(set(cores)),decoder=b64(decoder.read_bytes()))
(W/'config.json').write_text(json.dumps(cfg,separators=(',',':')))
template=(repo/'toolsuite/Suite.html.in').read_text()
for key,p in [('SDK',repo/'sdk/WebUpdate.js'),('INSTALLER',repo/'web/installer/InstallerCore.js'),('FORMATS',repo/'toolsuite/Formats.js'),('FLOW',repo/'toolsuite/BackupFlow.js'),('UI',repo/'toolsuite/UI.js')]:template=template.replace('/*'+key+'*/',p.read_text())
for name,tab in [('Installazione.html','install'),('Backup.html','backup'),('Slot-e-Convertitore.html','slots')]:
 (dest/name).write_text(template.replace('/*CONFIG*/',json.dumps({**cfg,'tab':tab},ensure_ascii=False,separators=(',',':'))))
pages={}
for section,tab in [('install','install'),('backup','backup'),('convert','slots'),('projects','slots')]:
 pages[section]=b64(template.replace('/*CONFIG*/',json.dumps({**cfg,'tab':tab,'section':section},ensure_ascii=False,separators=(',',':'))).encode())
shell=(repo/'toolsuite/Shell.html.in').read_text()
assert shell.count('__PAYLOAD__')==1
(dest/'Meighty.html').write_text(shell.replace('__PAYLOAD__',json.dumps(pages)))
shutil.copy2(O/'Meighty-HW9.fwsc',dest/'Meighty-1.00.fwsc')
shutil.copy2(O/'Meighty-Manuale-Italiano.pdf',dest/'Manuale-Meighty.pdf')
(dest/'RemoteFM1').mkdir(exist_ok=True);shutil.copy2(module,dest/'RemoteFM1'/module.name)
shutil.copy2('/Users/gfcalvi/Documents/Codex/Loom-8/Installazione-Bloomy-1.0/convertitore/LICENSE-LZFSE.txt',dest/'LICENSE-LZFSE.txt')
shutil.copy2(repo/'LICENSE.md',dest/'LICENSE-Meighty.md')
print('Built three standalone pages; firmware unchanged:',hw['sha256'])
