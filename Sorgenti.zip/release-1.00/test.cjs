const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const R=path.resolve(__dirname,'../..'),repo=R+'/outputs/fm1-tracker',cfg=JSON.parse(fs.readFileSync(__dirname+'/config.json'));
for(const f of ['sdk/WebUpdate.js','web/installer/InstallerCore.js','toolsuite/Formats.js','toolsuite/BackupFlow.js'])vm.runInThisContext(fs.readFileSync(repo+'/'+f,'utf8'));
const F=MeightyFiles,decoder=F.un64(cfg.decoder),options={cores:cfg.cores,decoder};
const equal=(a,b)=>assert.deepEqual(a.slots.map(p=>p?Array.from(F.data(p)):null),b.slots.map(p=>p?Array.from(F.data(p)):null));
function song(i){const d=F.data(cfg.empty);new DataView(d.buffer).setUint16(9266,80+i*10,true);d[6688]=0;d[0]=48+i;d[1]=0;return F.project(d,i,'Brano '+(i+1));}
const m=F.model([song(0),null,null,song(3),null,null,null,song(7)]);
async function main(){
 FM1M8Installer.prepare(cfg.hardware);assert.equal(cfg.hardware.product,'FM-1_998201');
 for(const kind of ['meighty','legacy','state','save']){const out=F.output(kind,m,{target:cfg.remote,emulator:cfg.emulator});equal(await F.read(out.bytes,options),m);}
 equal(F.flashRead(F.flashWrite(m)),m);
 const binary=F.output('state',m,{target:cfg.remote}).bytes,n=new DataView(binary.buffer).getUint32(8,true);fs.writeFileSync(__dirname+'/state-none.bin',binary);fs.writeFileSync(__dirname+'/flash.bin',binary.slice(12+n));
 for(let count=0;count<=8;count++){
  const slots=Array.from({length:8},(_,i)=>i<count?song(i):null),set=F.model(slots);
  equal(await F.read(F.output('meighty',set).bytes,options),set);assert.equal(set.slots.filter(Boolean).length,count);
 }
 const working=F.model(m.slots,F.project(F.data(song(0)),255,'RAM'));
 const copy=await F.read(F.output('meighty',working).bytes,options);assert.deepEqual(F.data(copy.working),F.data(working.working));
 assert.throws(()=>F.output('state',working,{target:cfg.remote}),/RAM/);
 F.output('state',working,{target:cfg.remote,dropWorking:true});
 const j=F.bank(m);j.slots[0].name='manomesso';await assert.rejects(()=>F.read(new TextEncoder().encode(JSON.stringify(j)),options),/Integrità/);
 const bad=F.output('state',m,{target:cfg.remote}).bytes.slice();bad[bad.length-1]^=1;await assert.rejects(()=>F.read(bad,options),/SHA/);
 const d=F.data(song(0));for(const len of [10788,11812]){const old=d.slice(0,len),p=F.normalize(old);assert.equal(p.length,11940);assert(p.subarray(11812).every(x=>x===128));}
 const colored=F.data(F.tiffany(song(0)));assert.deepEqual(colored.filter((_,i)=>i!==9855&&i!==10785),d.filter((_,i)=>i!==9855&&i!==10785));assert.equal(colored[9855],0x2a);assert.equal(colored[10785],0x57);
 let slots=m.slots.map(p=>p?F.data(p):null),commands=[];
 const api={async read(i){commands.push(['read',i]);if(i===255)return F.data(song(0));if(!slots[i])throw Object.assign(Error('empty'),{status:7});return slots[i].slice();},async write(i,b){commands.push(['write',i]);F.validate(b);slots[i]=b.slice();}};
 const backed=await MeightyBackup.backup(api,cfg.empty);equal(backed,m);assert(backed.working);
 const small=F.model([null,song(1),null,null,null,null,null,null]);
 const replace=MeightyBackup.plan(small,'replace',cfg.empty);assert.equal(replace.length,8);await MeightyBackup.restore(api,replace);
 assert.deepEqual(slots[1],F.data(song(1)));for(const i of [0,2,3,4,5,6,7])assert.deepEqual(slots[i],F.data(cfg.empty));
 const recaptured=await MeightyBackup.backup(api,cfg.empty);assert.equal(recaptured.slots.filter(Boolean).length,1);
 assert.equal(MeightyBackup.plan(small,'merge',cfg.empty).length,1);
 let calls=0;await assert.rejects(()=>MeightyBackup.restore({write(){calls++;}},[{slot:8,project:song(0)}]));assert.equal(calls,0);
 const corruptApi={read:async()=>{throw Object.assign(Error('corrupt'),{status:3});}};await assert.rejects(()=>MeightyBackup.backup(corruptApi,cfg.empty),/corrupt/);
 const partial={format:'FM1-M8-bank',schema:1,slots:[song(0)]};await assert.rejects(()=>F.read(new TextEncoder().encode(JSON.stringify(partial)),options));
 let fixtures=0;const dir=R+'/outputs/FM1-M8-Esempi-Manuale';
 for(const name of fs.readdirSync(dir).filter(x=>x.endsWith('.fm1tracker.json'))){await F.read(fs.readFileSync(dir+'/'+name),options);fixtures++;}
 const stateDir=R+'/outputs/FM1-M8-Berlin-School-V2';if(fs.existsSync(stateDir))for(const name of fs.readdirSync(stateDir).filter(x=>x.endsWith('.rfm1state'))){await F.read(fs.readFileSync(stateDir+'/'+name),options);fixtures++;}
 const before=fs.readFileSync(__dirname+'/flash.bin'),fallback=Buffer.from(before),at=0xaf000;fallback.copy(fallback,at+0x3000,at,at+0x3000);fallback.writeUInt32LE(2,at+0x3000+12);fallback[at+24+100]^=1;equal(F.flashRead(fallback),m);
 console.log('PASS: all 0–8 project counts, sparse slots, canonical/legacy/RFM1/Emulator roundtrips, old payload migration, checksum/truncation failures, RAM loss confirmation, no-music Tiffany palette, exact replace-empty/merge behavior, corrupt-backup rejection; '+fixtures+' existing fixtures');
}
main().catch(e=>{console.error(e);process.exitCode=1;});
