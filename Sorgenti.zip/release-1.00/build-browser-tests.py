from pathlib import Path
import base64,json,re
R=Path(__file__).resolve().parents[2];D=R/'outputs/Meighty-1.00';W=Path(__file__).parent
shell=(D/'Meighty.html').read_text();raw=json.loads(re.search(r'const PAGES=(.*);\nconst titles=',shell)[1]);pages={k:base64.b64decode(v).decode() for k,v in raw.items()}
pre='''<script>window.__errors=[];addEventListener('error',e=>__errors.push(e.message));addEventListener('unhandledrejection',e=>__errors.push(String(e.reason)));
window.fetch=()=>{throw Error('NETWORK FORBIDDEN')};window.confirm=()=>{throw Error('NATIVE CONFIRM FORBIDDEN')};
window.__downloads=[];window.__blobs=new Map();URL.createObjectURL=b=>{const u='blob:qa-'+__blobs.size;__blobs.set(u,b);return u};URL.revokeObjectURL=()=>{};
HTMLAnchorElement.prototype.click=function(){if(this.download)__downloads.push({name:this.download,blob:__blobs.get(this.href)});};
Object.defineProperty(navigator,'requestMIDIAccess',{configurable:true,value:async()=>{if(window.__deny)throw Error('Autorizzazione negata');return {};}});
</script>'''
mock='''<script>
window.__writes=[];window.__installed=0;window.__slots=Array(8).fill(null);
window.__testBusy=on=>parent.postMessage({meightyBusy:on},'*');
FM1M8Installer.Installer=class {constructor(){this.link={};this.identity='FM-1_998201';}async connect(){this.link={};}async disconnect(){this.link=null;}async install(){window.__installed++;this.link=null;}};
FM1M8Installer.Projects=class {async info(){} async read(i){if(i===255)return MeightyFiles.data(MEIGHTY_CONFIG.empty);if(!__slots[i])throw Object.assign(Error('Vuoto'),{status:7});return __slots[i].slice();}async write(i,d){__writes.push(i);__slots[i]=d.slice();}};
</script>'''
for k,s in pages.items():
 s=s.replace('<script>',pre+'<script>',1)
 s=s.replace('<script>/*UI*/</script>','') if '/*UI*/' in s else s
 marker='<script>/* GPL-3.0-only WITH GPL-3.0-linking-exception. Local UI; no external requests. */'
 assert marker in s
 s=s.replace(marker,mock+marker,1);pages[k]=s
# Shell retains the real shell logic and uses the same test-only child mocks.
shell=re.sub(r'const PAGES=.*;\nconst titles=',lambda _: 'const PAGES='+json.dumps({k:base64.b64encode(v.encode()).decode() for k,v in pages.items()})+';\nconst titles=',shell,count=1)
pages['shell']=shell
wrapper='''<!doctype html><html><meta charset="utf-8"><title>Meighty suite QA</title><style>body{background:#071e20;color:white;font:16px/1.5 system-ui}iframe{width:380px;height:400px}li{margin:8px}</style><h1>Meighty · Test della suite</h1><h2 id="summary">In esecuzione</h2><ol id="results"></ol><div id="frames"></div><script>const SOURCES=__SOURCES__;const CONFIG=__CONFIG__;</script><script>__TESTS__</script></html>'''
wrapper=wrapper.replace('const SOURCES=',"Object.defineProperty(navigator,'requestMIDIAccess',{configurable:true,value:async()=>{if(window.__deny)throw Error('Autorizzazione negata');return {};}});const SOURCES=")
(W/'QA.html').write_text(wrapper.replace('__SOURCES__',json.dumps(pages).replace('<','\\u003c')).replace('__CONFIG__',(W/'config.json').read_text()).replace('__TESTS__',(W/'browser-tests.js').read_text()))
shell=shell.replace('<script>',"<script>Object.defineProperty(navigator,'requestMIDIAccess',{configurable:true,value:async()=>({})});</script><script>",1)
shelltest='''<script>
const poll=async fn=>{for(let n=0;n<500;n++){if(fn())return;await new Promise(r=>setTimeout(r,20));}throw Error('Timeout shell');};
async function qaShell(){const output=document.createElement('p');output.id='qaSummary';document.querySelector('header').append(output);let count=0;const check=(v)=>{if(!v)throw Error('Controllo shell '+count);count++;};try{
check(document.querySelectorAll('[data-tab]').length===5);document.querySelector('[data-tab=install]').click();await poll(()=>document.querySelector('iframe')?.contentWindow?.MeightyUI);
const f=document.querySelector('iframe');check(f.getAttribute('allow').includes('midi-sysex'));check(!!f.contentWindow.navigator.requestMIDIAccess);
f.contentWindow.__testBusy(true);await poll(()=>document.querySelector('[data-tab=backup]').disabled);check(document.querySelector('[data-tab=backup]').disabled);
f.contentWindow.__testBusy(false);await poll(()=>!document.querySelector('[data-tab=backup]').disabled);document.querySelector('[data-tab=backup]').click();await poll(()=>document.querySelectorAll('iframe').length===2);check(f.hidden);output.textContent='Shell: '+count+' PASS · 0 FAIL';
}catch(e){output.textContent='Shell FAIL: '+e.message;}}
qaShell();</script>'''
(W/'QA-shell.html').write_text(shell.replace('</body>',shelltest+'</body>'))
print('Built real DOM harness; MIDI fully mocked, no device writes')
