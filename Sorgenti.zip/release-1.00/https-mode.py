from pathlib import Path
R=Path(__file__).resolve().parents[2];S=R/'outputs/fm1-tracker/toolsuite'
p=S/'Shell.html.in';s=p.read_text();a=s.index('<h2>iPhone:');b=s.index('<p class="note">',a)
s=s[:a]+'''<h2>iPhone: HTTPS → Make Available Offline</h2><ol><li>In MIDIWeb Browser apri <b>questa suite dall’indirizzo HTTPS dell’hosting statico</b>, con rete attiva. Nessun Mac o server locale necessario.</li><li>Verifica il titolo <b>Meighty 1.00 · Suite offline 1.2</b> e SHA-256 nella scheda Installazione.</li><li>Nel menu di MIDIWeb scegli <b>Make Available Offline</b> e attendi il completamento. Una sola copia contiene tutti e quattro gli strumenti.</li><li>Richiama la copia offline da MIDIWeb, anche senza rete. Usa file già scaricati sul telefono. Per aggiornare la suite riapri l’indirizzo HTTPS e sostituisci la copia offline.</li></ol>'''+s[b:]
s=s.replace('Avvia-Mac.command oppure Avvia-PC.cmd: server locale Python 3, poi Chrome/Edge. Avvia-iPhone.command serve sul Mac soltanto a trasferire inizialmente la pagina; non si esegue su iOS.','Puoi aprire lo stesso indirizzo HTTPS in Chrome/Edge oppure usare Avvia-Meighty.command / Avvia-Meighty.cmd con Python 3 per il solo uso locale. Avvia-iPhone.command è un’alternativa per le prove dalla rete locale: non serve nel percorso HTTPS e non si esegue su iOS.')
p.write_text(s)
p=Path(__file__).parent/'finalize-suite.py';s=p.read_text();a=s.index('IPHONE/IPAD: PRIMA APERTURA');b=s.index('USO QUOTIDIANO',a)
s=s[:a]+'''IPHONE/IPAD: HTTPS → MAKE AVAILABLE OFFLINE
1. Apri la suite Meighty dall’indirizzo HTTPS dell’hosting statico in MIDIWeb.
   Usa lo stesso servizio predisposto per Bloomy. Non occorre il Mac.
2. Verifica Meighty 1.00 / Suite offline 1.2 e SHA in Installazione.
3. Scegli Make Available Offline e attendi il completamento.
   Basta questa sola pagina: tutti e quattro gli strumenti sono incorporati.
4. Richiama la copia offline dall’app, senza PC e senza rete.
   Per aggiornare, riapri l’indirizzo HTTPS e sostituisci la copia offline.
Non usare File → Apri con MIDIWeb: questo percorso aveva fallito con Bloomy.

'''+s[b:]
a=s.index('La preparazione iniziale dal Mac rimane');b=s.index('MAC / PC',a)
s=s[:a]+'''Il nuovo percorso iniziale usa hosting statico HTTPS, come deciso per Bloomy.
Lo ZIP è una copia di distribuzione: non importa da solo una pagina
nell’archivio offline di MIDIWeb. L’indirizzo definitivo verrà registrato
quando sarà completata la pubblicazione sul servizio scelto per Bloomy.

'''+s[b:]
s=s.replace('initial LAN load then Mac off.','initial HTTPS static hosting then saved offline. LAN is optional development fallback.')
p.write_text(s)
print('Primary route switched to HTTPS; LAN only optional fallback')
