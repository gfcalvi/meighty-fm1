"""Validate linked RAM code, flash image and startup ordering for a HW build."""
from pathlib import Path
import struct, re, json, sys
b = Path(__file__).resolve().parent.parent
r = b / 'Sorgenti/fm1-tracker-poly3'
hw = int(sys.argv[1])
version = sys.argv[2]
d = r / f'build/hardware-hw{hw}'
raw = (d / 'tracker.elf').read_bytes()
image = (d / 'tracker.bin').read_bytes()
mp = (d / 'tracker.map').read_text()
def sym(name):
    m = re.search(r'0x([0-9a-fA-F]+)\s+' + re.escape(name) + r'\s*=', mp)
    assert m, name
    return int(m[1], 16)
shoff = struct.unpack_from('<I', raw, 32)[0]
shsize, shcount, shstr = struct.unpack_from('<HHH', raw, 46)
sh = [struct.unpack_from('<10I', raw, shoff + i * shsize) for i in range(shcount)]
names = raw[sh[shstr][4]:sh[shstr][4] + sh[shstr][5]]
sec = {names[x[0]:].split(b'\0',1)[0].decode():x for x in sh}
x = sec['.ram_hot2']
lma = sym('_rh2_load')
n = x[5]
assert image[lma - 0x02000120:lma - 0x02000120 + n] == raw[x[4]:x[4] + n]
body = (r / 'emulator/main.c').read_text().split('void fm1_cstart(void)',1)[1]
assert body.index('for(w=_rh2_start') < body.index('tr_benchmark_arithmetic(') < body.index('tracker_device_init(')
report = json.loads((d / 'report.json').read_text())
assert report['image_bytes'] == len(image) <= 552672
rom = 552672 - len(image)
ram = 0x1c07f00 - sym('_rh_end')
guard = 0x1c74000 - sym('_bss_end')
assert min(rom, ram, guard) > 0
data = dict(secondary_ram_bytes=n, secondary_image_matches_ELF=True, boot_order='copy secondary RAM -> math benchmark -> device init -> CPU1/audio', rom_remaining=rom, ramtext_remaining=ram, bss_to_stack_guard=guard, project_bytes=11944, voice_runtime_cache_only=True)
(b / f'Verifiche/poly3-{version}-memory.json').write_text(json.dumps(data,indent=2) + '\n')
print(json.dumps(data))
