"""Validate linked RAM code, flash image and startup ordering for a HW build."""
from pathlib import Path
import struct, re, json, sys
b = Path(__file__).resolve().parent.parent
r = b / 'Sorgenti/fm1-tracker-poly3'
hw = int(sys.argv[1])
version = sys.argv[2]
d = r / f'build/hardware-hw{hw}'
raw = (d / 'tracker.elf').read_bytes()
image = (d / 'tracker.bin').read_bytes()
mp = (d / 'tracker.map').read_text()
def sym(name):
    m = re.search(r'0x([0-9a-fA-F]+)\s+' + re.escape(name) + r'\s*=', mp)
    assert m, name
    return int(m[1], 16)
shoff = struct.unpack_from('<I', raw, 32)[0]
shsize, shcount, shstr = struct.unpack_from('<HHH', raw, 46)
sh = [struct.unpack_from('<10I', raw, shoff + i * shsize) for i in range(shcount)]
names = raw[sh[shstr][4]:sh[shstr][4] + sh[shstr][5]]
sec = {names[x[0]:].split(b'\0',1)[0].decode():x for x in sh}
x = sec['.ram_hot2']
lma = sym('_rh2_load')
n = x[5]
assert image[lma - 0x02000120:lma - 0x02000120 + n] == raw[x[4]:x[4] + n]
body = (r / 'emulator/main.c').read_text().split('void fm1_cstart(void)',1)[1]
assert body.index('for(w=_rh2_start') < body.index('tracker_device_init(')
if hw < 28: assert body.index('for(w=_rh2_start') < body.index('tr_benchmark_arithmetic(') < body.index('tracker_device_init(')
else: assert 'tr_benchmark_arithmetic' not in mp and 'tr_bench_kernel' not in mp
report = json.loads((d / 'report.json').read_text())
assert report['image_bytes'] == len(image) <= 552672
rom = 552672 - len(image)
ram = 0x1c07f00 - sym('_rh_end')
guard = 0x1c74000 - sym('_bss_end')
assert min(rom, ram, guard) > 0
data = dict(secondary_ram_bytes=n, secondary_image_matches_ELF=True, boot_order=('copy secondary RAM -> math benchmark -> device init -> CPU1/audio' if hw < 28 else 'copy secondary RAM -> device init -> CPU1/audio; math benchmark replaced by scheduler diagnostics'), rom_remaining=rom, ramtext_remaining=ram, bss_to_stack_guard=guard, project_bytes=11944, voice_runtime_cache_only=True)
if hw >= 29:
    for name, prefix in [('.ram_text','_rt'), ('.ram_hot','_rh')]:
        bank = sec[name]
        offset = sym(prefix + '_load') - 0x02000120
        assert image[offset:offset + bank[5]] == raw[bank[4]:bank[4] + bank[5]]
    assert body.index('for(w=_rh_start') < body.index('for(w=_rh2_start') < body.index('fm1_timer5_start(')
    assert body.index('volatile("csync"') < body.index('fm1_timer5_start(')
    def function_address(name):
        m = re.search(r'^\s*0x([0-9a-fA-F]+)\s+' + re.escape(name) + r'\s*$', mp, re.M)
        assert m, name
        return int(m[1],16)
    addresses = {name:function_address(name) for name in ['isr_alnk0_ram','isr_timer5_ram','fm1_alnk0_irq','fm1_timer5_irq','tracker_device_active_voices','tracker_device_audio_cost','tracker_device_render']}
    for name in ['isr_alnk0_ram','isr_timer5_ram']:
        assert sym('_rh_start') <= addresses[name] < sym('_rh_end')
    for name in ['fm1_alnk0_irq','tracker_device_active_voices','tracker_device_audio_cost','tracker_device_render']:
        assert sym('_rt_start') <= addresses[name] < sym('_rt_end')
    assert sym('_rh2_start') <= addresses['fm1_timer5_irq'] < sym('_rh2_end')
    preprocessed = (d / 'main.i').read_text()
    restarts = re.findall(r'fm1_audio_init\s*\(\s*abuf\s*,\s*256\s*,\s*(\w+)\s*,\s*3\s*\)',preprocessed)
    assert len(restarts) >= 5 and set(restarts) == {'isr_alnk0_ram'}, restarts
    assert re.search(r'fm1_timer5_start\s*\(\s*isr_timer5_ram\s*,\s*4\s*\)',preprocessed)
    assembly = (d / 'main.s').read_text()
    audio = assembly.split('fm1_alnk0_irq:',1)[1].split('.Lfunc_end',1)[0]
    callees = re.findall(r'\bcall\s+(\w+)',audio)
    assert set(callees) == {'tracker_device_render','tracker_device_active_voices','tracker_device_audio_cost'}, callees
    device = (d / 'device.s').read_text()
    for name in ['tracker_device_active_voices','tracker_device_audio_cost']:
        routine = device.split(name + ':',1)[1].split('.Lfunc_end',1)[0]
        assert not re.search(r'\bcall\b',routine)
    data['boot_order']='copy DSP RAM -> copy IRQ entries -> copy secondary RAM -> csync -> device init -> IRQ enable'
    data.update(irq_ram_addresses={name:hex(address) for name,address in addresses.items()}, copied_irq_bank_bytes=sec['.ram_hot'][5], all_dma_restarts_use_ram_vector=len(restarts), audio_direct_callees_in_ram=True, tail_observers_no_libc_calls=True, audio_frames=128, audio_budget_us=2902, interrupt_priorities_unchanged=[3,4])
(b / f'Verifiche/poly3-{version}-memory.json').write_text(json.dumps(data,indent=2) + '\n')
print(json.dumps(data))
