from pathlib import Path
import json,base64,hashlib,shutil,html,zipfile
b=Path(__file__).resolve().parent.parent;r=b/'Sorgenti/fm1-tracker-poly3';o=b/'Candidata-Poly3-A3';o.mkdir(exist_ok=True)
fw=b/'Sorgenti/Meighty-1.02-A3-Poly3.fwsc';raw=fw.read_bytes();report=json.loads((r/'build/hardware-hw19/report.json').read_text());assert hashlib.sha256(raw).hexdigest()==report['sha256']
c=json.loads((b/'Verifiche/RC3/config-rc3.json').read_text());c.update(version='1.02 A3',suiteVersion='2.2');c['hardware'].update(product='FM-1_998204',data=base64.b64encode(raw).decode(),sha256=report['sha256'])
empty=(b/'Verifiche/empty-rc6.bin').read_bytes()+bytes([0,1,0,0]);assert len(empty)==11944;c['empty'].update(schema=2,data=base64.b64encode(empty).decode(),sha256=hashlib.sha256(empty).hexdigest())
t=(r/'toolsuite/SimpleSuite.html.in').read_text()
for key,path in [('SDK','sdk/WebUpdate.js'),('INSTALLER','web/installer/InstallerCore.js'),('FORMATS','toolsuite/Formats.js'),('FLOW','toolsuite/BackupFlow.js'),('SIMPLEUI','toolsuite/SimpleUI.js')]:t=t.replace('/*'+key+'*/',(r/path).read_text())
t=t.replace('/*CONFIG*/',json.dumps(c,ensure_ascii=False,separators=(',',':')))
for name in ['index.html','Meighty.html']:(o/name).write_text(t)
shutil.copy2(fw,o/fw.name)
shutil.copy2(b/'Candidata-RC7-Tools2.1/index.html',o/'Ritorno-RC7.html')
shutil.copy2(b/'Candidata-RC7-Tools2.1/Ritorno-RC3.html',o/'Ritorno-RC3.html')
guide='''MEIGHTY 1.02 A3 / HW19 - POLY3 - TOOLS 2.2

Candidata per il collaudo fisico. A1 ha fallito lo stress: PolyON MAX3865us/LATE8077/MISSES8169; prova pulita PolyOFF a riposo1445/0/0, dopo60s3156/2619/2632. A2 ha fallito lo stress PolyON:MAX3753/LATE6573/MISSES6576, audio distorto. A3 parallelizza anche pan/mandate, calcola i target dei fader una sola volta per blocco e usa blocchi interni128campioni per ridurre le sincronizzazioni; rispetta i confini del clock. Ripartisce5+5voci e memorizza esattamente la divisioneFM quando gli ingressi non cambiano. Nessuna riduzione di qualità. Audio verificato identico adA1 su18casi/1152000frame con cambi modello,Color,Timbre,LFO,glide e accordi. Miglioramento fisico da misurare. Non sostituisce la versione stabile RC7 nel sito principale. La tenuta sul dispositivo non è ancora dimostrata dai soli test software.

USO
Global → Poly 3 track → OFF oppure T1..T8 con K2. La scelta seleziona anche la traccia per l’editing. Le altre sette restano monofoniche. Il progetto conserva questa impostazione; nell’intestazione della traccia interessata compare 3V. Instrument mostra anche il contesto Tn / 3V accanto a Ixx.
La tastiera suona fino a tre note vere con inviluppi, filtri e LFO indipendenti. Ogni rilascio interessa quel tasto. Alla quarta nota viene sostituita prima una voce libera, altrimenti la più vecchia. Mixer, mute/solo, pan e mandate appartengono alla traccia e agiscono sull’intero gruppo.

PHRASE
CHD XY aggiunge due intervalli alla nota fondamentale: 47 maggiore, 37 minore, 57 sus4. Sono semitoni (cifre esadecimali), soggetti alla scala globale come le note normali: per Do4 con CHD47 suonano Do4/Mi4/Sol4 insieme. Intervallo0 disattiva quella voce aggiunta; CHD00 torna alle note indipendenti e consente di sovrapporre note successive fino a tre. La modalità CHD resta attiva sulle note successive fino a CHD00. ARP mantiene il suo significato di arpeggio, non è la polifonia.
OFF rilascia il gruppo, KIL/STOP lo fermano. LEV controlla il gruppo dal mixer; VOL riguarda la voce corrente (e viene copiato sulle nuove note di un accordo). Le Table progrediscono separatamente per le voci; i comandi del mixer restano condivisi.
In Phrase la tastiera registra una triade nel campo nota e in FX1 come CHD. Attenzione: sostituisce FX1. Il formato compatto registra massimo tre tasti con intervalli entro15semitoni. Voicing più larghi sono suonabili live, ma per registrarli viene mostrato un avviso. La copia/incolla ARP-SHIFT rimane disponibile.

PROGETTI / COMPATIBILITÀ
I vecchi slot e i file.monofonici si aprono con PolyOFF. Non serve inizializzare gli slot. Layout nuovo11944byte, precedente11940; partizioni e bootloader non cambiano. La banca Poly3 è.meighty versione2/schema2. Per le banche.meighty i tools2.2 mantengono il formato precedente quando il contenuto è interamente compatibile; un progetto polifonico non viene ridotto silenziosamente per RC7/vecchio Emulator.
Con A3 usa questa pagina/poly3 per backup/ripristino e conserva i backup.meighty. I tools2.1 non leggono i dati nuovi. Per tornare a RC7 usa Ritorno-RC7.html; i progetti polifonici richiedono la candidata per essere riprodotti. I file restano locali al browser.

COLLAUDO SUL DISPOSITIVO
1. Installa questa candidata dal tab Firmware e conferma nel pannello. L’installer verifica l’identità nuova FM-1_998204; in GLOBAL deve comparire1.02A1. Non scollegare durante la scrittura.
2. Per la prima prova seleziona Global → Poly3track → T4, apri Instrument e premi tre tasti: ascolta la triade e i rilasci separati. In alternativa carica Poly3-Pad-one-track.meighty in una casella libera di Ripristino/Caricamento e premi PLAY: il pad suona sulla sola T4.
3. Salva il progetto di stress in uno slot scelto da te, conservando prima eventuali brani che vuoi tenere. Gli altri slot restano invariati. Il file Poly3-Stress-10-voices.meighty usa T8 polifonica, tutte le altre tracce,18motori in sequenza,300BPM, filtri/LFO/delay/reverb. È rumoroso: prova a volume basso.
4. Per misure pulite riavvia, carica lo slot del test e attendi5secondi senza PLAY. Leggi MAX/LATE nel tabFirmware con Leggi carico audio, oppure con OCT- e OCT+ insieme sul dispositivo. Poi PLAY per60secondi, STOP, rileggi. Il budget del blocco è2902us: vogliamo LATE0 e un massimo inferiore al budget, con margine.
5. Verifica anche l’ascolto da tastiera su una traccia diversa dalla polifonica durante lo stress: questo aggiunge un preview e porta il caso massimo a11voci. Riporta MAX/LATE/MISSES e la riga Blocco del MAX: PREP/CPU0/CPU1/ATTESA/MIX-FX. CPU1 lavora in parallelo e non va sommato agli altri tempi. Riporta anche qualità audio; non definiremo stabile la funzione prima di questi risultati.

VERIFICHE SOFTWARE
18modelli x8tracce: audio scalar/blocchi/pthread identico con10voci; PCM22.05/32kHz, sorgenti legacy, preview11voci, note-off, stealing, mute e Table indipendenti. ASan/UBSan e ThreadSanitizer passati. Regressione1216000frame con effetti/preview/clock/STOP. PolyOFF: audio identico aRC7 su19casi. Pannello e tutti8slot, migrazione11940->11944. Tools120controlli sul core nuovo e118su quello precedente; codec71nuovo/63precedente. OTA/loader verificati. Stress nativo aggiuntivo:60secondi di audio/1920000frame con11voci, tutti18modelli, mixer/mandate/master/resonanza massimi e variazioni di feedback, divisioni e tempo; nessun errore dei sanitizzatori. Questi controlli non misurano il tempo reale PI32. Il Mac vede USB ma l’accesso CoreMIDI automatico dell’agente è indisponibile(-10833): nessun flash fisico eseguito.
'''
(o/'POLY3-LEGGIMI.txt').write_text(guide)
(o/'LEGGIMI.html').write_text('<!doctype html><meta charset="utf-8"><title>Meighty Poly3</title><style>body{max-width:850px;margin:30px auto;padding:20px;font:16px/1.6 system-ui;background:#071e20;color:#edf9f6}pre{white-space:pre-wrap;font:inherit}a{color:#70dfd0}</style><a href="index.html">Apri candidata Poly3</a><pre>'+html.escape(guide)+'</pre>')
logs=['poly3-core.log','poly3-panel.log','poly3-block-regression.log','poly3-tsan.log','poly3-tools.log','poly3-tools-rc7.log','poly3-codec.log','poly3-codec-legacy.log','poly3-ota.log','poly3-loader.log','poly3-stress.log','poly3-balanced.log','poly3-balanced-tsan.log','poly3-hash-0.log','poly3-hash-1.log','poly3-hash-A3.log','poly3-parallel-mix.log','poly3-parallel-tsan.log','poly3-parallel-block.log','poly3-parallel-device.log']
log_source={'poly3-block-regression.log':'poly3-parallel-block.log','poly3-core.log':'poly3-parallel-mix.log','poly3-tsan.log':'poly3-parallel-tsan.log','poly3-stress.log':'poly3-stress-A3.log','poly3-tools.log':'poly3-tools-A3.log','poly3-ota.log':'poly3-ota-A3.log','poly3-loader.log':'poly3-loader-A3.log'}
for name in logs:shutil.copy2(b/'Verifiche'/log_source.get(name,name),o/name)
report.update(version='1.02 A3',build=19,suite='2.2',product='FM-1_998204',project_bytes=11944,previous_project_bytes=11940,hardware_validated=False,mono_audio='RC7 identical:19cases/608000frames',render_regression_frames=1216000,tools_new_checks=120,tools_legacy_checks=118,native_stress_frames=1920000,codec_new_checks=71,codec_legacy_checks=63,tsan='pass',host_sanitizers='ASan/UBSan pass',flash_regions='unchanged',font_lossless_saving=6375,physical_usb='A3 not tested; A1/A2 stress FAIL; live3notes/release PASS',audio_vs_A1_frames=1152000,prior_A1_poly_off_idle=[1445,0,0],prior_A1_poly_off_play=[3156,2619,2632],prior_A1_poly_on_play=[3865,8077,8169],render_split='5+5 forPoly,4+4 mono',braids_fm='exact variable division cache',partial_mixer='parallel pan/sends with exact per-track ramp snapshots',render_chunk=128,resampler_regression_frames=258174,prior_A2_poly_on_play=[3753,6573,6576])
(o/'VERIFICHE.json').write_text(json.dumps(report,indent=2)+'\n')
for name in ['LICENSE-Meighty.md','LICENSE-LZFSE.txt']:shutil.copy2(b/'Candidata-RC7-Tools2.1'/name,o/name)
with zipfile.ZipFile(o/'Sorgenti.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(r.rglob('*')):
  rel=p.relative_to(r)
  if p.is_file() and not any(x in rel.parts for x in ['build','.git','__pycache__']) and p.name!='.DS_Store':z.write(p,'fm1-tracker-poly3/'+str(rel))
 for name in ['build-poly3-a3-suite.py']:z.write(b/'Verifiche'/name,'verification/'+name)
 for name in logs:z.write(o/name,'verification/'+name)
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(o.iterdir()) if p.is_file() and p.name!='SHA256SUMS.txt'}
(o/'SHA256SUMS.txt').write_text(''.join(v+'  '+k+'\n' for k,v in hashes.items()))
print(json.dumps({'folder':str(o),'sha256':report['sha256'],'page_bytes':len(t.encode()),'files':len(hashes)}))
