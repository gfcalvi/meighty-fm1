
int original(int n,unsigned gain){long long p=(long long)n*gain;return (int)((p+(p<0?32767:0))>>15);}
int magnitude(int n,unsigned gain){unsigned mag=n<0?0U-(unsigned)n:(unsigned)n;unsigned q=(unsigned)(((unsigned long long)mag*gain)>>15);return (int)(n<0?0U-q:q);}
int split16(int n,unsigned gain){unsigned mag=n<0?0U-(unsigned)n:(unsigned)n;unsigned q=(mag>>15)*gain+((mag&32767U)*gain>>15);return (int)(n<0?0U-q:q);}
