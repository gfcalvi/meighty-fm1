"""Package the tested HW26 candidate. Never opens or writes physical USB."""
from pathlib import Path
import json, base64, hashlib, shutil, html, zipfile

b = Path(__file__).resolve().parent.parent
r = b / 'Sorgenti/fm1-tracker-poly3'
o = b / 'Candidata-Poly3-A10'
o.mkdir(exist_ok=True)
fw = b / 'Sorgenti/Meighty-1.02-A10-Poly3.fwsc'
raw = fw.read_bytes()
report = json.loads((r / 'build/hardware-hw26/report.json').read_text())
assert hashlib.sha256(raw).hexdigest() == report['sha256']
assert report['image_bytes'] <= 552672
tests = json.loads((b / 'Verifiche/poly3-A10-host-tests.json').read_text())
assert all(x['status'] == 'PASS' for x in tests)
assert (b / 'Verifiche/poly3-A10-hash.log').read_bytes() == (b / 'Verifiche/poly3-hash-0.log').read_bytes()
assert 'PASS' in (b / 'Verifiche/poly3-A10-effects.log').read_text()
assert 'PASS 123 checks' in (b / 'Verifiche/poly3-tools-A10.log').read_text()
c = json.loads((b / 'Verifiche/RC3/config-rc3.json').read_text())
c.update(version='1.02 A10', suiteVersion='2.2')
c['hardware'].update(product='FM-1_998211', data=base64.b64encode(raw).decode(), sha256=report['sha256'])
empty = (b / 'Verifiche/empty-rc6.bin').read_bytes() + bytes([0, 1, 0, 0])
assert len(empty) == 11944
c['empty'].update(schema=2, data=base64.b64encode(empty).decode(), sha256=hashlib.sha256(empty).hexdigest())
t = (r / 'toolsuite/SimpleSuite.html.in').read_text()
for key, path in [('SDK','sdk/WebUpdate.js'), ('INSTALLER','web/installer/InstallerCore.js'), ('FORMATS','toolsuite/Formats.js'), ('FLOW','toolsuite/BackupFlow.js'), ('SIMPLEUI','toolsuite/SimpleUI.js')]:
    t = t.replace('/*' + key + '*/', (r / path).read_text())
t = t.replace('/*CONFIG*/', json.dumps(c, ensure_ascii=False, separators=(',', ':')))
for name in ['index.html', 'Meighty.html']:
    (o / name).write_text(t)
shutil.copy2(fw, o / fw.name)
for p in (b / 'Candidata-Poly3-A9').glob('Poly3-*'):
    if p.is_file(): shutil.copy2(p, o / p.name)
shutil.copy2(b / 'Candidata-Poly3-A8/index.html', o / 'Ritorno-A8.html')
shutil.copy2(b / 'Candidata-Poly3-A9/index.html', o / 'Ritorno-A9.html')
for name in ['Ritorno-A6.html', 'Ritorno-RC7.html', 'Ritorno-RC3.html', 'LICENSE-Meighty.md', 'LICENSE-LZFSE.txt']:
    shutil.copy2(b / 'Candidata-Poly3-A8' / name, o / name)

guide = 'MEIGHTY 1.02 A10 / HW26 — POLY3 — TOOLS 2.2\n\nCandidata per aumentare il margine audio mantenendo tre voci su una traccia e sette tracce monofoniche. Il sito principale conserva RC7.\n\nCOSA CAMBIA RISPETTO AD A9 / HW25\nLe interpolazioni di senoidi, tabella bell, wavetable, campioni PCM e tabelle di controllo Braids usano prodotti interi a 32 bit dove i limiti dei dati lo consentono. Per le frazioni a 24 bit il calcolo viene scomposto in due prodotti: il risultato conserva esattamente il troncamento verso zero della formula precedente a 64 bit, anche per valori negativi.\nNon cambia alcuna tabella, forma d’onda, risoluzione della fase, frequenza di elaborazione, inviluppo o effetto. Sono conservate le ottimizzazioni di FM4 e degli effetti già provate su HW25. Progetti e protocolli restano invariati.\n\nINSTALLAZIONE E PROVA FISICA\n1. Apri la pagina HTTPS, tab Firmware, scegli Installa 1.02 A10 e conferma la scrittura. Mantieni cavo e alimentazione collegati durante l’update.\n2. Verifica GLOBAL: 1.02 A10. Leggi carico audio deve riportare HW26. Se vedi ancora HW25 aggiorna la pagina prima di installare.\n3. Riavvia per azzerare i massimi. Carica lo stesso Poly3-Stress-10-voices.meighty già usato su HW25, con Poly 3 track = T8. Non inizializzare gli slot.\n4. Seleziona T1 con SELECT, apri Instrument e scegli I10 (esadecimale, FM4) con K3. Premi PLAY e tieni un Do centrale per 60 secondi, a volume basso. Rilascia, STOP e Leggi carico audio.\n5. Riporta tutta la lettura MAX/LATE/MISSES, PREP/CPU0/CPU1/ATTESA/MIX-FX, DIV/SHIFT/CHECK e qualità audio. CPU1 lavora in parallelo e non va sommato a CPU0.\nRiferimento HW25: MAX 2675 µs, LATE 0, MISSES 0; costi 101/2125/2478/85/326 µs. Budget 2902 µs: margine osservato 227 µs. Audio confermato buono. Obiettivo indicativo 300–400 µs; il miglioramento di HW26 va misurato, non è garantito dai test Mac.\nPer tornare a HW25 usa Ritorno-A9.html. Ritorno-A8.html, Ritorno-A6.html e RC7 restano disponibili. Su iPhone in MIDIWeb Browser aggiorna Make Available Offline e salva separatamente anche la pagina di ritorno per usarla senza rete.\n\nUSO DELLA POLIFONIA\nGLOBAL → Poly 3 track → OFF oppure T1–T8 con K2. La scelta viene salvata nel progetto. La traccia scelta suona tre note vere, con filtri, inviluppi e rilasci indipendenti; le altre sette restano monofoniche. Mixer, mute/solo e mandate appartengono al gruppo. Alla quarta nota si riusa una voce libera oppure la più vecchia.\nIn Phrase, CHD 47 aggiunge terza maggiore e quinta; CHD 37 terza minore e quinta; CHD 57 crea un sus4. Gli intervalli sono semitoni esadecimali, quantizzati alla scala globale. CHD resta attivo sulle note seguenti; CHD 00 lo disattiva e consente sovrapposizioni indipendenti. Un intervallo zero disattiva quella voce aggiuntiva.\nOFF rilascia il gruppo; KIL e STOP lo fermano. LEV controlla il livello condiviso; VOL interessa la voce corrente ed è copiato sulle nuove note dell’accordo. Le Table avanzano separatamente per ciascuna voce.\nLa tastiera in Phrase registra fondamentale e CHD in FX1, sostituendo il contenuto precedente di FX1. Si registrano fino a tre note, con intervalli entro 15 semitoni; voicing più larghi restano suonabili live. ARP come SHIFT conserva selezione, cancellazione e copia/incolla.\n\nPROGETTI E TOOLS\nQuesta suite 2.2 ha quattro tab: Firmware, Backup/estrazione, Conversione, Ripristino/caricamento. Per trasferire una song seleziona il file nella casella dello slot desiderato e scrivi: vengono sostituiti solo gli slot contenenti un file; le caselle vuote non cancellano gli altri slot. Non è richiesta un’inizializzazione preventiva.\nI vecchi progetti da 11940 byte sono migrati; quelli attuali ne usano 11944. Le banche polifoniche usano .meighty v2/schema2. Non ridurre i progetti polifonici per i vecchi firmware; conserva un backup .meighty prima di un eventuale ritorno. I dati musicali restano locali al browser.\n\nVERIFICHE\n7370775 confronti delle interpolazioni con le formule signed originali a 64 bit: tutti i 131071 delta possibili tra estremi a 16 bit, frazioni limite a 8/16/24 bit, un milione di frazioni casuali a 24 bit, seno/bell e fine periodo, quattro banchi wavetable per sei mip, 256 posizioni e 65 fasi, tabelle Braids con pitch ai limiti. Formule ed effetti contro i riferimenti congelati A8/A9 identici.\n16 test host passati con ASan/UBSan e ThreadSanitizer. Gold A1: 1152000 frame identici; stress nativo 60 s/1920000 frame/11 voci con hash invariato. Live 2432 casi, cache 1536 blocchi, sparse 432 casi, renderer 1216000 frame e ricampionamento 258174 frame esatti. Tools: 123 controlli dei veri handler JavaScript collegati al core C, tutti gli otto slot. OTA, loader, limiti memoria e copia del codice RAM verificati.\nNessuna misura di tempo nativa del Mac rappresenta una misura del chip. Non promuovere automaticamente la candidata a stabile prima del collaudo fisico.\n'
(o / 'POLY3-LEGGIMI.txt').write_text(guide)
(o / 'LEGGIMI.html').write_text('<!doctype html><html lang="it"><meta charset="utf-8"><title>Meighty A10 / HW26</title><style>body{max-width:850px;margin:30px auto;padding:20px;font:16px/1.6 system-ui;background:#071e20;color:#edf9f6}pre{white-space:pre-wrap;font:inherit}a{color:#70dfd0}</style><a href="index.html">Apri Meighty A10</a><pre>' + html.escape(guide) + '</pre></html>')

logs = sorted(p.name for p in (b / 'Verifiche').glob('poly3-A10-*.log'))
logs += ['poly3-A10-host-tests.json', 'poly3-A10-memory.json', 'poly3-tools-A10.log', 'poly3-ota-A10.log', 'poly3-loader-A10.log', 'poly3-hardware-A9.json']
for name in logs: shutil.copy2(b / 'Verifiche' / name, o / name)
report.update(version='1.02 A10', build=26, product='FM-1_998211', suite='2.2', project_bytes=11944, previous_project_bytes=11940, hardware_validated=False, physical_usb='HW26 not yet measured; HW25 reference 2675/0/0 with good audio', prior_A9_live=[2675,0,0], margin_target_us=[300,400], fm4_cache_oracle_samples=131072, effects_oracle_wet_frames=96000, audio_vs_A1_frames=1152000, native_stress_frames=1920000, native_stress_hash='74916ec3ba4c1e56', live_cases=2432, cache_blocks=1536, sparse_cases=432, render_regression_frames=1216000, resampler_regression_frames=258174, tools_new_checks=123, host_sanitizers='ASan/UBSan pass', tsan='pass', flash_regions='unchanged', math_benchmark='unchanged; full loop timings only', exact_fx_shifts=True, exact_fm4_increment_cache=True, memory=json.loads((o / 'poly3-A10-memory.json').read_text()), fallback='Ritorno-A9.html', interpolation_oracle_checks=7370775, exact_bounded_interpolation=True)
(o / 'VERIFICHE.json').write_text(json.dumps(report, indent=2) + '\n')
with zipfile.ZipFile(o / 'Sorgenti.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(r.rglob('*')):
        rel = p.relative_to(r)
        if p.is_file() and not any(x in rel.parts for x in ['build','.git','__pycache__']) and p.name != '.DS_Store': z.write(p, 'fm1-tracker-poly3/' + str(rel))
    z.write(Path(__file__), 'verification/' + Path(__file__).name)
    for name in ['run-poly3-host-tests.py','audit-poly3-memory.py']: z.write(b / 'Verifiche' / name, 'verification/' + name)
    for name in logs: z.write(o / name, 'verification/' + name)
hashes = {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(o.iterdir()) if p.is_file() and p.name != 'SHA256SUMS.txt'}
(o / 'SHA256SUMS.txt').write_text(''.join(v + '  ' + k + '\n' for k,v in hashes.items()))
print(json.dumps({'folder':str(o), 'sha256':report['sha256'], 'files':len(hashes)}))
