"""Native correctness/concurrency regression; does not measure PI32 timing."""
from pathlib import Path
import os, subprocess, concurrent.futures, json, sys

root = Path(__file__).resolve().parent.parent
src = root / 'Sorgenti/fm1-tracker-poly3'
out = root / 'Verifiche'
version = sys.argv[1] if len(sys.argv) > 1 else 'A10'
env = dict(os.environ, TMPDIR=str(root / 'Temporanei'), SDKROOT='/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk')
base = ['/Library/Developer/CommandLineTools/usr/bin/clang', '-DFM1_HOST_TEST', '-DFM1_BLOCK_RENDER=1', '-O1', '-g', '-fno-omit-frame-pointer', '-Iapp', '-Iapp/synth', '-Isdk/include']
jobs = [
    ('products', 'test_exact_products.c', 'asan', 'include'),
    ('interpolation', 'test_exact_interpolation.c', 'asan', 'include'),
    ('fmcache', 'test_fm4_exact_cache.c', 'asan', 'include'),
    ('effects', 'test_effects_exact.c', 'asan', 'include'),
    ('control', 'test_exact_control.c', 'asan', 'include'),
    ('bench', 'test_arithmetic_bench.c', 'asan', 'normal'),
    ('core', 'test_poly3.c', 'asan', 'normal'),
    ('tsan', 'test_poly3_render_clock.c', 'tsan', 'normal'),
    ('live', 'test_poly3_live.c', 'tsan', 'normal'),
    ('cache', 'test_poly3_mix_cache.c', 'tsan', 'normal'),
    ('overlap', 'test_poly3_stream.c', 'tsan', 'normal'),
    ('duet', 'test_poly3_duet.c', 'asan', 'normal'),
    ('hash', 'test_poly3_audio_hash.c', 'asan', 'normal'),
    ('stress', 'test_poly3_stress.c', 'asan', 'normal'),
    ('block', 'test_block_render.c', 'asan', 'normal'),
    ('device', 'test_block_device.c', 'asan', 'normal'),
    ('panel', 'test_poly3_panel.c', 'asan', 'device'),
]

def run(job):
    name, test, san, kind = job
    log = out / f'poly3-{version}-{name}.log'
    exe = out / f'test-poly3-{version}-{name}'
    cmd = base + ['-fsanitize=' + ('thread' if san == 'tsan' else 'address,undefined'), 'tests/' + test]
    if kind != 'include': cmd += ['app/tracker/tracker.c']
    cmd += ['app/tracker/commands.c']
    if kind == 'device': cmd += ['app/tracker/device.c', '-DTEST_FLASH_BYTES=0x49000']
    cmd += ['-pthread', '-o', str(exe)]
    with log.open('w') as f:
        result = subprocess.run(cmd, cwd=src, env=env, stdout=f, stderr=subprocess.STDOUT)
        if result.returncode: return dict(test=name, status='COMPILE FAIL', code=result.returncode)
        args = [str(exe)]
        if name == 'stress': args += [str(root / 'Candidata-Poly3-A9/Poly3-Stress-10-voices.project.bin')]
        result = subprocess.run(args, cwd=src, env=env, stdout=f, stderr=subprocess.STDOUT, timeout=240)
    return dict(test=name, status='PASS' if result.returncode == 0 else 'FAIL', code=result.returncode)

results = []
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    for f in concurrent.futures.as_completed([pool.submit(run, j) for j in jobs]):
        result = f.result()
        results.append(result)
        print(json.dumps(result), flush=True)
(out / f'poly3-{version}-host-tests.json').write_text(json.dumps(results, indent=2) + '\n')
if any(x['code'] for x in results): raise SystemExit(1)
assert (out / f'poly3-{version}-hash.log').read_bytes() == (out / 'poly3-hash-0.log').read_bytes(), 'A1 audio gold differs'
assert 'hash74916ec3ba4c1e56' in (out / f'poly3-{version}-stress.log').read_text(), 'Stress audio differs'
print('PASS frozen A1 audio hashes and full-stress hash')
