	.text
	.file	"Verifiche/arithmetic-mul-q15.c"
	.globl	original
	.p2align	1
	.type	original,@function
original:                               ; @original
; BB#0:
	[--sp] = {rets, r5, r4}
	r2 = r0
	r3 = r2 >>> 31
	r0 = r1 * r3
	r3_r2 = r1 * r2 (u)
	r3 += r0
	r1_r0 = r3_r2
	r1_r0 >>>= 63
	r4 = 32767
	r4 &= r0
	r5 = 0
	r0 = r4 + r2
	r1 = r5 + r3 + c
	r1_r0 >>= 15
                                        ; kill: %R0<def> %R0<kill> %D0<kill>
	{pc, r5, r4} = [sp++]
.Lfunc_end0:
	.size	original, .Lfunc_end0-original

	.globl	magnitude
	.p2align	1
	.type	magnitude,@function
magnitude:                              ; @magnitude
; BB#0:
	[--sp] = {rets, r5, r4}
	r2 = r0
	r0 = abs(r2)
	r5_r4 = r0 * r1 (u)
	r5_r4 >>= 15
	r0 = 0x0 - r4
	ifs (r2 >= 0) {
		r0 = r4
	}
	{pc, r5, r4} = [sp++]
.Lfunc_end1:
	.size	magnitude, .Lfunc_end1-magnitude

	.globl	split16
	.p2align	1
	.type	split16,@function
split16:                                ; @split16
; BB#0:
	[--sp] = {rets, r4}
	r2 = r0
	r0 = abs(r2)
	r3 = r0 >> 15
	r3 *= r1
	r4 = 32767
	r0 &= r4
	r0 *= r1
	r0 = r0 >> 15
	r1 = r0 + r3
	r0 = 0x0 - r1
	ifs (r2 >= 0) {
		r0 = r1
	}
	{pc, r4} = [sp++]
.Lfunc_end2:
	.size	split16, .Lfunc_end2-split16


