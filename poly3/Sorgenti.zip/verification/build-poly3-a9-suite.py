"""Package the tested HW25 candidate. Never opens or writes physical USB."""
from pathlib import Path
import json, base64, hashlib, shutil, html, zipfile

b = Path(__file__).resolve().parent.parent
r = b / 'Sorgenti/fm1-tracker-poly3'
o = b / 'Candidata-Poly3-A9'
o.mkdir(exist_ok=True)
fw = b / 'Sorgenti/Meighty-1.02-A9-Poly3.fwsc'
raw = fw.read_bytes()
report = json.loads((r / 'build/hardware-hw25/report.json').read_text())
assert hashlib.sha256(raw).hexdigest() == report['sha256']
assert report['image_bytes'] <= 552672
tests = json.loads((b / 'Verifiche/poly3-A9-host-tests.json').read_text())
assert all(x['status'] == 'PASS' for x in tests)
assert (b / 'Verifiche/poly3-A9-hash.log').read_bytes() == (b / 'Verifiche/poly3-hash-0.log').read_bytes()
assert 'PASS' in (b / 'Verifiche/poly3-A9-effects.log').read_text()
assert 'PASS 123 checks' in (b / 'Verifiche/poly3-tools-A9.log').read_text()
c = json.loads((b / 'Verifiche/RC3/config-rc3.json').read_text())
c.update(version='1.02 A9', suiteVersion='2.2')
c['hardware'].update(product='FM-1_998210', data=base64.b64encode(raw).decode(), sha256=report['sha256'])
empty = (b / 'Verifiche/empty-rc6.bin').read_bytes() + bytes([0, 1, 0, 0])
assert len(empty) == 11944
c['empty'].update(schema=2, data=base64.b64encode(empty).decode(), sha256=hashlib.sha256(empty).hexdigest())
t = (r / 'toolsuite/SimpleSuite.html.in').read_text()
for key, path in [('SDK','sdk/WebUpdate.js'), ('INSTALLER','web/installer/InstallerCore.js'), ('FORMATS','toolsuite/Formats.js'), ('FLOW','toolsuite/BackupFlow.js'), ('SIMPLEUI','toolsuite/SimpleUI.js')]:
    t = t.replace('/*' + key + '*/', (r / path).read_text())
t = t.replace('/*CONFIG*/', json.dumps(c, ensure_ascii=False, separators=(',', ':')))
for name in ['index.html', 'Meighty.html']:
    (o / name).write_text(t)
shutil.copy2(fw, o / fw.name)
for p in (b / 'Candidata-Poly3-A8').glob('Poly3-*'):
    if p.is_file(): shutil.copy2(p, o / p.name)
shutil.copy2(b / 'Candidata-Poly3-A8/index.html', o / 'Ritorno-A8.html')
for name in ['Ritorno-A6.html', 'Ritorno-RC7.html', 'Ritorno-RC3.html', 'LICENSE-Meighty.md', 'LICENSE-LZFSE.txt']:
    shutil.copy2(b / 'Candidata-Poly3-A8' / name, o / name)

guide = '''MEIGHTY 1.02 A9 / HW25 — POLY3 — TOOLS 2.2

Questa candidata cerca più margine audio senza ridurre le tre voci, gli altri sette canali, i motori o gli effetti. Il sito principale conserva RC7.

COSA CAMBIA RISPETTO AD A8 / HW24
FM4 conserva i quattro incrementi degli operatori quando pitch e rapporti sono invariati. La chiave comprende tutti i rapporti originali: pitch/glide, OR1–OR4 e modifiche ai parametri vengono rilevati senza attendere una nota nuova. Una nota nuova invalida la cache.
Delay, riverbero e mix usano altre divisioni esatte tramite shift, con lo stesso troncamento verso zero dei campioni negativi. Entrambi i riverberi continuano ad aggiornare il proprio stato, anche durante il passaggio fra Room e Ambient. Nessun cambiamento a code, smoothing o frequenze di elaborazione.
Le cache sono solo in RAM. Progetti, slot, formato .meighty e protocollo di trasferimento restano invariati rispetto ad A8.

INSTALLAZIONE E CONFRONTO SUL DISPOSITIVO
1. Apri index.html dal sito HTTPS, tab Firmware, e scegli Installa 1.02 A9. Conferma la scrittura nel pannello; mantieni alimentazione e USB collegate durante l’update.
2. Verifica GLOBAL: 1.02 A9. Leggi carico audio deve riconoscere HW25. Se mostra ancora HW24 aggiorna la pagina e controlla la versione prima di proseguire.
3. Per azzerare i massimi spegni e riaccendi normalmente. Carica lo stesso Poly3-Stress-10-voices.meighty già usato su HW24, con Poly 3 track = T8. Non serve inizializzare gli slot.
4. Seleziona T1 con SELECT, apri Instrument e scegli I10 (esadecimale, sedicesimo indice: FM4) con K3. Premi PLAY e tieni un Do centrale per 60 secondi, a volume basso. Rilascia la nota, premi STOP e scegli Leggi carico audio.
5. Riporta tutta la lettura: MAX / LATE / MISSES, PREP / CPU0 / CPU1 / ATTESA / MIX-FX e DIV / SHIFT / CHECK. Segnala se l’audio cambia. CPU1 lavora in parallelo: non sommarlo a CPU0.
Riferimento HW24: MAX 2791 µs, LATE 0, MISSES 0; PREP 102, CPU0 2207, CPU1 2585, ATTESA 67, MIX/FX 371. Budget 2902 µs: margine osservato 111 µs. Obiettivo indicativo 300–400 µs, ancora da raggiungere. I test Mac non misurano il tempo reale del chip.
Per tornare alla stessa versione appena provata usa Ritorno-A8.html. Sono disponibili anche Ritorno-A6.html e Ritorno-RC7.html. Su iPhone in MIDIWeb Browser aggiorna Make Available Offline e salva separatamente la pagina di ritorno, se vuoi usarla senza rete.

USO DELLA POLIFONIA
GLOBAL → Poly 3 track → OFF oppure T1–T8 con K2. La scelta viene salvata nel progetto. La traccia scelta suona tre note vere, con filtri, inviluppi e rilasci indipendenti; le altre sette restano monofoniche. Mixer, mute/solo e mandate appartengono al gruppo. Alla quarta nota si riusa una voce libera oppure la più vecchia.
In Phrase, CHD 47 aggiunge terza maggiore e quinta; CHD 37 terza minore e quinta; CHD 57 crea un sus4. Gli intervalli sono semitoni esadecimali, quantizzati alla scala globale. CHD resta attivo sulle note seguenti; CHD 00 lo disattiva e consente sovrapposizioni indipendenti. Un intervallo zero disattiva quella voce aggiuntiva.
OFF rilascia il gruppo; KIL e STOP lo fermano. LEV controlla il livello condiviso; VOL interessa la voce corrente ed è copiato sulle nuove note dell’accordo. Le Table avanzano separatamente per ciascuna voce.
La tastiera in Phrase registra fondamentale e CHD in FX1, sostituendo il contenuto precedente di FX1. Si registrano fino a tre note, con intervalli entro 15 semitoni; voicing più larghi restano suonabili live. ARP come SHIFT conserva selezione, cancellazione e copia/incolla.

PROGETTI E TOOLS
Questa suite 2.2 ha quattro tab: Firmware, Backup/estrazione, Conversione, Ripristino/caricamento. Per trasferire una song seleziona il file nella casella dello slot desiderato e scrivi: vengono sostituiti solo gli slot contenenti un file; le caselle vuote non cancellano gli altri slot. Non è richiesta un’inizializzazione preventiva.
I vecchi progetti da 11940 byte sono migrati; quelli attuali ne usano 11944. Le banche polifoniche usano .meighty v2/schema2. Non ridurre i progetti polifonici per i vecchi firmware; conserva un backup .meighty prima di un eventuale ritorno. I dati musicali restano locali al browser.

VERIFICHE
Confronto FM4 contro il codice congelato A8: 131072 campioni, otto algoritmi, glide, rapporti fuori intervallo, saturazione degli incrementi, rilascio e nota nuova; campioni e stato DSP identici.
Confronto delay/reverb contro A8: 96000 frame stereo wet, tutte le 18 divisioni, ingressi di entrambi i segni, BPM 30/300, transizioni Room/Ambient e parametri variabili; uscite e stato completo degli effetti identici.
Regressione audio A1: 1152000 frame identici. Stress nativo: 60 secondi, 1920000 frame con dieci voci sequencer più preview, tutti i modelli e massimi mixer/mandate/master, hash invariato. ASan/UBSan e ThreadSanitizer passati; 2432 casi live, 1536 blocchi cache, 432 casi sparsi, renderer e ricampionamento verificati. Tools: 123 controlli dei veri handler JavaScript collegati al core C, inclusi tutti gli otto slot. OTA e loader passati; limiti memoria e copia del codice RAM controllati.
Sono verifiche software. Il margine reale di HW25 deve essere misurato sul FM-1 prima di promuoverla a versione stabile.
'''
(o / 'POLY3-LEGGIMI.txt').write_text(guide)
(o / 'LEGGIMI.html').write_text('<!doctype html><html lang="it"><meta charset="utf-8"><title>Meighty A9 / HW25</title><style>body{max-width:850px;margin:30px auto;padding:20px;font:16px/1.6 system-ui;background:#071e20;color:#edf9f6}pre{white-space:pre-wrap;font:inherit}a{color:#70dfd0}</style><a href="index.html">Apri Meighty A9</a><pre>' + html.escape(guide) + '</pre></html>')

logs = sorted(p.name for p in (b / 'Verifiche').glob('poly3-A9-*.log'))
logs += ['poly3-A9-host-tests.json', 'poly3-A9-memory.json', 'poly3-tools-A9.log', 'poly3-ota-A9.log', 'poly3-loader-A9.log', 'poly3-hardware-A8.json']
for name in logs: shutil.copy2(b / 'Verifiche' / name, o / name)
report.update(version='1.02 A9', build=25, product='FM-1_998210', suite='2.2', project_bytes=11944, previous_project_bytes=11940, hardware_validated=False, physical_usb='HW25 not yet measured; HW24 reference 2791/0/0', prior_A8_live=[2791,0,0], margin_target_us=[300,400], fm4_cache_oracle_samples=131072, effects_oracle_wet_frames=96000, audio_vs_A1_frames=1152000, native_stress_frames=1920000, native_stress_hash='74916ec3ba4c1e56', live_cases=2432, cache_blocks=1536, sparse_cases=432, render_regression_frames=1216000, resampler_regression_frames=258174, tools_new_checks=123, host_sanitizers='ASan/UBSan pass', tsan='pass', flash_regions='unchanged', math_benchmark='unchanged; full loop timings only', exact_fx_shifts=True, exact_fm4_increment_cache=True, memory=json.loads((o / 'poly3-A9-memory.json').read_text()), fallback='Ritorno-A8.html')
(o / 'VERIFICHE.json').write_text(json.dumps(report, indent=2) + '\n')
with zipfile.ZipFile(o / 'Sorgenti.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(r.rglob('*')):
        rel = p.relative_to(r)
        if p.is_file() and not any(x in rel.parts for x in ['build','.git','__pycache__']) and p.name != '.DS_Store': z.write(p, 'fm1-tracker-poly3/' + str(rel))
    z.write(Path(__file__), 'verification/' + Path(__file__).name)
    for name in logs: z.write(o / name, 'verification/' + name)
hashes = {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(o.iterdir()) if p.is_file() and p.name != 'SHA256SUMS.txt'}
(o / 'SHA256SUMS.txt').write_text(''.join(v + '  ' + k + '\n' for k,v in hashes.items()))
print(json.dumps({'folder':str(o), 'sha256':report['sha256'], 'files':len(hashes)}))
