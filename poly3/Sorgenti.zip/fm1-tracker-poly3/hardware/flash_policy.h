/* GPL-3.0-only. Policy shared by app and update loader. These two 1 MiB
 * parts use the same plain SPI NOR commands; unknown parts stay read-only. */
#ifndef TR_FLASH_POLICY_H
#define TR_FLASH_POLICY_H
static inline int tr_flash_jedec_known(unsigned id) {
    return id == 0x856014u || id == 0xB36014u;
}
#endif
