# Hardware candidate HW1 — 2026-11-07

Build: `python3 tools/Build-Hardware-Mac.py`. This compiles on the configured Mac toolchain and prepares the installer without connecting to or flashing a device. The emitted package is **FM1-M8-Hardware-HW1.fwsc**, identity **FM-1_998201**. The existing INTERACTIVE package remains the emulator target.

The hardware variant enables the pinned USB MIDI driver and OTA session, initializes the MASTER ADC, and applies its smoothed gain outside the saved project. An early OCT− selection enters a silent USB recovery loop. MIDI performance/audio and BLE are not added by this adapter.

Flash: user services expose physical 0x97000..0xDFFFF (0x49000 bytes); the shared transactional allocator places eight 2×3-sector slots at 0xAF000..0xDEFFF. OTA exclusively owns 0xE0000..0xE4FFF. Header/SPL and SDK VM/BTIF/key regions are not project storage. Legacy emulator save sectors do not share this mapping. Unknown flash JEDEC IDs disable project/OTA writes.

OTA validates the incoming package, flash span and loader, stages and verifies the loader, waits for host success, records parameters and resets into the supplied loader. Audio is stopped during that session. Raw reads use short IRQ-off RAM driver calls; USB is polled in TIMER5. Other applications can replace this firmware through that same standard service. The provisional identity is not a claim of registration or compatibility with every existing firmware.

Tests: `sh tests/run.sh`; after building both packages and installer, `FM1_NODE=/path/to/node sh tests/run_install.sh`. Source provenance and GPL notices remain in vendor/. Test fixtures run the actual pinned OTA/loader source against simulated NOR, including rejection, interruption and bounds cases. Browser tests use mocked MIDI endpoints. Native emulator traces are not physical device measurements.

See the Italian installation guide distributed alongside the installer. Hardware and actual iPad/MIDIWeb validation remain outstanding; no physical flash has been performed. The installer verifies the package SHA-256 before transfer and firmware identity after reboot, not a full device flash read-back.

## Project data protocol v1

`projects.inc` dispatches commands 0x60..0x66 alongside OTA identity without modifying the upstream driver or OTA source. Standard 00 59 / pack7 / complement checksum framing is retained. Reply status precedes payload. Commands: 60 capabilities (version, slots, u32 size); 61 snapshot (u8 slot or FF RAM → u32 size + CRC32); 62 read (u32 offset,u16 count≤256); 63 start upload (u8 slot,u32 size,u32 CRC32); 64 ordered chunk (u32 offset,≤256 bytes); 65 validate/commit; 66 release. Thirty-second inactivity expires the RAM session. Upload requires complete length, CRC32 and tracker structural validity before writing a transactional slot; the browser independently reads it back and compares SHA-256. Slot imports do not replace the live RAM project. No arbitrary flash commands are exposed. Bank restore is per-slot transactional, not atomic across all eight.

The self-contained installer HTML can be imported into MIDIWeb Browser local files for offline use. Support is documented by the app; the real local-file/WebMIDI bridge and iOS download/import behavior are not physically tested here.

HW1 builds the RAM-only loader from source. Both loader and app share hardware/flash_policy.h, allowing exactly 0x856014 and 0xB36014. Unknown IDs remain refused. The original prebuilt ota.bin is historical; HW1 uses build/loader-hw1/ota.bin. The generated HTML must pass tests/test_installer_html.cjs against the actual FWSC (template substitutions run before payload injection).
