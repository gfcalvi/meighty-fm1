/* GPL-3.0-only. Exact FM-1 output scaling.
 * tracker_device_render emits signed 16-bit PCM * 256. ADC gain is 0..4096.
 * Thus (s*256*g)/4096 == trunc(s*g/16), with s*g in signed 32-bit range.
 * Arithmetic right shifts are used by PI32v2 and by the host test targets. */
#ifndef TR_HW_AUDIO_MATH_H
#define TR_HW_AUDIO_MATH_H
#include <stdint.h>
static inline __attribute__((always_inline)) int32_t tr_hw_output_gain(int32_t sample24,unsigned gain){int32_t value=(sample24>>8)*(int32_t)gain;return (value+(value<0?15:0))>>4;}
#endif
