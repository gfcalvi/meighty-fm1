/* Read-only timing observations, in timer4 ticks (24 ticks/us).
 * No music state or scheduling decisions depend on these measurements. */
#ifndef TR_AUDIO_SCHEDULE_H
#define TR_AUDIO_SCHEDULE_H
#include <stdint.h>
typedef struct {
 volatile uint32_t maximum[8],snapshot[4];
 volatile uint32_t mask_start,mask_end,mask_duration,timer_end,timer_duration,last_entry;
 volatile unsigned active,have_mask,have_timer,have_entry;
} TrAudioSchedule;
#define TR_SCHEDULE_FN static inline __attribute__((always_inline))
TR_SCHEDULE_FN void tr_schedule_running(TrAudioSchedule *s,unsigned active){
 s->active=active;s->have_entry=s->have_mask=s->have_timer=0;
}
TR_SCHEDULE_FN void tr_schedule_mask_end(TrAudioSchedule *s,uint32_t now){
 if(!s->active)return;
 uint32_t d=now-s->mask_start;s->mask_end=now;s->mask_duration=d;s->have_mask=1;
 if(d>s->maximum[0])s->maximum[0]=d;
}
TR_SCHEDULE_FN void tr_schedule_timer_end(TrAudioSchedule *s,uint32_t begin,uint32_t now){
 if(!s->active)return;
 uint32_t d=now-begin;s->timer_end=now;s->timer_duration=d;s->have_timer=1;
 if(d>s->maximum[1])s->maximum[1]=d;
}
TR_SCHEDULE_FN void tr_schedule_entry(TrAudioSchedule *s,uint32_t now){
 if(!s->active)return;
 uint32_t gap=s->have_entry?now-s->last_entry:0;
 s->last_entry=now;s->have_entry=1;if(gap>s->maximum[2])s->maximum[2]=gap;
 s->snapshot[0]=gap;
 uint32_t age=now-s->mask_end;
 unsigned recent=s->have_mask&&age<69632U;
 s->snapshot[1]=recent?s->mask_duration:0;s->snapshot[2]=recent?age:0;
 /* TIMER5 may preempt this handler: reject a sample spanning its update. */
 uint32_t timer_end=s->timer_end,timer_duration=s->timer_duration;
 s->snapshot[3]=s->have_timer&&now-timer_end<69632U&&timer_end==s->timer_end?timer_duration:0;
}
TR_SCHEDULE_FN void tr_schedule_late(TrAudioSchedule *s,uint32_t duration){
 if(!s->active)return;
 if(duration>s->maximum[3]){
  s->maximum[3]=duration;
  for(unsigned i=0;i<4;i++)s->maximum[4+i]=s->snapshot[i];
 }
}
#undef TR_SCHEDULE_FN
#endif
