#!/usr/bin/env python3
"""Build candidate firmware and its self-contained installer; never connects or flashes."""
from pathlib import Path
import os,sys,subprocess
root=Path(__file__).resolve().parents[1]
subprocess.run([sys.executable,str(root/'tools/Build-Loader-Mac.py')],check=True)
subprocess.run([sys.executable,str(root/'tools/Build-Emulator-Mac.py')],env={**os.environ,'FM1_HARDWARE':'1','FM1_HWFIX_RELEASE':'1','FM1_OTA_BIN':str(root/'build/loader-hw1/ota.bin'),'FM1_BLUE_RELEASE':'1','FM1_CONTRAST_RELEASE':'1','FM1_FOLLOW_RELEASE':'1'},check=True)
subprocess.run([sys.executable,str(root/'tools/Build-Installer.py'),'--hwfix'],check=True)
