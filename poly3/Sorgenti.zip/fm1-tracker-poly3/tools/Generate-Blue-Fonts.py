"""Inter OFL variable-font atlases, cropped glyphs, 4-bit alpha; device independent."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
r=Path(__file__).resolve().parents[1]
out=['/* Generated from Inter, SIL OFL 1.1. Do not edit. */',
'typedef struct {unsigned short at;unsigned char w,h,advance,x,y;} BlueGlyph;',
'typedef struct {const BlueGlyph *g;const unsigned char *data;unsigned h;} BlueFont;']
for name,size,weight in [('small',9,450),('body',13,450),('chain',17,350),('title',19,650),('value',23,450),('name',23,650)]:
 f=ImageFont.truetype(str(r/'app/tracker/fonts/Inter-Variable.ttf'),size);f.set_variation_by_axes([max(14,min(size,32)),weight]);data=[];glyphs=[]
 for code in range(32,127):
  if name=='value' and chr(code) not in '0123456789ABCDEF IO-?':
   glyphs.append((len(data),0,0,round(f.getlength(chr(code))),0,0));continue
  im=Image.new('L',(40,36));ImageDraw.Draw(im).text((0,0),chr(code),font=f,fill=255);box=im.getbbox()or(0,0,0,0);crop=im.crop(box);v=[min(15,(x+8)//17)for x in crop.tobytes()]
  if len(v)%2:v.append(0)
  glyphs.append((len(data),crop.width,crop.height,round(f.getlength(chr(code))),box[0],box[1]));data += [(v[i]<<4)|v[i+1]for i in range(0,len(v),2)]
 assert len(data)<65536
 out+=['static const BlueGlyph blue_'+name+'_g[95]={'+','.join('{'+','.join(map(str,g))+'}'for g in glyphs)+'};',
 'static const unsigned char blue_'+name+'_data[]={'+','.join(map(str,data))+'};',
 'static const BlueFont blue_'+name+'={blue_'+name+'_g,blue_'+name+'_data,'+str(size+5)+'};']
(r/'app/tracker/blue_fonts.inc').write_text('\n'.join(out)+'\n')
print('Inter atlases generated')
