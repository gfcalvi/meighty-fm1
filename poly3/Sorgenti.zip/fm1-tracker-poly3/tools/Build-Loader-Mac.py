#!/usr/bin/env python3
"""Build the RAM-only loader with the shared supported-flash policy. No USB."""
from pathlib import Path
import os,sys,subprocess,struct,json,hashlib
import lz4blk
r=Path(__file__).resolve().parents[1];d=r/'build/loader-hw1';d.mkdir(parents=True,exist_ok=True)
prior=Path('/Users/gfcalvi/Documents/Codex/2026-10-21/stiamo-sviluppando-fm1-evolving-un-firmware')
tc=Path(os.environ.get('FM1_JIELI_TOOLCHAIN',str(prior/'work/target-tools/jieli-linux-toolchains-20250324.1')))
runner=Path(os.environ.get('FM1_JIELI_RUNNER',str(prior/'work/jieli_runner.py')))
def run(tool,args):
 subprocess.run([sys.executable,str(runner),str(tc/tool),*map(str,args)],cwd=r,check=True)
flags=['-target','pi32v2','-mcpu=r3','-mfprev1','-Os','-mllvm','-pi32v2-large-program=true','-std=gnu11','-ffreestanding','-fno-builtin','-fwrapv','-ffunction-sections','-fdata-sections','-Iemulator/hal']
for src in ['crt0_ldr.S','loader.c']:
 run('pi32v2/bin/clang',[*flags,'-c',r/'emulator/loader'/src,'-o',d/(Path(src).stem+'.o')])
run('pi32v2/bin/ld',['--gc-sections','-e','_start','-Temulator/loader/loader.ld',d/'crt0_ldr.o',d/'loader.o','-o',d/'loader.elf'])
raw=(d/'loader.elf').read_bytes();at=struct.unpack_from('<I',raw,32)[0];ss,sn,si=struct.unpack_from('<HHH',raw,46)
sections=[struct.unpack_from('<10I',raw,at+i*ss) for i in range(sn)]
names=raw[sections[si][4]:sections[si][4]+sections[si][5]];image=None
for h in sections:
 name=names[h[0]:].split(b'\0')[0]
 if h[2]&2 and h[5]:assert 0x1c0a800<=h[3] and h[3]+h[5]<=0x1c1e800,'loader must reside in RAM'
 if name==b'.text':
  assert h[3]==0x1c0a800
  image=raw[h[4]:h[4]+h[5]]
assert image and b'FELUCCA-LOADER-1' in image and b'ota-FM-1_700' in image
sys.path.insert(0,str(r/'emulator'));import fm1pkg_make as pkg
name=b'usb_hid_ota.bin'
def head(crc,a,b,attr):
 body=struct.pack('<HIIBBH16s',crc,a,b,attr,0,0,name);return struct.pack('<H',pkg.crc16(body))+body
blocks=bytearray()
for n in range(0,len(image),4096):
 block=image[n:n+4096];c=lz4blk.compress(block);assert len(c)<=4096 and lz4blk.decompress(c)==block
 blocks+=struct.pack('<II',len(c),len(block))+c
body=head(pkg.crc16(image),len(image),0x1c0a800,0)+blocks
ota=head(pkg.crc16(body),32,len(body),0x41)+body
(d/'loader.bin').write_bytes(image);(d/'ota.bin').write_bytes(ota)
(d/'report.json').write_text(json.dumps({'image_bytes':len(image),'ota_bytes':len(ota),'sha256':hashlib.sha256(ota).hexdigest(),'jedec':['0x856014','0xB36014'],'ram_only':True},indent=2))
print('PASS loader: RAM-only, checked LZ4 roundtrip,',len(image),'bytes;',len(ota),'packaged bytes')
