from pathlib import Path
import re,math,json,hashlib
root=Path(__file__).resolve().parent.parent;d=root/'app/tracker';ref=root/'third_party/braids'
# Retain exact upstream reference and licence; mechanically lower selected oscillator bodies to C.
s=(ref/'analog_oscillator.reference.cc').read_text();out='/* MIT Copyright 2012 Emilie Gillet. C adaptation at 32 kHz; see third_party/braids/LICENSE.\n * Original BLEP equations, no block interpolation; pitch increments supplied by tracker. */\n'
out+='''static FM1_AUDIO_CODE int32_t ThisBlepSample(uint32_t t){if(t>65535)t=65535;return (int32_t)(t*t>>18);}
static FM1_AUDIO_CODE int32_t NextBlepSample(uint32_t t){if(t>65535)t=65535;t=65535-t;return -(int32_t)(t*t>>18);}
'''
for name in ['CSaw','Square','Saw','VariableSaw','Triangle','Sine']:
 start=s.index('void AnalogOscillator::Render'+name+'(');beg=s.index('{',start);end=s.index('\n}',beg)+2;body=s[beg:end];body='{(void)sync_out;'+body[1:]
 body=body.replace('BEGIN_INTERPOLATE_PHASE_INCREMENT','').replace('END_INTERPOLATE_PHASE_INCREMENT','').replace('INTERPOLATE_PHASE_INCREMENT','')
 body=body.replace('static_cast<uint32_t>','(uint32_t)').replace('static_cast<int32_t>','(int32_t)').replace('static_cast<int16_t>','(int16_t)').replace('bool ','int ').replace('false','0').replace('true','1')
 for field in ['phase_','high_','parameter_','aux_parameter_','discontinuity_depth_','next_sample_']:
  body=re.sub(r'\b'+field+r'\b','o->'+field,body)
 body=body.replace('Interpolate824(wav_sine, phase)','sound_sine(phase)')
 # C wrapping is deliberate, but never signed left-shift negative values.
 body=body.replace('(this_sample - 8192) << 1','(this_sample - 8192) * 2').replace('(this_sample - 16384) << 1','(this_sample - 16384) * 2')
 out+=f'static FM1_AUDIO_CODE void ba_{name}(TrAnalog *o,uint32_t phase_increment,const uint8_t *sync_in,int16_t *buffer,uint8_t *sync_out,size_t size)'+body+'\n'
 # unused arguments for triangle/sine are valid in upstream, suppress by explicit reads
 out=out.replace('{\n  \n  uint32_t phase = o->phase_;','{\n  (void)sync_out;\n  uint32_t phase = o->phase_;')
(d/'braids_analog.inc').write_text(out)
resources=(root/'third_party/braids/resources.reference.cc.txt').read_text();tables='/* MIT Emilie Gillet; original Braids filter and waveshaper tables. */\n'
for name in ['lut_svf_cutoff','lut_svf_damp','ws_violent_overdrive']:
 m=re.search(r'const (\w+) '+name+r'\[\] = \{(.*?)\};',resources,re.S);assert m
 tables+='static const '+m[1]+' '+name+'[]={'+m[2]+'};\n'
(d/'braids_extra_tables.inc').write_text(tables)
# Original, generated harmonic tables, not a copy of a commercial bank. Three bandlimit levels.
w='/* Original harmonic wavetable banks: CLASSIC, HOLLOW, GLASS, FORMANT. */\nstatic const int16_t dual_waves[4][3][5][129]={\n'
for bank in range(4):
 w+='{\n'
 for cap in [48,12,3]:
  w+='{\n'
  for frame in range(5):
   a=[]
   for n in range(128):
    ph=n*2*math.pi/128;v=0
    for h in range(1,cap+1):
     if bank==0:g=(1-frame/4)*(1/h if h==1 else 0)+(frame/4)*((-1)**(h+1)/h)
     elif bank==1:g=(1/h if h%2 else 0)*math.cos(h*frame*.23)
     elif bank==2:g=math.exp(-abs(h-(1+frame*2.5))*.55)/h
     else:g=(math.exp(-((h-(2+frame*2))/2)**2)+.55*math.exp(-((h-12)/3)**2))/h
     v+=math.sin(ph*h)*g
    a.append(v)
   peak=max(map(abs,a)) or 1;b=[round(v/peak*28000) for v in a];b.append(b[0]);w+='{'+','.join(map(str,b))+'},\n'
  w+='},\n'
 w+='},\n'
w+='};\n';(d/'dual_tables.inc').write_text(w)
print('Generated C oscillator adapters and tables')
