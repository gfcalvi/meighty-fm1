#!/usr/bin/env python3
"""HW4 exact arithmetic/inline candidate. Builds files; never flashes."""
from pathlib import Path
import os,sys,subprocess
r=Path(__file__).resolve().parents[1]
subprocess.run([sys.executable,str(r/'tools/Build-Loader-Mac.py')],check=True)
subprocess.run([sys.executable,str(r/'tools/Build-Emulator-Mac.py')],env={**os.environ,'FM1_HARDWARE':'1','FM1_HWFIX_RELEASE':'1','FM1_HWDIAG_RELEASE':'1','FM1_HWPERF_RELEASE':'1','FM1_HW4_RELEASE':'1','FM1_BLUE_RELEASE':'1','FM1_FOLLOW_RELEASE':'1','FM1_OTA_BIN':str(r/'build/loader-hw1/ota.bin')},check=True)
subprocess.run([sys.executable,str(r/'tools/Build-Installer.py'),'--hw4'],check=True)
