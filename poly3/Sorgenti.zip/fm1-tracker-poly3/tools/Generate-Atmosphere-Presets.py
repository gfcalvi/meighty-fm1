#!/usr/bin/env python3
"""Deterministic Atmosphere 100 sound bank; preserves the 77 original IDs."""
from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parents[1];out=R.parent
# Ten distinct timbral families, ten named designs in each. No runtime randomness.
families=[
 ('NEBULA',17,0,1,92,34,'Pad morbidi: due spettri caldi e scansioni lente',
  'Blue Nebula|Cirrus Veil|Soft Horizon|Polar Cloud|Silver Haze|Distant Glow|Cobalt Mist|Night Vapour|High Altitude|Endless Blue'),
 ('TIDAL',17,1,0,68,48,'Fondali scuri, movimento ampio e filtro respirato',
  'Slow Current|Pelagic Drift|Deep Tide|Moonlit Foam|Dark Estuary|Arctic Water|Quiet Lagoon|Tidal Glass|Ocean Floor|Abyss Bloom'),
 ('HALO',17,2,1,150,28,'Vetri soffusi e armoniche alte in movimento',
  'Glass Halo|Ice Cathedral|Prism Veil|Frozen Rays|Bell Nebula|Crystal Rain|Pale Corona|Glacial Arch|Lucent Dust|Diamond Fog'),
 ('AURORA',17,3,1,136,54,'Formanti mobili e aperture da coro sintetico',
  'Aurora Choir|Vowel Clouds|Formant Bloom|Solar Chapel|Halo Voices|Indigo Hymn|Northern Veil|Ether Choir|Violet Breath|Silent Choir'),
 ('ASTRAL',17,2,3,126,38,'Incroci spettrali, quinte e ottave atmosferiche',
  'Orbit Trace|Comet Tail|Zenith Drift|Magnetosphere|Lunar Halo|Starlit Reef|Eclipse Loom|Cosmic Ribbon|Meteor Silk|Vacuum Light'),
 ('VELVET',9,0,0,102,44,'Pad analogici Braids: saw, sub, morph e sync',
  'Velvet Saw|Soft Brass Air|Cedar Strings|Bronze Horizon|Dusk Ensemble|Hollow Reed|Submarine Air|Analog Dunes|Slow Sync Halo|Warm Solstice'),
 ('VOICES',7,0,0,132,36,'Voci VOSIM, FM e feedback filtrati lentamente',
  'VOSIM Choir|Wooden Vowels|Whisper Reed|Ether Organ|Spectral Ooh|FBFM Cloud|Low FM Mist|Vocal Drone|Hollow Air|Faint Satellite'),
 ('FM SILK',16,0,0,148,24,'FM4 morbida: inviluppi indipendenti e spettri armonici',
  'FM Silk|Opal Choir|Harmonic Sea|Warm Operators|Copper Cloud|Quiet Marimba|Organ Mist|Sine Cathedral|Woven Fifths|Floating Keys'),
 ('FM PRISM',16,0,0,180,32,'FM4 luminosa: campane sostenute e strati di parziali',
  'FM Icefield|Glass Circuit|Shimmer Arc|Bell Horizon|Mercury Fog|Digital Chapel|Radiant Bloom|Polar Bells|Silver Lattice|Celestial FM'),
 ('AFTERGLOW',17,1,3,116,42,'Due LFO: controfase, scansioni incrociate e pulsazioni',
  'Slow Fireflies|Moving Dust|Afterglow|Hollow Mirrors|Countertide|Spiral Bloom|Velvet Orbit|Breathing Sky|Liminal Lights|Last Light')]
# pos1,pos2,osc2 semitones,detune,mix,A,D,S,R,LFO1,LFO2,scan1,scan2,filter env depth.
designs=[
 (36,176,0,14,118,100,132,205,150,12,9,46,37,28),
 (84,134,0,-18,144,128,156,190,176,8,13,62,44,38),
 (146,42,0,22,100,72,118,218,140,19,11,38,60,-24),
 (62,202,12,-10,90,146,172,180,196,6,9,54,30,46),
 (184,88,0,9,156,92,146,200,162,15,7,28,72,-32),
 (110,168,7,12,76,54,110,174,132,24,16,76,46,54),
 (42,126,-12,17,82,164,184,210,188,7,5,36,54,32),
 (152,206,0,-24,136,114,140,190,172,17,23,66,32,-42),
 (202,56,12,8,110,82,158,220,154,11,18,40,68,22),
 (92,152,0,-13,166,138,192,186,206,5,8,70,52,40)]
def clamp(v):return max(0,min(255,v))
bank=[]
for f,(family,model,ba,bb,cut,res,description,names)in enumerate(families):
 for j,name in enumerate(names.split('|')):
  assert len(name)<=15
  x,y,semi,det,mix,a,d,su,r,rate1,rate2,scan1,scan2,depth=designs[j]
  m=([9,10,11,8,9,10,11,9,12,8][j]if f==5 else [7,7,5,7,7,6,5,7,6,5][j]if f==6 else model)
  cutoff=clamp(cut+[-8,4,16,-12,8,24,-18,12,2,-6][j]);volume=148 if m==17 else 158 if m==16 else 142
  # Falling filter contours must remain audible after settling, including both LFOs.
  if depth<0:depth=max(depth,-24);cutoff=max(cutoff,80+abs(depth)*2)
  patch=[m,255,volume,cutoff,clamp(128+(j-4)*3),255,1,0]
  snd=[0]*23;snd[:9]=[1,a,d,su,r,clamp(res+j*3),1,x,y]
  # Sine/triangle only for sustained pads; no abrupt S&H or hard pitch jumps.
  snd[9:16]=[rate1,0 if j%3 else 1,0,128+(22+j*3),128+(1 if f==5 and j in [2,4,7]else 0),128+(12+j*2),128+(8 if j in [1,5,9]else 0)]
  snd[16:23]=[rate1 if j in [1,4,8]else rate2,0,128 if j in [1,4,8]else 64,128-(8+j),128,128-(8+j*2),128+(14 if j in [2,7]else 4)]
  ce=[1,min(220,a+34),min(230,d+22),160+(j*7)%65,min(230,r+10),128+depth]
  eng=[0]*32;eng[1]=24
  for k in range(4):eng[2+k*6:8+k*6]=[k+1,150 if k else 255,0,64,200,48]
  eng[26:32]=[ba,bb,24+semi,128+det,mix,0]
  wt=[128+scan1,128-scan2,128+(12 if j%2 else -18),128+(26 if j%2 else 16)]
  if m==16:
   # Ratios use editor indices: 0=.5, 1=1, 2=2, ... 12=12, 13=14, 14=16.
   algorithms=([4,6,7,5,4,0,7,6,4,5]if f==7 else [0,4,5,3,4,1,6,0,5,4])
   ratios=([(1,2,1,3),(1,2,3,1),(1,2,3,4),(1,2,3,1),(1,3,1,2),(1,2,3,4),(0,1,2,3),(1,2,1,4),(1,3,2,4),(1,2,4,1)]if f==7 else [(1,3,2,7),(1,5,1,7),(1,2,4,3),(1,3,5,7),(1,7,2,5),(1,2,5,9),(1,3,7,5),(1,5,3,11),(1,2,7,3),(1,7,1,5)])
   eng[0]=algorithms[j];eng[1]=(10+j*3)if f==7 else 12+j*4
   for k in range(4):
    gain=([245,132,205,104][k]if f==7 else [235,148,190,126][k]);oa=min(192,max(24,a-24+k*13));od=min(224,d+k*9);os=clamp(su-k*22+(j%3)*8);orr=min(224,r+k*7)
    eng[2+k*6:8+k*6]=[ratios[j][k],gain,oa,od,os,orr]
   snd[7]=[24,38,0,48,32,42,0,28,36,52][j]if f==7 else [58,72,66,82,48,92,44,68,80,54][j]
   snd[8]=128;wt=[128]*4
  elif m!=17:
   wt=[128]*4
   if f==6:snd[7]=[64,90,32,112,128,42,56,150,30,76][j];snd[8]=[140,168,108,122,188,90,154,104,180,130][j]
   else:snd[7]=[90,148,76,48,174,116,64,206,132,36][j];snd[8]=[116,160,84,196,148,66,172,100,188,132][j]
  if f==9:
   snd[9]=[20,28,11,16,14,24,8,32,18,6][j];snd[16]=snd[9]if j in [0,4,7]else rate2;snd[18]=128 if j in [0,4,7]else 64
   wt=[128+scan1,128,128,128+scan2]if j in [0,4,7]else wt
  patch_id=77+len(bank)
  bank.append(dict(id=patch_id,hex=f'{patch_id:02X}',name=name,family=family,description=description,patch=patch,sound=snd,cutoff_env=ce,engine=eng,wt_lfo=wt))
assert len(bank)==100 and len({p['name']for p in bank})==100
for p in bank:
 assert all(0<=v<=255 for k in ['patch','sound','cutoff_env','engine','wt_lfo']for v in p[k])
 assert p['patch'][1]==255 and p['sound'][0]==1
base=(R/'app/tracker/presets.inc').read_text().split('/* ATMOSPHERE 100 */')[0].rstrip()
if base.endswith('};'):base=base[:-2]
rows=['/* ATMOSPHERE 100 */']+[' {"%s",{%s},0},'%(p['name'],','.join(map(str,p['patch'])))for p in bank]+['};']
(R/'app/tracker/presets.inc').write_text(base+'\n'+'\n'.join(rows)+'\n')
arr=lambda a:'{'+','.join(map(str,a))+'}'
rows=['/* Generated by tools/Generate-Atmosphere-Presets.py. Original pad designs. */','enum {TR_ATMOS_FIRST=77,TR_ATMOS_COUNT=100};','typedef struct {uint8_t sound[TR_SOUND_FIELDS],cutoff_env[6],engine[8],wt_lfo[4];} TrAtmosphere;','static const TrAtmosphere atmosphere_presets[]={']
rows+=[' {'+','.join([arr(p['sound']),arr(p['cutoff_env']),arr(p['engine'][:2]+p['engine'][26:]),arr(p['wt_lfo'])])+'},'for p in bank]
rows+=['};','/* Only FM4 uses per-operator values; the other 80 patches share defaults. */','static const uint8_t atmosphere_fm_operators[20][24]={']
rows += [' '+arr(p['engine'][2:26])+','for p in bank if p['patch'][0]==16]
rows+=['};','static const uint8_t atmosphere_default_operators[24]='+arr(bank[0]['engine'][2:26])+';','static const unsigned preset_family_starts[]={0,24,30,63,77,87,97,107,117,127,137,147,157,167};','static const char *preset_family_names[]={"CLASSIC","BRAIDS","DRUMS","ENGINES","NEBULA","TIDAL","HALO","AURORA","ASTRAL","VELVET","VOICES","FM SILK","FM PRISM","AFTERGLOW"};']
(R/'app/tracker/atmosphere.inc').write_text('\n'.join(rows)+'\n')
(out/'FM1-M8-Atmosphere-100.json').write_text(json.dumps(bank,indent=2)+'\n')
lines=['# Atmosphere 100 — catalogo dei nuovi preset','','100 suoni aggiunti ai 77 esistenti: ID 4D–B0 esadecimali (77–176 decimali). Gli ID precedenti restano invariati.','','Instrument → K3 sceglie I00–I1F; K4 apre il catalogo; K1/K4 scorrono i suoni; **K2 salta fra famiglie**; REC copia il preset nello slot Instrument. Le Phrase che usano quello slot suoneranno il nuovo timbro.','','I preset contengono motore, ADSR, filtro, inviluppo cutoff, due LFO e, per DUAL WT, modulazione delle due posizioni. Non contengono mandate o effetti master: restano quelli del progetto. Per ascoltarli asciutti lascia i return a zero; per un ambiente ampio prova AMBIENT con return 70–A0 e send della traccia 60–90. Un pad usa una voce: per accordi distribuisci le note su più tracce. Per note su più Phrase usa una nota iniziale seguita da Phrase valide vuote; una cella Song vuota spegne la voce.','','Tieni le note almeno 5–8 secondi: molti attacchi sono lenti e i due LFO hanno cicli di diversi secondi. Rilascia i tasti per ascoltare la coda ADSR.']
for f in range(10):
 group=bank[f*10:f*10+10];lines+=['','## '+group[0]['family'],'',group[0]['description']+'.','','| ID | Preset | Motore | Attack / Release | LFO1 / LFO2 |','|---|---|---|---|---|']
 for p in group:
  model={17:'DUAL WT',16:'FM4',5:'BR FM',6:'BR FBFM',7:'BR VOSIM',8:'BR CSAW',9:'BR MORPH',10:'BR SAW SQR',11:'BR SAW SUB',12:'BR SYNC'}[p['patch'][0]]
  s=p['sound'];lines.append('| %s | %s | %s | %.2f s / %.2f s | %.3f / %.3f Hz |'%(p['hex'],p['name'],model,(1+s[1]**2*4)/32000,(1+s[4]**2*4)/32000,(64+s[9]**2)/3200,(64+s[16]**2)/3200))
(out/'FM1-M8-Atmosphere-100-Catalogo.md').write_text('\n'.join(lines)+'\n')
print('Generated 100 complete pads; 177 presets total; legacy IDs 00–4C preserved.')
