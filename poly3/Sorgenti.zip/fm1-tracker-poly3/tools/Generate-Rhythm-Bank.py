#!/usr/bin/env python3
"""Regenerate embedded PCM from the preserved Evolver WAVs (Python standard library)."""
from pathlib import Path
import hashlib,json,struct,wave
root=Path(__file__).resolve().parent.parent
assets=root/'assets/rhythm-bank'
names=['CR78-Kick','CR78-Snare','CR78-OpenHat','CR78-Tom','MP45-Snare','MP45-OpenHat','MP45-FX3','MP45-FX4']
names += [a['name'] for a in json.loads((assets/'expanded-catalog.json').read_text())]
lines=['/* Prepared Evolver samples, resampled to PCM16/22050 for the tracker. See assets/rhythm-bank. */'];report=[]
for i,name in enumerate(names):
 f=assets/(name+'.wav')
 with wave.open(str(f)) as w:
  assert w.getsampwidth()==2 and w.getnchannels()==1
  rate=w.getframerate();a=struct.unpack('<'+'h'*w.getnframes(),w.readframes(w.getnframes()))
 n=round(len(a)*22050/rate);b=[]
 for j in range(n):
  x=j*rate/22050;k=min(int(x),len(a)-1);q=x-k
  b.append(round(a[k]*(1-q)+a[min(k+1,len(a)-1)]*q))
 lines.append('static const int16_t rhythm_%d[]={%s};'%(i,','.join(map(str,b))))
 report.append(dict(slot=i,name=name,frames=n,rate=22050,source_sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
lines.append('static const char *rhythm_names[TR_SAMPLES]={'+','.join(json.dumps(s) for s in names)+'};')
lines.append('static void load_rhythm_bank(void){')
for i,r in enumerate(report):lines.append(' {TrSample s={rhythm_%d,%d,22050,60};(void)tr_set_sample(&tracker,%d,&s);}'%(i,r['frames'],i))
lines.append('}')
(root/'app/tracker/rhythm_bank.inc').write_text('\n'.join(lines)+'\n')
(assets/'tracker-map.json').write_text(json.dumps(report,indent=2))
print('Generated embedded PCM16 samples:',sum(x['frames']*2 for x in report),'bytes')
