#!/usr/bin/env python3
"""Build FM1 M8 RFM1 v1 for RemoteFM1IOS. No physical firmware is changed."""
from pathlib import Path
import argparse,hashlib,json,subprocess,zipfile,os
r=Path(__file__).resolve().parents[1];out=r.parent
p=argparse.ArgumentParser();p.add_argument('--wasi-sdk',required=True);a=p.parse_args();sdk=Path(a.wasi_sdk).resolve();b=r/'build/rfm1';b.mkdir(parents=True,exist_ok=True)
sha=lambda x:hashlib.sha256(x).hexdigest()
version='follow-20261105';name='fm1_m8-'+version
# A content-addressed local source snapshot, supplied beside the module. No fictitious public repository.
files=[]
for top in ['app/tracker','remote','sdk/include']:
 files += [f for f in (r/top).rglob('*')if f.is_file()]
files += list((r/'app').glob('*.h'))
files += [r/'tests/test_rfm1.cjs',r/'tests/test_rfm1_host.cpp',r/'tests/capture_blue.cjs',r/'tests/test_device.c',r/'tests/test_effects.c']
files += [r/"tools/Generate-Blue-Fonts.py",r/"tools/Generate-Atmosphere-Presets.py",r/"tests/test_atmosphere.c"]
files += [Path(__file__),r/'LICENSE.md',r/'THIRD_PARTY.md']
files += [f for f in (r/'third_party').rglob('*')if f.is_file()]
files=sorted(set(files));snapshot={str(f.relative_to(r)):sha(f.read_bytes())for f in files};source_hash=sha(json.dumps(snapshot,sort_keys=True).encode());source='urn:sha256:'+source_hash
credits='FM1 M8 Tracker — custom tracker development for gfcalvi.\nRemoteFM1 adapter: local build, 5 November 2026.\n177 presets, 33 MiniPops45/CR78 hits; BASIC, Braids-derived, FM4, dual wavetable.\nCorresponding source: FM1-M8-Follow-Sorgenti.zip, snapshot '+source_hash+'.\nNo public source repository has been published. See supplied source archive.\nfm1core ABI 6 by Quixotic7/FM1VST contributors (GPL-3.0-only).\n\n'+(r/'LICENSE.md').read_text()+'\n\n'+(r/'THIRD_PARTY.md').read_text()
(b/'build_info.h').write_text('#define M8_VERSION '+json.dumps(version)+'\n#define M8_SOURCE '+json.dumps(source)+'\n#define M8_CREDITS '+json.dumps(credits)+'\n')
sources=[r/'app/tracker'/f for f in ['tracker.c','commands.c','device.c']]+[r/'remote/core.c']
cmd=[str(sdk/'bin/clang'),'--sysroot='+str(sdk/'share/wasi-sysroot'),'-std=c11','-O2','-fno-builtin-malloc','-fno-builtin-free','-fno-builtin-calloc','-fno-builtin-realloc','-fwrapv','-fno-fast-math','-ffp-contract=off','-DFM1_HOST_TEST','-Wall','-Wextra','-Werror','-Wno-unused-function','-mexec-model=reactor','-mno-bulk-memory','-mno-reference-types','-I'+str(r/'sdk/include'),'-I'+str(r/'app'),'-I'+str(r/'app/synth'),'-I'+str(b),*map(str,sources),'-Wl,--strip-all','-Wl,--compress-relocations','-Wl,-z,stack-size=131072','-Wl,--initial-memory=8388608','-Wl,--max-memory=8388608','-o',str(b/'core.wasm')]
(b/'tmp').mkdir(exist_ok=True)
subprocess.run(cmd,check=True,env={**os.environ,'TMPDIR':str(b/'tmp')})
def leb(n):
 v=bytearray()
 while n>=128:v.append((n&127)|128);n>>=7
 v.append(n);return bytes(v)
def custom(name,payload):
 n=name.encode();data=leb(len(n))+n+payload;return b'\0'+leb(len(data))+data
manifest={'rfm1':1,'abi':6,'id':'fm1_m8','name':'FM1 M8 Tracker','version':version,'license':'GPL-3.0-only','source_url':source,'authors':['FM1 M8 project for gfcalvi'],'built_by':'FM1 M8 Build-RemoteFM1.py / WASI SDK 27','memory_mib':8,'source_archive':'FM1-M8-Follow-Sorgenti.zip','source_sha256':source_hash}
data=(b/'core.wasm').read_bytes()+custom('rfm1',json.dumps(manifest,ensure_ascii=False).encode())+custom('rfm1.credits',credits.encode())
for i,f in enumerate([r/'LICENSE.md',r/'THIRD_PARTY.md',r/'app/tracker/fonts/OFL-Inter.txt']):data+=custom('rfm1.license.'+str(i),f.read_bytes())
f=out/(name+'.rfm1');f.write_bytes(data)
with zipfile.ZipFile(out/'FM1-M8-Follow-Sorgenti.zip','w',zipfile.ZIP_DEFLATED)as z:
 for file in files:z.write(file,'fm1-tracker/'+str(file.relative_to(r)))
 z.writestr('SOURCE-SNAPSHOT.json',json.dumps(snapshot,indent=2));z.writestr('BUILD.txt','WASI SDK 27 arm64 macOS; python3 tools/Build-RemoteFM1.py --wasi-sdk /path/to/wasi-sdk-27.0-arm64-macos\nNo SDK binary libraries linked. source_url is a content-addressed local snapshot, not a published Git repository.\n')
report={'manifest':manifest,'module':f.name,'bytes':len(data),'sha256':sha(data),'source_snapshot_sha256':source_hash,'source_zip_sha256':sha((out/'FM1-M8-Follow-Sorgenti.zip').read_bytes()),'command':cmd,'physical_firmware_changed':False,'iOS_device_tested':False}
(out/'FM1-M8-Follow-Verifica.json').write_text(json.dumps(report,indent=2)+'\n');print(f,len(data),sha(data))
