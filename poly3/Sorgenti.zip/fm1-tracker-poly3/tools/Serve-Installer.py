#!/usr/bin/env python3
"""Serve only this installation bundle on the local network, no directory listing."""
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from urllib.parse import urlsplit
import subprocess,mimetypes
base=Path(__file__).resolve().parent
if not (base/'FM1-M8-Installer.html').exists():base=Path(__file__).resolve().parents[2]
allowed={n:base/n for n in ['FM1-M8-Installer.html','FM1-M8-Hardware-RC1.fwsc','FM1-M8-Installazione-Sorgenti.zip','FM1-M8-Installazione-LEGGIMI.md']}
class Handler(BaseHTTPRequestHandler):
 def do_HEAD(self):self.reply(False)
 def do_GET(self):self.reply(True)
 def reply(self,body):
  name=urlsplit(self.path).path.lstrip('/') or 'FM1-M8-Installer.html'
  if name not in allowed or not allowed[name].is_file():self.send_error(404);return
  raw=allowed[name].read_bytes();self.send_response(200);self.send_header('Content-Type',mimetypes.guess_type(name)[0]or'application/octet-stream');self.send_header('Content-Length',str(len(raw)));self.send_header('Cache-Control','no-store');self.end_headers()
  if body:self.wfile.write(raw)
 def log_message(self,*args):pass
ip='NOME-DEL-MAC.local'
for adapter in ['en0','en1']:
 try:
  value=subprocess.check_output(['/usr/sbin/ipconfig','getifaddr',adapter],stderr=subprocess.DEVNULL,text=True).strip()
  if value:ip=value;break
 except (OSError,subprocess.CalledProcessError):pass
print(f'Installer sul Mac: http://127.0.0.1:8786\nSu iPhone/iPad nella stessa rete Wi-Fi, apri MIDIWeb Browser:\nhttp://{ip}:8786\nLa pagina verifica il supporto WebMIDI. Se la connessione HTTP viene rifiutata dal browser occorre servirla via HTTPS.\nVengono esposti solo i quattro file del pacchetto. CTRL+C chiude il server.',flush=True)
try:ThreadingHTTPServer(('0.0.0.0',8786),Handler).serve_forever()
except KeyboardInterrupt:print('\nServer chiuso.')
