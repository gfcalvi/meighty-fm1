/* Host-only listening demo; not part of firmware. */
#include "tracker/tracker.h"
#include <stdio.h>
#include <math.h>
static Tracker t;
static void le(FILE *f,unsigned n,unsigned bytes){for(unsigned i=0;i<bytes;i++)fputc((int)((n>>(8*i))&255),f);}
int main(int argc,char **argv){if(argc!=2)return 1;FILE *f=fopen(argv[1],"wb");if(!f)return 1;unsigned frames=32000*18;
 fwrite("RIFF",1,4,f);le(f,36+frames*4,4);fwrite("WAVEfmt ",1,8,f);le(f,16,4);le(f,1,2);le(f,2,2);le(f,32000,4);le(f,128000,4);le(f,4,2);le(f,16,2);fwrite("data",1,4,f);le(f,frames*4,4);
 for(unsigned mode=0;mode<2;mode++){tr_init(&t);t.project.reverb_mode=mode;t.project.master[4]=224;t.project.master[5]=90;t.project.master[6]=255;tr_effects_reset(&t);unsigned length=mode?13:5;int32_t previous[2]={0,0};
  for(unsigned n=0;n<8000*length;n++){double time=n/8000.0;int input=time<.4?(int)(7000*(sin(6.283185307*220*time)+sin(6.283185307*277.18*time)+sin(6.283185307*329.63*time))*exp(-time*12)):0;int32_t wet[2];tr_effects_sample(&t,0,0,input,input/2,wet);
   for(unsigned k=0;k<4;k++)for(unsigned c=0;c<2;c++){int x=input/2+4*(previous[c]+(wet[c]-previous[c])*(int)k/4);if(x>32767)x=32767;if(x< -32768)x=-32768;le(f,(unsigned)(uint16_t)(int16_t)x,2);}previous[0]=wet[0];previous[1]=wet[1];
  }
 }fclose(f);return 0;
}
