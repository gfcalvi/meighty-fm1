#!/usr/bin/env python3
"""Build the real FM1 Open C simulator and custom tracker workbench on macOS/Linux.
The vendor SDK payload is read-only. No firmware image is produced or flashed.
"""
from pathlib import Path
import argparse,base64,hashlib,html,json,os,re,subprocess
root=Path(__file__).resolve().parent.parent
parser=argparse.ArgumentParser()
parser.add_argument('--wasi-sdk',default=os.environ.get('FM1_WASI_SDK'),required=not os.environ.get('FM1_WASI_SDK'))
parser.add_argument('--out',default=str(root.parent/'FM1-Tracker-A03-Workbench.html'))
a=parser.parse_args();sdk=Path(a.wasi_sdk).resolve();out=Path(a.out).resolve();build=root/'build/tracker-web';build.mkdir(parents=True,exist_ok=True)
manifest=json.loads((root/'sdk/manifest.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,expected in manifest['files'].items():
 if sha(root/name)!=expected:raise SystemExit('SDK integrity failure: '+name)
compiler=sdk/'bin/clang'
if not compiler.exists():raise SystemExit('WASI SDK compiler not found: '+str(compiler))
sources=sorted(p for top in ['app','web','third_party/synth'] for p in (root/top).rglob('*.c') if 'app/board/' not in p.relative_to(root).as_posix())
flags=['--sysroot='+str(sdk/'share/wasi-sysroot'),'-std=c11','-O2','-fwrapv','-fno-fast-math','-ffp-contract=off','-DFM1_HOST_TEST','-DFM1_OPEN_WEB','-Wall','-Wextra','-Werror','-Wno-unused-function','-Wno-array-parameter','-mexec-model=reactor']
for name in ['web/engine','web/synth','third_party/synth','sdk/include','app/synth','app']:flags+=['-I'+str(root/name)]
wasm=build/'simulator.wasm'
command=[str(compiler),*flags,*map(str,sources),'-Wl,--wrap=__wasi_fd_close','-Wl,--wrap=__wasi_fd_seek','-Wl,--wrap=__wasi_fd_write','-Wl,--strip-all','-Wl,-z,stack-size=131072','-Wl,--initial-memory=4194304','-Wl,--max-memory=33554432','-o',str(wasm)]
print('Compiling',len(sources),'C units, including the tracker and the official simulator',flush=True)
subprocess.run(command,check=True,cwd=root)
inputs={p.relative_to(root).as_posix():sha(p) for p in sources}
for p in (root/'app/tracker').rglob('*'):
 if p.is_file():inputs[p.relative_to(root).as_posix()]=sha(p)
source_hash=hashlib.sha256(json.dumps(inputs,sort_keys=True).encode()).hexdigest()
sim={'schema':1,'release_version':'Tracker A03','sha256':sha(wasm),'source_sha256':source_hash,'sample_bank':'33 hits MiniPops45 + CR78, PCM16 22050','data':base64.b64encode(wasm.read_bytes()).decode()}
web=(root/'sdk/Update.html.in').read_text()
web=re.sub(r'<a\b[^>]*href="/\*FM1_SOURCE_URL\*/"[^>]*>(.*?)</a>',r'<span>\1 (local source archive supplied)</span>',web)
notices='FM1 Tracker A03: experimental local C/WebAssembly preview. Source + SDK are supplied separately.\n\n'
for f in ['LICENSE.md','THIRD_PARTY.md']:notices+='\n'+(root/f).read_text()
replace={
 '/*FM1_SOURCE_URL*/':'',
 '/*FM1_PAYLOAD*/':'const FM1_PACKAGE = null;',
 '/*FM1_SIMULATOR*/':'const FM1_SIMULATOR = '+json.dumps(sim,separators=(',',':'))+';',
 '/*FM1_I18N*/':(root/'sdk/I18n.js').read_text(),
 '/*FM1_SCRIPT*/':(root/'sdk/WebUpdate.js').read_text(),
 '/*FM1_SIM_SCRIPT*/':(root/'web/tracker/Runtime.js').read_text(),
 '/*FM1_SAMPLE_SCRIPT*/':(root/'sdk/Samples.js').read_text(),
 '/*FM1_NOTICES*/':html.escape(notices)}
for key,value in replace.items():web=web.replace(key,value)
if re.search(r'/\*FM1_[A-Z_]+\*/',web):raise SystemExit('Unexpanded workbench placeholder')
native_path=root.parent/'FM1-M8-MultiEngine-INTERACTIVE.fwsc'
native={'sha256':sha(native_path),'data':base64.b64encode(native_path.read_bytes()).decode()} if native_path.exists() else None
web=web.replace('</html>','<style>\n'+(root/'web/tracker/Workbench.css').read_text()+'\n</style><script>\nconst FM1_TRACKER_NATIVE_PACKAGE = '+json.dumps(native,separators=(',',':'))+';\n'+(root/'web/tracker/ProjectFiles.js').read_text()+'\n'+(root/'web/tracker/Workbench.js').read_text()+'\n</script></html>')
web=re.sub(r'<title>.*?</title>','<title>FM1 Tracker A03 Workbench</title>',web,count=1)
out.parent.mkdir(parents=True,exist_ok=True);out.write_text(web)
report={'schema':1,'build':'Tracker A03 local workbench','compiler':str(compiler),'wasm_sha256':sha(wasm),'wasm_bytes':wasm.stat().st_size,'source_sha256':source_hash,'html_sha256':sha(out),'sdk_integrity_files':len(manifest['files']),'firmware_included':bool(native),'hardware_updater_enabled':False,'native_package_sha256':native['sha256'] if native else None,'command':command}
(build/'build-report.json').write_text(json.dumps(report,indent=2)+'\n')
print('Workbench:',out,'WASM bytes:',wasm.stat().st_size,flush=True)
