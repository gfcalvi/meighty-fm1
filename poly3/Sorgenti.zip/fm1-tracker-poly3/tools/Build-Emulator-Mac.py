from pathlib import Path
import subprocess,os,sys,json,shutil
root=Path(__file__).resolve().parent.parent;os.chdir(root)
prior=Path('/Users/gfcalvi/Documents/Codex/2026-10-21/stiamo-sviluppando-fm1-evolving-un-firmware')
tc=Path(os.environ.get('FM1_JIELI_TOOLCHAIN',str(prior/'work/target-tools/jieli-linux-toolchains-20250324.1')));runner=Path(os.environ.get('FM1_JIELI_RUNNER',str(prior/'work/jieli_runner.py')));hw7=os.environ.get('FM1_HW7_RELEASE')=='1';compact=os.environ.get('FM1_COMPACT_DSP')=='1';hw6=os.environ.get('FM1_HW6_RELEASE')=='1';hw5=os.environ.get('FM1_HW5_RELEASE')=='1';hw4=os.environ.get('FM1_HW4_RELEASE')=='1';profile=os.environ.get('FM1_AUDIO_PROFILE')=='1';perf=os.environ.get('FM1_HWPERF_RELEASE')=='1';diag=os.environ.get('FM1_HWDIAG_RELEASE')=='1';hwfix=os.environ.get('FM1_HWFIX_RELEASE')=='1';hardware=os.environ.get('FM1_HARDWARE')=='1';blue=os.environ.get('FM1_BLUE_RELEASE')=='1';vu=os.environ.get("FM1_FOLLOW_RELEASE")=="1";contrast=os.environ.get("FM1_CONTRAST_RELEASE")=="1";stress=os.environ.get('FM1_STRESS_ENGINE');out=root/('build/hardware-hw7' if hw7 else 'build/hardware-compact' if compact else 'build/hardware-hw6' if hw6 else 'build/hardware-hw5' if hw5 else 'build/hardware-hw4' if hw4 else 'build/hardware-profile' if profile else 'build/hardware-hw3' if hardware and perf else 'build/hardware-hw2' if hardware and diag else 'build/hardware-hwfix' if hardware and hwfix else 'build/hardware-follow' if hardware and vu else 'build/hardware-contrast' if hardware and contrast else 'build/hardware-deepblue' if hardware and blue else 'build/hardware' if hardware else 'build/emulator-stress'+stress if stress else 'build/emulator');out.mkdir(parents=True,exist_ok=True)
def run(tool,args):
 q=subprocess.run([sys.executable,str(runner),str(tc/tool),*map(str,args)],capture_output=True,text=True);print(q.stdout+q.stderr,flush=True)
 if q.returncode:raise SystemExit(q.returncode)
flags=['-target','pi32v2','-mcpu=r3','-mfprev1','-O2','-mllvm','-pi32v2-large-program=true','-std=gnu11','-ffreestanding','-fno-builtin','-fwrapv','-ffunction-sections','-fdata-sections','-Iemulator/hal','-Isdk/include','-Isdk/include/libc','-Iapp/tracker','-Iapp','-Iapp/synth']
if blue:flags += ['-save-temps=obj']
if hardware:flags+=['-DFM1_HARDWARE=1']
if diag:flags+=['-DFM1_AUDIO_DIAGNOSTICS=1']
if compact:flags+=['-DFM1_COMPACT_DSP=1']
if profile:flags+=['-DFM1_AUDIO_PROFILE=1']
if perf:flags+=['-DFM1_AUDIO_DIAG_VERSION='+('7' if hw7 else '6' if hw6 else '5' if hw5 else '4' if hw4 else '3')]
if stress:flags += ['-DFM1_STRESS_ENGINE='+str(int(stress))]
objs=[]
for f in ['emulator/startup.S','emulator/hal/fm1_vec.S','emulator/hal/fm1_isr.S','emulator/main.c','emulator/format.c','app/tracker/tracker.c','app/tracker/commands.c','app/tracker/device.c']:
 obj=out/(Path(f).stem+'.o');
 if obj.exists() and obj.stat().st_mtime>max(Path(f).stat().st_mtime,Path(__file__).stat().st_mtime,max((a.stat().st_mtime for folder in ['app/tracker','emulator/hal','hardware','hardware/vendor'] for a in (root/folder).glob('*') if a.suffix in ['.inc','.h','.c']),default=0)):
  objs.append(obj);continue
 print('compile',f,flush=True);run('pi32v2/bin/clang',[*flags,*(['-O3'] if compact and f=='app/tracker/tracker.c' else ['-Os'] if perf and (f in ['emulator/format.c','app/tracker/device.c'] or compact and f=='app/tracker/commands.c') else []),'-c',f,'-o',obj]);objs.append(obj)
lib=tc/'pi32v2/lib/r3';run('pi32v2/bin/ld',['--gc-sections','-Map='+str(out/'tracker.map'),'-Temulator/app.ld','-e','_start',*objs,'--start-group',lib/'libc.a',lib/'libcompiler_rt.a','--end-group','-o',out/'tracker.elf'])
# Extract load segments without platform-specific objcopy.
import struct,hashlib,importlib.util
raw=(out/'tracker.elf').read_bytes();phoff=struct.unpack_from('<I',raw,28)[0];phsize,phcount=struct.unpack_from('<HH',raw,42);image=bytearray()
for n in range(phcount):
 typ,offset,va,pa,size,mem,flags,align=struct.unpack_from('<IIIIIIII',raw,phoff+n*phsize)
 if typ!=1 or not size or not 0x02000120<=pa<0x02090000:continue
 off=pa-0x02000120
 if len(image)<off+size:image.extend(b'\xff'*(off+size-len(image)))
 image[off:off+size]=raw[offset:offset+size]
assert len(image)<0x86ee0
(out/'tracker.bin').write_bytes(image);(out/'tracker-xip.bin').write_bytes(bytes(0x120)+image)
sys.path.insert(0,str(root/'emulator'));import fm1pkg_make as pkg
pkg.SDK=root/'emulator/package-assets'
ota=Path(os.environ.get('FM1_OTA_BIN',str(root/'emulator/package-assets/ota.bin'))).read_bytes()
package=pkg.ufw(pkg.flash_image(bytes(image),pkg.KEY),ota,'FM-1_998213' if hardware else 'FM-1_900')
filename=root.parent/'FM1-M8-Hardware-HW7.fwsc' if hw7 else root.parent/'FM1-M8-Hardware-EXPERIMENT.fwsc' if compact else root.parent/'FM1-M8-Hardware-HW6.fwsc' if hw6 else root.parent/'FM1-M8-Hardware-HW5.fwsc' if hw5 else root.parent/'FM1-M8-Hardware-HW4.fwsc' if hw4 else root.parent/'FM1-M8-Hardware-Profile.fwsc' if profile else root.parent/'FM1-M8-Hardware-HW3.fwsc' if hardware and perf else root.parent/'FM1-M8-Hardware-HW2.fwsc' if hardware and diag else root.parent/'FM1-M8-Hardware-HW1.fwsc' if hardware and hwfix else root.parent/'FM1-M8-Hardware-Follow.fwsc' if hardware and vu else root.parent/'FM1-M8-Hardware-Contrast.fwsc' if hardware and contrast else root.parent/'FM1-M8-Hardware-DeepBlue.fwsc' if hardware and blue else root.parent/'FM1-M8-Hardware-RC1.fwsc' if hardware else out/'stress.fwsc' if stress else root.parent/'FM1-M8-MultiEngine-INTERACTIVE.fwsc';filename.write_bytes(package)
(out/'report.json').write_text(json.dumps({'target':'FM1 hardware candidate PI32v2' if hardware else 'FM1 Emulator PI32v2','image_bytes':len(image),'package_bytes':len(package),'sha256':hashlib.sha256(package).hexdigest(),'storage':'8 transactional slots 0xaf000..0xdefff; OTA 0xe0000..0xe4fff excluded' if hardware else '8 transactional slots, user partition 0x95000..0xe7000','hardware_validated':False},indent=2))
print(filename,len(package))
