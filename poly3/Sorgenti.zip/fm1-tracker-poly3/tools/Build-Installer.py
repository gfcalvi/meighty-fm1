#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,base64,sys,struct,zipfile,argparse
r=Path(__file__).resolve().parents[1];out=r.parent
sys.path.insert(0,str(r/'emulator'));import fm1pkg_make as make
p=argparse.ArgumentParser();p.add_argument('--deep-blue',action='store_true');p.add_argument('--contrast',action='store_true');p.add_argument('--hw7',action='store_true');p.add_argument('--hw6',action='store_true');p.add_argument('--hw5',action='store_true');p.add_argument('--hw4',action='store_true');p.add_argument('--hwperf',action='store_true');p.add_argument('--hwdiag',action='store_true');p.add_argument('--hwfix',action='store_true');p.add_argument('--follow',action='store_true');a=p.parse_args();a.hw6=a.hw6 or a.hw7;a.hw5=a.hw5 or a.hw6;a.hw4=a.hw4 or a.hw5;a.hwperf=a.hwperf or a.hw4;a.hwdiag=a.hwdiag or a.hwperf;a.hwfix=a.hwfix or a.hwdiag;a.follow=a.follow or a.hwfix;a.contrast=a.contrast or a.follow;a.deep_blue=a.deep_blue or a.contrast
folder=r/('build/hardware-hw7' if a.hw7 else 'build/hardware-hw6' if a.hw6 else 'build/hardware-hw5' if a.hw5 else 'build/hardware-hw4' if a.hw4 else 'build/hardware-hw3' if a.hwperf else 'build/hardware-hw2' if a.hwdiag else 'build/hardware-hwfix' if a.hwfix else 'build/hardware-follow' if a.follow else 'build/hardware-contrast' if a.contrast else 'build/hardware-deepblue' if a.deep_blue else 'build/hardware')
f=out/('FM1-M8-Hardware-HW7.fwsc' if a.hw7 else 'FM1-M8-Hardware-HW6.fwsc' if a.hw6 else 'FM1-M8-Hardware-HW5.fwsc' if a.hw5 else 'FM1-M8-Hardware-HW4.fwsc' if a.hw4 else 'FM1-M8-Hardware-HW3.fwsc' if a.hwperf else 'FM1-M8-Hardware-HW2.fwsc' if a.hwdiag else 'FM1-M8-Hardware-HW1.fwsc' if a.hwfix else 'FM1-M8-Hardware-Follow.fwsc' if a.follow else 'FM1-M8-Hardware-Contrast.fwsc' if a.contrast else 'FM1-M8-Hardware-DeepBlue.fwsc' if a.deep_blue else 'FM1-M8-Hardware-RC1.fwsc');raw=f.read_bytes();report=json.loads((folder/'report.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();assert sha(raw)==report['sha256']
image=b''.join(raw[n*48:n*48+47]for n in range(20))+raw[960:];h=bytearray(image[:64]);make.enc(h,0,64);count=struct.unpack_from('<H',h,8)[0];loader=None
for i in range(count):
 e=bytearray(image[64+i*80:144+i*80]);make.enc(e,0,80)
 if struct.unpack_from('<H',e,0)[0]==100:
  at,size=struct.unpack_from('<II',e,8);loader=image[at:at+size]
assert loader and b'ota-FM-1_700' in loader
meta={'product':'FM-1_998201','sha256':sha(raw),'loader_sha256':sha(loader),'loaderIdentity':'ota-FM-1_700','data':base64.b64encode(raw).decode(),'hardware_validated':False}
s=(r/'web/installer/index.html.in').read_text()
html_name='FM1-M8-HW7-Installer.html' if a.hw7 else 'FM1-M8-HW6-Installer.html' if a.hw6 else 'FM1-M8-HW5-Installer.html' if a.hw5 else 'FM1-M8-HW4-Installer.html' if a.hw4 else 'FM1-M8-HW3-Installer.html' if a.hwperf else 'FM1-M8-HW2-Installer.html' if a.hwdiag else 'FM1-M8-HW1-Installer.html' if a.hwfix else 'FM1-M8-Follow-Installer.html' if a.follow else 'FM1-M8-Contrast-Installer.html' if a.contrast else 'FM1-M8-DeepBlue-Installer.html' if a.deep_blue else 'FM1-M8-Installer.html'
source_name='FM1-M8-HW7-Sorgenti.zip' if a.hw7 else 'FM1-M8-HW6-Sorgenti.zip' if a.hw6 else 'FM1-M8-HW5-Sorgenti.zip' if a.hw5 else 'FM1-M8-HW4-Sorgenti.zip' if a.hw4 else 'FM1-M8-HW3-Sorgenti.zip' if a.hwperf else 'FM1-M8-HW2-Sorgenti.zip' if a.hwdiag else 'FM1-M8-HW1-Sorgenti.zip' if a.hwfix else 'FM1-M8-Follow-Hardware-Sorgenti.zip' if a.follow else 'FM1-M8-Contrast-Hardware-Sorgenti.zip' if a.contrast else 'FM1-M8-DeepBlue-Sorgenti.zip' if a.deep_blue else 'FM1-M8-Installazione-Sorgenti.zip'
if a.hwdiag:
 s=s.replace('RC1','HW2 diagnostica')
 s=s.replace('<section><h2>Progetti', '<section><h2>Misure audio HW2</h2><p>Lettura tramite identità USB: non modifica progetto, memoria o trasporto. Dopo la prova PLAY, ferma la riproduzione e leggi i contatori. In alternativa tieni OCT− e OCT+ insieme per leggerli sul display.</p><button id="audioread">Leggi misure audio · sola lettura</button><pre id="audiostats">In attesa della build HW2.</pre></section><section><h2>Progetti')
 s=s.replace("$('readslot').onclick=", r"""$('audioread').onclick=async()=>{if(busy||!connected){$('audiostats').textContent='Connetti prima FM-1.';return;}busy=true;update();try{const p=await installer.link.query(17,[],10000);if(p.length!==27||p[16]!==68||p[17]!==2)throw Error('Il dispositivo non esegue la diagnostica HW2.');const u=i=>p[i]+256*p[i+1];$('audiostats').textContent='Rendering massimo: '+u(18)+' us / budget 2902 us\nBuffer superati durante render: '+u(20)+'\nBlocchi oltre budget: '+u(22)+'\nSorgente clock: 0x'+p[24].toString(16)+'\nMASTER Q8: '+p[25]+'\nPagina: '+p[26];}catch(e){$('audiostats').textContent=e.message;}finally{busy=false;update();}};
$('readslot').onclick=""")
if a.hwperf:s=s.replace('HW2 diagnostica','HW3').replace('HW2','HW3').replace('p[17]!==2','p[17]!==3')
if a.hw4:s=s.replace('HW3','HW4').replace('p[17]!==3','p[17]!==4')
if a.hw5:s=s.replace('HW4','HW5').replace('p[17]!==4','p[17]!==5')
if a.hw6:s=s.replace('HW5','HW6').replace('p[17]!==5','p[17]!==6')
if a.hw7:s=s.replace('HW6','HW7').replace('p[17]!==6','p[17]!==7')
if a.hwfix:s=s.replace('RC1','HW1')
if a.follow:s=s.replace('RC1','Follow')
if a.contrast:s=s.replace('RC1','Contrast')
if a.deep_blue:s=s.replace('RC1','Deep Blue').replace('FM1-M8-Installazione-Sorgenti.zip',source_name)
s=s.replace('/*SDK*/',(r/'sdk/WebUpdate.js').read_text()).replace('/*CORE*/',(r/'web/installer/InstallerCore.js').read_text()).replace('/*PACKAGE*/',json.dumps(meta,separators=(',',':')))
(out/html_name).write_text(s);(folder/'installer-meta.json').write_text(json.dumps({k:v for k,v in meta.items()if k!='data'},indent=2))
with zipfile.ZipFile(out/source_name,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(r.rglob('*')):
  rel=p.relative_to(r)
  if p.is_file() and not set(rel.parts)&{'build','work','__pycache__','.git'} and p.name!='.DS_Store':z.write(p,Path('fm1-tracker')/rel)
print('Installer self-contained:',(out/html_name).stat().st_size,'bytes')
