#!/usr/bin/env python3
"""Meighty HW16 direct slot management candidate. Builds only; never opens or writes USB.

Uses the existing SDK builder with isolated output/flags. Older HW releases
remain reproducible with their frozen source archives, never overwritten here.
"""
from pathlib import Path
import os,sys,subprocess
root=Path(__file__).resolve().parents[1]
loader=root/'build/loader-hw1/ota.bin'
if not loader.exists():subprocess.run([sys.executable,str(root/'tools/Build-Loader-Mac.py')],check=True)
p=root/'tools/Build-Emulator-Mac.py';s=p.read_text()
assert s.count('out.mkdir(parents=True,exist_ok=True)')==1
assert s.count('filename.write_bytes(package)')==1
s=s.replace('out.mkdir(parents=True,exist_ok=True)','out=root/"build/hardware-hw16";out.mkdir(parents=True,exist_ok=True)',1)
s=s.replace('objs=[]',"flags+=['-DFM1_BLOCK_RENDER=1','-DFM1_CPU1=1','-DFM1_CPU1_FALLBACK=0','-Ihardware/cpu2','-UFM1_AUDIO_DIAG_VERSION','-DFM1_AUDIO_DIAG_VERSION=16'];objs=[]",1)
s=s.replace("['emulator/startup.S',","['hardware/cpu2/fm1_cpu1.S','emulator/startup.S',",1)
s=s.replace("['emulator/format.c','app/tracker/device.c']","['emulator/format.c','app/tracker/device.c','emulator/main.c']")
s=s.replace('filename.write_bytes(package)','filename=root.parent/"Meighty-1.01-RC7.fwsc";filename.write_bytes(package)',1)
os.environ.update(FM1_HARDWARE='1',FM1_HWPERF_RELEASE='1',FM1_HWDIAG_RELEASE='1',FM1_COMPACT_DSP='1',FM1_BLUE_RELEASE='1',FM1_FOLLOW_RELEASE='1',FM1_AUDIO_PROFILE='0',FM1_OTA_BIN=str(loader))
# Build flags are part of this wrapper, not the legacy cache key: force a clean
# object set so an earlier invocation cannot silently reuse different flags.
dest=root/'build/hardware-hw16';dest.mkdir(parents=True,exist_ok=True)
for obj in dest.glob('*.o'):obj.unlink()
exec(compile(s,str(p),'exec'),{'__file__':str(p),'__name__':'__main__'})
