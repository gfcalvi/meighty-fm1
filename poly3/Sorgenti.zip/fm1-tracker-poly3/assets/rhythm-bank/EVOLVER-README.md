# Mini Pops / CR-78 — compact User sample bank

Eight mono hits, 12 kHz G.711 µ-law, nominal root C4/MIDI 60. These are short percussion recordings, not accurately pitched instruments. The root is an editable playback reference.

The authors explicitly marked each linked source CC0 1.0. Redistribution and adaptation are permitted under the [CC0 public-domain dedication](https://creativecommons.org/publicdomain/zero/1.0/legalcode). Attribution is retained for provenance. Hardware names identify the recorded sources; no affiliation is implied.

Source files are the public high-quality **MP3 previews**, not the original downloadable WAVs. Decode, leading trim, short edge fades, explicit gain and 12 kHz µ-law conversion are documented per file in `catalog.json`. This is a bandwidth/quality compromise, not a lossless archive. No unlicensed samples are included.

| Asset | Author / source | Encoded bytes | Duration | Gain dB |
|---|---|---:|---:|---:|
| CR78 Kick | [oceansonmars](https://freesound.org/people/oceansonmars/sounds/708813/) | 991 | 0.083s | -2.74 |
| CR78 Snare | [oceansonmars](https://freesound.org/people/oceansonmars/sounds/708816/) | 744 | 0.062s | -2.71 |
| CR78 OpenHat | [oceansonmars](https://freesound.org/people/oceansonmars/sounds/708814/) | 3600 | 0.300s | -4.74 |
| CR78 Tom | [oceansonmars](https://freesound.org/people/oceansonmars/sounds/708817/) | 2196 | 0.183s | -2.68 |
| MP45 Snare | [schafferdavid](https://freesound.org/people/schafferdavid/sounds/267616/) | 1668 | 0.139s | 5.79 |
| MP45 OpenHat | [schafferdavid](https://freesound.org/people/schafferdavid/sounds/267615/) | 3600 | 0.300s | 0.79 |
| MP45 FX4 | [schafferdavid](https://freesound.org/people/schafferdavid/sounds/267607/) | 2400 | 0.200s | 3.26 |
| MP45 FX3 | [schafferdavid](https://freesound.org/people/schafferdavid/sounds/267608/) | 4200 | 0.350s | 12.00 |

Import the `.fm1bank` in the uploader. Importing a bank replaces its candidate list, and does not write flash until the explicit upload step. Keep a backup of an existing User bank. Existing project asset references are content IDs with CRC: removed/replaced assets become Missing, never another hit. The eight assets use 19399 of 23776 payload bytes.

This curated bank has passed the file-format/conversion checks. C20B actual browser playback and RC1 sample happy-path/readback are verified. RC1 does not qualify hardware or every twelve-voice load. Sources identify Mini Pops45, not7, and CR-78; see PROVENANCE_C20B_RHYTHM.md.
