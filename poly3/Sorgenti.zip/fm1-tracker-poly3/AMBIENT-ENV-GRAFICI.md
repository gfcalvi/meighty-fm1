# Ambient e pannello grafico di modulazione

## Prova rapida

Apri la versione aggiornata del Workbench. In **Master FX → Tipo riverbero** scegli **AMBIENT**. Per una coda lunga: Decay 224, Damping 90, Ritorno riverbero 160–200. Questi controlli web sono decimali; sul display C i valori sono esadecimali (E0, 5A, A0–C8). In Mixer alza la mandata Reverb della traccia: con mandata zero non entra segnale nel riverbero. Delay e riverbero mantengono le mandate indipendenti e i comandi Phrase DSN/RSN.

Per ascoltare un confronto già renderizzato: `FM1-Room-vs-Ambient.wav`, 18 secondi stereo. Prima ROOM per 5 secondi, poi AMBIENT per 13 secondi; stessa breve triade di ingresso. Il solo ritorno è amplificato allo stesso modo nelle due sezioni per rendere udibile la coda nel confronto. Non è una registrazione del dispositivo fisico.

## Display C, non un mockup web

La seconda pagina Instrument è ora un pannello suddiviso in quattro riquadri:

1. AMP ENV: ADSR di ampiezza, curva ciano.
2. CUT ENV: ADSR del cutoff, curva gialla.
3. LFO 1: forma d'onda viola.
4. LFO 2: forma d'onda verde.

K1 sceglie il parametro; il riquadro corrispondente viene evidenziato e mostra nome e valore. K2 modifica il parametro, K3 lo strumento. I BPM sono in Global (GLO); HOME apre Mixer e SEQ apre Master FX. Premendo di nuovo Instrument si torna alla pagina principale, mantenendo lo slot. L'editor esteso del Workbench mantiene i controlli numerici per impostazioni dirette; il display 240×240 viene disegnato dal firmware C.

Le curve ADSR mostrano Attack, Decay, Sustain e Release. La larghezza dei segmenti è compressa per restare leggibile anche con tempi molto diversi: non è una scala temporale lineare. Quando il riquadro non è selezionato, i quattro valori sono nell'ordine A, D, S, R. Un punto bianco segue la fase e il livello dell'inviluppo della preview o della voce selezionata. I punti sulle forme d'onda seguono la fase dei LFO; la fase iniziale è rappresentata anche a riposo. Le forme con fase 00 e 80 risultano in controfase.

La preview ha precedenza sulla voce della sequenza solo nella visualizzazione. Il rendering usa il buffer originale di 240×10 pixel, senza aggiungere un framebuffer intero. Passando alla pagina principale viene invalidata la cache di testo, evitando residui dei grafici.

## Secondo ADSR per il cutoff

Nel riquadro CUT ENV:

- ENABLE / CUT ENV ON: 01 per attivare, 00 per disattivare.
- ATTACK, DECAY, SUSTAIN, RELEASE: indipendenti dall'ADSR di ampiezza.
- DEPTH: −128…+127, decimale con segno nell'editor e nel riquadro. Positivo apre il filtro, negativo lo chiude; zero non modifica il cutoff. Nel progetto binario il valore neutro è 80 esadecimale.

Vale per synth e sample. La modulazione viene sommata al cutoff di base e ai due LFO, poi limitata a 00–FF. Per un movimento evidente prova un cutoff di base medio/basso, tipo filtro LP, profondità +60 e sustain diverso da zero. Per ascoltare il rilascio del filtro, il rilascio dell'ampiezza deve lasciare viva la voce abbastanza a lungo. I sample continuano a terminare alla fine del file: questa modifica non aggiunge il looping.

## Riverbero Ambient

ROOM conserva il precedente algoritmo. AMBIENT usa una rete di feedback a otto linee con matrice Householder, lunghezze differenti e quattro diffusori allpass in ingresso per canale. La matrice distribuisce l'energia fra le linee; damping e guadagno di feedback restano inferiori all'unità. L'uscita stereo usa combinazioni differenti delle linee. Il passaggio ROOM/AMBIENT avviene con una breve dissolvenza.

Il bus wet resta a 8 kHz e quello dry a 32 kHz. L'aggiunta richiede circa 37 KiB di stato DSP. I buffer vengono invalidati senza azzerare decine di KiB nell'interrupt audio. Nel test a impulso, tra 1 e 2 secondi il nuovo algoritmo produce campioni non nulli in 7994 casi su 8000, contro 5048 del ROOM; nel tratto 3–6 secondi conserva una coda misurabile dopo il decadimento del ROOM. Questi dati descrivono il test specifico, non un tempo di riverbero garantito per ogni impostazione.

## Compatibilità e verifiche

I progetti precedenti con 32 campi Instrument vengono importati mantenendo i parametri esistenti; Cutoff ENV viene inizializzato disattivato con profondità zero e il riverbero rimane ROOM. Il nuovo formato aggiunge i dati in coda, senza cambiare la disposizione degli strumenti precedenti. Dopo un'esportazione aggiornata occorre questa versione per riaprire tutti i parametri.

Test con ASan/UBSan: stati e release del secondo ADSR su synth/PCM, profondità positiva/negativa, densità e coda Ambient, limiti stereo, reset, navigazione e ridisegno del display. Test C/WASM: 38 parametri Instrument, 9 Master FX, validazione, salvataggio e migrazione dei progetti precedenti. Verificati anche i grafici e i controlli attraverso il browser. I 65 file ufficiali SDK sono invariati.

Compilati sul Mac i moduli PI32v2 aggiornati. Link completo, pacchetto installabile e misure di CPU/RAM sul FM-1 fisico restano da completare; `sizeof(Tracker)` nel test host è 251696 byte, non il consumo totale del firmware.
