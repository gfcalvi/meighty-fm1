# Meighty — Berlin School, campioni e pannello synth

Apri **FM1-M8-Berlin-INTERACTIVE.fwsc** in FM-1 Emulator:
https://joakimeriksson.github.io/fm1-emu/?fw=local&mhz=240

1. **Open .fwsc…** → scegli il file → **Start**, clock **240 MHz**.
2. La song **Dusk Relay** è già in RAM. **PLAY** (barra spaziatrice) avvia/ferma.
3. **LFO / Instrument** (tasto **4** del computer) apre il pannello synth; premilo ancora per inviluppi e LFO. **K1** sceglie il parametro, **K2** cambia il valore, **K3** cambia strumento. Nell’emulatore trascina o scorri sui rotativi.
4. **HOME** (7) apre Mixer; **SEQ** (0) Master FX; **GLO** (6) Global. In Song **OCT−/OCT+** attivano mute/solo della traccia selezionata.
5. **ARP** (9) in Instrument apre i preset: K1 seleziona, REC carica nello strumento corrente. Gli ultimi otto sono i campioni CR-78 e MiniPops.
6. **SAVE** (8) scrive lo slot scelto in Global. Per richiamarlo: Global → LOAD PROJECT → REC. All’avvio questa build prepara Dusk Relay; il caricamento di uno slot è esplicito. Usa anche Export dell’emulatore per conservare un `.fm1save` con firmware e flash.

## Song

**Dusk Relay**: originale, 108 BPM, Re minore, 16 battute, circa 35,6 secondi e ripetizione. Entrate progressive: basso e pad dalla prima battuta, arpeggio dalla terza, kick dalla quinta, lead e hi-hat dalla settima, snare dalla nona, effetti MiniPops dalla tredicesima. Le ultime quattro battute usano tutte le otto tracce. Quattro sezioni di Phrase, variazioni melodiche e cutoff, delay ping-pong e riverbero Ambient con mandate differenziate.

| Traccia | Suono |
|---|---|
| 1 | Dusk Bass — synth SAW |
| 2 | Clockwork Arp — synth SAW |
| 3 | Glass Echo — BR FM |
| 4 | Horizon Pad — PULSE |
| 5 | CR-78 Kick |
| 6 | MiniPops45 Snare |
| 7 | CR-78 Open Hat |
| 8 | MiniPops45 FX3 |

`FM1-M8-Berlin-School.wav` è il rendering stereo completo del motore C/WASM. Il JSON `FM1-M8-Berlin-School.fm1tracker.json` si importa nel Workbench, da Global → Importa progetto; non è un `.fm1save` dell’emulatore.

## Campioni

Sono gli **otto WAV già preparati per Evolver**, ricampionati per il lettore del tracker a PCM16 mono / 22050 Hz. Radice C4, MIDI 60. Non sono nuove registrazioni: conservano il carattere e i limiti del banco compatto di partenza. MiniPops **45**, come identificato nel catalogo originale.

Slot: 00 CR78 Kick; 01 CR78 Snare; 02 CR78 OpenHat; 03 CR78 Tom; 04 MP45 Snare; 05 MP45 OpenHat; 06 MP45 FX3; 07 MP45 FX4. Tutti incorporati nel `.fwsc` e nel Workbench; non serve importarli a parte. Preset totali: **38**. I vecchi progetti conservano gli indici campione 0–7, che ora identificano questo banco al posto del precedente rumore dimostrativo.

WAV originali, provenienza e mappa sono in `fm1-tracker/assets/rhythm-bank/`. Provenienza CC0 conservata dal banco Evolver.

## Display e controlli

Il pannello principale Instrument viene disegnato dal C sul display **240×240**, anche nel firmware PI32v2: manopole con indicatori, valori e cursori orizzontali. Il parametro selezionato è evidenziato; inviluppi e LFO restano sulla seconda pagina grafica. TIMBRE/COLOR sono i controlli dei modelli Braids; nei modelli semplici SAW/PULSE/SINE/CHIP/NOISE non hanno la stessa funzione. ATTACK/DECAY della pagina principale sono i parametri legacy: con ADSR attivo si regolano gli inviluppi dalla seconda pagina.

## Stato della build

È un **vero pacchetto eseguibile PI32v2 `.fwsc`**, compilato sul Mac, collegato e avviato dal batch runner di FM-1 Emulator. Non è HTML rinominato. Sequencer, DSP, sample bank e disegno LCD sono gli stessi sorgenti C del Workbench. Il target dell’emulatore aggiunge un adattatore per avvio, audio, pannello, LCD e flash usando l’HAL già impiegato per Evolver. Gli header del framework FM1 Open restano l’interfaccia del tracker; i 65 file SDK ufficiali sono inalterati.

Questa build dedicata all’emulatore **non è una build hardware qualificata del runtime completo M-Wave**: USB, Bluetooth e ingresso MIDI esterno non sono integrati nell’adattatore. Il potenziometro MASTER fisico non è collegato; usa MASTER LEVEL nella pagina FX. Nessun dispositivo è stato flashato.

Verificati: tutti i test C con AddressSanitizer/UBSan; riproduzione dell’intera song e ingresso di tutte le otto tracce; audizione di tutti gli otto campioni; 38 preset; C/WASM e AudioWorklet; avvio del `.fwsc`, input Instrument/K1/K2/PLAY/HOME, audio, colori LCD e salvataggio Global nel batch runner. La prova nativa breve misura l’inizio del brano, non certifica ogni combinazione a otto voci. Il caricamento automatico nell’emulatore web Chrome è stato impedito dal permesso file dell’estensione: la verifica del pacchetto è stata eseguita nel runner nativo.

Sorgenti: `FM1-Tracker-A03-sorgenti.zip`. Build: `python3 tools/Build-Emulator-Mac.py`; usa la toolchain JieLi Linux attraverso il runner Blink già presente su questo Mac. Percorsi alternativi tramite `FM1_JIELI_TOOLCHAIN` e `FM1_JIELI_RUNNER`. Gli asset di packaging e il wrapper sono inclusi sotto `emulator/`; il loader precompilato è quello già usato per Evolver, con sorgenti e avvisi conservati. La toolchain e Blink restano dipendenze esterne.
