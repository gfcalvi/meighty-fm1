# Tracker development build. Keep the vendor SDK and all its integrity checks intact.
[CmdletBinding()]
param([string]$Toolchain=$env:FM1_PI32_TOOLCHAIN)
$ErrorActionPreference='Stop'
& "$PSScriptRoot/sdk/Build.ps1" -FirmwareOnly -Toolchain $Toolchain
$elf=Join-Path $PSScriptRoot 'build/dx7/sdk.elf'
$nm=Join-Path $Toolchain 'bin/llvm-nm.exe'
$symbols=& $nm --print-size $elf
if($LASTEXITCODE -ne 0){throw 'Cannot inspect tracker ELF'}
$required=@('tr_sample','tr_tick','tr_transport','tracker_device_render','increments','wavetable','drum')
$seen=@{}
foreach($line in $symbols){
 if($line -cmatch '^([0-9a-fA-F]+)\s+(?:[0-9a-fA-F]+\s+)?([A-Za-z])\s+(\S+)'){
  $address=[Convert]::ToInt64($Matches[1],16);$name=$Matches[3]
  if($required -contains $name -or $name -cmatch '^(tr_table_start|tr_random|tr_chance|tr_random_value|tr_next_phrase|tr_apply|tr_commands|tr_row|tr_sample|tr_tick|tr_transport|tr_set_sample|bounded|pitch|fire|cell|voice_sample)(\.|$)'){
   if($address -lt 0x01c00000 -or $address -ge 0x01c80000){throw "Tracker audio dependency outside internal SRAM: $name"}
   $seen[$name]=$true
  }
 }
}
foreach($name in $required){if(!$seen.ContainsKey($name)){throw "Missing tracker audio symbol: $name"}}
Write-Host 'Vendor build checks and tracker SRAM checks passed. Hardware timing and recovery checks are still required.'
