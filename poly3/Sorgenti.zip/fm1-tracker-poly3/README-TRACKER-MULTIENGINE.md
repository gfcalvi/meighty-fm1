# Meighty MultiEngine

Tracker extension in app/tracker, web/tracker and emulator. The original upstream README below describes the base app; this tracker has separate engines and project format.

Current build: 8 mono tracks, 18 synth models in BASIC/BRAIDS/FM4/DUAL WT families, SAMPLE with 33 real percussion recordings, 32 Instrument slots and 77 presets. Shared amp/cutoff ADSRs, dual LFO with independent bipolar POS1/POS2 sends for wavetable, master delay/ambient reverb and per-track sends. Four-operator FM: 8 algorithms, four independent ADSRs, ratios/levels/feedback. Dual wavetable: two independent banks, morph positions, interval, detune, mix and hard sync.

Instrument K1 parameter, K2 value, K3 slot, K4 preset browser, REC applies. Same Instrument button cycles Sound → Modulations → Engine (third page on FM4/DUAL). Global K3 load selected slot, K4 save; SAVE button also saves. Firmware boots the new eight-track mixed-engine demo. Workbench Global also offers Berlin School and the drum kit.

Append-only project format: 11940 bytes; reads 10788- and 11812-byte previous projects and transactional flash records, with engine defaults and disabled new modulation routes. Old model IDs 00–07 and FX IDs 00–2A are unchanged; new models are 08–11 and FX 2B–38. A new-format project does not load in older firmware. See the supplied Italian guide and manual.

Build: tools/Build-Tracker-Web.py --wasi-sdk PATH; tools/Build-Emulator-Mac.py uses the configured local JieLi compiler runner. No Windows required in this workspace. sh tests/run.sh; Node tests/test_workbench.cjs; python3 tests/verify_sdk.py. FM1_STRESS_ENGINE=16 or 17 builds a separate eight-voice benchmark artifact under build/emulator-stressN. PCM regeneration: tools/Generate-Rhythm-Bank.py. MultiEngine oscillator/table generation: tools/Generate-MultiEngine-Tables.py. Export demo after WASM build: tools/Export-MultiEngine.cjs.

Firmware is qualified for FM1 Emulator only, at 240 MHz; physical hardware has not been tested. Braids adaptations are not a complete/bit-identical port. FM4 routing source and GPL notice: third_party/fm4; Braids source references and MIT notice: third_party/braids. Wavetables are original generated harmonic banks. Full native benchmark results are supplied separately.
