/* Bounded integer/string formatter for the freestanding PI32v2 target. */
#include <stdarg.h>
#include <stddef.h>
#include <stdint.h>
static void emit(char *out,size_t cap,size_t *at,char c){if(*at+1<cap)out[*at]=c;(*at)++;}
int snprintf(char *out,size_t cap,const char *fmt,...){
 va_list ap;va_start(ap,fmt);size_t at=0;
 while(*fmt){
  if(*fmt!='%'){emit(out,cap,&at,*fmt++);continue;}
  fmt++;int left=0,plus=0,zero=0,width=0,precision=-1;
  while(*fmt=='-'||*fmt=='+'||*fmt=='0'){if(*fmt=='-')left=1;if(*fmt=='+')plus=1;if(*fmt=='0')zero=1;fmt++;}
  while(*fmt>='0'&&*fmt<='9')width=width*10+*fmt++-'0';
  if(*fmt=='.'){fmt++;precision=0;while(*fmt>='0'&&*fmt<='9')precision=precision*10+*fmt++-'0';}
  if(!*fmt)break;char kind=*fmt++;char buf[40];const char *s=buf;unsigned len=0;
  if(kind=='s'){s=va_arg(ap,const char*);if(!s)s="";while(s[len]&&(precision<0||(int)len<precision))len++;}
  else if(kind=='c')buf[len++]=(char)va_arg(ap,int);
  else if(kind=='%')buf[len++]='%';
  else if(kind=='u'||kind=='d'||kind=='X'||kind=='x'){
   uint32_t val=kind=='d'?(uint32_t)va_arg(ap,int):va_arg(ap,unsigned);int neg=kind=='d'&&(int32_t)val<0;if(neg)val=0-val;
   char tmp[16];unsigned n=0,base=kind=='X'||kind=='x'?16:10;
   do{unsigned d=val%base;tmp[n++]=(char)(d<10?'0'+d:(kind=='X'?'A':'a')+d-10);val/=base;}while(val);
   if(neg||plus)buf[len++]=neg?'-':'+';
   if(zero&&!left){while((int)(len+n)<width&&len<30)buf[len++]='0';}
   while(n)buf[len++]=tmp[--n];
  }else{emit(out,cap,&at,'%');emit(out,cap,&at,kind);continue;}
  if(!left)for(int k=(int)len;k<width;k++)emit(out,cap,&at,' ');
  for(unsigned k=0;k<len;k++)emit(out,cap,&at,s[k]);
  if(left)for(int k=(int)len;k<width;k++)emit(out,cap,&at,' ');
 }
 va_end(ap);if(cap)out[at<cap?at:cap-1]=0;return(int)at;
}
int groove_master_update(unsigned adc){(void)adc;return 0;}
