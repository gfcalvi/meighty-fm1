# Emulator adapter

See ../../FM1-M8-Berlin-LEGGIMI.md for controls, architecture and limits.

HAL, linker and startup: pinned local Evolver RC1 sources, originally Felucca / Optimist, Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments, GPL-3.0-only. The copied source files retain their SPDX/copyright notices. The formatter and FM1 API adapter are new for this target. SDK/SPL packaging assets retain their original provenance from the Evolver build. Package wrapper fm1pkg_make.py is GPL-3.0-only. Loader source under loader/ is supplied for the reused precompiled ota.bin. See package-assets/SHA256.json. No replacement of the immutable official SDK files.
