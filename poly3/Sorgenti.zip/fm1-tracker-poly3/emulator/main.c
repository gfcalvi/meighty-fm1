/* GPL-3.0-only. Emulator target adapter; tracker uses the published FM1 API. */
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "fm1_cc.h"
#include "fm1_time.h"
#include "fm1_irq.h"
#include "fm1_sys.h"
#include "fm1_gpio.h"
#include "fm1_timer.h"
#include "fm1_lcd_hw.h"
#include "fm1_audio.h"
#include "fm1_input.h"
#ifdef FM1_CPU1
#include "../hardware/cpu2/fm1_cpu1.h"
#endif
#ifdef FM1_HARDWARE
#include "fm1_adc.h"
#include "../hardware/flash_policy.h"
#include "../hardware/audio_math.h"
#endif
#define FL_ERASE_ONE_WINDOW 1
#ifdef FM1_HARDWARE
#define FL_RANGE_OK(off,n) (FL_IN(off,n,0x97000u,0xe0000u)||FL_IN(off,n,0xe0000u,0xe5000u))
#else
#define FL_RANGE_OK(off,n) ((uint32_t)(off)>=0x95000u&&(uint32_t)(off)<=0xe7000u&&(uint32_t)(n)<=0xe7000u-(uint32_t)(off))
#endif
#include "fm1_flash.h"
#include "tracker.h"
#include "ui.h"
#include "fm1_device.h"
static int32_t abuf[512];
volatile uint32_t emu_blocks,emu_frames,emu_max_ticks,emu_misses,emu_fault,emu_max_voices;
static uint32_t tr_audio_cost_peak[5];
static uint32_t tr_math_bench[4];
#if defined(FM1_AUDIO_DIAG_VERSION) && FM1_AUDIO_DIAG_VERSION >= 28
#include "../hardware/audio_schedule.h"
static TrAudioSchedule tr_schedule;
void tr_diag_audio_running(unsigned active){tr_schedule_running(&tr_schedule,active);}
#endif

#ifdef FM1_AUDIO_DIAGNOSTICS
static volatile uint32_t tr_audio_late;
#endif
#ifdef FM1_AUDIO_PROFILE
#include "fm1_clock.h"
volatile unsigned tr_profile_active;
uint32_t tr_profile_ticks[12];
volatile uint32_t tr_profile_peak[12],tr_profile_total,tr_profile_count,tr_profile_late;
volatile uint32_t tr_profile_cpu_khz,tr_profile_clock[3],tr_timer5_sum,tr_timer5_max,tr_profile_nested;
static void tr_profile_screen(void){char b[11][40];const char *lines[11];uint32_t v[12],total,count,nested;unsigned irq=fm1_device_irq_save();for(unsigned i=0;i<12;i++)v[i]=tr_profile_peak[i];total=tr_profile_total;count=tr_profile_count;nested=tr_profile_nested;fm1_device_irq_restore(irq);
 snprintf(b[0],40,"NORMAL MAX %u LATE %u",(unsigned)(emu_max_ticks/24),(unsigned)tr_audio_late);
 snprintf(b[1],40,"PROBE %uus N%u L%u",(unsigned)(total/24),(unsigned)count,(unsigned)tr_profile_late);
 for(unsigned j=0;j<4;j++)snprintf(b[2+j],40,"T%u %uus   T%u %uus",j*2+1,(unsigned)(v[j*2]/24),j*2+2,(unsigned)(v[j*2+1]/24));
 snprintf(b[6],40,"SYN %uus FIL %uus",(unsigned)(v[10]/24),(unsigned)(v[11]/24));
 snprintf(b[7],40,"MOD %uus FX %uus",(unsigned)(v[9]/24),(unsigned)(v[8]/24));
 uint32_t used=v[8];for(unsigned j=0;j<8;j++)used+=v[j];snprintf(b[8],40,"REST %uus IRQ %uus",(unsigned)(total>used?(total-used)/24:0),(unsigned)(nested/24));
 snprintf(b[9],40,"CPU~%uMHz SRC %02X",(unsigned)(tr_profile_cpu_khz/1000),(unsigned)(tr_profile_clock[0]&255));
 snprintf(b[10],40,"DIV %08X T5MAX %uus",(unsigned)tr_profile_clock[1],(unsigned)(tr_timer5_max/24));
 for(unsigned j=0;j<11;j++)lines[j]=b[j];tracker_ui_diagnostic(lines,11);
}
#endif
#ifdef FM1_AUDIO_DIAGNOSTICS

#endif
static uint16_t fb[240*240] __attribute__((section(".pool")));
static volatile uint32_t ms;
#ifdef FM1_HARDWARE
static unsigned tr_flash_ok;
static volatile unsigned tr_master_gain;
static int tr_master_filtered;
static void tr_master_poll(int immediate){int a=fm1_adc_read(FM1_ADC_MASTER);if(a<0)return;if(immediate)tr_master_filtered=a*8;else tr_master_filtered+=a-tr_master_filtered/8;unsigned value=(unsigned)tr_master_filtered/8;tr_master_gain=value*value/256;}
#endif
#ifdef FM1_HARDWARE
static void tr_usb_tick(void);
#endif
/* Use copied RAM entries for every initialisation/restart path below. */
void isr_timer5_ram(void);void isr_alnk0_ram(void);
#define isr_timer5 isr_timer5_ram
#define isr_alnk0 isr_alnk0_ram
static void fm1_fault(const fm1_crash_t *c){
#ifdef FM1_CPU1
fm1_cpu1_stop();
#endif
emu_fault=c->pc;for(;;)fm1_idle();}
uint32_t fm1_device_irq_save(void){uint32_t s;__asm__ volatile("%0 = icfg\ncli":"=r"(s)::"memory");
#if defined(FM1_AUDIO_DIAG_VERSION) && FM1_AUDIO_DIAG_VERSION >= 28
if(s&0x200)tr_schedule.mask_start=fm1_ticks();
#endif
return s;}
void fm1_device_irq_restore(uint32_t s){if(s&0x200){
#if defined(FM1_AUDIO_DIAG_VERSION) && FM1_AUDIO_DIAG_VERSION >= 28
tr_schedule_mask_end(&tr_schedule,fm1_ticks());
#endif
__asm__ volatile("sti":::"memory");}}
uint32_t fm1_millis(void){return ms;}
void fm1_controls_read(struct fm1_controls *c){unsigned s=fm1_device_irq_save();memset(c,0,sizeof *c);c->keys=fm1_in.notes;c->buttons=fm1_in.buttons;for(unsigned i=0;i<7;i++){c->encoders[i]=fm1_in.enc_steps[i];fm1_in.enc_steps[i]=0;}fm1_device_irq_restore(s);
#ifdef FM1_HARDWARE
tr_master_poll(0);c->knob=(unsigned)tr_master_filtered/8;
#endif
}
void fm1_screen_fill(unsigned x,unsigned y,unsigned w,unsigned h,uint16_t col){for(unsigned a=y;a<y+h;a++)for(unsigned b=x;b<x+w;b++)fb[a*240+b]=(uint16_t)((col>>8)|(col<<8));}
int fm1_screen_blit(unsigned x,unsigned y,unsigned w,unsigned h,const uint16_t *p,size_t count){if(x+w>240||y+h>240||count<w*h)return -1;for(unsigned a=0;a<h;a++)for(unsigned b=0;b<w;b++){uint16_t v=p[a*w+b];fb[(y+a)*240+x+b]=(uint16_t)((v>>8)|(v<<8));}return 0;}
/* Dedicated user partition; transactional store refuses foreign sectors. */
#ifdef FM1_HARDWARE
#define TR_FLASH_BYTES 0x49000u
#define TR_FLASH_BASE 0x97000u
#else
#define TR_FLASH_BYTES 0x52000u
#define TR_FLASH_BASE 0x95000u
#endif
uint32_t fm1_flash_size(void){
#ifdef FM1_HARDWARE
if(!tr_flash_ok)return 0;
#endif
return TR_FLASH_BYTES;}
int fm1_flash_read(uint32_t a,void *p,size_t n){if(a>TR_FLASH_BYTES||n>TR_FLASH_BYTES-a)return -1;memcpy(p,(const void*)FL_XIP(TR_FLASH_BASE+a),n);return 0;}
int fm1_flash_write(uint32_t a,const void *p,size_t n){if(a>TR_FLASH_BYTES||n>TR_FLASH_BYTES-a)return -1;return fl_write(TR_FLASH_BASE+a,p,n);}
int fm1_flash_erase(uint32_t a){if((a&4095)||a>=TR_FLASH_BYTES)return -1;uint32_t took;return fl_erase4k(TR_FLASH_BASE+a,&took);}
void __attribute__((section(".ram_hot2"),noinline)) fm1_timer5_irq(void){static uint32_t last,acc;
#if defined(FM1_AUDIO_DIAG_VERSION) && FM1_AUDIO_DIAG_VERSION >= 28
uint32_t schedule_begin=fm1_ticks();
#endif

#ifdef FM1_AUDIO_PROFILE
uint32_t timer_begin=fm1_ticks();
#endif
fm1_timer5_ack();fm1_input_tick();
#ifdef FM1_HARDWARE
tr_usb_tick();
#endif
uint32_t now=fm1_ticks();acc+=now-last;last=now;while(acc>=24000){acc-=24000;ms++;}
#if defined(FM1_AUDIO_DIAG_VERSION) && FM1_AUDIO_DIAG_VERSION >= 28
tr_schedule_timer_end(&tr_schedule,schedule_begin,fm1_ticks());
#endif

#ifdef FM1_AUDIO_PROFILE
uint32_t timer_took=fm1_ticks()-timer_begin;tr_timer5_sum+=timer_took;if(timer_took>tr_timer5_max)tr_timer5_max=timer_took;
#endif
}
FM1_AUDIO_CODE void fm1_alnk0_irq(void){uint8_t p=fm1_audio_pending();fm1_audio_ack_aux(p);if(p&FM1_AUDIO_HALF){uint32_t begin=fm1_ticks();unsigned half=fm1_audio_free_half();int32_t *out=abuf+half*256;
#if defined(FM1_AUDIO_DIAG_VERSION) && FM1_AUDIO_DIAG_VERSION >= 28
tr_schedule_entry(&tr_schedule,begin);
#endif

#ifdef FM1_AUDIO_PROFILE
uint32_t nested_begin=tr_timer5_sum;tr_profile_active=tracker_ui_state(6)&&!(emu_blocks&63U);if(tr_profile_active)memset(tr_profile_ticks,0,sizeof tr_profile_ticks);
#endif
tracker_device_render(out,128);
#ifdef FM1_AUDIO_PROFILE
if(tr_profile_active){uint32_t total=fm1_ticks()-begin;++tr_profile_count;if(total>tr_profile_total){tr_profile_total=total;tr_profile_nested=tr_timer5_sum-nested_begin;for(unsigned j=0;j<12;j++)tr_profile_peak[j]=tr_profile_ticks[j];}}
#endif
#ifdef FM1_HARDWARE
unsigned gain=tr_master_gain;for(unsigned i=0;i<256;i++)out[i]=tr_hw_output_gain(out[i],gain);
#endif
fm1_audio_sync();fm1_audio_ack_half();
#ifdef FM1_AUDIO_DIAGNOSTICS
if(fm1_audio_free_half()!=half){
#ifdef FM1_AUDIO_PROFILE
if(tr_profile_active)tr_profile_late++;else
#endif
tr_audio_late++;
#if defined(FM1_AUDIO_DIAG_VERSION) && FM1_AUDIO_DIAG_VERSION >= 28
tr_schedule_late(&tr_schedule,fm1_ticks()-begin);
#endif
}
#endif
unsigned active=tracker_device_active_voices();if(active>emu_max_voices)emu_max_voices=active;uint32_t d=fm1_ticks()-begin;
#ifdef FM1_AUDIO_PROFILE
if(!tr_profile_active){
#endif
if(d>emu_max_ticks){emu_max_ticks=d;tracker_device_audio_cost(tr_audio_cost_peak);}if(d>69632)emu_misses++;
#ifdef FM1_AUDIO_PROFILE
}tr_profile_active=0;
#endif
emu_blocks++;}}
static void lcd_cmd(uint8_t c,const uint8_t *d,unsigned n){static uint8_t b[8];fm1_lcd_send_cmd(c);fm1_lcd_wait();if(n){memcpy(b,d,n);fm1_lcd_send_data(b,n);fm1_lcd_wait();}fm1_lcd_deselect();}
static void lcd_init(void){static const uint8_t pix=0x55,mad=0;fm1_lcd_hw_init();fm1_delay_ms(80);lcd_cmd(1,0,0);fm1_delay_ms(150);lcd_cmd(0x11,0,0);fm1_delay_ms(120);lcd_cmd(0x3a,&pix,1);lcd_cmd(0x36,&mad,1);lcd_cmd(0x21,0,0);lcd_cmd(0x13,0,0);fm1_lcd_baud(4);lcd_cmd(0x29,0,0);}
static void lcd_frame(void){static const uint8_t win[]={0,0,0,239};lcd_cmd(0x2a,win,4);lcd_cmd(0x2b,win,4);fm1_lcd_send_cmd(0x2c);fm1_lcd_wait();for(unsigned y=0;y<240;y+=24){fm1_lcd_send_data(fb+y*240,11520);fm1_lcd_wait();}fm1_lcd_deselect();emu_frames++;}
static void tr_panel_lights(void){
 unsigned mask=tracker_ui_button_lights()|fm1_in.buttons;
 for(unsigned id=0;id<14;id++)fm1_led_key(id,(mask>>id)&1U);
 /* PLAY has a second, green LED at the unkeyed column 8 / row PA5. */
 fm1_led_key(12,!!(fm1_in.buttons&(1U<<12)));
 if(mask&(1U<<12))fm1_led[8]|=1U<<1;else fm1_led[8]&=(uint8_t)~(1U<<1);
}
#ifdef FM1_HARDWARE
#include "../hardware/transport.inc"
#ifdef FM1_CPU1
#include "../hardware/cpu2_adapter.inc"
#endif
#endif
void fm1_cstart(void){extern uint32_t _bss_start[],_bss_end[],_data_start[],_data_end[],_data_load[],_pz_start[],_pool_end[],_rt_start[],_rt_end[],_rt_load[],_rh_start[],_rh_end[],_rh_load[],_rh2_start[],_rh2_end[],_rh2_load[];uint32_t *w;
#ifdef FM1_CPU1
 fm1_cpu1_stop(); /* Before clearing any shared RAM, including after watchdog reset. */
#endif
 fm1_time_init();fm1_wdt_arm(15);fm1_irq_init();for(w=_bss_start;w<_bss_end;w++)*w=0;for(w=_data_start;w<_data_end;w++)*w=_data_load[w-_data_start];for(w=_pz_start;w<_pool_end;w++)*w=0;for(w=_rt_start;w<_rt_end;w++)*w=_rt_load[w-_rt_start];
 /* The IRQ entries already have a RAM section in the BSP. Copy it too:
  * attaching the RAM vectors before this copy would execute uninitialised RAM. */
 for(w=_rh_start;w<_rh_end;w++)*w=_rh_load[w-_rh_start];
 /* Copy secondary code, including TIMER5, before CPU1 or interrupts start. */
 for(w=_rh2_start;w<_rh2_end;w++)*w=_rh2_load[w-_rh2_start];
 __asm__ volatile("csync" ::: "memory");
#if defined(FM1_HARDWARE) && (!defined(FM1_AUDIO_DIAG_VERSION) || FM1_AUDIO_DIAG_VERSION < 28)
 tr_benchmark_arithmetic(fm1_ticks,tr_math_bench);
#endif
 fl_plain_window_init();
#ifdef FM1_HARDWARE
tr_flash_ok=tr_flash_jedec_known(fl_jedec_ram());
#endif
tracker_device_init();tracker_ui_demo(4);tracker_ui_project_restore();
#ifdef FM1_STRESS_ENGINE
 static TrProject stress;stress=*tracker_ui_project();for(unsigned c=0;c<8;c++){stress.instrument_source[c]=1;stress.instruments[c].model=FM1_STRESS_ENGINE;stress.sound[c][0]=1;stress.sound[c][1]=0;stress.sound[c][2]=255;stress.sound[c][3]=255;stress.sound[c][4]=255;stress.sound[c][9]=stress.sound[c][16]=170;stress.sound[c][12]=stress.sound[c][19]=145;stress.sound[c][14]=stress.sound[c][21]=145;if(FM1_STRESS_ENGINE==17){stress.wt_lfo[c][0]=192;stress.wt_lfo[c][1]=64;stress.wt_lfo[c][2]=160;stress.wt_lfo[c][3]=192;}stress.phrases[c].step[0].note=60;stress.phrases[c].step[0].instrument=c;stress.chains[c].length=1;stress.chains[c].phrase[0]=c;stress.song[0][c]=c;}stress.song_length=1;stress.reverb_mode=1;tracker_ui_project_apply(&stress);
#endif
 lcd_init();fm1_input_init();
#ifdef FM1_HARDWARE
tracker_device_audio_clock(fm1_ticks);
#endif
#ifdef FM1_AUDIO_PROFILE
tr_profile_cpu_khz=fm1_cpu_khz();tr_profile_clock[0]=fm1_clk_reg(3);tr_profile_clock[1]=fm1_clk_reg(0);tr_profile_clock[2]=fm1_clk_reg(7);
#endif
#ifdef FM1_HARDWARE
fm1_adc_init();tr_master_poll(1);tr_master_poll(1);tr_usb_start();
#ifdef FM1_CPU1
tr_cpu2_start();
#endif
#endif
fm1_timer5_start(isr_timer5,4);fm1_irq_enable_all();
#ifdef FM1_HARDWARE
if(!tr_recovery)
#endif
fm1_audio_init(abuf,256,isr_alnk0,3);unsigned last=0;for(;;){fm1_wdt_feed();if(ms-last>=50){last=ms;
#ifdef FM1_HARDWARE
if(!tr_recovery)
#endif
{
#ifdef FM1_AUDIO_DIAGNOSTICS
if(tracker_device_diagnostic_buttons(fm1_in.buttons)){
#ifdef FM1_AUDIO_PROFILE
tr_profile_screen();
#else
char diag[28];snprintf(diag,sizeof diag,"MAX %uus LATE %u",(unsigned)(emu_max_ticks/24u),(unsigned)tr_audio_late);
#ifdef FM1_CPU1
tracker_ui_notice(fm1_cpu1_on?"MEIGHTY 2 CORE":"MEIGHTY CPU2 OFF",diag);
#elif defined(FM1_AUDIO_DIAG_VERSION) && FM1_AUDIO_DIAG_VERSION == 7
tracker_ui_notice("HW7 AUDIO / 2902us",diag);
#elif defined(FM1_AUDIO_DIAG_VERSION) && FM1_AUDIO_DIAG_VERSION == 6
tracker_ui_notice("HW6 AUDIO / 2902us",diag);
#elif defined(FM1_AUDIO_DIAG_VERSION) && FM1_AUDIO_DIAG_VERSION == 4
tracker_ui_notice("HW4 AUDIO / 2902us",diag);
#elif defined(FM1_AUDIO_DIAG_VERSION) && FM1_AUDIO_DIAG_VERSION == 3
tracker_ui_notice("HW3 AUDIO / 2902us",diag);
#else
tracker_ui_notice("HW2 AUDIO / 2902us",diag);
#endif
#endif
}else
#endif
tracker_device_control();tr_panel_lights();lcd_frame();}}
#ifdef FM1_HARDWARE
tr_usb_service();
#endif
fm1_idle();}}
