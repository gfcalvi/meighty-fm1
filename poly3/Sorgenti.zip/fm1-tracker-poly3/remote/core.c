/* SPDX-License-Identifier: GPL-3.0-only
 * FM1 M8 native tracker adapter for RemoteFM1's RFM1 v1 / fm1core ABI 6.
 * No hardware SDK libraries, browser simulation engine or device OTA are linked. */
#include "vendor/fm1core.h"
#include "tracker/tracker.h"
#include "tracker/ui.h"
#include "fm1_device.h"
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "build_info.h"
#define API(n) __attribute__((export_name("rfm1_" #n)))
/* Bounded host allocator: fixed linear memory, no memory.grow. */
static _Alignas(16) uint8_t heap[2*1024*1024];static size_t heap_used;
void *malloc(size_t n){if(n>sizeof heap-16)return NULL;size_t total=(n+31)&~(size_t)15;if(total>sizeof heap-heap_used)return NULL;size_t *h=(size_t *)(heap+heap_used);h[0]=total;h[1]=n;heap_used+=total;return h+4;}
void free(void *p){if(!p)return;size_t *h=(size_t *)p-4;if((uint8_t *)h+h[0]==heap+heap_used)heap_used-=h[0];}
void *calloc(size_t n,size_t z){if(z&&n>SIZE_MAX/z)return NULL;void *p=malloc(n*z);if(p)memset(p,0,n*z);return p;}
void *realloc(void *p,size_t n){if(!p)return malloc(n);if(!n){free(p);return NULL;}size_t old=((size_t *)p)[-3];if(n<=old)return p;void *q=malloc(n);if(q)memcpy(q,p,old);return q;}
#define FLASH_BYTES 0x100000u
#define STORE_BASE 0x97000u
#define STORE_BYTES 0x49000u
static fm1panel_t panel;
static const int8_t keymap[6][11]={
 {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},{5,11,4,10,3,9,2,8,-1,-1,-1},
 {34,35,36,37,38,40,39,13,7,6,12},{23,24,25,26,27,28,29,30,31,32,33},
 {0,1,15,14,17,16,19,18,20,21,22},{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1}};
static uint8_t flash_image[FLASH_BYTES];
static struct fm1_controls input;
static unsigned now,dirty,booted,staged,gain=900;
static int midi_note=-1;
uint32_t fm1_millis(void){return now;}
uint32_t fm1_device_irq_save(void){return 0;}
void fm1_device_irq_restore(uint32_t s){(void)s;}
void fm1_controls_read(struct fm1_controls *c){*c=input;memset(input.encoders,0,sizeof input.encoders);}
int groove_master_update(unsigned adc){(void)adc;return 0;}
uint32_t fm1_flash_size(void){return STORE_BYTES;}
int fm1_flash_read(uint32_t at,void *p,size_t n){if(at>STORE_BYTES||n>STORE_BYTES-at)return -1;memcpy(p,flash_image+STORE_BASE+at,n);return 0;}
int fm1_flash_erase(uint32_t at){if(at%4096||at>STORE_BYTES-4096)return -1;memset(flash_image+STORE_BASE+at,255,4096);++dirty;return 0;}
int fm1_flash_write(uint32_t at,const void *data,size_t n){if(at>STORE_BYTES||n>STORE_BYTES-at)return -1;const uint8_t *p=data;uint8_t *d=flash_image+STORE_BASE+at;for(size_t i=0;i<n;i++)if((d[i]&p[i])!=p[i])return -1;memcpy(d,p,n);++dirty;return 0;}
static uint16_t be565(uint16_t c){return (c>>8)|(c<<8);}
void fm1_screen_fill(unsigned x,unsigned y,unsigned w,unsigned h,uint16_t color){if(x>240||y>240||w>240-x||h>240-y)return;for(unsigned r=0;r<h;r++)for(unsigned c=0;c<w;c++)panel.lcd[(y+r)*240+x+c]=be565(color);++panel.lcd_writes;}
int fm1_screen_blit(unsigned x,unsigned y,unsigned w,unsigned h,const uint16_t *p,size_t n){if(x>240||y>240||w>240-x||h>240-y||n<w*h)return -1;for(unsigned r=0;r<h;r++)for(unsigned c=0;c<w;c++)panel.lcd[(y+r)*240+x+c]=be565(p[r*w+c]);++panel.lcd_writes;return 0;}
API(version) unsigned rfm1_version(void){return 1;}
API(alloc) void *rfm1_alloc(unsigned n){return malloc(n);}
API(free) void rfm1_free(void *p){free(p);}
API(options) void rfm1_options(const char *p,int nf,int save,int headless){(void)p;(void)nf;(void)save;(void)headless;}
API(boot_options) int rfm1_boot_options(int f,const char *r,int s){(void)f;(void)r;(void)s;return 1;}
API(flash_stage) int rfm1_flash_stage(const uint8_t *p,unsigned n){if(n>FLASH_BYTES||(!p&&n))return 0;memset(flash_image,255,sizeof flash_image);if(n)memcpy(flash_image,p,n);staged=1;dirty=0;return 1;}
API(flash) uint8_t *rfm1_flash(void){return flash_image;}
API(flash_dirty) unsigned rfm1_flash_dirty(void){return dirty;}
API(flash_sync) int rfm1_flash_sync(void){return 1;}
API(init) void rfm1_init(int demo){(void)demo;if(!staged)rfm1_flash_stage(0,0);now=50;memset(&input,0,sizeof input);static const uint8_t btn[]={2,3,4,5,6,7,8,9,10,11,12,13,0,1},enc[]={0,1,6,2,3,4,5};memcpy(panel.btn_id,btn,sizeof btn);memcpy(panel.enc_id,enc,sizeof enc);for(unsigned i=0;i<7;i++)panel.enc_dir[i]=1;if(!panel.master)panel.master=900;gain=panel.master;tracker_device_init();tracker_ui_demo(4);tracker_ui_project_restore();booted=1;panel.ready=1;tracker_device_control();}
API(tick) void rfm1_tick(unsigned ms){if(!booted)return;now=ms+50;input.keys=panel.keys|panel.keys_tap;input.buttons=panel.buttons|panel.buttons_tap;panel.keys_tap=panel.buttons_tap=0;input.knob=panel.master<0?0:panel.master>1023?1023:panel.master;for(unsigned i=0;i<7;i++){int32_t v=panel.enc[i];input.encoders[i]=v<-127?-127:v>127?127:v;panel.enc[i]=0;}tracker_device_control();for(unsigned r=1;r<5;r++)for(unsigned c=0;c<11;c++){int id=keymap[r][c];panel.led[c][r-1]=id>=14?((input.keys&(1u<<(id-14)))?255:0):id>=0?((input.buttons&(1u<<id))?255:0):0;}panel.led_play_green=tracker_ui_state(6)?255:0;}
API(frame) void rfm1_frame(void){}
API(idle) void rfm1_idle(void){}
API(audio) void rfm1_audio(int16_t *out,unsigned frames){int32_t pcm[256];while(frames){unsigned n=frames>128?128:frames;if(booted)tracker_device_render(pcm,n);else memset(pcm,0,n*2*sizeof *pcm);unsigned target=panel.master<0?0:panel.master>1023?1023:panel.master;for(unsigned f=0;f<n;f++){if(gain<target)gain++;else if(gain>target)gain--;for(unsigned c=0;c<2;c++){int32_t v=(pcm[f*2+c]/256)*(int32_t)gain/1023;*out++=(int16_t)(v<-32768?-32768:v>32767?32767:v);}}frames-=n;}}
API(midi_in) int rfm1_midi_in(unsigned packet){uint8_t status=packet>>8,a=packet>>16,b=packet>>24;if(!booted)return 1;if((status&0xf0)==0x90&&b){midi_note=a;tracker_ui_audition(a);}else if(((status&0xf0)==0x80||((status&0xf0)==0x90&&!b))&&a==midi_note){tracker_ui_audition(-1);midi_note=-1;}else if((status&0xf0)==0xb0&&(a==120||a==123)){tracker_ui_audition(-1);midi_note=-1;}else if(status==0xfa||status==0xfb)tracker_ui_play(1);else if(status==0xfc)tracker_ui_play(0);return 1;}
API(midi_out_take) int rfm1_midi_out_take(unsigned *p){(void)p;return 0;}
API(halted) int rfm1_halted(void){return 0;}
API(shutdown) void rfm1_shutdown(void){tracker_ui_play(0);booted=0;}
API(stats) void rfm1_stats(unsigned *shed,unsigned *cpu){if(shed)*shed=0;if(cpu)*cpu=0;}
API(ui_info) void rfm1_ui_info(char *p,unsigned n){if(n)snprintf(p,n,"FM1 M8 %s | %s | SAVE SLOT before saving app state",M8_VERSION,tracker_ui_state(6)?"PLAY":"STOP");}
static const fm1core_t descriptor={.abi_version=6,.id="fm1_m8",.name="FM1 M8 Tracker",.version=M8_VERSION,.source_url=M8_SOURCE,.family="fm1_m8_tracker",.license="GPL-3.0-only",.flash_size=FLASH_BYTES,
 .button_names={"SONG","CHAIN","PHRASE","INST","TABLE","GLOBAL","MIXER","SAVE","PRESET","FX","PLAY","REC","MUTE / OCT-","SOLO / OCT+"},.panel=&panel,.keymap=&keymap[0][0],
 .options=rfm1_options,.boot_options=rfm1_boot_options,.init=rfm1_init,.tick=rfm1_tick,.frame=rfm1_frame,.idle=rfm1_idle,.audio=rfm1_audio,.midi_in=rfm1_midi_in,.midi_out_take=rfm1_midi_out_take,.stats=rfm1_stats,.ui_info=rfm1_ui_info,.shutdown=rfm1_shutdown,.halted=rfm1_halted,.flash_stage=rfm1_flash_stage,.flash=rfm1_flash,.flash_dirty=rfm1_flash_dirty,.flash_sync=rfm1_flash_sync,.credits=M8_CREDITS};
API(get) const fm1core_t *rfm1_get(unsigned abi){return abi==6?&descriptor:0;}
#define P(f) offsetof(fm1panel_t,f)
#define D(f) offsetof(fm1core_t,f)
API(layout) int rfm1_layout(unsigned i){static const int v[]={sizeof(fm1panel_t),P(keys),P(buttons),P(keys_tap),P(buttons_tap),P(enc),P(master),P(key_vel),P(key_lean),P(led),P(led_play_green),P(lcd),P(lcd_writes),P(btn_id),P(enc_id),P(enc_dir),P(ready),sizeof(fm1core_t),D(abi_version),D(id),D(name),D(version),D(source_url),D(family),D(license),D(gated),D(flash_size),D(button_names),D(params),D(nparams),D(panel),D(keymap),D(options),D(credits)};return i<sizeof v/sizeof v[0]?v[i]:-1;}
