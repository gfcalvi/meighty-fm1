# Meighty for RemoteFM1IOS

This is a separate host target: RFM1 format v1, fm1core ABI 6, fixed 8 MiB memory, 44.1 kHz stereo output. It compiles the existing tracker.c / commands.c / device.c, including the preset catalog, sample bank, engines and graphics, with remote/core.c as platform glue. It does not link proprietary hardware SDK archives and does not modify either physical firmware or emulator packages.

## Build and test

```sh
python3 tools/Build-RemoteFM1.py --wasi-sdk /path/to/wasi-sdk-27.0-arm64-macos
node tests/test_rfm1.cjs ../fm1_m8-deepblue-20261104.rfm1
```

The LLVM linker uses --compress-relocations: wasm3 0.5.0 rejects padded call_indirect table indices. The allocator uses a bounded local arena; no memory.grow. The manifest's source_url is an honest content-addressed `urn:sha256` source snapshot, not an invented public repository. The corresponding source ZIP is supplied beside the module. This is a local/private distribution, not a publicly hosted release. Build-RemoteFM1.py emits a source file hash inventory in that ZIP.

The native checker test_rfm1_host.cpp exercises the official RemoteFM1IOS loader and wasm3 at commit e527b74d04a95e6445b42fc27bd96704794294c0, using RFMWasmCore.cpp, its RFMCore headers and CWasm3 sources. References are cached under workspace work/remotefm1-reference/ios; this test is not a dependency of the shipped module. Host tests are on macOS, not an iPhone/iPad end-to-end test.

## Runtime

The native panel mapping is retained: FX=Song; SEL=Chain; ENV=Phrase; LFO=Instrument; EDIT=Table; GLO=Global; HOME=Mixer; SAVE=saves active project slot; ARP=preset browser on Instrument; SEQ=master FX; PLAY=transport; REC=contextual edit/load; OCT-/OCT+=mute/solo in Song, octave elsewhere. The same Instrument button cycles instrument subpages. Seven encoders and absolute MASTER are mapped using ABI 6 defaults.

Controls run on host ticks; LCD is RGB565 big-endian. Audio comes from the same 32 kHz synth core converted by tracker_device_render to 44.1 kHz. The adapter provides mono MIDI audition (last note) plus MIDI start/continue/stop and all-notes-off. It does not add external MIDI clock sync, velocity/pressure response, MIDI output, USB audio or OTA. Remote hardware panel transport and AUv3 are managed by the host app, not this module.

The default is the current 8-track MultiEngine demo in RAM, stopped. Boot restores valid slot 1. The flash image is 1 MiB; tracker storage is mapped at physical base 0x97000 with the same slots 0xAF000..0xDEFFF as the hardware candidate. Only the emulated store is written. Global Load/Save and SAVE use the existing transactional store. Host state persists flash, not unsaved project RAM: Save Slot first, then use the app's state/backup. The browser project SysEx protocol belongs to the physical build and is not exposed by this host target.

## Provenance

vendor/fm1core.h: Quixotic7/FM1VST, core-api/fm1core.h at commit 177e27a7643284833f06b37435faf7a611ecf065, GPL-3.0-only. Format specification and loader validation: Quixotic7/RemoteFM1IOS commit e527b74d04a95e6445b42fc27bd96704794294c0. All original tracker and third-party licenses remain applicable; see LICENSE.md, THIRD_PARTY.md, third_party and app/tracker/fonts.

## Deep Blue edition, 4 November 2026

The shared C renderer uses Inter (SIL OFL 1.1), eight Song tracks and eight visible rows, light Chain numbers, navy/azure selection, graphical knobs and ADSR sliders. Controls, DSP, project format and fm1_m8 identifier are unchanged. The 1 November saved flash loads in this build and re-saves byte-identically. Generate-Blue-Fonts.py regenerates the cropped 4-bit font atlases. Hardware packages are separate; see FM1-M8-DeepBlue-LEGGIMI.md.
