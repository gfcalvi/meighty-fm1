# Comandi di riga A03

Interprete originale per FM1 Open, ispirato a M8 e picoTracker Advance. Due colonne per Phrase e tre per Table. I codici binari sono locali al progetto. L'implementazione non promette compatibilità esatta con nessuno dei due dispositivi.

| Codice | Comando | Comportamento A03 |
| --- | --- | --- |
| 00 | --- | No command; active lane REP continues |
| 01 | DEL | Defer entire row 0-5 ticks |
| 02 | KIL | Kill voice after XX ticks |
| 03 | HOP | Next phrase row Y; FF stops this track |
| 04 | CHA | M8-style left/right chance X/Y, 0-F |
| 05 | RND | Randomize remembered FX in this lane |
| 06 | REP | Repeat remembered FX with signed increment |
| 07 | PSL | Glide toward subsequent note; 00 disables |
| 08 | CND | Extension: A:B loop condition, nibbles |
| 09 | PRV | Extension: previous row condition 00/01 |
| 0A | CUT | Absolute lowpass coefficient 00-FF |
| 0B | STA | PCM region start, fraction XX/256 |
| 0C | LEN | PCM region length; 00 means remainder |
| 0D | RET | Retrigger every Y ticks, X volume ramp |
| 0E | RNL | Randomize immediate left FX or note/instrument |
| 0F | SED | Reset this track PRNG to seed XX |
| 10 | RTO | Set current lane REP stopping bound |
| 11 | VOL | Absolute voice volume 00-FF |
| 12 | PIT | Relative signed semitone offset |
| 13 | ARP | Three-note arpeggio: base, +X, +Y |
| 14 | ARC | Arpeggio tick rate Y; X reserved |
| 15 | TBL | Select and restart table 00-0F |
| 16 | THO | Jump table to row low nibble |
| 17 | TIC | Table row duration 01-FF ticks |
| 18 | TPO | Set BPM 1E-FF |
| 19 | JMP | Extension: local phrase jump to row Y |
| 1A | SNG | Signed relative song row jump |
| 1B | INS | Change instrument and retrigger voice |
| 1C | OFF | 00 starts decay; nonzero schedules kill |
| 1D | CHN | pico-style chance of immediate left, 00-FF |
| 1E | PBN | Signed pitch drift, 1/16 semitone per tick |
| 1F | PVB | Tick vibrato: speed X, depth Y |
| 20 | PWM | Absolute pulse width 00-FF |
| 21 | MDL | Select oscillator model 00-04 |
| 22 | SCA | Key X, scale Y: 0 chromatic 1 major 2 minor |
| 23 | SCG | Set SCA for all eight tracks |
| 24 | TSP | Global signed semitone transpose |
| 25 | STP | Stop current table |
| 26 | NTH | Adapted: left every X loops, right every Y |

## Esecuzione e combinazioni

I gate sono risolti prima degli effetti, così `CUT 30 CHN 00` mantiene il cutoff precedente pur consentendo il trigger della nota; `HOP 03 CHN 80` esegue il salto circa metà delle volte. `CHN FF` consente sempre, `CHN 00` impedisce sempre. Nel primo slot CHN agisce sul trigger nota; negli slot successivi agisce sul comando immediatamente a sinistra.

Nella Phrase `CHA XY` controlla separatamente ciò che si trova a sinistra e a destra del comando: ciascun nibble va da 0 a F. `CHA 0F` sopprime nota/strumento alla sua sinistra e lascia passare gli FX a destra. Nella Table CHA applica la probabilità dell'intero byte a ciò che si trova alla sua sinistra. I gate si combinano con AND.

`CND 12`, `CND 22` e `CND 14` sono estensioni esplicite per primo giro di due, secondo giro di due e primo giro di quattro; condizionano la riga intera. `PRV 01` richiede esito vero della riga Phrase precedente, `PRV 00` falso. La valutazione della Table non sovrascrive l'esito PRV della Phrase.

Ogni colonna conserva separatamente l'ultimo FX operativo. Esempio di sweep in FX1:

```text
00 C-4 00 CUT20 ---00
01 --- FF REP04 ---00
02 --- FF RTOC0 ---00
03 --- FF ---00 ---00
04 --- FF ---00 ---00
```

REP aggiunge 04 a ogni riga, incluse quelle vuote. RTO imposta C0 come limite e arresta la progressione al suo raggiungimento. `REP 00` arresta il repeater; un nuovo comando operativo nella stessa colonna lo sostituisce. Il valore corrente prosegue anche su un nuovo trigger strumento, senza modificare i parametri salvati nello strumento. La Table ha tre memorie FX proprie, distinte dalle due della Phrase.

`RND XY` applica una variazione al precedente FX operativo della stessa colonna. `RNL XY` modifica la copia dell'evento immediatamente a sinistra sulla stessa riga; nel primo slot modifica nota e strumento, o trasposizione e volume nella Table. A02 usa variazioni simmetriche limitate dei nibble: non è un'emulazione verificata della distribuzione M8. I dati salvati nella Phrase non cambiano. SED imposta un generatore xorshift32 indipendente per traccia; viene valutato prima dei gate e delle estrazioni casuali della riga. Lo stesso seed e la stessa sequenza di comandi producono lo stesso risultato.

`RET XY` è distinto da REP: se Y è positivo, ripete il trigger ogni Y tick applicando un cambiamento di volume determinato da X; con Y uguale a zero esegue un solo retrigger dopo X tick. A02 usa una rampa di volume semplice, documentata nel sorgente, senza promettere la stessa curva M8.

`HOP 0Y` nella Phrase continua dalla riga Y della prossima Phrase nella Chain/Song. `HOP FF` arresta solo la traccia. `JMP 0Y` è un'estensione per saltare nella Phrase corrente. Nella Table `HOP XY` torna alla riga Y X volte; X uguale a zero ripete senza limite. Ogni salto si applica a un tick successivo e non genera esecuzione ricorsiva. Nella Table non esiste un arresto traccia con HOP FF; usare STP per fermare la Table.

## Differenze e limiti intenzionalmente espliciti

- **DEL:** differisce dal completo M8; A02 rinvia l'intera riga solo da 0 a 5 tick. Valori da 6 in su saltano la riga. Non mantiene una coda di molte righe ritardate. Un gate sul comando DEL stesso non annulla il ritardo già programmato.
- **NTH:** adotta una forma semplice ogni X/Y giri, con 0 sempre. Non replica la codifica estesa M8. Le condizioni A:B del documento si ottengono con CND. Il contatore della Phrase è per traccia: avanza a ogni fine Phrase o salto all’indietro, non è una memoria separata per ciascun ID Phrase.
- **PSL:** glide lineare in campioni con durata stimata dal tempo corrente. Non è ancora certificata la precisione del tempo di glide su variazioni BPM durante una nota.
- **PBN/PVB:** drift in sedicesimi di semitono per tick e vibrato aggiornato ai tick; il pitch risultante è quantizzato a semitoni. Non sono bend/vibrato continui ad alta risoluzione.
- **ARP/ARC:** base, +X, +Y con velocità Y di ARC; il nibble alto di ARC è riservato. Nessuna sequenza arpeggio polifonica.
- **TIC:** durata della riga Table da 1 a 255 tick, uguale per tutte le colonne. 00 congela la Table. Non implementa modalità automatiche per nota, tick indipendenti per colonna o TICFF ad alta frequenza.
- **Table:** TBL e THO sono presenti, TBX parallela non ancora. DEL nelle Table non è implementato. I contatori di HOP sono per riga e si azzerano con un nuovo trigger strumento.
- **INS:** cambia strumento e retriggera la voce, ma non ricarica tutti i parametri nello stesso modo di un nuovo evento nota/strumento.
- **OFF:** 00 avvia il decay attuale; valori non nulli programmano un kill. Il motore non ha una fase ADSR Release indipendente.
- **CUT/VOL/PWM/MDL:** operano sullo stato della voce, non sui parametri condivisi dello strumento. Sono parametri assoluti. Non tutti i comandi relativi strumento M8 hanno ancora un equivalente.
- **SCA/SCG:** solo cromatica, maggiore e minore naturale. Nessuna banca completa di scale o quantizzazione personalizzata.
- **TPO:** il byte permette 30–255 BPM; il controllo BPM permette fino a 300.
- **SNG:** salto relativo con byte signed, limitato alle righe della Song; non implementa le modalità live/selection dei riferimenti.
- **Sampler:** STA e LEN cambiano la regione usata al successivo trigger; non spostano immediatamente la testina già attiva.
- **Mancanti:** MTT, GRV/GGR, TBX, RMX, NXT, comandi MIDI/CC e comandi MIDI estesi. I 42 comandi presenti non sono l'intera libreria M8.

## Priorità successive

1. Microtiming MTT e groove per traccia.
2. Parametri pitch frazionari e automazioni continue.
3. Table ausiliarie e velocità indipendenti delle colonne.
4. Comandi dei bus audio e MIDI.
5. Catalogo di esempi musicali con risultati attesi e test sul dispositivo.

La priorità è conservare comportamento deterministico, memoria statica e costo prevedibile, documentando ogni differenza rispetto ai riferimenti.


## Mixer e mandate master

| Codice | Comando | Comportamento |
| --- | --- | --- |
| 27 | LEV | Livello mixer 00–FF |
| 28 | PAN | 00 sinistra, 80 centro, FF destra |
| 29 | DSN | Mandata post-fader al delay master 00–FF |
| 2A | RSN | Mandata post-fader al riverbero master 00–FF |

Gli override sono solo di esecuzione e condivisi con il mixer; una modifica manuale riprende il controllo del parametro. Stop/riavvio ripristina le basi salvate. VOL resta il livello della voce. Dettagli, divisioni musicali, mute/solo e limiti in MIXER-FX.md. I 43 valori includono il comando vuoto.
