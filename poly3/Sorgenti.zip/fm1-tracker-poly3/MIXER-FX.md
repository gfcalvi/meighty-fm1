# Mixer e ritorni master — Tracker A03

Il codice C disegna il mixer e Master FX sul display nativo 240×240. Le otto tracce, SYNTH o SAMPLE, attraversano livello e pan, poi due mandate post-fader indipendenti. Delay e riverbero sono ritorni master paralleli. Non sono insert per voce.

## Controlli FM-1

- SEQ apre Mixer; SELECT sceglie la traccia. K1 livello, K2 pan, K3 mandata delay, K4 mandata riverbero.
- REC attiva/disattiva mute della traccia, ARP solo. Nel Mixer le prime otto note fisiche attivano/disattivano mute delle otto tracce. La riproduzione delle Phrase continua sulle tracce mute, ma il fader viene portato a zero e non alimenta le mandate.
- GLO apre Master FX. K1 sceglie il parametro, K2 ne cambia il valore, K3 controlla il ritorno delay e K4 il ritorno riverbero. PRESETS/HOME e la mappa permettono di cambiare vista.
- PLAY/STOP arresta anche le code e azzera gli override Phrase. Il mute interrompe il nuovo segnale ma lascia decadere le code già nei ritorni.

Il mixer mostra otto fader colorati, meter post-fader, pan, mandate e indicatori M/S. In alto i quattro valori della traccia selezionata sono esadecimali nell'ordine livello/pan/delay/reverb. La modifica manuale di un parametro riprende il controllo sul relativo override Phrase. Mute/solo hanno priorità sul livello e sulle mandate, anche se una Phrase contiene LEV.

## Comandi Phrase e Table

| Codice | Nome | Parametro |
| --- | --- | --- |
| 27 | LEV | Livello mixer 00–FF, FF = guadagno unitario |
| 28 | PAN | 00 sinistra, 80 centro, FF destra |
| 29 | DSN | Mandata delay 00–FF |
| 2A | RSN | Mandata riverbero 00–FF |

VOL rimane il volume della voce/strumento; LEV agisce sul fader della traccia. I quattro nuovi comandi sono valori assoluti di esecuzione: non riscrivono le impostazioni di base salvate nel mixer. Persistono fra note e righe vuote fino a un nuovo comando, a una modifica manuale dello stesso parametro o al riavvio del trasporto. Possono essere usati con REP/RTO, probabilità e Table. Il salvataggio conserva basi mixer, mute/solo, parametri master e comandi delle Phrase, non lo stato transitorio degli override o le code.

Esempio: riga 03 della Phrase 00, `DSN 80` e `RSN 50`. In riproduzione le due mandate diventano 80 e 50 nel mixer. Nel progetto di prova del browser queste due celle sono state inserite in una riga prima vuota.

## Delay master

18 divisioni sincronizzate al BPM, da 1/2 a 1/64; per ciascuna versione normale, puntata D e terzina T. Il menu del Workbench scrive esplicitamente puntata/terzina. Il display fisico mostra, per esempio, 1/8D o 1/16T. L'intervallo è 30–300 BPM, con al massimo 6 secondi per 1/2D a 30 BPM. Non è presente 1/1.

Feedback 00–F0 (0–94,1%), ritorno 00–FF e ping-pong ON/OFF. Il ping-pong somma l'ingresso alla prima eco sinistra e incrocia il feedback: le ripetizioni successive alternano destra e sinistra. Con ping-pong OFF il delay mantiene due canali separati. Cambi di BPM/divisione usano una dissolvenza di 128 campioni del bus effetti fra i due tap (16 ms).

## Riverbero master

Riverbero stereo Schroeder originale: quattro comb smorzati e due allpass per canale, ritardi diversi sui due lati e crossfeed d'ingresso. Controlli decay 00–E0, damping 00–FF, ritorno 00–FF. Sono coefficienti, non secondi o metri. Non è una convoluzione o un'emulazione di una sala specifica.

## Audio, memoria e limiti verificati

Il percorso diretto resta a 32 kHz stereo. Per contenere memoria e costo, i ritorni operano a 8 kHz (banda limitata), con media di quattro campioni d'ingresso e interpolazione lineare in uscita. L'adattatore hardware conserva i due canali a 44,1 kHz Q23. Livello/pan/mandate e mute/solo raggiungono il nuovo valore in massimo 128 campioni; feedback e ritorni hanno rampe separate. Il pan usa guadagno unitario al centro e attenua il lato opposto verso gli estremi. Le mandate seguono il fader e il pan. Il master finale applica volume e saturazione morbida.

Tutti i buffer sono statici: il Tracker host pesa 213120 byte, inclusi i buffer dei ritorni. La sola sezione BSS di device.o PI32 è 218424 byte, più 2048 byte di campione e i dati/codici degli altri moduli e del framework. Il reset delle code invalida contatori e testine; non cancella il grande ring buffer nell'interrupt audio. Il vecchio fm1_engine_render non viene più chiamato prima del rendering custom. Non sono ancora verificati linking completo, budget RAM complessivo, tempi ISR o underrun sull'FM-1: questo è un prototipo compilato/testato, non un nuovo firmware installabile.

Prove superate: 72 combinazioni BPM/divisione con impulso e tempo atteso, prima/seconda/terza eco ping-pong, decadimento e diffusione stereo del riverbero, stress dei coefficienti massimi e reset senza code residue, pan agli estremi/centro, mandate post-fader, LEV/PAN/DSN/RSN, mute/solo, controlli nativi, persistenza e migrazione delle tre precedenti varianti A03. ASan e UBSan attivi. In C/WASM è verificato anche il passaggio al worklet a 48 kHz con ritorni attivi e memoria identica. I tre moduli custom sono stati compilati sul Mac anche per PI32v2 r3 tramite la toolchain Linux/Blink disponibile; non costituisce linking o collaudo hardware.

`../FM1-Mixer-Delay-Reverb.wav` è un render stereo del motore: 0–2 s asciutto; 2–6 s aggiunge ping-pong; 6–10 s anche riverbero e variazioni di pan; 10–14 s decadimento senza nuove note. Il picco misurato è 6023/32767 e i quattro segmenti contengono audio; il primo è mono al centro, i successivi differiscono tra sinistra e destra.
