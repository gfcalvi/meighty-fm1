# Meighty Tracker A03 Drums33

Current tracker extension: app/tracker, web/tracker, emulator. The upstream README describes the official base app, not tracker capabilities. This build has 8 mono tracks, 32 Instrument slots, 63 preset patches, 33 embedded percussion WAVs and two Instrument pages. Firmware boots an eight-track CR78/MiniPops kit; Workbench offers it in Global.

Instrument: K3 chooses slot; K4 browses presets; REC applies. Global: K1 field, K2 value, K3 load selected slot, K4 save selected slot. SAVE button also stores. See ../FM1-M8-Drums33-Guida.md for Italian instructions and asset provenance. Emulator target is separate from the immutable official SDK; hardware is not qualified.

Checks: sh tests/run.sh; tools/Build-Tracker-Web.py with WASI SDK 27; bundled Node tests/test_workbench.cjs; python3 tests/verify_sdk.py. Emulator build: python3 tools/Build-Emulator-Mac.py, using the local JieLi compiler runner configured there. The firmware package is created on macOS.

Regenerate PCM bank: python3 tools/Generate-Rhythm-Bank.py. Export ready kit: node tools/Export-Drums.cjs after WASM build. See assets/rhythm-bank for WAVs, metadata, licenses and conversion notes. Legacy PCM slots 0–7 retain their former recordings.
