#!/bin/sh
set -eu
cd "$(dirname "$0")"
sh tests/run.sh
cc -std=c11 -DFM1_HOST_TEST -O2 -Isdk/include -Iapp \
 app/tracker/tracker.c app/tracker/commands.c tests/render_demo.c \
 -o build/tracker-host/render_demo
build/tracker-host/render_demo build/tracker-host/anteprima.wav
printf '\nTest completati. Anteprima: build/tracker-host/anteprima.wav\n'
