# Modelli, ADSR, filtri e LFO — Tracker A03

Il motore C del tracker e il Workbench condividono queste funzioni. Sono implementazioni eseguibili nel simulatore; non costituiscono ancora un firmware installabile o una verifica di CPU/RAM sul dispositivo.

## Due pagine Instrument

Premi nuovamente **Instrument** per alternare **1/2 Suono** e **2/2 Modulazioni**, mantenendo lo slot selezionato. Nel mapping attuale del pannello FM-1 la funzione Instrument è sul tasto fisico **LFO**. Nel Workbench anche il pulsante Instrument della mappa ruota tra le due pagine.

- Suono: SYNTH/SAMPLE, modello, TIMBRE, COLOR, sample slot, Table, volume, cutoff, resonance, tipo filtro, pulse width e vecchi parametri AD.
- Modulazioni: ADSR e i due LFO.
- K1 seleziona il parametro nella pagina; K2 cambia il valore; K3 cambia lo strumento; il BPM si cambia in Global (GLO).
- I pulsanti web Suono, Modulazioni, ADSR, LFO 1 e LFO 2 portano direttamente al parametro corrispondente sul display C.
- REC non cambia pagina. Nel browser preset (ARP) carica il preset selezionato.

## Sintesi

I cinque oscillatori originali SAW, PULSE, SINE, CHIP, NOISE restano disponibili. Sono aggiunti:

| ID | Modello | TIMBRE | COLOR |
|---|---|---|---|
| 05 | BR FM | indice di modulazione | rapporto del modulatore, quantizzatore Braids |
| 06 | BR FBFM | indice con feedback | rapporto del modulatore |
| 07 | BR VOSIM | frequenza prima formante | frequenza seconda formante |

Sono adattamenti C degli algoritmi **RenderFm, RenderFeedbackFm e RenderVosim** di Braids, con equazioni e lookup table originali di Emilie Gillet, licenza MIT. Usano il clock/tuning a 32 kHz del tracker e non espongono il sync esterno o l'interpolazione per blocchi del modulo originale. Non sono un port completo di Braids o Plaits, né una replica certificata del loro suono. Provenienza e hash in `third_party/braids/provenance.json`, licenza e riferimento sorgente inclusi.

Sorgente ufficiale: https://github.com/pichenettes/eurorack/blob/master/braids/digital_oscillator.cc

Plaits non è incluso in questa versione. Il port selettivo a interi di Braids limita l'aumento della memoria; prima di ampliare ulteriormente i motori serve misurare il carico sul FM-1 con otto voci ed effetti attivi.

Sei nuovi preset, dal numero 18 al 1D esadecimale: FM GLASS, FM METAL, FBFM GROWL, FBFM DRIFT, VOSIM VOICE e VOSIM ORBIT. Totale 30 preset. Gli ultimi due suoni in movimento includono LFO già assegnati. Caricare un preset ripristina anche ADSR, filtro e LFO dello slot.

## ADSR su SYNTH e SAMPLE

**ADSR ENABLE = 01** attiva Attack, Decay, Sustain, Release. 00 conserva il vecchio inviluppo AD: questo è il valore assegnato ai progetti precedenti per mantenerne il comportamento.

Attack, Decay e Release: 00–FF, tempi crescenti secondo `(1 + valore² × 4) / 32000` secondi, fino a circa 8,13 secondi. L'accumulatore frazionario conserva anche i tempi lunghi. Sustain: 00–FF, livello 0–100%. Con sustain zero l'inviluppo termina dopo il decay.

Il rilascio della tastiera e la nota Phrase **OFF** avviano il Release. **OFF 00** come comando avvia il Release quando ADSR è abilitato. KIL e Stop restano interruzioni esplicite. Le note tenute restano al sustain fino a OFF, rilascio del tasto o nuovo trigger. Un sample non viene automaticamente messo in loop: se il file finisce prima dell'inviluppo, finisce anche il suono.

## Filtro per strumento

CUTOFF e RESONANCE, 00–FF; FILTER TYPE:

- 00 LEGACY: passa basso originale a un polo, senza risonanza, per compatibilità.
- 01 LP: passa basso risonante.
- 02 BP: passa banda risonante.
- 03 HP: passa alto risonante.

I nuovi filtri sono SVF a interi con due passi di integrazione per campione e stati limitati. Stanno prima dell'amplificatore ADSR e valgono anche sui sample. Nei sei nuovi preset il filtro risonante è già abilitato. Nei vecchi suoni occorre selezionare LP/BP/HP per usare Resonance.

## Due LFO con assegnazioni simultanee

Ogni LFO ha Rate, Shape, Phase e quattro profondità indipendenti: PAN, PITCH, CUT e AMP. Tutte e quattro possono essere diverse da zero contemporaneamente. Entrambi i LFO lavorano sulla singola voce, anche in preview, e si sommano.

- Forme: 00 SINE, 01 TRI, 02 SQUARE, 03 SAW.
- Rate: 00 ferma la fase; 01–FF circa 0,02–20,34 Hz, scala quadratica. Frequenza libera, non sincronizzata al tempo in questa versione.
- Phase: 00 = 0°, 40 = 90°, 80 = 180°, C0 = 270°. Le fasi si applicano al trigger.
- Profondità: −128…+127, valore decimale con segno sul display e nell'editor. Nel progetto binario 80 esadecimale indica zero. K2 aumenta/diminuisce direttamente la profondità con segno.
- Pitch: circa ±un'ottava per LFO a profondità massima; anche il playback PCM segue la modulazione. AMP riduce il volume nella parte negativa del ciclo; la parte positiva è limitata al livello di base.

Esempio: stessa Rate e Shape, LFO1 Phase 00, LFO2 Phase 80. Assegna LFO1 a Pan e LFO2 a Cutoff per due movimenti opposti. Due profondità uguali sulla stessa destinazione si cancellano; con profondità diverse rimane la differenza. In alternativa usa profondità di segno opposto e fasi uguali.

## Verifiche e limiti

Test C con AddressSanitizer/UndefinedBehaviorSanitizer: ADSR e release su synth/PCM, attacco lungo, tre nuovi modelli, modulazioni multiple, controfase, estremi del filtro, pan stereo della preview. Test nativi: due pagine e rotazione con Instrument, conservazione slot, REC indipendente. Test WASM: 32 campi, validazione, salvataggio e migrazione progetti precedenti mantenendo mixer e master FX.

I 65 file ufficiali SDK restano immutati. Compilazione dei moduli PI32v2 dal Mac verificata separatamente; link finale, packaging .fwsc, margine RAM completo e tempi CPU sul dispositivo non ancora verificati. I progetti esportati con questi nuovi parametri richiedono questa versione del Workbench per essere riaperti.

## Aggiornamento successivo: secondo ADSR e pannelli grafici

La pagina 2/2 ora usa riquadri con curve e indicatori in tempo reale. Si aggiunge
CUT ENV con ADSR indipendente e profondità bipolare; i campi Instrument sono 38.
Il riverbero offre anche il tipo AMBIENT. La descrizione aggiornata è in
[AMBIENT-ENV-GRAFICI.md](AMBIENT-ENV-GRAFICI.md); sostituisce le precedenti
indicazioni relative alla disposizione grafica della seconda pagina.
