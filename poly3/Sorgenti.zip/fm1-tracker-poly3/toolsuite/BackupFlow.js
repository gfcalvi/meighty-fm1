/* GPL-3.0-only WITH GPL-3.0-linking-exception. Data only, no firmware commands. */
globalThis.MeightyBackup=(()=>{'use strict';
const F=MeightyFiles;
async function backup(api,empty,onProgress=()=>{}){
 const slots=[],unreadable=[];
 for(let i=0;i<8;i++){onProgress(i/9,'Lettura slot '+(i+1)+' di 8');try{const d=await api.read(i);slots.push(F.sha(d)===empty.sha256?null:F.project(d,i));}catch(e){if(e.status===7)slots.push(null);else if(e.status===3||e.status===5){slots.push(null);unreadable.push({slot:i+1,status:e.status,error:e.message});}else{e.message='Lettura slot '+(i+1)+' interrotta: '+e.message;throw e;}}}
 onProgress(8/9,'Lettura progetto in lavorazione');const raw=await api.read(255);let working=null,workingRaw=null;
 try{working=F.project(raw,255,'In lavorazione');}catch(e){workingRaw={format:'FM1-Tracker-A03',schema:1,slot:255,name:'RAM non valida da recuperare',data:F.b64(raw),sha256:F.sha(raw)};unreadable.push({slot:'RAM',error:e.message});}
 const m=F.model(slots,working);
 if(unreadable.length){const e=Error('Backup INCOMPLETO: posizioni '+unreadable.map(s=>s.slot).join(', ')+' illeggibili o non valide. Recuperati i dati leggibili; i dati originali non sono stati modificati. Gli slot illeggibili non sono vuoti.');e.recovery={model:m,unreadable,workingRaw};throw e;}
 onProgress(1,'Backup verificato');return m;
}
function plan(m,mode,empty){
 const targets=m.restoreTargets;m=F.model(m.slots,m.working);F.data(empty);
 return m.slots.flatMap((p,i)=>targets&&!targets.some(t=>t.slot===i+1)?[]:p?[{slot:i,project:p,empty:false}]:(targets||mode==='replace')?[{slot:i,project:F.project(F.data(empty),i,'Vuoto'),empty:true}]:[]);
}
async function protectTargets(api,steps,onProgress=()=>{}){
 // Back up exactly what this operation can overwrite. Unrelated corrupt slots
 // must not prevent loading a song into a healthy/empty destination.
 const slots=Array(8).fill(null),targets=[];
 const seen=new Set();
 for(const s of steps){if(!Number.isInteger(s.slot)||s.slot<0||s.slot>7||seen.has(s.slot))throw Error('Piano slot non valido.');seen.add(s.slot);F.data(s.project);}
 for(let i=0;i<steps.length;i++){
  const n=steps[i].slot;onProgress(i/steps.length,'Backup della destinazione: slot '+(n+1));
  try{slots[n]=F.project(await api.read(n),n);targets.push({slot:n+1,empty:false});}
  catch(e){if(e.status===7){targets.push({slot:n+1,empty:true});continue;}
   if(e.status===3||e.status===5)throw Error('Slot '+(n+1)+' corrotto o appartenente a un altro firmware. Nessuna scrittura eseguita. Per usarlo, inizializza SOLO questo slot da Global → Project slot → '+(n+1)+' → Init slot (doppio REC), quindi riprova.');
   throw Error('Backup della destinazione '+(n+1)+' fallito: '+e.message+'. Nessuna scrittura eseguita.');}
 }
 return{model:F.model(slots),targets};
}
async function restore(api,steps,onProgress=()=>{}){
 /* Validate the whole plan before the first write, including unique targets. */
 const seen=new Set();for(const s of steps){if(!Number.isInteger(s.slot)||s.slot<0||s.slot>7||seen.has(s.slot))throw Error('Piano slot non valido.');seen.add(s.slot);F.data(s.project);}
 const results=[];
 for(let i=0;i<steps.length;i++){const s=steps[i];onProgress(i/steps.length,'Scrittura e verifica slot '+(s.slot+1));const back=await api.write(s.slot,F.data(s.project));if(!(back instanceof Uint8Array)||F.sha(back)!==s.project.sha256)throw Error('Slot '+(s.slot+1)+': il contenuto riletto non coincide con il brano. Ripristino interrotto.');results.push({slot:s.slot+1,sha256:F.sha(back),...F.summary(s.project)});}
 onProgress(1,'Ripristino completato e verificato');
 return results;
}
return{backup,plan,protectTargets,restore};
})();
