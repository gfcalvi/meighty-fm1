/* Direct offline tools: one command per operation, native file controls. */
(()=>{'use strict';
const C=MEIGHTY_CONFIG,F=MeightyFiles,B=MeightyBackup,$=id=>document.getElementById(id),E=new TextEncoder();
let busy=false,installer=null,metadata=null,conversion=null,output=null,pending=null,sources=[],library=[],logs=[];
const choices=Array(8).fill('');let pkg;
const json=j=>E.encode(JSON.stringify(j,null,2)),safe=s=>String(s||'Meighty').replace(/[^\p{L}\p{N} _.-]/gu,'_').slice(0,100);
function status(s,error=false,f){$('status').textContent=s;$('status').className='status'+(error?' error':'');$('progress').hidden=f===undefined;if(f!==undefined)$('progress').value=f*100;logs.push(s);if(logs.length>80)logs.shift();$('debugLog').textContent=logs.join('\n');}
function lock(on){document.querySelectorAll('button,input,select').forEach(x=>x.disabled=on);}
function cancelConfirm(){pending=null;$('confirmBox').hidden=true;}
async function run(fn){if(busy){status('Operazione in corso, attendi.');return;}cancelConfirm();busy=true;lock(true);try{await fn();}catch(e){status(e.code==='TIMEOUT'?'FM-1 non risponde. L’operazione non è completata. Ricollega lo strumento e riprova.':e.message||String(e),true);}finally{busy=false;lock(false);}}
function confirm(title,text,fn){if(busy)return;pending=fn;$('confirmTitle').textContent=title;$('confirmText').textContent=text;$('confirmBox').hidden=false;$('confirmBox').scrollIntoView({block:'nearest'});}
$('confirmYes').onclick=()=>{const fn=pending;if(fn)return run(fn);};$('confirmNo').onclick=()=>{cancelConfirm();status('Operazione annullata.');};
document.querySelectorAll('[data-page]').forEach(b=>b.onclick=()=>{if(busy)return;cancelConfirm();document.querySelectorAll('.page').forEach(x=>x.hidden=x.id!==b.dataset.page);document.querySelectorAll('[data-page]').forEach(x=>x.setAttribute('aria-selected',String(x===b)));});
async function connect(requireNew=true){
 if(!installer?.link||installer.link.lost){if(!navigator.requestMIDIAccess)throw Error('Apri questa pagina in Chrome/Edge o MIDIWeb Browser con supporto MIDI.');status('Collegamento FM-1…');const access=await navigator.requestMIDIAccess({sysex:true});installer=new FM1M8Installer.Installer(access,pkg,(s,n)=>status(s,false,n===undefined?undefined:n/100),{idle:20000,writeIdle:180000,reconnect:60000,settle:800});await installer.connect();metadata=null;}
 if(requireNew){if(![C.hardware.product,'FM-1_998201','FM-1_998202','FM-1_998203','FM-1_998204','FM-1_998205','FM-1_998206','FM-1_998207'].includes(installer.identity))throw Error('Per i progetti serve Meighty RC6 o successiva. Usa la pagina Firmware per installarlo.');const api=new FM1M8Installer.Projects(installer.link);await api.info();if(!metadata)metadata=await api.metadata();if(metadata.build<15)throw Error('Installa Meighty RC6 o successiva dalla pagina Firmware per usare la gestione diretta degli slot. Nessuna modifica eseguita.');$('connection').textContent='FM-1 collegato · Meighty '+metadata.version+' / HW'+metadata.build;return api;}
 $('connection').textContent='FM-1 collegato';return null;
}
$('connect').onclick=()=>run(async()=>{await connect(false);status('FM-1 collegato.');});
function saveOutput(){if(!output)return;const url=URL.createObjectURL(new Blob([output.bytes],{type:output.type})),a=document.createElement('a');a.href=url;a.download=output.name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),120000);}
function download(bytes,name,type='application/octet-stream'){
 output={bytes:new Uint8Array(bytes),name:safe(name),type};$('resultName').textContent=output.name;$('result').hidden=false;
 try{$('share').hidden=!(navigator.canShare&&navigator.share&&navigator.canShare({files:[new File([bytes],output.name,{type})]}));}catch(_){$('share').hidden=true;}
 saveOutput();
}
$('download').onclick=saveOutput;$('share').onclick=async()=>{if(!output)return;try{await navigator.share({files:[new File([output.bytes],output.name,{type:output.type})]});}catch(e){if(e.name!=='AbortError')status('Usa Salva il file per conservare il risultato.',true);}};
function readFile(file){return new Promise((resolve,reject)=>{if(!file||file.size>4*1048576){reject(Error('Scegli un file fino a 4 MiB.'));return;}const r=new FileReader(),t=setTimeout(()=>{r.abort();reject(Error('File non disponibile. Scaricalo da iCloud/Dropbox e riprova.'));},20000);r.onload=()=>{clearTimeout(t);resolve(new Uint8Array(r.result));};r.onerror=()=>{clearTimeout(t);reject(Error('Impossibile leggere il file.'));};r.onabort=()=>clearTimeout(t);r.readAsArrayBuffer(file);});}
const options=()=>({cores:C.cores,decoder:F.un64(C.decoder),base:Number($('layout').value)||undefined});
async function open(api,n,sha){const ram=await api.activate(n,sha),state=await api.state();if(state.loaded!==n)throw Error('Il dispositivo non ha aperto lo slot '+(n+1)+'.');return F.summary(F.project(ram));}
async function loadBank(m){
 const steps=B.plan(m,'merge',C.empty).filter(s=>!s.empty);if(!steps.length)throw Error('Scegli almeno un brano negli otto slot. Nessuna modifica eseguita.');const api=await connect();
 for(let i=0;i<steps.length;i++){const s=steps[i];status('Caricamento slot '+(s.slot+1)+'…',false,i/steps.length);const back=await api.write(s.slot,F.data(s.project));if(F.sha(back)!==s.project.sha256)throw Error('Verifica slot '+(s.slot+1)+' non riuscita.');}
 await open(api,steps[0].slot,steps[0].project.sha256);status('Caricati slot '+steps.map(s=>s.slot+1).join(', ')+'. Gli altri restano invariati. Aperto slot '+(steps[0].slot+1)+': premi PLAY.',false,1);
}
$('backupBank').onclick=()=>run(async()=>{const m=await B.backup(await connect(),C.empty,(f,s)=>status(s,false,f));download(json(F.bank(m)),'Meighty-backup-'+new Date().toISOString().slice(0,10)+'.meighty');status('Backup pronto.');});
$('backupWorking').onclick=()=>run(async()=>{const api=await connect(),p=F.project(await api.read(255),255,'Progetto aperto');download(json(api.projectSize===11940?F.legacy(p):p),'Meighty-progetto-aperto.fm1tracker.json');status('Progetto esportato.');});
function selectedSource(){return sources[Number($('sourceChoice').value)||0];}
function paintSource(){
 const parent=$('sourceSlots');parent.replaceChildren();const s=selectedSource();if(!s)return;
 s.model.slots.forEach((p,i)=>{const row=document.createElement('div');row.className='slotrow';const n=document.createElement('span');n.className='slotnum';n.textContent=String(i+1);const label=document.createElement('span');label.textContent=p?p.name+' · '+F.summary(p).bpm+' BPM':'Vuoto';const button=document.createElement('button');button.textContent='Estrai';button.onclick=()=>{if(!p){status('Questo posto è vuoto.');return;}download(json(p),'Slot-'+(i+1)+'-'+safe(p.name)+'.fm1tracker.json');status('Brano estratto.');};row.append(n,label,button);parent.append(row);});
}
$('sourceChoice').onchange=paintSource;
async function importFiles(files,target=null,fill=false){
 const parsed=[];for(const file of files)parsed.push({name:file.name,model:await F.read(await readFile(file),options())});if(sources.length+parsed.length>32)throw Error('Apri fino a 32 file per sessione.');
 const added=[],staged=[],next=fill?Array(8).fill(''):choices.slice();for(const s of parsed){const count=s.model.slots.filter(Boolean).length;
 s.model.slots.forEach((p,i)=>{if(p){const id=String(library.length+staged.length);staged.push({id,p,source:s.name});added.push(id);if(fill){const dest=parsed.length>1&&count===1?next.findIndex(x=>!x):i;if(dest<0||next[dest])throw Error('Troppi brani o destinazioni sovrapposte: carica i file singolarmente nelle caselle.');next[dest]=id;}}});
 if(s.model.working){const id=String(library.length+staged.length);staged.push({id,p:s.model.working,source:s.name+' · RAM'});added.push(id);if(fill&&!count){const dest=next.findIndex(x=>!x);if(dest<0)throw Error('Più di otto brani: scegli i file nelle singole caselle.');next[dest]=id;}}}
 if(target!==null&&added.length===1)next[target]=added[0];
 sources.push(...parsed);library.push(...staged);choices.splice(0,8,...next);
 $('sourceChoice').replaceChildren();sources.forEach((s,i)=>$('sourceChoice').add(new Option(s.name,i)));$('sourceChoice').value=String(sources.length-1);$('libraryInfo').textContent=sources.length+' file · '+library.length+' progetti';paintSource();paintComposer();status(target!==null&&added.length>1?'File aperto. Scegli nel menu il brano da usare nello slot '+(target+1)+'.':fill?'File pronti negli otto slot. Premi Carica gli slot selezionati.':'File pronti.');
}
$('sourceFiles').onchange=()=>{const files=Array.from($('sourceFiles').files);$('sourceFiles').value='';return run(()=>importFiles(files));};
$('restoreFiles').onchange=()=>{const files=Array.from($('restoreFiles').files);$('restoreFiles').value='';if(!files.length)return;choices.fill('');paintComposer();return run(()=>importFiles(files,null,true));};
function paintCount(){$('setCount').textContent=choices.filter(Boolean).length+' slot da caricare · '+choices.filter(x=>!x).length+' da non modificare';}
function paintComposer(){
 $('composer').replaceChildren();for(let i=0;i<8;i++){
  const row=document.createElement('div');row.className='slotrow';const number=document.createElement('span');number.className='slotnum';number.textContent=String(i+1);
  const select=document.createElement('select');select.setAttribute('aria-label','Brano nello slot '+(i+1));select.add(new Option('Non modificare',''));for(const e of library)select.add(new Option(e.source+' · '+e.p.name,e.id));select.value=choices[i];select.onchange=()=>{choices[i]=select.value;paintCount();};
  const input=document.createElement('input');input.type='file';input.id='setFile'+i;input.setAttribute('aria-label','Carica file per slot '+(i+1));input.onchange=()=>{const files=Array.from(input.files);input.value='';if(files.length){choices[i]='';select.value='';paintCount();return run(()=>importFiles(files,i));}};const actions=document.createElement('div');actions.className='actions';actions.append(input);row.append(number,select,actions);$('composer').append(row);
 }paintCount();
}
function getSet(){return F.model(choices.map((id,i)=>{if(!id)return null;const e=library.find(e=>e.id===id);if(!e)throw Error('Brano non trovato.');return F.project(F.data(e.p),i,e.p.name);}));}
$('clearSet').onclick=()=>{choices.fill('');paintComposer();status('Selezione svuotata. I file originali restano intatti.');};
$('exportSet').onclick=()=>run(async()=>{const saved=F.bank(getSet());download(json(saved),safe($('setName').value)+'.meighty');status(saved.version===1?'Set pronto, compatibile anche con RC7.':'Set pronto in formato Poly3.');});
$('loadSet').onclick=()=>run(()=>loadBank(getSet()));
$('convertFile').onchange=()=>{const f=$('convertFile').files[0];$('convertFile').value='';conversion=null;$('convertInfo').textContent='Nessun file pronto.';return run(async()=>{if(!f)return;conversion={name:f.name,model:await F.read(await readFile(f),options())};$('convertInfo').textContent=f.name;status('File pronto per la conversione.');});};
$('convert').onclick=()=>run(async()=>{const s=conversion;if(!s)throw Error('Scegli prima il file da convertire.');const kind=$('convertFormat').value,name=safe(s.name.replace(/\.[^.]+$/,'')),o=F.output(kind,s.model,{target:C.remote,emulator:C.emulator,name,dropWorking:true});if(s.model.working&&kind!=='meighty'){download(zip([{name:name+o.ext,bytes:o.bytes},{name:'Progetto-in-lavorazione.fm1tracker.json',bytes:json(s.model.working)}]),name+'.zip','application/zip');status('Conversione pronta. Il progetto in lavorazione è conservato separatamente nello ZIP.');}else{download(o.bytes,name+o.ext);status('Conversione pronta.');}});
$('extractWorking').onclick=()=>{const p=selectedSource()?.model.working;if(!p){status('Questo file non contiene una copia in lavorazione.');return;}download(json(p),'Progetto-in-lavorazione.fm1tracker.json');status('Progetto estratto.');};
$('extractAll').onclick=()=>{const s=selectedSource();if(!s){status('Scegli prima il file da estrarre.',true);return;}const files=[],index=[];s.model.slots.forEach((p,i)=>{const name=p?'Slot-'+(i+1)+'-'+safe(p.name)+'.fm1tracker.json':null;index.push({slot:i+1,name:p?.name||null,file:name});if(p)files.push({name,bytes:json(p)});});if(s.model.working)files.push({name:'In-lavorazione.fm1tracker.json',bytes:json(s.model.working)});files.push({name:'Indice-slot.json',bytes:json(index)});download(zip(files),'Meighty-brani-estratti.zip','application/zip');status('Brani estratti. L’indice indica anche i posti vuoti.');};
function zip(files){const chunks=[],directory=[];let at=0;for(const f of files){const name=E.encode(f.name),sum=F.crc(f.bytes),h=new Uint8Array(30+name.length),v=new DataView(h.buffer);v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint16(6,0x800,true);v.setUint16(12,33,true);v.setUint32(14,sum,true);v.setUint32(18,f.bytes.length,true);v.setUint32(22,f.bytes.length,true);v.setUint16(26,name.length,true);h.set(name,30);chunks.push(h,f.bytes);const c=new Uint8Array(46+name.length),w=new DataView(c.buffer);w.setUint32(0,0x02014b50,true);w.setUint16(4,20,true);w.setUint16(6,20,true);w.setUint16(8,0x800,true);w.setUint16(14,33,true);w.setUint32(16,sum,true);w.setUint32(20,f.bytes.length,true);w.setUint32(24,f.bytes.length,true);w.setUint16(28,name.length,true);w.setUint32(42,at,true);c.set(name,46);directory.push(c);at+=h.length+f.bytes.length;}const size=directory.reduce((n,b)=>n+b.length,0),end=new Uint8Array(22),v=new DataView(end.buffer);v.setUint32(0,0x06054b50,true);v.setUint16(8,files.length,true);v.setUint16(10,files.length,true);v.setUint32(12,size,true);v.setUint32(16,at,true);const out=new Uint8Array(at+size+22);let p=0;for(const b of [...chunks,...directory,end]){out.set(b,p);p+=b.length;}return out;}
$('readDiagnostics').onclick=()=>run(async()=>{const m=await(await connect()).metadata();if(!Number.isInteger(m.maxUs))throw Error('Questa build non espone i contatori audio.');status('Meighty '+m.version+' / HW'+m.build+' · MAX '+m.maxUs+' µs · LATE '+m.late+' · MISSES '+m.misses+'. Budget: 2902 µs.'+(m.cost?' Blocco del MAX: PREP '+m.cost[0]+' · CPU0 '+m.cost[1]+' · CPU1 '+m.cost[2]+' · ATTESA '+m.cost[3]+' · MIX/FX '+m.cost[4]+' µs. CPU1 è parallelo, non va sommato.':''));});
$('installFirmware').onclick=()=>confirm('Installare Meighty 1.02 A1 Poly3?','Sostituisce il firmware. Conserva prima un backup se vuoi tenere i tuoi progetti. Non scollegare durante l’aggiornamento.',async()=>{await connect(false);await installer.install();metadata=null;$('connection').textContent='Aggiornamento terminato';status('1.02 A1 trasferita. Verifica il riavvio e la versione sul display.');});
window.addEventListener('beforeunload',e=>{if(busy){e.preventDefault();e.returnValue='Operazione in corso';}});
try{pkg=FM1M8Installer.prepare(C.hardware);status('Pronto.');}catch(e){status(e.message,true);}paintComposer();
})();
