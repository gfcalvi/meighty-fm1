#include "tracker/tracker.h"
#include <assert.h>
#include <pthread.h>
#include <stdio.h>
#include <string.h>
static Tracker scalar,block;
static TrVoice ps,pb;
static TrRender work;
static int16_t pcm[8192],expected[2*257],actual[2*257];
static unsigned rng=0x7381831;
static unsigned rnd(void){rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;return rng;}
static pthread_t thread;
static void (*worker_fn)(void *);static void *worker_arg;
static void *thread_main(void *unused){(void)unused;worker_fn(worker_arg);return 0;}
static int submit(void (*fn)(void *),void *arg){static unsigned calls;if(!(++calls%3))return 0;worker_fn=fn;worker_arg=arg;assert(!pthread_create(&thread,0,thread_main,0));return 1;}
static void join(void){assert(!pthread_join(thread,0));}
int main(void){
 unsigned long total=0;
 for(unsigned i=0;i<8192;i++)pcm[i]=(int16_t)rnd();
 for(unsigned threaded=0;threaded<2;threaded++)for(unsigned model=0;model<19;model++){
  tr_init(&scalar);tr_demo(&scalar);
  TrSample sample={pcm,8192,32000,60};assert(!tr_set_sample(&scalar,0,&sample));
  for(unsigned c=0;c<8;c++){
   scalar.project.instrument_source[c]=model==18?2:1;
   scalar.project.instruments[c].model=model%18;scalar.project.instruments[c].sample=0;
   scalar.project.sound[c][0]=1;scalar.project.sound[c][1]=0;scalar.project.sound[c][2]=15;
   scalar.project.sound[c][3]=220;scalar.project.sound[c][4]=20;scalar.project.sound[c][5]=100;
   scalar.project.sound[c][6]=c%4;scalar.project.sound[c][9]=200;
   scalar.project.sound[c][12]=150;scalar.project.sound[c][13]=145;
   scalar.project.sound[c][14]=145;scalar.project.sound[c][15]=135;
   scalar.project.mixer[c].delay=150;scalar.project.mixer[c].reverb=160;
  }
  scalar.project.bpm=299;
  /* Commands on distinct tracks share global state, in a defined order. */
  scalar.project.phrases[0].step[0].fx[0]=(TrFx){FX_TPO,255};
  scalar.project.phrases[1].step[0].fx[0]=(TrFx){FX_SCG,3};
  scalar.project.phrases[2].step[0].fx[0]=(TrFx){FX_TSP,7};
  scalar.project.phrases[0].step[1].fx[0]=(TrFx){FX_TPO,30};
  scalar.project.phrases[3].step[0].fx[1]=(TrFx){FX_TBL,0};
  scalar.project.tables[0].length=3;
  scalar.project.tables[0].row[0].fx[0]=(TrFx){FX_WTP,80};
  scalar.project.tables[0].row[1].fx[0]=(TrFx){FX_PIT,1};
  tr_transport(&scalar,1);tr_audition_on(&scalar,&ps,2,2,67);
  block=scalar;pb=ps;memset(&work,0,sizeof work);
  if(threaded){work.submit=submit;work.join=join;}
  unsigned frames=0;
  while(frames<32000){
   unsigned n=1+rnd()%257;
   if(n>32000-frames)n=32000-frames;
   unsigned c=rnd()%8;
   scalar.project.mixer[c].pan=rnd()%256;scalar.project.mixer[c].level=rnd()%256;
   scalar.project.mute_mask=(uint8_t)rnd();scalar.project.solo_mask=(uint8_t)rnd();
   scalar.project.bpm=30+rnd()%271;block.project=scalar.project;
   if(frames>16000&&frames<16500){tr_transport(&scalar,0);tr_transport(&block,0);}
   if(frames>20000&&!scalar.playing){tr_transport(&scalar,1);tr_transport(&block,1);}
   for(unsigned f=0;f<n;f++)tr_sample_stereo(&scalar,tr_audition_sample(&scalar,&ps,2),2,expected+f*2);
   tr_render_stereo(&block,&pb,2,actual,n,&work);
   if(memcmp(expected,actual,n*2*sizeof *actual)){
    fprintf(stderr,"audio mismatch threaded=%u model=%u at=%u n=%u\n",threaded,model,frames,n);return 1;
   }
   assert(!memcmp(&scalar,&block,sizeof scalar));assert(!memcmp(&ps,&pb,sizeof ps));
   frames+=n;total+=n;
  }
 }
 printf("PASS block renderer: %lu exact stereo frames/state, scalar and pthread worker, 18 synth models/PCM, preview, tick boundaries, shared FX, random chunk sizes, stop/restart\n",total);
 return 0;
}
