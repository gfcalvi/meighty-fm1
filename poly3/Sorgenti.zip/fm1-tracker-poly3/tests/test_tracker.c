/* SPDX-License-Identifier: GPL-3.0-only */
#include "tracker/tracker.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static Tracker t;
static TrStep *setup(void) {
 tr_init(&t);t.project.song[0][0]=0;t.project.chains[0].phrase[0]=0;
 TrStep *s=&t.project.phrases[0].step[0];s->note=60;s->instrument=0;tr_transport(&t,1);return s;
}
static void timing(void) {
 setup();for(unsigned n=0;n<32000;n++)tr_sample(&t);
 assert(t.ticks==49);assert(t.voice[0].step==8);assert(t.voice[0].tick==1);
 tr_transport(&t,0);for(unsigned n=0;n<100;n++)assert(tr_sample(&t)==0);
 setup();for(unsigned n=0;n<320000;n++)tr_sample(&t);assert(t.ticks==481);
}
static void conditions(void) {
 TrStep *s=setup();s->fx[0]=(TrFx){FX_CHA,0};tr_tick(&t);assert(!t.voice[0].active&&!t.voice[0].previous);
 s=setup();s->fx[0]=(TrFx){FX_CHA,255};tr_tick(&t);assert(t.voice[0].active&&t.voice[0].previous);
 s=setup();s->fx[0]=(TrFx){FX_CND,0x22};tr_tick(&t);assert(!t.voice[0].active);
 t.voice[0].tick=0;t.voice[0].loops=1;tr_tick(&t);assert(t.voice[0].active);
 s=setup();s->fx[0]=(TrFx){FX_PRV,1};tr_tick(&t);assert(!t.voice[0].active);
 t.voice[0].tick=0;t.voice[0].previous=1;tr_tick(&t);assert(t.voice[0].active);
 s=setup();s->fx[0]=(TrFx){FX_PRV,0};tr_tick(&t);assert(t.voice[0].active);
}
static void effects(void) {
 TrStep *s=setup();s->fx[0]=(TrFx){FX_DEL,2};s->fx[1]=(TrFx){FX_KIL,4};
 tr_tick(&t);assert(!t.voice[0].active);tr_tick(&t);assert(!t.voice[0].active);
 tr_tick(&t);assert(t.voice[0].active);tr_tick(&t);tr_tick(&t);assert(t.voice[0].active);tr_tick(&t);tr_tick(&t);assert(!t.voice[0].active);
 s=setup();s->fx[0]=(TrFx){FX_JMP,0};for(unsigned n=0;n<6;n++)tr_tick(&t);
 assert(t.voice[0].step==0&&t.voice[0].loops==1);
 s=setup();s->fx[0]=(TrFx){FX_RET,2};tr_tick(&t);t.voice[0].envelope=12345;
 tr_tick(&t);assert(t.voice[0].envelope==12345);tr_tick(&t);assert(t.voice[0].envelope==0);
 s=setup();s->fx[0]=(TrFx){FX_PORT,10};t.voice[0].increment=1000;
 tr_tick(&t);assert(t.voice[0].increment==1000);tr_sample(&t);assert(t.voice[0].increment>1000);
}
static void table(void) {
 setup();t.project.instruments[0].table=0;t.project.tables[0].length=2;
 t.project.tables[0].row[0].transpose=12;t.project.tables[0].row[1].transpose=-12;
 tr_tick(&t);uint32_t high=t.voice[0].target;assert(t.voice[0].table_row==1);
 tr_tick(&t);assert(t.voice[0].target<high&&t.voice[0].table_row==0);
}
static void arrangement(void) {
 setup();t.project.song_length=2;t.project.chains[0].length=2;t.project.chains[0].phrase[1]=1;
 t.project.song[1][0]=1;t.project.chains[1].phrase[0]=2;
 for(unsigned i=0;i<96;i++)tr_tick(&t);assert(t.voice[0].chain==1&&t.voice[0].song==0);
 for(unsigned i=0;i<96;i++)tr_tick(&t);assert(t.voice[0].chain==0&&t.voice[0].song==1);
 for(unsigned i=0;i<96;i++)tr_tick(&t);assert(t.voice[0].song==0);
}
static void pcm(void) {
 static const int16_t data[]={10000,-10000,10000,-10000};
 setup();TrSample s={data,4,22050,60};assert(tr_set_sample(&t,0,&s)==0);
 assert(tr_set_sample(&t,TR_SAMPLES,&s)<0);s.rate=44100;assert(tr_set_sample(&t,0,&s)<0);s.rate=22050;
 t.project.song[0][4]=1;t.project.chains[1].phrase[0]=1;
 t.project.phrases[1].step[0]=(TrStep){60,0,{{FX_START,128},{FX_LENGTH,64}}};
 tr_tick(&t);assert(t.voice[4].index==2&&t.voice[4].end==3);
 for(unsigned n=0;n<10;n++)tr_sample(&t);assert(!t.voice[4].active);
}
static void stress(void) {
 tr_init(&t);tr_demo(&t);static int16_t data[257];for(unsigned i=0;i<257;i++)data[i]=(int16_t)(i*391);
 for(unsigned i=0;i<8;i++){TrSample s={data,257,32000,60};assert(!tr_set_sample(&t,i,&s));}
 tr_transport(&t,1);long long energy=0;
 for(unsigned n=0;n<320000;n++){int x=tr_sample(&t);energy+=abs(x);}
 assert(energy>100000);printf("Stress energy %lld; static Tracker bytes %zu\n",energy,sizeof t);
}
int main(void){timing();conditions();effects();table();arrangement();pcm();stress();puts("PASS: clock, transport, conditions, DEL/KIL/JMP/RET/PSL, tables, arrangement, PCM, eight tracks");}
