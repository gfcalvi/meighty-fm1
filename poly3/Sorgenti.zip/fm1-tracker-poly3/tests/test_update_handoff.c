/* GPL-3.0-only. Exercise the same handoff code used by transport.inc. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#define FM1_CPU1 1
#define FM1_IRQ_ALNK0 11
static int interrupts=1, audio_irq=1, dma=1, core1=1, entered;
static char trace[64];static unsigned at;
static void mark(char c){trace[at++]=c;trace[at]=0;}
static uint32_t fm1_device_irq_save(void){unsigned old=interrupts;interrupts=0;mark('I');return old;}
static void fm1_device_irq_restore(uint32_t old){interrupts=old;mark('R');}
static void fm1_irq_mask(unsigned irq){assert(!interrupts&&irq==11);audio_irq=0;mark('M');}
static void fm1_audio_stop(void){assert(!interrupts&&!audio_irq);dma=0;mark('S');}
static unsigned fm1_audio_pending(void){return 0xf0;}
static void fm1_audio_ack_aux(unsigned p){assert(!dma&&p==0xf0);mark('A');}
static void fm1_audio_ack_half(void){assert(!dma);mark('H');}
static void fm1_cpu1_stop(void){assert(!interrupts&&!audio_irq&&!dma);core1=0;mark('C');}
static void usb_detach(void){assert(!interrupts&&!core1);mark('D');}
static void fm1_delay_ms(unsigned ms){assert(ms==30&&!interrupts&&!core1);mark('W');}
static void fm1_enter_update(const uint8_t *p){assert(!interrupts&&!core1&&p[0]==42);entered=1;mark('E');}
#include "../hardware/update_handoff.inc"
int main(void){
 uint8_t parm[112]={42};
 tr_update_pause_audio();
 assert(interrupts&&!audio_irq&&!dma&&core1&&!strcmp(trace,"IMSAHR"));
 /* USB timer remains available for staging; CPU1 remains idle/alive so an
  * aborted session can reinitialise audio without restarting that core. */
 at=0;trace[0]=0;tr_update_commit(parm);
 assert(entered&&!interrupts&&!strcmp(trace,"ICDWE"));
 puts("PASS: audio IRQ masked and DMA stopped atomically; USB staging IRQs remain enabled");
 puts("PASS: CPU1 held only after CLI; no interrupt window before detach/mailbox/reset");
 return 0;
}
