#define main poly3_original_tests
#include "test_poly3.c"
#undef main
int main(void){
 const unsigned sizes[]={1,257,1,128,17,93,2,256};
 for(unsigned model=0;model<2;model++)for(unsigned track=1;track<=8;track++){
  setup(&a,model?17:0,track);tr_transport(&a,1);TrVoice pa,pb;tr_audition_on(&a,&pa,0,0,74);b=a;pb=pa;
  memset(&work,0,sizeof work);work.submit=submit;work.join=join;
  for(unsigned block=0;block<96;block++){
   unsigned n=sizes[block%8],ch=block%8;
   if(block%12==3){for(unsigned c=0;c<8;c++)a.project.mixer[c]=(TrMix){(uint8_t)(block*7+c*17),(uint8_t)(c*31),(uint8_t)(block*3+c*5),(uint8_t)(block*11+c*9)};}
   if(block%12==5){a.project.mute_mask=(uint8_t)(1U<<ch);a.project.solo_mask=0;}
   if(block%12==7){a.project.mute_mask=0;a.project.solo_mask=(uint8_t)(1U<<ch);}
   if(block%12==9)a.project.solo_mask=0;
   if(block==25||block==51||block==77){unsigned next=block==25?0:block==51?8:3;assert(!tr_poly_select(&a,next));assert(!tr_poly_select(&b,next));}
   if(block==40||block==60){tr_effects_reset(&a);tr_effects_reset(&b);}
   b.project=a.project;
   if(block%9==2){a.effects.override[ch][2]=(int16_t)((block*13)&255);b.effects.override[ch][2]=a.effects.override[ch][2];}
   int16_t one[514],two[514];for(unsigned f=0;f<n;f++)tr_sample_stereo(&a,tr_audition_sample(&a,&pa,ch),ch,one+f*2);
   tr_render_stereo(&b,&pb,ch,two,n,&work);
   assert(!memcmp(one,two,n*2*sizeof *one));assert(!memcmp(&a,&b,sizeof a));assert(!memcmp(&pa,&pb,sizeof pa));
  }
 }
 puts("PASS1536 persistent-cache blocks: short->long buffers, settled/ramping targets, mute/solo, override, reset, poly reassignment and preview-owner changes; exact scalar/threaded audio/full state");return 0;
}
