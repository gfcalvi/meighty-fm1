#include "tracker/tracker.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <pthread.h>
static Tracker a,b,c;
static TrRender work;static TrVoice preview;
static pthread_t worker;
static void (*job_fn)(void *);static void *job_arg;
static void *thread_entry(void *arg){(void)arg;job_fn(job_arg);return 0;}
static int submit(void (*fn)(void *),void *arg){job_fn=fn;job_arg=arg;assert(!pthread_create(&worker,0,thread_entry,0));return 1;}
static void join(void){assert(!pthread_join(worker,0));}
static void setup(Tracker *t,unsigned model,unsigned track){
 tr_init(t);t->project.master[7]=200;assert(!tr_poly_select(t,track));
 for(unsigned k=0;k<32;k++){t->project.instrument_source[k]=1;t->project.instruments[k].model=model;t->project.sound[k][0]=1;t->project.sound[k][1]=0;t->project.sound[k][2]=10;t->project.sound[k][3]=200;t->project.sound[k][4]=12;t->project.sound[k][6]=1;}
 for(unsigned k=0;k<8;k++){t->project.song[0][k]=k;t->project.chains[k].length=1;t->project.chains[k].phrase[0]=k;t->project.phrases[k].step[0]=(TrStep){(uint8_t)(48+k),0,{{k+1==track?FX_CHD:0,0x47},{0,0}}};}
}
static void samples(Tracker *t,unsigned n){for(unsigned k=0;k<n;k++){int16_t s[2];tr_sample_stereo(t,0,8,s);}}
static unsigned active(Tracker *t){unsigned n=0;for(unsigned k=0;k<10;k++)n+=!!t->voice[k].active;return n;}
int main(void){
 for(unsigned track=1;track<=8;track++)for(unsigned model=0;model<18;model++){
  setup(&a,model,track);tr_transport(&a,1);b=a;c=a;
  int16_t one[514],blocked[514],threaded[514];
  for(unsigned n=0;n<257;n++)tr_sample_stereo(&a,0,8,one+n*2);
  memset(&work,0,sizeof work);tr_render_stereo(&b,&preview,8,blocked,257,&work);
  memset(&work,0,sizeof work);work.submit=submit;work.join=join;tr_render_stereo(&c,&preview,8,threaded,257,&work);
  assert(!memcmp(one,blocked,sizeof one));assert(!memcmp(one,threaded,sizeof one));assert(active(&a)==10);
  assert(a.voice[8].note==a.voice[track-1].note+4&&a.voice[9].note==a.voice[track-1].note+7);
  assert(a.voice[8].increment!=a.voice[9].increment);
 }
 puts("PASS 18 models x 8 selected tracks: 10 active voices, exact scalar/block/pthread stereo, independent chord pitches");
 static int16_t pcm[4096];for(unsigned n=0;n<4096;n++)pcm[n]=(int16_t)(n*31919U);
 for(unsigned track=1;track<=8;track++)for(unsigned rate=0;rate<2;rate++){
  setup(&a,0,track);TrSample sample={pcm,4096,rate?22050:32000,60};assert(!tr_set_sample(&a,0,&sample));
  for(unsigned i=0;i<32;i++){a.project.instrument_source[i]=2;a.project.instruments[i].sample=0;}tr_transport(&a,1);b=a;
  int16_t one[514],out[514];for(unsigned n=0;n<257;n++)tr_sample_stereo(&a,0,8,one+n*2);
  memset(&work,0,sizeof work);work.submit=submit;work.join=join;tr_render_stereo(&b,&preview,8,out,257,&work);assert(!memcmp(one,out,sizeof one));assert(a.voice[8].sample_step!=a.voice[9].sample_step);
  tr_set_sample(&a,0,&sample);assert(!active(&a));
 }
 puts("PASS PCM22.05/32kHz x all8 tracks: independent sample pitch/position and exact threaded output; replacing sample stops all10 voices");
 setup(&a,0,1);TrSample longSample={pcm,4096,32000,60},shortSample={pcm,2,32000,60};assert(!tr_set_sample(&a,0,&longSample));assert(!tr_set_sample(&a,1,&shortSample));for(unsigned i=0;i<32;i++){a.project.instrument_source[i]=2;a.project.instruments[i].sample=0;}tr_transport(&a,1);samples(&a,100);for(unsigned i=0;i<32;i++)a.project.instruments[i].sample=1;samples(&a,1);assert(!active(&a));
 for(unsigned track=1;track<=8;track++){setup(&a,0,track);TrSample sample={pcm,4096,32000,60};assert(!tr_set_sample(&a,0,&sample));for(unsigned i=0;i<32;i++){a.project.instrument_source[i]=0;a.project.instruments[i].sample=0;}tr_transport(&a,1);samples(&a,1);assert(a.voice[8].sample_mode==(track>=5)&&a.voice[9].sample_mode==(track>=5));}
 setup(&a,16,4);tr_transport(&a,1);TrVoice pa,pb;tr_audition_on(&a,&pa,2,0,74);b=a;pb=pa;int16_t one11[514],two11[514];for(unsigned n=0;n<257;n++)tr_sample_stereo(&a,tr_audition_sample(&a,&pa,2),2,one11+n*2);
 memset(&work,0,sizeof work);work.submit=submit;work.join=join;tr_render_stereo(&b,&pb,2,two11,257,&work);assert(!memcmp(one11,two11,sizeof one11));assert(active(&a)==10&&pa.active);
 // Shared mixer ramps advance once per sample, not three times for the chord.
 setup(&a,10,4);a.project.mute_mask=255;tr_transport(&a,1);samples(&a,1);assert(a.effects.mix_now[3][0]==255*256-512);samples(&a,512);int16_t silent[2];tr_sample_stereo(&a,0,8,silent);assert(!silent[0]&&!silent[1]);
 puts("PASS legacy synth/PCM source follows logical track; exact 11-voice preview; poly mixer/mute ramp advances once and silences all3 voices");
 setup(&a,10,4);assert(!tr_poly_note_on(&a,0,60));samples(&a,100);assert(!tr_poly_note_on(&a,0,64));samples(&a,100);assert(!tr_poly_note_on(&a,0,67));samples(&a,100);
 assert(active(&a)==3&&a.voice[3].note==67&&a.voice[8].note==60&&a.voice[9].note==64);
 assert(a.voice[3].phase!=a.voice[8].phase);a.voice[9].ret_period=1;a.voice[9].table_active=1;tr_poly_note_off(&a,64);assert(a.voice[9].env_stage==3&&a.voice[8].env_stage!=3&&!a.voice[9].ret_period&&!a.voice[9].table_active);samples(&a,1000);assert(active(&a)==2);
 assert(!tr_poly_note_on(&a,0,71));assert(active(&a)==3&&a.voice[9].note==67);assert(!tr_poly_note_on(&a,0,74));assert(active(&a)==3&&a.voice[8].note==71);
 tr_poly_note_off(&a,71);tr_poly_note_off(&a,74);tr_poly_note_off(&a,67);samples(&a,1000);assert(!active(&a));
 assert(!tr_poly_select(&a,8));assert(!tr_poly_note_on(&a,0,60));assert(!tr_poly_select(&a,0));assert(!active(&a));assert(tr_poly_select(&a,9)<0);assert(tr_poly_note_on(&a,0,60)<0);
 puts("PASS live three-note overlap, individual Note Off, independent phase/envelopes, inactive-first/oldest stealing, track selection/off, invalid track");
 setup(&a,17,1);a.project.phrases[0].step[1]=(TrStep){TR_OFF,255,{{0,0},{0,0}}};tr_transport(&a,1);samples(&a,7000);assert(!active(&a)||active(&a)==7);assert(!a.voice[0].active&&!a.voice[8].active&&!a.voice[9].active);
 setup(&a,10,1);a.project.instruments[0].table=0;a.project.tables[0].length=1;a.project.tables[0].row[0].fx[0]=(TrFx){FX_RET,1};a.project.tables[0].row[0].fx[1]=(TrFx){FX_INS,0};a.project.phrases[0].step[1]=(TrStep){TR_OFF,255,{{0,0},{0,0}}};tr_transport(&a,1);samples(&a,7000);assert(!a.voice[0].active&&!a.voice[8].active&&!a.voice[9].active);assert(!a.voice[8].ret_period&&!a.voice[9].table_active);
 setup(&a,16,8);a.project.phrases[7].step[1]=(TrStep){255,255,{{FX_KIL,0},{0,0}}};tr_transport(&a,1);samples(&a,5000);assert(!a.voice[7].active&&!a.voice[8].active&&!a.voice[9].active);
 setup(&a,10,1);a.project.phrases[0].step[1]=(TrStep){255,255,{{FX_CUT,51},{0,0}}};tr_transport(&a,1);samples(&a,4500);assert(a.voice[0].cutoff==51&&a.voice[8].cutoff==51&&a.voice[9].cutoff==51);
 setup(&a,10,1);tr_transport(&a,1);samples(&a,1);a.project.tables[0].length=a.project.tables[1].length=1;a.project.tables[0].row[0].fx[0]=(TrFx){FX_CUT,25};a.project.tables[1].row[0].fx[0]=(TrFx){FX_CUT,205};
 for(unsigned v=0;v<3;v++){TrVoice *q=&a.voice[v?7+v:0];q->table_active=1;q->table_id=v?1:0;q->table_row=q->table_wait=0;}
 tr_tick(&a);assert(a.voice[0].cutoff==25&&a.voice[8].cutoff==205&&a.voice[9].cutoff==205);
 a.project.tables[1].row[0].fx[0]=(TrFx){FX_OFF,0};a.voice[8].table_wait=0;a.voice[9].table_active=0;tr_tick(&a);assert(a.voice[8].env_stage==3&&a.voice[0].env_stage!=3&&a.voice[9].env_stage!=3);
 setup(&a,10,1);a.project.phrases[0].step[1]=(TrStep){62,0,{{FX_CHD,0},{FX_VOL,77}}};tr_transport(&a,1);samples(&a,4500);assert(a.voice[0].volume==77&&a.voice[8].volume==a.project.instruments[0].volume&&a.voice[9].volume==a.project.instruments[0].volume);
 puts("PASS independent Table timbre/release and note velocity; Phrase cutoff controls group, VOL preserves older notes");
 // Releasing a physically held key must not release a later sequencer note of the same pitch.
 assert(!tr_poly_note_on(&a,0,48));a.voice[0].live_note=0;a.voice[0].env_stage=2;tr_poly_note_off(&a,48);assert(a.voice[0].env_stage==2);
 tr_transport(&a,0);assert(!active(&a));puts("PASS group OFF/KIL, no stuck extra voices after Stop");
 printf("RAM: Tracker %zu bytes; voice %zu; render workspace %zu. Hardware timing remains unverified.\n",sizeof(Tracker),sizeof(TrVoice),sizeof(TrRender));
 return 0;
}
