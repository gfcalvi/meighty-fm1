/* Actual device adapter against the pre-existing per-sample resampler. */
#define main previous_device_tests
#include "test_device.c"
#undef main
#include "../app/tracker/device.c"
static Tracker oracle;
static TrVoice oracle_preview;
static int32_t output[514];
int main(void){
 memset(store_flash,255,sizeof store_flash);tracker_device_init();tracker_ui_play(1);
 oracle=tracker;oracle_preview=audition;unsigned phase=rate_phase;int16_t last[2]={0,0};unsigned count=0;
 for(unsigned block=0;block<2000;block++){
  unsigned frames=1+(block*137U)%257U;
  tracker_device_render(output,frames);
  for(unsigned f=0;f<frames;f++){
   phase+=TR_RATE;
   if(phase>=44100){phase-=44100;tr_sample_stereo(&oracle,tr_audition_sample(&oracle,&oracle_preview,audition_channel),audition_channel,last);}
   assert(output[f*2]==(int32_t)last[0]*256);assert(output[f*2+1]==(int32_t)last[1]*256);count++;
  }
  assert(rate_phase==phase);assert(!memcmp(&tracker,&oracle,sizeof oracle));assert(!memcmp(&audition,&oracle_preview,sizeof audition));
 }
 printf("PASS device block resampler: %u output frames exactly match scalar 32000/44100 phase and full state across 2000 varying buffer sizes\n",count);
 assert(!tracker_ui_select(0,0,0,0,0));
 for(unsigned order=0;order<2;order++)for(unsigned mask=0;mask<4;mask++){
  uint8_t mute=(mask&1)?0x12:0,solo=(mask&2)?0x24:0;
  tracker.project.mute_mask=mute;tracker.project.solo_mask=solo;
  unsigned sequence[]={0,order?2U:1U,3,order?1U:2U,0,0};
  for(unsigned s=0;s<6;s++){controls.buttons=sequence[s];if(!tracker_device_diagnostic_buttons(controls.buttons))tracker_device_control();}
  assert(tracker.project.mute_mask==mute);assert(tracker.project.solo_mask==solo);
 }
 puts("PASS diagnostics OCT chord preserves mute/solo on staggered press/release in either order");return 0;
}
