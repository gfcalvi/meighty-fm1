/* Hold the producer just before retirement until the consumer has mixed.
 * A join-before-mix regression fails the bounded wait rather than hanging. */
#define main poly3_original_tests
#include "test_poly3.c"
#undef main
#include <stdatomic.h>
#include <time.h>
#include <sched.h>
static pthread_t consumer;
static atomic_uint producer_clock_calls,mixing,held;
static atomic_uint slow_ticks,slow_jobs,slow_joins;
static void *slow_entry(void *unused){(void)unused;struct timespec delay={0,5000000};nanosleep(&delay,0);atomic_fetch_add(&slow_jobs,1);job_fn(job_arg);return 0;}
static int slow_submit(void (*fn)(void *),void *arg){job_fn=fn;job_arg=arg;assert(!pthread_create(&worker,0,slow_entry,0));return 1;}
static void slow_join(void){atomic_fetch_add(&slow_joins,1);assert(!pthread_join(worker,0));}
static uint32_t slow_clock(void){return atomic_fetch_add(&slow_ticks,96000);}
static uint64_t wall_ns(void){struct timespec ts;assert(!clock_gettime(CLOCK_MONOTONIC,&ts));return (uint64_t)ts.tv_sec*1000000000ULL+ts.tv_nsec;}
static uint32_t stream_clock(void){
 if(pthread_equal(pthread_self(),consumer)){if(a.effects.meter_clock)atomic_store(&mixing,1);}
 else if(atomic_fetch_add(&producer_clock_calls,1)==1){
  uint64_t until=wall_ns()+2000000000ULL;
  while(!atomic_load(&mixing)){assert(wall_ns()<until);sched_yield();}
  atomic_store(&held,1);
 }
 return (uint32_t)(wall_ns()/1000U)*24U;
}
int main(void){
 setup(&a,16,8);tr_transport(&a,1);b=a;consumer=pthread_self();
 memset(&work,0,sizeof work);work.submit=submit;work.join=join;work.clock=stream_clock;
 int16_t streamed[186],scalar[186];tr_render_stereo(&a,&preview,8,streamed,93,&work);
 assert(atomic_load(&held)&&atomic_load(&mixing));
 for(unsigned f=0;f<93;f++)tr_sample_stereo(&b,0,8,scalar+f*2);
 assert(!memcmp(streamed,scalar,sizeof scalar));assert(!memcmp(&a,&b,sizeof a));
 puts("PASS consumer mixes before producer retires; bounded handoff, exact10voice audio/full state");
 setup(&a,17,8);tr_transport(&a,1);b=a;memset(&work,0,sizeof work);work.submit=slow_submit;work.join=slow_join;work.clock=slow_clock;
 tr_render_stereo(&a,&preview,8,streamed,93,&work);
 for(unsigned f=0;f<93;f++)tr_sample_stereo(&b,0,8,scalar+f*2);
 assert(atomic_load(&slow_jobs)==1&&atomic_load(&slow_joins)==1);
 assert(!memcmp(streamed,scalar,sizeof scalar));assert(!memcmp(&a,&b,sizeof a));
 puts("PASS delayed worker takes bounded join path exactly once, no DSP retry, exact audio/full state");return 0;
}
