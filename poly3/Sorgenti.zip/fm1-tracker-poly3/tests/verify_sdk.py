#!/usr/bin/env python3
"""Verify the unchanged vendor SDK; never rewrite hashes to accept changes."""
import hashlib
import json
from pathlib import Path
root = Path(__file__).resolve().parent.parent
manifest = json.loads((root / 'sdk/manifest.json').read_text())
for name, expected in manifest['files'].items():
    actual = hashlib.sha256((root / name).read_bytes()).hexdigest()
    if actual != expected:
        raise SystemExit(f'SDK integrity failure: {name}')
print(f"PASS: {len(manifest['files'])} official SDK files unchanged")
