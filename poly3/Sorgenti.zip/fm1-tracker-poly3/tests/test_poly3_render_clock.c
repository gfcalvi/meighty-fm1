#define main poly3_original_tests
#include "test_poly3.c"
#undef main
#include <stdatomic.h>
static atomic_uint fake_ticks;
static uint32_t fake_clock(void){return atomic_fetch_add(&fake_ticks,17);}
int main(void){
 assert(!poly3_original_tests());
 setup(&a,17,8);tr_transport(&a,1);b=a;
 int16_t timed[514],plain[514];memset(&work,0,sizeof work);work.submit=submit;work.join=join;work.clock=fake_clock;atomic_store(&fake_ticks,UINT32_MAX-8U);
 tr_render_stereo(&a,&preview,8,timed,257,&work);
 for(unsigned i=0;i<5;i++)assert(work.timing[i]>0);
 work.clock=0;tr_render_stereo(&b,&preview,8,plain,257,&work);
 assert(!memcmp(timed,plain,sizeof plain));assert(!memcmp(&a,&b,sizeof a));
 puts("PASS coarse profiling across both cores and timer wrap; all5 stages populated, audio/full DSP state unchanged");return 0;
}
