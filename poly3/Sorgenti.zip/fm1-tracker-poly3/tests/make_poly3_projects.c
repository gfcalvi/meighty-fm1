#define main fixture_main
#include "test_device.c"
#undef main
static TrProject project;
static void init(void){tr_project_init(&project);for(unsigned i=0;i<32;i++){project.instrument_source[i]=1;snprintf(project.instrument_names[i],16,"Init %02X",i);}project.poly_track=8;project.reverb_mode=1;}
static void write_project(const char *name){assert(tracker_ui_project_valid(&project));char path[200];snprintf(path,sizeof path,"../../Candidata-Poly3/%s.project.bin",name);FILE *f=fopen(path,"wb");assert(f);assert(fwrite(&project,1,sizeof project,f)==sizeof project);fclose(f);printf("%s %zu bytes\n",path,sizeof project);}
int main(void){
 init();project.bpm=300;project.song_length=32;uint8_t master[]={7,180,1,130,218,150,110,96};memcpy(project.master,master,8);
 for(unsigned i=0;i<18;i++){
  project.instruments[i]=(TrInstrument){i,255,145,210,128,255,1,0};snprintf(project.instrument_names[i],16,"Stress %s",tr_model_name(i));uint8_t *s=project.sound[i];
  s[0]=1;s[1]=0;s[2]=40;s[3]=220;s[4]=25;s[5]=110;s[6]=1;s[9]=127;s[12]=145;s[13]=130;s[14]=155;s[15]=140;s[16]=93;s[18]=128;s[19]=110;s[20]=126;s[21]=105;s[22]=120;
  project.cutoff_env[i][0]=1;project.cutoff_env[i][1]=2;project.cutoff_env[i][2]=65;project.cutoff_env[i][3]=180;project.cutoff_env[i][5]=185;
 }
 for(unsigned t=0;t<8;t++)project.mixer[t]=(TrMix){100,30+t*28,155,140};
 for(unsigned r=0;r<32;r++){
  project.chains[r].length=1;project.chains[r].phrase[0]=r;for(unsigned t=0;t<8;t++)project.song[r][t]=r;
  for(unsigned s=0;s<16;s++)project.phrases[r].step[s]=(TrStep){(uint8_t)(48+(s%4)*3),(uint8_t)(r%18),{{FX_CHD,0x47},{FX_CUT,(uint8_t)(120+s*8)}}};
 }write_project("Poly3-Stress-10-voices");
 init();project.poly_track=4;project.bpm=94;project.song_length=4;project.master[0]=7;project.master[1]=100;project.master[3]=120;project.master[4]=218;project.master[6]=120;project.master[7]=210;
 project.instruments[0]=(TrInstrument){10,255,155,77,128,255,1,0};strcpy(project.instrument_names[0],"Poly3 Juno pad");uint8_t *s=project.sound[0];s[0]=1;s[1]=65;s[2]=110;s[3]=190;s[4]=95;s[5]=24;s[6]=1;s[7]=100;s[8]=76;s[9]=13;s[13]=130;s[14]=139;
 project.mixer[3]=(TrMix){135,128,70,125};project.chains[31].length=1;project.chains[31].phrase[0]=63;project.phrases[63].step[0].note=TR_OFF;
 const unsigned root[]={50,48,46,48},chord[]={0x37,0x47,0x47,0x47};
 for(unsigned r=0;r<4;r++){project.chains[r].length=1;project.chains[r].phrase[0]=r;for(unsigned t=0;t<8;t++)project.song[r][t]=t==3?r:31;project.phrases[r].step[0]=(TrStep){root[r],0,{{FX_CHD,chord[r]},{0,0}}};project.phrases[r].step[8].note=TR_OFF;}
 write_project("Poly3-Pad-one-track");return 0;
}
