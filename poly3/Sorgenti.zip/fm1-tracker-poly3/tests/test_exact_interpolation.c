/* The original signed 64-bit formulas are the independent oracle. */
#include "../app/tracker/tracker.c"
#include "wt-A9-reference.inc"
#include <assert.h>
#include <stdio.h>
static unsigned long long checks;
static int32_t oracle(int32_t d,uint32_t f,unsigned bits){return (int32_t)(((int64_t)d*f)/(INT64_C(1)<<bits));}
static void check(int32_t d,uint32_t f,unsigned bits){assert(tr_lerp_delta(d,f,bits)==oracle(d,f,bits));checks++;}
int main(void){
 static const uint32_t fractions[]={0,1,127,128,255,256,32767,32768,65534,65535,65536,0x7fffff,0x800000,0xfffffe,0xffffff};
 for(int32_t d=-65535;d<=65535;d++)for(unsigned bits=8;bits<=24;bits+=8)
  for(unsigned i=0;i<sizeof fractions/sizeof fractions[0];i++)check(d,fractions[i]&((1U<<bits)-1),bits);
 uint32_t random=0x13576bcd;
 for(unsigned k=0;k<1000000;k++){random=random*1664525U+1013904223U;int32_t d=(int32_t)(random%131071U)-65535;random=random*1664525U+1013904223U;check(d,random&0xffffff,24);}
 for(unsigned n=0;n<256;n++)for(unsigned k=0;k<sizeof fractions/sizeof fractions[0];k++){
  uint32_t p=(n<<24)|fractions[k];
  assert(sound_sine(p)==wav_sine[n]+oracle(wav_sine[n+1]-wav_sine[n],p&0xffffff,24));checks++;
  assert(lut_bell[n]+tr_lerp_delta((int32_t)lut_bell[n+1]-lut_bell[n],p&0xffffff,24)==lut_bell[n]+oracle((int32_t)lut_bell[n+1]-lut_bell[n],p&0xffffff,24));checks++;
 }
 static const uint32_t increments[]={0,0x02666667,0x04cccccd,0x0999999a,0x13333334,0x26666667};
 for(unsigned bank=0;bank<4;bank++)for(unsigned mip=0;mip<6;mip++)for(unsigned pos=0;pos<256;pos++)for(unsigned k=0;k<65;k++){
  random=random*1664525U+1013904223U;uint32_t phase=k==64?UINT32_MAX:random;
  assert(wt_wave(bank,phase,increments[mip],pos)==wt_wave_reference(bank,phase,increments[mip],pos));checks++;
 }
 for(int pitch=-1;pitch<=32768;pitch++){
  unsigned x=(unsigned)bounded(pitch,0,32767)*2U,n=x>>8;
  assert(eng_table(lut_svf_cutoff,pitch)==lut_svf_cutoff[n]+oracle((int)lut_svf_cutoff[n+1]-lut_svf_cutoff[n],x&255,8));
  assert(eng_table(lut_svf_damp,pitch)==lut_svf_damp[n]+oracle((int)lut_svf_damp[n+1]-lut_svf_damp[n],x&255,8));checks+=2;
 }
 printf("PASS %llu exact interpolation checks: all131071 endpoint deltas,8/16/24-bit boundary fractions,1M random24-bit fractions,sine/bell wrap,4banks x6mips x256positions x65phases and clamped Braids tables vs frozen signed64-bit formulas\n",checks);return 0;
}
