/* Reuse the tested simulated panel/NOR adapter, and exercise the real preset API. */
#define main previous_device_tests
#include "test_device.c"
#undef main
#include <stdint.h>
static void save_project(const char *name){char path[256];snprintf(path,sizeof path,"../../work/atmosphere/%s.project.bin",name);FILE *f=fopen(path,"wb");assert(f);assert(fwrite(tracker_ui_project(),1,sizeof(TrProject),f)==sizeof(TrProject));fclose(f);}
static void silence_arrangement(TrProject *p){memset(p->song,255,sizeof p->song);p->song_length=1;for(unsigned n=0;n<64;n++)for(unsigned r=0;r<16;r++)p->phrases[n].step[r]=(TrStep){255,255,{{0,0},{0,0}}};for(unsigned n=0;n<32;n++){memset(p->chains[n].phrase,255,16);p->chains[n].length=1;}p->mute_mask=p->solo_mask=0;}
static void wav_header(FILE *f,unsigned frames){fwrite("RIFF",1,4,f);uint32_t x=36+frames*4;fwrite(&x,4,1,f);fwrite("WAVEfmt ",1,8,f);x=16;fwrite(&x,4,1,f);uint16_t y=1;fwrite(&y,2,1,f);y=2;fwrite(&y,2,1,f);x=44100;fwrite(&x,4,1,f);x=176400;fwrite(&x,4,1,f);y=4;fwrite(&y,2,1,f);y=16;fwrite(&y,2,1,f);fwrite("data",1,4,f);x=frames*4;fwrite(&x,4,1,f);}
int main(void){
 memset(store_flash,255,sizeof store_flash);tracker_device_init();tracker_ui_play(0);assert(tracker_ui_preset_count()==177);
 static TrProject before,after,patch;static uint32_t fingerprints[100];unsigned engines[18]={0};int32_t audio[256];
 FILE *metrics=fopen("../../work/atmosphere/preset-metrics.csv","w");assert(metrics);fputs("id,name,model,peak,dry_mean_square,stereo_difference,hash\n",metrics);
 for(unsigned id=77;id<177;id++){
  before=*tracker_ui_project();assert(!tracker_ui_preset_load(0,id));assert(tracker_ui_project_valid(tracker_ui_project()));assert(tracker_ui_preset_match(0)==(int)id);
  const TrProject *p=tracker_ui_project();assert(p->instrument_source[0]==1&&p->instruments[0].table==255&&p->sound[0][0]==1&&p->cutoff_env[0][0]==1);assert(strlen(tracker_ui_instrument_name(0))<=15);
  for(unsigned j=77;j<id;j++)assert(strcmp(tracker_ui_preset_name(j),tracker_ui_preset_name(id)));
  ++engines[p->instruments[0].model];after=*p;after.instruments[0]=before.instruments[0];after.instrument_source[0]=before.instrument_source[0];memcpy(after.instrument_names[0],before.instrument_names[0],16);memcpy(after.sound[0],before.sound[0],TR_SOUND_FIELDS);memcpy(after.cutoff_env[0],before.cutoff_env[0],6);memcpy(after.engine[0],before.engine[0],32);memcpy(after.wt_lfo[0],before.wt_lfo[0],4);assert(!memcmp(&before,&after,sizeof before));
  patch=*p;silence_arrangement(&patch);patch.master[3]=patch.master[6]=0;for(unsigned ch=0;ch<8;ch++)patch.mixer[ch].delay=patch.mixer[ch].reverb=0;assert(!tracker_ui_project_apply(&patch));assert(!tracker_ui_select(4,0,0,70,0));tracker_ui_audition(60);
  uint64_t square=0,difference=0;unsigned peak=0,hash=2166136261U;for(unsigned b=0;b<2068;b++){tracker_device_render(audio,128);for(unsigned n=0;n<256;n++){int v=audio[n]/256;assert(v>=-32768&&v<=32767);unsigned a=(unsigned)(v<0?-v:v);if(a>peak)peak=a;hash=(hash^(uint16_t)v)*16777619U;if(b>1200)square+=(int64_t)v*v;}if(b>1200)for(unsigned n=0;n<256;n+=2)difference+=(uint64_t)(audio[n]>audio[n+1]?audio[n]-audio[n+1]:audio[n+1]-audio[n]);}
  assert(peak>20&&square>100000&&difference>0);for(unsigned n=0;n<id-77;n++)assert(fingerprints[n]!=hash);fingerprints[id-77]=hash;
  fprintf(metrics,"%02X,%s,%u,%u,%.3f,%llu,%08X\n",id,tracker_ui_preset_name(id),patch.instruments[0].model,peak,(double)square/(867*256),(unsigned long long)difference,hash);fflush(metrics);
  tracker_ui_audition(-1);for(unsigned b=0;b<2300;b++)tracker_device_render(audio,128);for(unsigned n=0;n<256;n++)assert(!audio[n]);
  if((id-77)%10==0){assert(!tracker_ui_project_save(0));assert(!tracker_ui_set(4,0,0,10,0));assert(!tracker_ui_project_load(0));assert(tracker_ui_preset_match(0)==(int)id);}
 }
 fclose(metrics);assert(engines[17]==60&&engines[16]==20);unsigned braids=0;for(unsigned n=5;n<13;n++)braids+=engines[n];assert(braids==20);
 puts("PASS Atmosphere 100: names unique, 60 dual WT/20 FM4/20 Braids, valid full patches, unchanged other instruments/song/tables/mixer/FX, 100 distinct dry audio fingerprints, stereo motion, clean release and saved patch roundtrip");
 assert(!tracker_ui_preset_load(0,77));assert(!tracker_ui_select(4,0,0,70,0));controls.buttons=0;tracker_device_control();controls.buttons=1U<<10;tracker_device_control();controls.buttons=0;tracker_device_control();assert(tracker_ui_state(18)==77);controls.encoders[3]=9;tracker_device_control();assert(tracker_ui_state(18)==167);capture("atmosphere-family");controls.encoders[5]=9;tracker_device_control();assert(tracker_ui_state(18)==176);capture("atmosphere-last");controls.buttons=1U<<13;tracker_device_control();assert(!strcmp(tracker_ui_instrument_name(0),"Last Light"));controls.buttons=0;tracker_device_control();assert(tracker_ui_preset_match(0)==176);
 puts("PASS catalog: K2 family jump, K4 reaches B0, REC loads full Last Light patch and match survives browsing");
 /* Four 25-instrument projects: every Song row auditions one pad for six seconds, then releases for two. */
 for(unsigned bank=0;bank<4;bank++){
  tracker_ui_demo(0);for(unsigned i=0;i<25;i++)assert(!tracker_ui_preset_load(i,77+bank*25+i));patch=*tracker_ui_project();silence_arrangement(&patch);patch.song_length=25;
  for(unsigned i=0;i<25;i++){patch.song[i][0]=(uint8_t)i;patch.chains[i].length=4;patch.chains[i].phrase[0]=(uint8_t)i;patch.chains[i].phrase[1]=patch.chains[i].phrase[2]=63;patch.chains[i].phrase[3]=62;patch.phrases[i].step[0]=(TrStep){48,(uint8_t)i,{{0,0},{0,0}}};}
  patch.phrases[62].step[0]=(TrStep){254,255,{{0,0},{0,0}}};patch.reverb_mode=1;patch.master[0]=7;patch.master[1]=130;patch.master[2]=1;patch.master[3]=80;patch.master[4]=200;patch.master[5]=130;patch.master[6]=150;patch.mixer[0].delay=40;patch.mixer[0].reverb=85;assert(!tracker_ui_project_apply(&patch));char name[16];snprintf(name,sizeof name,"Bank-%c",'A'+bank);save_project(name);
 }
 puts("PASS generated four independent 25-pad audition projects, valid 4-Phrase sections and release events");
 /* A short musical preview: one chord per family, six seconds held and four seconds release. */
 FILE *wav=fopen("../../work/atmosphere/Atmosphere-10-Famiglie.wav","wb");assert(wav);wav_header(wav,10*10*44100);
 for(unsigned family=0;family<10;family++){
  tracker_ui_demo(0);assert(!tracker_ui_preset_load(0,77+family*10));patch=*tracker_ui_project();silence_arrangement(&patch);patch.master[3]=0;patch.master[6]=120;patch.master[4]=185;patch.reverb_mode=1;
  for(unsigned ch=0;ch<4;ch++){patch.song[0][ch]=(uint8_t)ch;patch.chains[ch].length=8;patch.chains[ch].phrase[0]=(uint8_t)ch;for(unsigned n=1;n<8;n++)patch.chains[ch].phrase[n]=63;patch.phrases[ch].step[0]=(TrStep){(uint8_t)((unsigned[]){48,55,60,64})[ch],0,{{0,0},{0,0}}};patch.phrases[ch].step[1]=(TrStep){255,255,{{FX_LEV,150},{FX_RSN,75}}};patch.phrases[ch].step[2]=(TrStep){255,255,{{FX_PAN,(uint8_t)(32+ch*60)},{0,0}}};}
  patch.phrases[62].step[0]=(TrStep){254,255,{{0,0},{0,0}}};for(unsigned ch=0;ch<4;ch++)patch.chains[ch].phrase[3]=62;
  assert(!tracker_ui_project_apply(&patch));tracker_ui_play(1);
  for(unsigned n=0;n<441000;n+=128){
   unsigned frames=441000-n<128?441000-n:128;tracker_device_render(audio,frames);for(unsigned k=0;k<frames*2;k++){int16_t sample=(int16_t)(audio[k]/256);fwrite(&sample,2,1,wav);}
  }
 }
 fclose(wav);puts("PASS rendered ten family chords through actual synth/filter/LFO/FX paths");return 0;
}
