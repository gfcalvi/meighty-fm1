/* Frozen A8 delay/reverb formulas are the independent oracle. */
#include "../app/tracker/tracker.c"
#include <assert.h>
#include <stdio.h>
#define comb_lengths ref_comb_lengths
#define ap_lengths ref_ap_lengths
#define delay_names ref_delay_names
#define tr_delay_name ref_tr_delay_name
#define tr_delay_frames ref_tr_delay_frames
#define tr_project_mixer_defaults ref_tr_project_mixer_defaults
#define mix_value_hot ref_mix_value_hot
#define tr_mixer_value ref_tr_mixer_value
#define tr_effects_reset ref_tr_effects_reset
#define fx_read ref_fx_read
#define approach ref_approach
#define ambient_sample ref_ambient_sample
#define tr_effects_sample ref_tr_effects_sample
#include "reference-A8/effects.inc"
#undef tr_effects_sample
static Tracker a,b;
int main(void){
 tr_init(&a);b=a;uint32_t random=0x71429b37;unsigned cases=0;
 for(unsigned n=0;n<96000;n++){
  if(!(n%113)){
   for(unsigned k=0;k<8;k++){random=random*1664525U+1013904223U;a.project.master[k]=(uint8_t)(random>>24);}
   a.project.master[0]=(uint8_t)((n/113)%18);a.project.bpm=n%226?30:300;a.project.reverb_mode=(n/113)&1;b.project=a.project;
  }
  int32_t in[4],x[2],y[2];
  for(unsigned k=0;k<4;k++){random=random*1664525U+1013904223U;in[k]=(int32_t)(random&131071)-65536;}
  tr_effects_sample(&a,in[0],in[1],in[2],in[3],x);ref_tr_effects_sample(&b,in[0],in[1],in[2],in[3],y);
  assert(!memcmp(x,y,sizeof x));assert(!memcmp(&a.effects,&b.effects,sizeof a.effects));cases++;
 }
 printf("PASS frozen A8 effects oracle: %u stereo wet frames, all18 divisions, signed inputs, tempo30/300, room/ambient transitions, feedback/damping/ping/smoothing and complete persistent FX state\n",cases);return 0;
}
