#include "tracker/tracker.h"
#include <assert.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
static Tracker t;static TrVoice preview;static TrRender work;
static pthread_t worker;static pthread_mutex_t mutex=PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t ready=PTHREAD_COND_INITIALIZER,done=PTHREAD_COND_INITIALIZER;
static int pending,stop;static void (*job)(void *);static void *argument;
static void *run(void *ignored){(void)ignored;assert(!pthread_mutex_lock(&mutex));for(;;){while(!pending&&!stop)assert(!pthread_cond_wait(&ready,&mutex));if(stop)break;void (*fn)(void *)=job;void *arg=argument;assert(!pthread_mutex_unlock(&mutex));fn(arg);assert(!pthread_mutex_lock(&mutex));pending=0;assert(!pthread_cond_signal(&done));}assert(!pthread_mutex_unlock(&mutex));return 0;}
static int submit(void (*fn)(void *),void *arg){assert(!pthread_mutex_lock(&mutex));assert(!pending);job=fn;argument=arg;pending=1;assert(!pthread_cond_signal(&ready));assert(!pthread_mutex_unlock(&mutex));return 1;}
static void join(void){assert(!pthread_mutex_lock(&mutex));while(pending)assert(!pthread_cond_wait(&done,&mutex));assert(!pthread_mutex_unlock(&mutex));}
int main(int argc,char **argv){assert(argc==2);tr_init(&t);FILE *f=fopen(argv[1],"rb");assert(f);assert(fread(&t.project,1,sizeof t.project,f)==sizeof t.project);fclose(f);assert(t.project.poly_track==8);
 for(unsigned i=0;i<32;i++){t.project.instruments[i].volume=255;t.project.sound[i][3]=255;t.project.sound[i][5]=255;}
 for(unsigned i=0;i<8;i++)t.project.mixer[i]=(TrMix){255,30+i*28,255,255};
 t.project.master[3]=t.project.master[6]=t.project.master[7]=255;t.project.master[4]=224;
 tr_transport(&t,1);tr_audition_on(&t,&preview,0,16,74);work.submit=submit;work.join=join;assert(!pthread_create(&worker,0,run,0));
 unsigned peak=0,mask=0,maxVoices=0,lastSecond=~0U;uint64_t hash=1469598103934665603ULL;int16_t audio[186];
 for(unsigned frames=0;frames<60U*32000U;){unsigned n=60U*32000U-frames;if(n>93)n=93;unsigned second=frames/32000;
  if(second!=lastSecond){lastSecond=second;t.project.bpm=second&1?30:300;t.project.master[0]=second%18;t.project.master[1]=second&1?240:0;t.project.master[2]=second&1;t.project.master[5]=second&1?0:255;}
  tr_render_stereo(&t,&preview,0,audio,n,&work);unsigned count=0;for(unsigned v=0;v<10;v++){count+=!!t.voice[v].active;assert(t.voice[v].model<18);mask|=1U<<t.voice[v].model;}if(count>maxVoices)maxVoices=count;
  for(unsigned i=0;i<n*2;i++){unsigned a=abs(audio[i]);if(a>peak)peak=a;hash=(hash^(uint16_t)audio[i])*1099511628211ULL;}frames+=n;
 }
 assert(!pthread_mutex_lock(&mutex));stop=1;assert(!pthread_cond_signal(&ready));assert(!pthread_mutex_unlock(&mutex));assert(!pthread_join(worker,0));assert(maxVoices==10&&preview.active&&mask==((1U<<18)-1));
 printf("PASS native60s/1920000frames, persistent pthread worker, 10voices+preview, all18models, max mixer/sends/master/resonance, feedback0/240, damping0/255, all18delay divisions, tempo30/300; peak%u hash%016llx. NOT a PI32 timing measurement.\n",peak,(unsigned long long)hash);return 0;
}
