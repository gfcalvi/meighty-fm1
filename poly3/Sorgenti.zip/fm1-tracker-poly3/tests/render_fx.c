/* SPDX-License-Identifier: GPL-3.0-only */
#include "tracker/tracker.h"
#include <stdio.h>
#include <stdint.h>
#include <string.h>
static Tracker t;
static void u16(FILE *f,unsigned v){fputc(v&255,f);fputc((v>>8)&255,f);}
static void u32(FILE *f,unsigned v){u16(f,v);u16(f,v>>16);}
int main(int argc,char **argv){if(argc!=2)return 1;FILE*f=fopen(argv[1],"wb");if(!f)return 2;unsigned frames=14*TR_RATE;fwrite("RIFF",1,4,f);u32(f,36+frames*4);fwrite("WAVEfmt ",1,8,f);u32(f,16);u16(f,1);u16(f,2);u32(f,TR_RATE);u32(f,TR_RATE*4);u16(f,4);u16(f,16);fwrite("data",1,4,f);u32(f,frames*4);
 tr_init(&t);t.project.song[0][0]=0;t.project.chains[0].phrase[0]=0;t.project.instruments[0]=(TrInstrument){2,255,220,230,128,255,16,0};t.project.instrument_source[0]=1;unsigned notes[]={60,64,67,72};for(unsigned n=0;n<4;n++){TrStep *s=&t.project.phrases[0].step[n*4];s->note=(uint8_t)notes[n];s->instrument=0;}
 t.project.master[0]=7;t.project.master[1]=110;t.project.master[2]=1;t.project.master[3]=210;t.project.master[6]=180;tr_transport(&t,1);
 for(unsigned n=0;n<frames;n++){if(n==2*TR_RATE)t.project.mixer[0].delay=190;if(n==6*TR_RATE){t.project.mixer[0].delay=135;t.project.mixer[0].reverb=190;}if(n==8*TR_RATE){t.project.phrases[0].step[4].fx[0]=(TrFx){FX_PAN,0};t.project.phrases[0].step[12].fx[0]=(TrFx){FX_PAN,255};}if(n==10*TR_RATE)for(unsigned s=0;s<16;s++){t.project.phrases[0].step[s].note=255;memset(t.project.phrases[0].step[s].fx,0,sizeof t.project.phrases[0].step[s].fx);}
  int16_t out[2];tr_sample_stereo(&t,0,8,out);u16(f,(uint16_t)out[0]);u16(f,(uint16_t)out[1]);}
 fclose(f);return 0;}
