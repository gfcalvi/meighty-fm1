#define main poly3_original_tests
#include "test_poly3.c"
#undef main
static int16_t pcm[8192];
int main(void){
 for(unsigned n=0;n<8192;n++)pcm[n]=(int16_t)(n*17513U);
 for(unsigned model=0;model<19;model++)for(unsigned track=1;track<=8;track++)for(unsigned ch=0;ch<8;ch++)for(unsigned on=0;on<2;on++){
  setup(&a,model%18,track);
  if(model==18){TrSample sample={pcm,8192,22050,60};assert(!tr_set_sample(&a,0,&sample));for(unsigned i=0;i<32;i++){a.project.instrument_source[i]=2;a.project.instruments[i].sample=0;}}
  for(unsigned c=0;c<8;c++)a.project.mixer[c]=(TrMix){(uint8_t)(70+c*23),(uint8_t)(17+c*31),173,191};
  tr_transport(&a,1);TrVoice pa,pb;tr_audition_on(&a,&pa,ch,0,74);if(!on)pa.active=0;b=a;pb=pa;
  memset(&work,0,sizeof work);work.submit=submit;work.join=join;
  int16_t scalar[186],threaded[186];for(unsigned f=0;f<93;f++)tr_sample_stereo(&a,tr_audition_sample(&a,&pa,ch),ch,scalar+f*2);
  tr_render_stereo(&b,&pb,ch,threaded,93,&work);
  assert(!memcmp(scalar,threaded,sizeof scalar));assert(!memcmp(&a,&b,sizeof a));assert(!memcmp(&pa,&pb,sizeof pa));
 }
 puts("PASS 2432 live cases:19models inclPCM x8poly tracks x8preview channels xactive/inactive; exact scalar/threaded audio, voice+preview send rounding and full state");return 0;
}
