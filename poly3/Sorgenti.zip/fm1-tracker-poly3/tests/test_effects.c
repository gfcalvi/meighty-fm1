/* SPDX-License-Identifier: GPL-3.0-only */
#include "tracker/tracker.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
static Tracker t;
static void defaults(void){tr_init(&t);t.project.master[3]=255;t.project.master[6]=0;t.project.master[1]=0;t.project.master[2]=0;tr_effects_reset(&t);}
static void musical(void){
 const unsigned bpms[]={30,60,120,300};
 for(unsigned b=0;b<4;b++)for(unsigned d=0;d<18;d++){
  defaults();t.project.bpm=bpms[b];t.project.master[0]=(uint8_t)d;tr_effects_reset(&t);
  unsigned base=d/3,variant=d%3;uint64_t numerator=8000ULL*60*2,denominator=(uint64_t)bpms[b]*(1U<<base);if(variant==1){numerator*=3;denominator*=2;}if(variant==2){numerator*=2;denominator*=3;}unsigned expected=(unsigned)(numerator/denominator);assert(tr_delay_frames(bpms[b],d)==expected);
  int32_t out[2];for(unsigned n=0;n<=expected;n++){tr_effects_sample(&t,n?0:12000,0,0,0,out);if(n<expected)assert(out[0]==0&&out[1]==0);else assert(out[0]==12000&&out[1]==0);}
 }
}
static void pingpong(void){
 defaults();t.project.master[0]=6;t.project.master[1]=128;t.project.master[2]=1;tr_effects_reset(&t);unsigned period=tr_delay_frames(120,6);int32_t out[2];
 for(unsigned n=0;n<=period*3;n++){tr_effects_sample(&t,n?0:12000,n?0:12000,0,0,out);if(n==period)assert(out[0]==12000&&out[1]==0);if(n==period*2)assert(out[0]==0&&out[1]==12000*128/255);if(n==period*3)assert(out[0]>2800&&out[0]<3200&&out[1]==0);}
}
static void reverb(void){
 defaults();t.project.master[3]=0;t.project.master[6]=255;tr_effects_reset(&t);long long early=0,late=0,difference=0;int32_t out[2];
 for(unsigned n=0;n<32000;n++){tr_effects_sample(&t,0,0,n?0:16000,n?0:16000,out);long long a=llabs(out[0])+llabs(out[1]);if(n<16000)early+=a;else late+=a;difference+=llabs((long long)out[0]-out[1]);assert(abs(out[0])<=65536&&abs(out[1])<=65536);}
 assert(early>10000&&late<early/10&&difference>1000);
 tr_effects_reset(&t);long long stereo_l=0,stereo_r=0;for(unsigned n=0;n<4000;n++){tr_effects_sample(&t,0,0,n?0:12000,0,out);stereo_l+=abs(out[0]);stereo_r+=abs(out[1]);}assert(stereo_l>1000&&stereo_r>1000&&stereo_l!=stereo_r);
 t.project.master[1]=240;t.project.master[4]=224;tr_effects_reset(&t);
 for(unsigned n=0;n<32000;n++){int32_t x=n&1?30000:-30000;tr_effects_sample(&t,x,-x,x,-x,out);assert(abs(out[0])<=65536&&abs(out[1])<=65536);}
 tr_effects_reset(&t);for(unsigned n=0;n<16000;n++){tr_effects_sample(&t,0,0,0,0,out);assert(!out[0]&&!out[1]);}
}
static void route(unsigned pan){
 tr_init(&t);t.project.song[0][0]=0;t.project.chains[0].phrase[0]=0;t.project.phrases[0].step[0].note=60;t.project.phrases[0].step[0].instrument=0;t.project.instruments[0].decay=1;t.project.mixer[0].pan=(uint8_t)pan;tr_transport(&t,1);
}
static void mixer(void){
 for(unsigned side=0;side<3;side++){unsigned pan=side==0?0:side==1?128:255;route(pan);long long l=0,r=0;int16_t out[2];for(unsigned n=0;n<2000;n++){tr_sample_stereo(&t,0,8,out);l+=abs(out[0]);r+=abs(out[1]);if(pan==128)assert(out[0]==out[1]);}assert(pan==0?l>10000&&r==0:pan==255?r>10000&&l==0:l==r&&l>10000);}
 route(128);t.project.phrases[0].step[0].fx[0]=(TrFx){FX_LEV,0};t.project.phrases[0].step[0].fx[1]=(TrFx){FX_DSN,200};int16_t out[2];for(unsigned n=0;n<400;n++){tr_sample_stereo(&t,0,8,out);if(n>128)assert(!out[0]&&!out[1]);}assert(t.project.mixer[0].level==255&&t.project.mixer[0].delay==0&&tr_mixer_value(&t,0,0)==0&&tr_mixer_value(&t,0,2)==200);assert(!t.effects.wet[0]&&!t.effects.wet[1]);
 route(128);t.project.phrases[0].step[0].fx[0]=(TrFx){FX_PAN,255};t.project.phrases[0].step[0].fx[1]=(TrFx){FX_RSN,180};for(unsigned n=0;n<1000;n++)tr_sample_stereo(&t,0,8,out);assert(t.project.mixer[0].pan==128&&t.project.mixer[0].reverb==0&&tr_mixer_value(&t,0,1)==255&&tr_mixer_value(&t,0,3)==180);
 route(128);t.project.master[3]=255;t.project.master[6]=255;t.project.master[0]=15;t.project.master[2]=1;t.project.phrases[0].step[0].fx[0]=(TrFx){FX_DSN,220};t.project.phrases[0].step[0].fx[1]=(TrFx){FX_RSN,200};tr_effects_reset(&t);long long wet=0;for(unsigned n=0;n<10000;n++){tr_sample_stereo(&t,0,8,out);wet+=llabs(t.effects.wet[0])+llabs(t.effects.wet[1]);}assert(wet>10000);
 tr_transport(&t,0);for(unsigned n=0;n<100;n++){tr_sample_stereo(&t,0,8,out);assert(!out[0]&&!out[1]);}
 route(128);t.project.mute_mask=1;for(unsigned n=0;n<500;n++){tr_sample_stereo(&t,0,8,out);if(n>=128)assert(!out[0]&&!out[1]);}route(128);t.project.solo_mask=2;for(unsigned n=0;n<500;n++){tr_sample_stereo(&t,0,8,out);if(n>=128)assert(!out[0]&&!out[1]);}
}
static void meters(void){
 route(128);int16_t out[2];for(unsigned n=0;n<2000;n++){tr_sample_stereo(&t,0,8,out);if(t.effects.peaks[0]>1000)break;}unsigned peak=t.effects.peaks[0];assert(peak>1000);
 t.voice[0].active=0;for(unsigned n=0;n<1600;n++)tr_sample_stereo(&t,0,8,out);assert(t.effects.peaks[0]==peak);
 for(unsigned n=0;n<32000;n++)tr_sample_stereo(&t,0,8,out);assert(t.effects.peaks[0]<peak/20);
 tr_transport(&t,0);assert(!t.effects.peaks[0]&&!t.effects.peak_hold[0]);
 route(128);t.project.mixer[0].level=0;tr_effects_reset(&t);for(unsigned n=0;n<2000;n++)tr_sample_stereo(&t,0,8,out);assert(!t.effects.peaks[0]);
 puts("PASS: meter captures short peaks, holds across LCD frames, decays, clears on Stop and follows post-fader silence");
}
int main(void){musical();pingpong();reverb();mixer();meters();puts("PASS: 72 musical delay timings, feedback echo alternation, stereo reverb decay, bounded stress/reset, pan endpoints, LEV/PAN/DSN/RSN, post-fader sends, mute/solo");}
