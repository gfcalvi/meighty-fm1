/* GPL-3.0-only. Reject unknown parts and capacity variants, even same maker. */
#include <assert.h>
#include <stdio.h>
#include "../hardware/flash_policy.h"
int main(void){
 assert(tr_flash_jedec_known(0x856014));assert(tr_flash_jedec_known(0xB36014));
 for(unsigned id=0;id<0x1000000;id++)
  assert(!!tr_flash_jedec_known(id)==(id==0x856014||id==0xB36014));
 assert(!tr_flash_jedec_known(0xffffffff));assert(!tr_flash_jedec_known(0x1B36014));
 puts("PASS flash policy: both exact 1 MiB IDs, all other 24-bit IDs and high bits refused");
}
