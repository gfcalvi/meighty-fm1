#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/tracker-host
${CC:-cc} -std=c11 -O1 -g -Wall -Wextra -Werror -Wno-unused-function -Iemulator/hal -fsanitize=address,undefined tests/test_ota.c -o build/tracker-host/test_ota
build/tracker-host/test_ota ../FM1-M8-Hardware-HW1.fwsc
${CC:-cc} -std=c11 -O1 -g -Wno-int-to-pointer-cast -Iemulator/hal -fsanitize=address,undefined tests/test_loader.c -o build/tracker-host/test_loader
build/tracker-host/test_loader ../FM1-M8-MultiEngine-INTERACTIVE.fwsc ../FM1-M8-Hardware-HW1.fwsc

${FM1_NODE:-node} tests/test_installer.cjs
${FM1_NODE:-node} tests/test_installer_html.cjs ../FM1-M8-HW1-Installer.html ../FM1-M8-Hardware-HW1.fwsc
${FM1_NODE:-node} tests/test_hardware_projects.cjs

${CC:-cc} -std=c11 -DFM1_HOST_TEST -DTEST_FLASH_BYTES=0x49000 -Wall -Wextra -Werror -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer -Isdk/include -Iapp -Iapp/synth app/tracker/tracker.c app/tracker/commands.c app/tracker/device.c tests/test_device.c -o build/tracker-host/test_hardware_store
build/tracker-host/test_hardware_store
