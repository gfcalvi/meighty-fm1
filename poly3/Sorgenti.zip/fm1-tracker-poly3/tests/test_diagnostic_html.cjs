/* GPL-3.0-only. Exercise the shipped diagnostics UI through actual MIDI framing. */
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const html=fs.readFileSync(process.argv[2],'utf8'),els=new Map(),el=id=>{if(!els.has(id))els.set(id,{disabled:true,textContent:'',checked:false,value:0});return els.get(id);};
let receive,ctx,starts=0;
const input={name:'FM-1 diagnostic test',state:'connected',open:async()=>{},close:async()=>{},addEventListener:(n,f)=>receive=f,removeEventListener:()=>receive=null};
const id=new Uint8Array(27);id.set(Buffer.from('FM-1_998201'));id[16]=68;id[17]=Number(process.argv[3]||2);id[18]=232;id[19]=3;id[20]=3;id[22]=4;id[24]=6;id[25]=128;
const output={name:input.name,state:'connected',open:async()=>{},close:async()=>{},send(raw){if(raw.length===6){starts++;throw Error('No install permitted in diagnostic test');}const p=ctx.FM1Web.parse(new Uint8Array(raw));assert.equal(p.command,17);queueMicrotask(()=>receive?.({data:ctx.FM1Web.frame(17,id)}));}};
const access={inputs:new Map([['a',input]]),outputs:new Map([['b',output]])};
ctx={document:{getElementById:el,querySelectorAll:()=>[]},navigator:{requestMIDIAccess:async()=>access},isSecureContext:true,Uint8Array,ArrayBuffer,DataView,TextEncoder,TextDecoder,atob:s=>Buffer.from(s,'base64').toString('binary'),console,setTimeout,clearTimeout};vm.createContext(ctx);
for(const [,s]of html.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g))vm.runInContext(s,ctx);
(async()=>{await el('connect').onclick();assert.match(el('identity').textContent,/FM-1_998201/);await el('audioread').onclick();const text=el('audiostats').textContent;assert.match(text,/1000 us/);assert.match(text,/render: 3/);assert.match(text,/budget: 4/);assert.match(text,/clock: 0x6/);assert.equal(starts,0);assert.equal(el('install').disabled,true);console.log('PASS diagnostic HTML: real SDK MIDI framing, extended identity, counter decoding, zero install commands');})();
