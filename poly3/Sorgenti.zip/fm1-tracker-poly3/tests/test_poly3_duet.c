#define main poly3_original_tests
#include "test_poly3.c"
#undef main
int main(void){
 for(unsigned model=0;model<18;model++)for(unsigned track=1;track<=8;track++)for(unsigned mode=0;mode<3;mode++){
  setup(&a,model,track);
  a.project.phrases[track-1].step[0].fx[0].value=mode==1?0x07:0x40;
  if(mode==2)for(unsigned ch=0;ch<8;ch++)if(ch+1!=track&&(ch&1))a.project.phrases[ch].step[0].note=TR_EMPTY;
  tr_transport(&a,1);b=a;memset(&work,0,sizeof work);work.submit=submit;work.join=join;
  int16_t one[514],threaded[514];for(unsigned n=0;n<257;n++)tr_sample_stereo(&a,0,8,one+n*2);
  tr_render_stereo(&b,&preview,8,threaded,257,&work);
  assert(!memcmp(one,threaded,sizeof one));assert(!memcmp(&a,&b,sizeof a));if(mode<2)assert(active(&a)==9);
 }
 puts("PASS 432 nine-voice/sparse cases: both CHD40/CHD07,18models x8tracks, adaptive split, exact scalar/threaded audio/full state");return 0;
}
