/* GPL-3.0-only: exercise the actual RFM1 artifact using the host ABI clock. */
const fs=require('node:fs'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const file=process.argv[2]||'../fm1_m8-vu-20261105.rfm1';
const data=fs.readFileSync(file),mod=new WebAssembly.Module(data),manifest=JSON.parse(Buffer.from(WebAssembly.Module.customSections(mod,'rfm1')[0]));
assert.equal(manifest.abi,6);assert.equal(manifest.id,'fm1_m8');
const allowed=['fd_write','fd_read','fd_close','fd_seek','clock_time_get','proc_exit'];for(const x of WebAssembly.Module.imports(mod))assert(x.module==='wasi_snapshot_preview1'&&allowed.includes(x.name));
const make=()=>{let e;const wasi={fd_close:()=>8,fd_seek:()=>8,fd_read:()=>8,fd_write:(fd,iov,n,out)=>{new DataView(e.memory.buffer).setUint32(out,0,true);return 0;},proc_exit:()=>{throw Error('proc_exit');},clock_time_get:()=>0};e=new WebAssembly.Instance(mod,{wasi_snapshot_preview1:wasi}).exports;e._initialize?.();return e;};
const crc=b=>{let c=0xffffffff;for(const x of b){c^=x;for(let i=0;i<8;i++)c=(c>>>1)^(0xedb88320&-(c&1));}return(c^0xffffffff)>>>0;};
const string=(e,p)=>{const b=new Uint8Array(e.memory.buffer);let end=p;while(b[end])end++;return Buffer.from(b.subarray(p,end)).toString();};
let e=make(),ms=0;const view=()=>new DataView(e.memory.buffer);const desc=e.rfm1_get(6),panel=()=>view().getUint32(desc+e.rfm1_layout(30),true),field=i=>panel()+e.rfm1_layout(i),u32=(p,v)=>view().setUint32(p,v,true);assert(desc);assert.equal(e.rfm1_get(5),0);assert.equal(e.rfm1_layout(34),-1);assert.equal(e.memory.buffer.byteLength,8388608);
assert.equal(string(e,view().getUint32(desc+e.rfm1_layout(20),true)),manifest.name);
assert.equal(e.rfm1_flash_stage(0,1048577),0);assert.equal(e.rfm1_flash_stage(0,1),0);assert.equal(e.rfm1_flash_stage(0,0),1);e.rfm1_options(0,0,0,1);new Uint8Array(e.memory.buffer)[field(16)]=2;e.rfm1_init(0);
function tick(){e.rfm1_tick(ms++);if(ms%15===0)e.rfm1_frame();else e.rfm1_idle();assert.equal(e.rfm1_halted(),0);}
function tap(bit){u32(field(4),1<<bit);tick();tick();}
function enc(i,n){view().setInt32(field(5)+i*4,n,true);tick();}
assert(view().getUint32(field(12),true)>0);tap(12);const audio=e.rfm1_alloc(512);let energy=0;for(let block=0;block<1024;block++){for(let t=0;t<3;t++)tick();e.rfm1_audio(audio,128);for(const v of new Int16Array(e.memory.buffer,audio,256))energy+=Math.abs(v);}assert(energy>10000);tap(12);
// Native RGB565-big-endian screen preview: this is rendered by the real C UI.
const lcd=new Uint8Array(e.memory.buffer,field(11),240*240*2);let rgb=Buffer.alloc(240*240*3);for(let i=0;i<240*240;i++){let c=lcd[i*2]*256+lcd[i*2+1];rgb[i*3]=(c>>11)*255/31;rgb[i*3+1]=(c>>5&63)*255/63;rgb[i*3+2]=(c&31)*255/31;}fs.writeFileSync('build/rfm1/lcd.ppm',Buffer.concat([Buffer.from('P6\n240 240\n255\n'),rgb]));
// A muted absolute MASTER must stay silent, and MIDI audition must produce audio.
u32(field(6),0);for(let i=0;i<12;i++)e.rfm1_audio(audio,128);assert(new Int16Array(e.memory.buffer,audio,256).every(x=>x===0));u32(field(6),900);e.rfm1_midi_in((100<<24)|(60<<16)|(0x90<<8)|9);let midiEnergy=0;for(let i=0;i<20;i++){e.rfm1_audio(audio,128);for(const v of new Int16Array(e.memory.buffer,audio,256))midiEnergy+=Math.abs(v);}assert(midiEnergy>0);e.rfm1_midi_in((60<<16)|(0x80<<8)|8);
// Distinct BPMs in all eight slots, written through the same controls as on the device.
tap(7);enc(2,-127);enc(3,-78); // BPM 108 -> 30
for(let slot=0;slot<8;slot++){if(slot){enc(2,-3);enc(3,1);}enc(2,3);if(slot)enc(3,1);enc(5,1);}
const flash=e.rfm1_flash(),bytes=new Uint8Array(e.memory.buffer,flash,1048576),slots=[];for(let slot=0;slot<8;slot++){const at=0xaf000+slot*24576,h=new DataView(bytes.buffer,bytes.byteOffset+at,24);assert.equal(h.getUint32(0,true),0x31505254);assert.equal(h.getUint32(8,true),11940);assert.equal(h.getUint32(20,true),0);const p=Buffer.from(bytes.subarray(at+24,at+24+11940));assert.equal(crc(p),h.getUint32(16,true));slots.push(p);}assert.equal(new Set(slots.map(p=>crypto.createHash('sha256').update(p).digest('hex'))).size,8);
const saved=Buffer.from(bytes);assert(e.rfm1_flash_dirty()>0);assert.equal(e.rfm1_flash_sync(),1);e.rfm1_shutdown();
// Independent instances; staged flash restores slot 1 on boot. Saving again must preserve its exact payload.
e=make();const p=e.rfm1_alloc(saved.length);assert(p);new Uint8Array(e.memory.buffer,p,saved.length).set(saved);assert.equal(e.rfm1_flash_stage(p,saved.length),1);e.rfm1_free(p);e.rfm1_options(0,0,0,1);e.rfm1_init(0);tap(9);const restored=new Uint8Array(e.memory.buffer,e.rfm1_flash(),1048576);assert.deepEqual(Buffer.from(restored.subarray(0xb2000+24,0xb2000+24+11940)),slots[0]);
console.log(JSON.stringify({test:'RFM1 artifact ABI/layout/imports, C LCD, demo/audio, master mute, MIDI audition, 8 distinct saved slots/CRC and state reboot',status:'PASS',audio_energy:energy,midi_energy:midiEnergy,sha256:crypto.createHash('sha256').update(data).digest('hex')}));
