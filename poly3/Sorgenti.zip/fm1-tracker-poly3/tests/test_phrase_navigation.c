#define main original_device_main
#include "test_device.c"
#undef main
static void release(void){controls.buttons=controls.keys=0;tracker_device_control();}
static void key(unsigned k){controls.buttons=1U<<k;tracker_device_control();release();}
static void select_track(int d){controls.encoders[0]=d;tracker_device_control();}
static void render_second(void){int32_t out[64];for(unsigned n=0;n<1400;n++)tracker_device_render(out,32);}
int main(void){
 original_device_main();tracker_device_init();tracker_ui_play(0);
 static TrProject p,before;tr_project_init(&p);p.song_length=3;
 for(unsigned t=0;t<8;t++){p.song[2][t]=t;p.chains[t].length=2;p.chains[t].phrase[0]=t+10;p.chains[t].phrase[1]=t+20;}
 assert(!tracker_ui_project_apply(&p));assert(!tracker_ui_select(0,0,2,0,0));key(4);
 assert(tracker_ui_state(0)==1&&tracker_ui_state(4)==10);
 for(unsigned t=1;t<8;t++){select_track(1);assert(tracker_ui_state(1)==t&&tracker_ui_state(4)==t+10);}
 for(unsigned t=7;t>0;t--){select_track(-1);assert(tracker_ui_state(4)==t+9);}
 assert(!tracker_ui_select(0,0,2,0,0));key(3);assert(tracker_ui_state(4)==0);
 for(unsigned t=1;t<8;t++){select_track(1);assert(tracker_ui_state(4)==t);}
 // Context is the selected Song row and selected Chain position, not row zero.
 assert(!tracker_ui_select(3,0,1,0,5));key(4);assert(tracker_ui_state(4)==25);select_track(1);assert(tracker_ui_state(4)==21);
 // A missing assignment is visibly empty and cannot alter P00 via any panel edit.
 p.song[2][2]=TR_EMPTY;assert(!tracker_ui_project_apply(&p));before=*tracker_ui_project();select_track(1);capture("phrase-no-assignment");
 controls.encoders[3]=7;controls.buttons=1U<<13;controls.keys=1;tracker_device_control();release();
 controls.buttons=(1U<<10)|1U;tracker_device_control();release();assert(!memcmp(&before,tracker_ui_project(),sizeof before));
 // Explicit Phrase browsing remains available in an unassigned track.
 controls.encoders[4]=5;tracker_device_control();assert(tracker_ui_state(4)==5);controls.buttons=1U<<13;tracker_device_control();release();assert(tracker_ui_project()->phrases[5].step[tracker_ui_state(2)].note==60);
 // During playback track selection resumes follow, even after a manual edit hold.
 p.song[0][0]=0;p.song[0][1]=1;assert(!tracker_ui_project_apply(&p));tracker_ui_play(1);render_second();
 assert(!tracker_ui_select(1,0,0,0,33));tracker_device_control();assert(tracker_ui_state(4)==33&&!tracker_ui_state(19));select_track(1);
 unsigned expected=tracker_ui_voice(1,7);
 assert(tracker_ui_state(1)==1&&tracker_ui_state(4)==expected&&tracker_ui_state(19));tracker_ui_play(0);
 puts("PASS physical-panel navigation: all eight tracks, stopped Song/Chain context, live follow after edit, missing assignment blocks edits, explicit Phrase browsing");
 // Reproduce the reported volumes on the unmodified musical payload.
 FILE *f=fopen("../../Suoni-e-progetti/FM1-M8-Berlin-School-V2/01-Oltre-le-dune.project.bin","rb");assert(f);assert(fread(&p,1,sizeof p,f)==sizeof p);fclose(f);
 assert(!tracker_ui_project_apply(&p));assert(!tracker_ui_select(0,3,0,0,0));key(3);assert(tracker_ui_state(4)==0x0c);capture("dune-chain-0c");key(4);assert(tracker_ui_state(4)==0x18);capture("dune-phrase-18");
 assert(p.phrases[0x18].step[0].fx[0].command==FX_LEV||p.phrases[0x18].step[0].fx[1].command==FX_LEV);
 for(unsigned ph=0;ph<64;ph++)for(unsigned r=0;r<16;r++)for(unsigned fx=0;fx<2;fx++)if(p.phrases[ph].step[r].fx[fx].command==FX_VOL)p.phrases[ph].step[r].fx[fx]=(TrFx){0,0};
 for(unsigned t=3;t<=5;t++)p.mixer[t].level=32;
 assert(!tracker_ui_project_apply(&p));tracker_ui_play(1);render_second();for(unsigned t=3;t<=5;t++)assert(tracker_ui_get(5,0,t,0)==225);
 tracker_ui_play(0);for(unsigned t=3;t<=5;t++)assert(tracker_ui_get(5,0,t,0)==32);
 // Remove LEV automation everywhere: manual base levels now survive PLAY.
 for(unsigned ph=0;ph<64;ph++)for(unsigned r=0;r<16;r++)for(unsigned fx=0;fx<2;fx++)if(p.phrases[ph].step[r].fx[fx].command==FX_LEV)p.phrases[ph].step[r].fx[fx]=(TrFx){0,0};
 for(unsigned tab=0;tab<16;tab++)for(unsigned r=0;r<16;r++)for(unsigned fx=0;fx<3;fx++)if(p.tables[tab].row[r].fx[fx].command==FX_LEV)p.tables[tab].row[r].fx[fx]=(TrFx){0,0};
 assert(!tracker_ui_project_apply(&p));tracker_ui_play(1);render_second();for(unsigned t=3;t<=5;t++)assert(tracker_ui_get(5,0,t,0)==32);tracker_ui_play(0);
 puts("PASS Oltre le dune: removing VOL still yields LEV E1 on T4/T5/T6; Stop restores saved mixer base; removing LEV preserves manually lowered levels");return 0;
}
