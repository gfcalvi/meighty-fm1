/* Test-only stdio bridge: real project protocol and transactional NOR fixture.
 * No hardware access. FE resets the simulated machine; not a firmware command. */
#define main original_device_main
#include "test_device.c"
#undef main
int main(void){
 memset(store_flash,255,sizeof store_flash);tracker_device_init();tracker_ui_project_restore();
 char line[2048];uint8_t payload[640];
 while(fgets(line,sizeof line,stdin)){
  size_t count=strcspn(line,"\r\n")/2;unsigned cmd=0,value=0;
  if(!count||count>sizeof payload+1)return 2;
  if(sscanf(line,"%2x",&cmd)!=1)return 2;
  for(size_t i=1;i<count;i++){if(sscanf(line+i*2,"%2x",&value)!=1)return 2;payload[i-1]=(uint8_t)value;}
  if(cmd==0xfe||cmd==0xfd){memset(store_flash,cmd==0xfe?255:0x3c,sizeof store_flash);tracker_device_init();tracker_ui_project_restore();puts("00");fflush(stdout);continue;}
  if(cmd==0xfc){flash_fail=count>1?payload[0]:-1;puts("00");fflush(stdout);continue;}
  if(cmd==0xfa){tracker_device_init();tracker_ui_project_restore();puts("00");fflush(stdout);continue;}
  if(cmd==0xf9){uint32_t c=tr_project_crc(store_flash,sizeof store_flash);printf("00%02x%02x%02x%02x\n",c&255,(c>>8)&255,(c>>16)&255,c>>24);fflush(stdout);continue;}
  if(cmd==0xf8){unsigned base=sizeof store_flash-4096-16*12288;uint32_t a=tr_project_crc(store_flash,base),b=tr_project_crc(store_flash+sizeof store_flash-4096,4096);printf("00%08x%08x\n",a,b);fflush(stdout);continue;}
  if(cmd==0xf7&&count==3&&payload[0]<8&&payload[1]<2){unsigned base=sizeof store_flash-4096-16*12288;store_flash[base+payload[0]*24576+payload[1]*12288+24]^=1;puts("00");fflush(stdout);continue;}
  if(cmd==17){const char id[27]="FM-1_998201";for(unsigned i=0;i<sizeof id;i++)printf("%02x",(uint8_t)id[i]);putchar('\n');fflush(stdout);continue;}
  ++ms;project_request(cmd,payload,(unsigned)count-1);
  unsigned n=tr_project_reply[3]|((unsigned)tr_project_reply[4]<<8);
  for(unsigned i=0;i<n;i++)printf("%02x",tr_project_reply[6+i]);putchar('\n');fflush(stdout);
 }
 return 0;
}
