#define main original_device_main
#include "test_device.c"
#undef main
enum { SHIFT=1U<<10, DELETE=1U, COPY=2U, PASTE=1U<<13, UNDO=1U<<8 };
static void release_panel(void){controls.buttons=controls.keys=0;tracker_device_control();}
static void chord(unsigned action){controls.buttons=SHIFT|action;tracker_device_control();controls.buttons=SHIFT;tracker_device_control();release_panel();}
static void move_selection(unsigned encoder,int delta){controls.buttons=SHIFT;controls.encoders[encoder]=delta;tracker_device_control();}
static void place(unsigned page,unsigned object,unsigned r,unsigned f){release_panel();assert(!tracker_ui_select(page,0,r,f,object));tracker_device_control();}
static void seed_phrase(unsigned p){for(unsigned r=0;r<16;r++){assert(!tracker_ui_set(1,p,r,0,60+r));assert(!tracker_ui_set(1,p,r,1,r%8));assert(!tracker_ui_set(1,p,r,2,FX_CUT));assert(!tracker_ui_set(1,p,r,3,32+r));assert(!tracker_ui_set(1,p,r,4,FX_PAN));assert(!tracker_ui_set(1,p,r,5,100+r));}}
int main(void){
 original_device_main();tracker_device_init();tracker_ui_play(0);seed_phrase(0);
 static TrProject before;before=*tracker_ui_project();
 // Clear exactly a note; no injected REC note or neighboring-cell change.
 place(1,0,2,0);chord(DELETE);assert(tracker_ui_get(1,0,2,0)==TR_EMPTY);assert(tracker_ui_get(1,0,2,1)==2);chord(UNDO);assert(!memcmp(&before,tracker_ui_project(),sizeof before));
 place(1,0,2,1);chord(DELETE);assert(tracker_ui_get(1,0,2,1)==TR_EMPTY&&tracker_ui_get(1,0,2,0)==62);chord(UNDO);
 place(1,0,2,2);chord(DELETE);assert(!tracker_ui_get(1,0,2,2)&&!tracker_ui_get(1,0,2,3));assert(tracker_ui_get(1,0,2,4)==FX_PAN);chord(UNDO);
 place(1,0,2,3);chord(DELETE);assert(tracker_ui_get(1,0,2,2)==FX_CUT&&!tracker_ui_get(1,0,2,3));chord(UNDO);
 assert(!memcmp(&before,tracker_ui_project(),sizeof before));
 // Copy FX1 with its value, paste it as FX2 in another Phrase.
 place(1,0,2,2);chord(COPY);place(1,1,7,4);chord(PASTE);assert(tracker_ui_get(1,1,7,4)==FX_CUT&&tracker_ui_get(1,1,7,5)==34);assert(tracker_ui_get(1,1,7,0)==before.phrases[1].step[7].note);chord(UNDO);assert(!memcmp(&before,tracker_ui_project(),sizeof before));
 // Note pasted into an FX column is rejected, never reinterpreted as a command.
 place(1,0,2,0);chord(COPY);place(1,1,7,2);chord(PASTE);assert(!memcmp(&before,tracker_ui_project(),sizeof before));
 // Rectangle: two rows x NOTE+INST, release keeps selection for Copy.
 place(1,0,2,0);move_selection(1,1);move_selection(2,1);release_panel();chord(COPY);place(1,1,8,0);chord(PASTE);
 assert(tracker_ui_get(1,1,8,0)==62&&tracker_ui_get(1,1,9,0)==63&&tracker_ui_get(1,1,9,1)==3);chord(UNDO);assert(!memcmp(&before,tracker_ui_project(),sizeof before));
 // Copy, clear and paste the still-selected block restores it in place.
 place(1,0,2,0);move_selection(1,1);move_selection(2,1);release_panel();chord(COPY);chord(DELETE);chord(PASTE);assert(!memcmp(&before,tracker_ui_project(),sizeof before));
 // Complete rows: K2 expands columns without moving the row; ALGORITHM extends.
 place(1,0,2,3);move_selection(3,1);assert(tracker_ui_state(2)==2);move_selection(1,1);release_panel();capture("editor-selected-rows");chord(COPY);
 place(1,1,8,5);chord(PASTE);assert(!memcmp(&tracker_ui_project()->phrases[1].step[8],&before.phrases[0].step[2],2*sizeof(TrStep)));capture("editor-pasted-rows");chord(UNDO);assert(!memcmp(&before,tracker_ui_project(),sizeof before));
 place(1,1,15,0);chord(PASTE);assert(!memcmp(&before,tracker_ui_project(),sizeof before));
 // Whole row clear and single-level undo; clipboard is independent.
 place(1,0,2,3);move_selection(3,1);release_panel();chord(DELETE);const TrStep *s=&tracker_ui_project()->phrases[0].step[2];assert(s->note==TR_EMPTY&&s->instrument==TR_EMPTY&&!s->fx[0].command&&!s->fx[0].value&&!s->fx[1].command&&!s->fx[1].value);chord(UNDO);assert(!memcmp(&before,tracker_ui_project(),sizeof before));
 // Backward rectangle, command pairs, cancellation with a fresh ARP tap.
 place(1,0,4,4);move_selection(1,-2);move_selection(2,-2);release_panel();chord(DELETE);for(unsigned r=2;r<=4;r++){assert(!tracker_ui_get(1,0,r,2)&&!tracker_ui_get(1,0,r,3)&&!tracker_ui_get(1,0,r,4)&&!tracker_ui_get(1,0,r,5));}chord(UNDO);
 place(1,0,4,4);move_selection(1,-2);release_panel();controls.buttons=SHIFT;tracker_device_control();release_panel();chord(DELETE);assert(!tracker_ui_get(1,0,2,4)&&tracker_ui_get(1,0,3,4)==FX_PAN);chord(UNDO);assert(!memcmp(&before,tracker_ui_project(),sizeof before));
 // Table signed transpose, neutral velocity and FX3 command+value.
 assert(!tracker_ui_set(2,0,3,0,-17));place(2,0,3,0);chord(COPY);place(2,1,6,0);chord(PASTE);assert(tracker_ui_get(2,1,6,0)==-17);chord(UNDO);
 assert(!tracker_ui_set(2,0,3,1,42));place(2,0,3,1);chord(DELETE);assert(tracker_ui_get(2,0,3,1)==255);chord(UNDO);assert(tracker_ui_get(2,0,3,1)==42);
 assert(!tracker_ui_set(2,0,3,6,FX_WTP));assert(!tracker_ui_set(2,0,3,7,190));place(2,0,3,6);chord(DELETE);assert(!tracker_ui_get(2,0,3,6)&&!tracker_ui_get(2,0,3,7));chord(UNDO);
 // Chain block references only: never alter object LEN.
 assert(!tracker_ui_set(3,0,0,1,12));assert(!tracker_ui_set(3,0,2,0,7));assert(!tracker_ui_set(3,0,3,0,9));place(3,0,2,0);move_selection(1,1);release_panel();chord(COPY);place(3,1,5,0);unsigned length=tracker_ui_get(3,1,0,1);chord(PASTE);assert(tracker_ui_get(3,1,5,0)==7&&tracker_ui_get(3,1,6,0)==9&&tracker_ui_get(3,1,0,1)==(int)length);
 // Song rectangular selection does not fire mute/solo or live REC launch.
 place(0,0,2,0);for(unsigned r=2;r<5;r++)for(unsigned c=0;c<3;c++)assert(!tracker_ui_set(0,0,r,c,7));unsigned mute=tracker_ui_project()->mute_mask,solo=tracker_ui_project()->solo_mask;
 move_selection(1,2);move_selection(2,2);release_panel();chord(DELETE);for(unsigned r=2;r<5;r++)for(unsigned c=0;c<3;c++)assert(tracker_ui_get(0,0,r,c)==TR_EMPTY);assert(tracker_ui_project()->mute_mask==mute&&tracker_ui_project()->solo_mask==solo);chord(UNDO);assert(tracker_ui_get(0,0,2,0)==7);chord(COPY);place(1,0,0,0);before=*tracker_ui_project();chord(PASTE);assert(!memcmp(&before,tracker_ui_project(),sizeof before));
 // Ordinary keyboard edits invalidate block undo; project load clears clipboard.
 place(1,0,2,0);chord(DELETE);controls.keys=1;tracker_device_control();release_panel();before=*tracker_ui_project();chord(UNDO);assert(!memcmp(&before,tracker_ui_project(),sizeof before));
 assert(!tracker_ui_project_apply(&before));place(1,0,0,0);chord(PASTE);assert(!memcmp(&before,tracker_ui_project(),sizeof before));
 assert(tracker_ui_project_valid(tracker_ui_project()));assert(!irq_depth);puts("PASS native panel editor: cell/FX-pair/row/rectangle copy-clear-paste, reverse ranges, cross-Phrase, type/bounds rejection, Table/Chain/Song, one-level undo, no mute/solo/REC side effects, project reset");return 0;
}
