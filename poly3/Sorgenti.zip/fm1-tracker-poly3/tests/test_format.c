#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <limits.h>
int fm1_snprintf(char *,size_t,const char *,...);
int main(void){char a[100],b[100];
 const char *labels[][3]={{"TRK","CHN","LEN"},{"FLD","NOTE","PHR"},{"FLD","PHR","CHAIN"},{"FLD","PITCH","TABLE"},{"FLD","VOLUME","INST"}};
 for(unsigned k=0;k<5;k++)for(unsigned cap=0;cap<40;cap++){memset(a,0x55,sizeof a);memset(b,0x55,sizeof b);int x=fm1_snprintf(a,cap,"%-5.5s%-5.5s%-5.5s--",labels[k][0],labels[k][1],labels[k][2]),y=snprintf(b,cap,"%-5.5s%-5.5s%-5.5s--",labels[k][0],labels[k][1],labels[k][2]);assert(x==y&&!memcmp(a,b,sizeof a));}
 assert(fm1_snprintf(a,sizeof a,"%+d %02X %u %c %%",INT_MIN,255U,UINT_MAX,'A')==snprintf(b,sizeof b,"%+d %02X %u %c %%",INT_MIN,255U,UINT_MAX,'A'));assert(!strcmp(a,b));
 puts("PASS: native formatter preserves Song/Chain/Phrase legends, precision, padding and truncation");}
