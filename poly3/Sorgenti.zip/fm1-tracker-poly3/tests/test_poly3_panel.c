#define main original_device_main
#include "test_device.c"
#undef main
static void release(void){controls.buttons=controls.keys=0;tracker_device_control();}
int main(void){
 original_device_main();tracker_device_init();tracker_ui_play(0);
 assert(!tracker_ui_select(7,0,0,15,0));controls.encoders[3]=4;tracker_device_control();assert(tracker_ui_get(7,0,0,15)==4&&tracker_ui_state(1)==3);capture("poly3-global");
 assert(!tracker_ui_select(4,3,0,8,0));assert(!tracker_ui_set(4,0,0,9,1));assert(!tracker_ui_set(4,0,0,10,0));assert(!tracker_ui_set(4,0,0,13,12));
 controls.keys=(1U<<7)|(1U<<11)|(1U<<14);tracker_device_control();int32_t audio[128];tracker_device_render(audio,64);
 assert(tracker_ui_voice(3,4));capture("poly3-instrument");controls.keys=(1U<<7)|(1U<<14);tracker_device_control();for(unsigned n=0;n<32;n++)tracker_device_render(audio,64);release();
 assert(!tracker_ui_select(1,3,0,0,0));controls.keys=(1U<<7)|(1U<<11)|(1U<<14);tracker_device_control();
 assert(tracker_ui_get(1,0,0,0)==60&&tracker_ui_get(1,0,0,2)==FX_CHD&&tracker_ui_get(1,0,0,3)==0x47);capture("poly3-chord-recorded");release();
 // A physical single key on another track leaves the poly track configuration alone.
 assert(!tracker_ui_select(4,2,0,8,0));controls.keys=1;tracker_device_control();assert(tracker_ui_state(10));release();assert(tracker_ui_get(7,0,0,15)==4);
 static TrProject p,out; p=*tracker_ui_project();
 for(unsigned slot=0;slot<8;slot++){assert(!tracker_ui_slot_import(slot,&p));assert(!tracker_ui_project_load(slot));assert(tracker_ui_get(7,0,0,15)==4);assert(!tracker_ui_slot_export(slot,&out));assert(!memcmp(&p,&out,sizeof p));}
 // Manufacture genuine previous-layout committed banks, with original CRCs.
 for(unsigned slot=0;slot<8;slot++){
  unsigned at=0x18000+slot*0x6000;memset(store_flash+at,255,0x6000);uint32_t h[6]={0x31505254,1,offsetof(TrProject,poly_track),1,0,0};
  p.poly_track=0;for(unsigned r=0;r<16;r++)for(unsigned f=0;f<2;f++)if(p.phrases[0].step[r].fx[f].command==FX_CHD)p.phrases[0].step[r].fx[f]=(TrFx){0,0};
  h[4]=tr_project_crc(&p,h[2]);memcpy(store_flash+at,h,sizeof h);memcpy(store_flash+at+sizeof h,&p,h[2]);
  assert(!tracker_ui_project_load(slot));assert(tracker_ui_get(7,0,0,15)==0);assert(!tracker_ui_slot_export(slot,&out));assert(out.poly_version==1&&!out.poly_reserved&&!out.poly_track);assert(!memcmp(&p,&out,h[2]));
  assert(!tracker_ui_set(7,0,0,15,slot+1));assert(!tracker_ui_project_save(slot));assert(!tracker_ui_project_load(slot));assert(tracker_ui_get(7,0,0,15)==(int)slot+1);
 }
 assert(tracker_ui_set(7,0,0,15,9)<0);out.poly_track=9;assert(!tracker_ui_project_valid(&out));out.poly_track=0;out.poly_reserved=1;assert(!tracker_ui_project_valid(&out));
 printf("PASS Poly3 physical Global/keyboard/chord record, mono preview elsewhere, save/load all8, CRC-valid11940 -> %zu migration, config persistence, invalid config rejected\n",sizeof(TrProject));return 0;
}
