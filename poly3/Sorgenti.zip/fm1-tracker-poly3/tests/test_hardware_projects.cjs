const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
vm.runInThisContext(fs.readFileSync('sdk/WebUpdate.js','utf8'));vm.runInThisContext(fs.readFileSync('web/installer/InstallerCore.js','utf8'));
const {Projects,projectFile,projectData}=FM1M8Installer;
const fixture=JSON.parse(fs.readFileSync('../FM1-M8-Esempi-Manuale/'+fs.readdirSync('../FM1-M8-Esempi-Manuale').find(n=>n.endsWith('.json'))));const original=projectData(fixture);assert.equal(original.length,11940);assert.deepEqual(projectData(projectFile(original,2)),original);assert.throws(()=>projectData({...fixture,sha256:'0'.repeat(64)}));assert.throws(()=>projectData({format:'fm1-emulator-save'}));
const wr=n=>[n&255,n>>>8&255,n>>>16&255,n>>>24],rd=p=>new DataView(Uint8Array.from(p).buffer).getUint32(0,true);
let writing,at,expected,snapshot,corrupt=false,commands=[];const slots=[original,...Array(7).fill(null)];
const link={async query(cmd,p=[]){commands.push(cmd);let data=[];
 if(cmd===0x60)data=[1,8,...wr(11940)];
 else if(cmd===0x61){snapshot=p[0]===255?original:slots[p[0]];if(!snapshot)return Uint8Array.of(7);data=[...wr(11940),...wr(FM1Web.crc32(snapshot))];}
 else if(cmd===0x62)data=snapshot.slice(rd(p),rd(p)+(p[4]|p[5]<<8));
 else if(cmd===0x63){writing=p[0];expected=rd(p.slice(5));at=0;snapshot=new Uint8Array(11940);}
 else if(cmd===0x64){assert.equal(rd(p),at);snapshot.set(p.slice(4),at);at+=p.length-4;}
 else if(cmd===0x65){assert.equal(at,11940);assert.equal(FM1Web.crc32(snapshot),expected);slots[writing]=snapshot.slice();if(corrupt)slots[writing][10]^=1;}
 else assert.equal(cmd,0x66);
 return Uint8Array.from([0,...data]);}};
(async()=>{const api=new Projects(link);assert.deepEqual(await api.read(0),original);await assert.rejects(()=>api.read(7),e=>e.status===7);await api.write(7,original);assert.deepEqual(slots[7],original);assert(!commands.includes(17)&&!commands.includes(48));corrupt=true;await assert.rejects(()=>api.write(2,original),/Verifica/);console.log('PASS hardware project client: Workbench interchange, CRC, 256-byte chunks, eight-slot targeting, empty slot, post-write readback mismatch, no firmware commands');})();
