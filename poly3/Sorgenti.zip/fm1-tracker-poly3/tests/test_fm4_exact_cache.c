/* Frozen A8 FM4 is the independent oracle: output and persistent DSP state. */
#include "../app/tracker/tracker.c"
#include "fm4-A8-reference.inc"
#include <assert.h>
#include <stdio.h>
static Tracker t;
static TrVoice a,b;
int main(void){
 tr_init(&t);
 unsigned cases=0;uint32_t random=0x37ab8149U;
 for(unsigned algorithm=0;algorithm<8;algorithm++){
  t.project.engine[0][0]=(uint8_t)algorithm;
  a=(TrVoice){0};a.instrument=0;a.model=16;a.note=60;engine_start(&t,&a);b=a;
  for(unsigned n=0;n<16384;n++){
   random=random*1664525U+1013904223U;
   /* Repeated keys, ordinary glide, clamp extremes and raw out-of-range ratios. */
   uint32_t inc=(n%64<32)?increments[60]:n%64<56?(uint32_t)(increments[60]+n*1337U):random;
   if(!(n%97))for(unsigned k=0;k<4;k++)a.engine_ratios[k]=b.engine_ratios[k]=(uint8_t)(random>>(k*8));
   if(!(n%32)){engine_control(&t,&a,inc);engine_control(&t,&b,inc);}
   if(!(n%251)){engine_release(&t,&a);engine_release(&t,&b);}
   if(!(n%509)){engine_start(&t,&a);engine_start(&t,&b);assert(!a.fm_cache_valid);}
   int32_t x=fm4_sample(&t,&a,inc),y=fm4_reference(&t,&b,inc);assert(x==y);
   uint32_t raw;memcpy(&raw,a.engine_ratios,4);assert(a.fm_cache_valid&&a.fm_cached_inc==inc&&a.fm_cached_ratios==raw);
   static const unsigned ratio[]={128,256,512,768,1024,1280,1536,1792,2048,2304,2560,2816,3072,3584,4096};
   for(unsigned k=0;k<4;k++){uint64_t s=(uint64_t)inc*ratio[a.engine_ratios[k]%15]/256;assert(a.fm_step[k]==(s>0x73000000U?0x73000000U:s));b.fm_step[k]=a.fm_step[k];}
   b.fm_cached_inc=a.fm_cached_inc;b.fm_cached_ratios=a.fm_cached_ratios;b.fm_cache_valid=a.fm_cache_valid;
   assert(!memcmp(&a,&b,sizeof a));cases++;
  }
 }
 printf("PASS FM4 exact increment cache vs frozen A8: %u samples,8 algorithms,raw ratios,glide,clamp,release,restart and full DSP state\n",cases);
 return 0;
}
