#include "tracker/tracker.h"
#include <stdint.h>
#include <stdio.h>
static Tracker t;static int16_t pcm[8192];
int main(void){uint64_t all=0;for(unsigned k=0;k<8192;k++)pcm[k]=(int16_t)(k*17513U);
 for(unsigned model=0;model<19;model++){tr_init(&t);tr_berlin_demo(&t);t.project.song_length=1;TrSample sample={pcm,8192,32000,60};tr_set_sample(&t,0,&sample);
  for(unsigned c=0;c<8;c++){t.project.song[0][c]=c;t.project.chains[c].length=1;t.project.chains[c].phrase[0]=c;t.project.instrument_source[c]=model==18?2:1;t.project.instruments[c].model=model%18;t.project.instruments[c].sample=0;t.project.sound[c][0]=1;for(unsigned r=0;r<16;r++)t.project.phrases[c].step[r]=(TrStep){(uint8_t)(40+c+r%5),c,{{FX_CUT,99+r},{0,0}}};}
  tr_transport(&t,1);uint64_t h=1469598103934665603ULL;for(unsigned n=0;n<32000;n++){int16_t a[2];tr_sample_stereo(&t,0,8,a);h=(h^(uint16_t)a[0])*1099511628211ULL;h=(h^(uint16_t)a[1])*1099511628211ULL;}all^=h;printf("%02u %016llx\n",model,(unsigned long long)h);
 }printf("ALL %016llx\n",(unsigned long long)all);return 0;}
