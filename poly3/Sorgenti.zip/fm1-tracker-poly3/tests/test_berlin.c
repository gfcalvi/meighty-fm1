#include "tracker/tracker.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
static Tracker tracker;
#include "tracker/rhythm_bank.inc"
int main(void){tr_init(&tracker);tr_berlin_demo(&tracker);load_rhythm_bank();unsigned seen=0,late=0;unsigned long long energy=0;assert(tracker.project.bpm==108&&tracker.project.song_length==16);for(unsigned i=0;i<TR_SAMPLES;i++){assert(tracker.samples[i].frames>0&&tracker.samples[i].data);assert(rhythm_names[i][0]);if(i<8)for(unsigned bar=12;bar<16;bar++)assert(tracker.project.song[bar][i]<32);}
 for(unsigned i=0;i<TR_SAMPLES;i++){tracker.project.instrument_source[31]=2;tracker.project.instruments[31].sample=i;tracker.project.instruments[31].attack=255;tracker.project.instruments[31].decay=1;TrVoice v;tr_audition_on(&tracker,&v,0,31,60);unsigned long sum=0;for(unsigned n=0;n<8000;n++)sum+=(unsigned)abs(tr_audition_sample(&tracker,&v,0));assert(sum>10000);}
 tr_transport(&tracker,1);for(unsigned n=0;n<1200000;n++){int16_t audio[2];tr_sample_stereo(&tracker,0,8,audio);energy+=(unsigned)abs(audio[0])+(unsigned)abs(audio[1]);for(unsigned c=0;c<8;c++)if(tracker.voice[c].active){seen|=1U<<c;if(tracker.voice[c].song>=12)late|=1U<<c;}}
 assert(seen==255&&late==255&&energy>1000000);tr_drum_demo(&tracker);assert(tracker.project.bpm==112&&tracker.project.song_length==4);unsigned ids[]={21,23,8,11,12,14,19,28};for(unsigned i=0;i<8;i++)assert(tracker.project.instrument_source[i]==2&&tracker.project.instruments[i].sample==ids[i]);seen=0;tr_transport(&tracker,1);for(unsigned n=0;n<420000;n++){int16_t a[2];tr_sample_stereo(&tracker,0,8,a);for(unsigned i=0;i<8;i++)if(tracker.voice[i].active)seen|=1U<<i;}assert(seen==255);printf("PASS: drum kit, eight tracks; Berlin School full arrangement, eight late-entry tracks, all 33 real PCM samples, energy %llu\n",energy);}
