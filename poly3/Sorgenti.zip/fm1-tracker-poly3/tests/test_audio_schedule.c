/* Fake timestamps verify observations, never physical timing performance. */
#include "../hardware/audio_schedule.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
int main(void){
 TrAudioSchedule s={0};s.mask_start=100;tr_schedule_mask_end(&s,999999);tr_schedule_timer_end(&s,10,900000);
 for(unsigned i=0;i<8;i++)assert(s.maximum[i]==0);
 tr_schedule_running(&s,1);
 s.mask_start=UINT32_MAX-23U;tr_schedule_mask_end(&s,24);
 assert(s.maximum[0]==48&&s.mask_duration==48);
 tr_schedule_timer_end(&s,48,96);assert(s.maximum[1]==48);
 tr_schedule_entry(&s,120);assert(s.snapshot[0]==0&&s.snapshot[1]==48&&s.snapshot[2]==96&&s.snapshot[3]==48);
 /* Subsequent timer/mask updates must not alter the entry's snapshot. */
 s.mask_start=121;tr_schedule_mask_end(&s,145);tr_schedule_timer_end(&s,146,170);
 tr_schedule_late(&s,60000);assert(s.maximum[3]==60000&&s.maximum[4]==0&&s.maximum[5]==48&&s.maximum[6]==96&&s.maximum[7]==48);
 tr_schedule_entry(&s,69752);assert(s.maximum[2]==69632&&s.snapshot[1]==24&&s.snapshot[2]==69607&&s.snapshot[3]==24);
 tr_schedule_entry(&s,139384);assert(s.snapshot[1]==0&&s.snapshot[2]==0&&s.snapshot[3]==0);
 tr_schedule_late(&s,61000);assert(s.maximum[3]==61000&&s.maximum[4]==69632&&s.maximum[5]==0&&s.maximum[6]==0&&s.maximum[7]==0);
 uint32_t maximum[8];for(unsigned i=0;i<8;i++)maximum[i]=s.maximum[i];
 tr_schedule_late(&s,60001);for(unsigned i=0;i<8;i++)assert(maximum[i]==s.maximum[i]);
 tr_schedule_running(&s,0);s.mask_start=0;tr_schedule_mask_end(&s,999999);tr_schedule_timer_end(&s,0,999999);tr_schedule_entry(&s,999999);tr_schedule_late(&s,999999);for(unsigned i=0;i<8;i++)assert(maximum[i]==s.maximum[i]);
 tr_schedule_running(&s,1);tr_schedule_entry(&s,2000000);assert(s.snapshot[0]==0&&s.snapshot[1]==0&&s.snapshot[3]==0);assert(s.maximum[2]==69632);
 /* The periodic timer wraps every179seconds; unsigned deltas stay valid. */
 tr_schedule_running(&s,1);tr_schedule_entry(&s,UINT32_MAX-100);tr_schedule_entry(&s,69531);assert(s.snapshot[0]==69632);
 puts("PASS audio schedule: inactive boot/stop excluded, outer mask timestamps, timer wrap, first entry/restart excluded from gaps, recent-event window, co-occurring snapshot and largest-LATE preservation. Fake timings only.");return 0;
}
