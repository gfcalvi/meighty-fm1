#include "tracker/tracker.h"
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
static Tracker t;static TrVoice v,w;static int16_t pcm[32000];
static void start(unsigned model,unsigned sample){tr_init(&t);t.project.instrument_source[0]=sample?2:1;t.project.instruments[0].model=model;t.project.instruments[0].volume=200;t.project.sound[0][0]=1;t.project.sound[0][1]=2;t.project.sound[0][2]=3;t.project.sound[0][3]=128;t.project.sound[0][4]=4;if(sample){TrSample s={pcm,32000,32000,60};assert(tr_set_sample(&t,0,&s)==0);}tr_audition_on(&t,&v,0,0,60);}
int main(void){
 for(unsigned n=0;n<32000;n++)pcm[n]=(n%100<50)?12000:-12000;
 for(unsigned sample=0;sample<2;sample++){
  start(2,sample);long long energy=0;for(unsigned n=0;n<200;n++)energy+=abs(tr_audition_sample(&t,&v,0));assert(energy>1000);assert(v.env_stage==2&&abs(v.envelope-16447)<2&&v.active);
  tr_release(&t,&v);assert(v.active&&v.env_stage==3);for(unsigned n=0;n<70;n++)tr_audition_sample(&t,&v,0);assert(!v.active&&v.envelope==0);
 }
 start(2,0);t.project.sound[0][1]=255;tr_audition_on(&t,&v,0,0,60);for(unsigned n=0;n<32000;n++)tr_audition_sample(&t,&v,0);assert(v.env_stage==0&&v.envelope>3900&&v.envelope<4200);
 for(unsigned model=5;model<8;model++){start(model,0);long long energy=0;for(unsigned n=0;n<32000;n++)energy+=abs(tr_audition_sample(&t,&v,0));assert(energy>100000);}
 start(5,0);uint8_t *s=t.project.sound[0];s[9]=s[16]=160;s[11]=0;s[18]=128;s[12]=s[19]=200;s[13]=s[20]=190;s[14]=s[21]=210;s[15]=s[22]=175;tr_audition_on(&t,&v,0,0,60);
 for(unsigned n=0;n<10000;n++){tr_audition_sample(&t,&v,0);assert(abs(v.mod_pan)<=2&&abs(v.mod_pitch)<=2&&abs(v.mod_cutoff)<=2&&abs(v.mod_amp)<=2);}
 s[19]=128;s[20]=128;s[21]=128;s[22]=128;int moved=0;for(unsigned n=0;n<10000;n++){tr_audition_sample(&t,&v,0);moved|=abs(v.mod_pan)>30&&abs(v.mod_pitch)>20&&abs(v.mod_cutoff)>30;}assert(moved);
 /* Sweep all resonant filter modes/extreme cutoffs on noise and PCM. */
 for(unsigned sample=0;sample<2;sample++)for(unsigned type=1;type<4;type++)for(unsigned cut=0;cut<256;cut+=17){start(4,sample);t.project.sound[0][5]=255;t.project.sound[0][6]=type;v.cutoff=cut;for(unsigned n=0;n<3000;n++){int x=tr_audition_sample(&t,&v,0);assert(abs(x)<60000&&abs(v.filter)<=131072&&abs(v.filter_band)<=131072);}}
 /* Signed LFO pan actually reaches stereo output, including stopped audition. */
 start(2,0);s=t.project.sound[0];s[9]=0;s[10]=2;s[12]=255;tr_audition_on(&t,&v,0,0,60);int16_t out[2];for(unsigned n=0;n<200;n++)tr_sample_stereo(&t,tr_audition_sample(&t,&v,0),0,out);assert(abs(out[1])>abs(out[0])*20);
 for(unsigned sample=0;sample<2;sample++){start(2,sample);t.project.sound[0][4]=255;uint8_t *ce=t.project.cutoff_env[0];ce[0]=1;ce[1]=2;ce[2]=3;ce[3]=128;ce[4]=4;ce[5]=220;tr_audition_on(&t,&v,0,0,60);for(unsigned n=0;n<200;n++)tr_audition_sample(&t,&v,0);assert(v.cutoff_envelope.stage==2&&v.cutoff_envelope.level==16447);tr_release(&t,&v);for(unsigned n=0;n<70;n++)tr_audition_sample(&t,&v,0);assert(v.active&&v.cutoff_envelope.level==0&&v.env_stage==3);}
 long long cut_energy[2]={0,0};for(unsigned sign=0;sign<2;sign++){start(2,0);t.project.sound[0][6]=1;t.project.cutoff_env[0][0]=1;t.project.cutoff_env[0][1]=0;t.project.cutoff_env[0][2]=0;t.project.cutoff_env[0][3]=255;t.project.cutoff_env[0][5]=sign?28:228;tr_audition_on(&t,&v,0,0,60);for(unsigned n=0;n<8000;n++){int x=tr_audition_sample(&t,&v,0);if(n>1000)cut_energy[sign]+=abs(x);}}assert(cut_energy[0]>cut_energy[1]*2);
 puts("PASS: independent cutoff ADSR on synth/PCM, independent release and bipolar filter modulation");
 static const unsigned scale_masks[]={0xfff,0xab5,0x6ad,0x5ab,0xad5,0x6b5,0x5ad,0x56b,0x4a9,0x295};for(unsigned scale=0;scale<10;scale++)for(unsigned root=0;root<12;root++){tr_init(&t);t.project.global_scale=scale;t.project.global_root=root;for(int note=0;note<128;note++){int q=tr_global_note(&t.project,note);assert(q>=0&&q<128&&(scale_masks[scale]&(1U<<((q+12-root)%12))));if(!scale)assert(q==note);}}
 start(2,0);t.project.global_scale=1;t.project.global_root=0;tr_audition_on(&t,&v,0,0,61);tr_audition_on(&t,&w,0,0,60);assert(v.increment==w.increment);
 puts("PASS: all ten global scales over twelve roots and all MIDI notes, chromatic passthrough and quantized keyboard audition");
 puts("PASS: Braids-derived models, synth/PCM ADSR stages and release, dual LFO cancellation/multiple targets, resonant filter extremes, preview stereo pan");return 0;
}
