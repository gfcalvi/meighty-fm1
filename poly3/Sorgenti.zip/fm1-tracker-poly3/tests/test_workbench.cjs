const stylesheet=require('node:fs').readFileSync('web/tracker/Workbench.css','utf8');require('node:assert/strict').ok(stylesheet.includes(':root')&&stylesheet.includes('body.lcd-focus')&&!stylesheet.includes('#include'), 'Tracker CSS must be stylesheet, not a source file');
/* SPDX-License-Identifier: GPL-3.0-only WITH GPL-3.0-linking-exception */
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),crypto=require('node:crypto');
vm.runInThisContext(fs.readFileSync('web/tracker/Runtime.js','utf8'));
const wasm=new Uint8Array(fs.readFileSync('build/tracker-web/simulator.wasm'));
const moduleInfo=new WebAssembly.Module(wasm);assert.equal(WebAssembly.Module.imports(moduleInfo).length,0);
const core=new FM1SimulatorCore(wasm),c=core.c;
const op=(op,args={})=>core.command({type:'tracker',op,...args});
op('demo',{value:1});
op('select',{page:1,track:0,row:0,field:0,object:0});
let frame=core.frame(true);assert.equal(frame.tracker.state[0],1);assert.equal(frame.tracker.commands.length,57);assert.equal(frame.tracker.rows[1][2],6);
const original=core.command({type:'tracker-export'});
// Earlier A03 snapshots have no names: preserve their parameters and migrate.
const legacy=original.slice(0,c.sim_tracker_legacy_bytes());core.command({type:'tracker-import',data:legacy});assert.equal(c.sim_tracker_get(1,0,0,0),48);
op('select',{page:4,track:0,row:0,field:0,object:1});op('preset',{object:1,value:10});op('set',{page:4,object:1,row:0,field:3,value:100});
assert.equal(c.sim_tracker_get(4,1,0,8),0);op('set',{page:4,object:1,row:0,field:8,value:1});assert.equal(c.sim_tracker_get(4,1,0,8),1);assert.throws(()=>op('set',{page:4,object:1,row:0,field:8,value:2}));
const named=core.command({type:'tracker-export'});const previousNamed=named.slice(0,c.sim_tracker_named_bytes());core.command({type:'tracker-import',data:previousNamed});assert.equal(c.sim_tracker_get(4,1,0,8),0);
core.command({type:'tracker-import',data:named});
const readName=p=>{let s='',a=new Uint8Array(c.memory.buffer);while(a[p])s+=String.fromCharCode(a[p++]);return s;};assert.equal(readName(c.sim_tracker_instrument_name(1)),'GLASS PLUCK');assert.equal(c.sim_tracker_get(4,1,0,8),1);
op('audition',{value:60});let previewEnergy=0;for(let i=0;i<80;i++){const a=new Float32Array(c.memory.buffer,c.sim_render(),256);for(const v of a)previewEnergy+=Math.abs(v);}assert(previewEnergy>1&&c.sim_tracker_state(6)===0);op('audition',{value:-1});
core.command({type:'tracker-import',data:original});op('select',{page:1,track:0,row:0,field:0,object:0});

op('set',{page:1,object:0,row:0,field:0,value:64});assert.equal(core.frame().tracker.rows[0][0],64);
assert.throws(()=>op('set',{page:1,object:0,row:0,field:0,value:128}));assert.equal(c.sim_tracker_get(1,0,0,0),64);
core.command({type:'tracker-import',data:original});assert.equal(c.sim_tracker_get(1,0,0,0),48);
const previousSource=original.slice(0,c.sim_tracker_source_bytes());core.command({type:'tracker-import',data:previousSource});assert.equal(c.sim_tracker_get(5,0,0,0),255);assert.equal(c.sim_tracker_get(6,0,0,0),7);
op('set',{page:5,object:0,row:0,field:2,value:180});op('set',{page:5,object:0,row:0,field:3,value:140});op('set',{page:6,object:0,row:0,field:0,value:11});op('set',{page:6,object:0,row:0,field:1,value:140});assert.equal(c.sim_tracker_get(6,0,0,1),140);assert.throws(()=>op('set',{page:6,object:0,row:0,field:1,value:241}));
const mixSaved=core.command({type:'tracker-export'});core.command({type:'tracker-import',data:mixSaved});assert.equal(c.sim_tracker_get(5,0,0,2),180);assert.equal(c.sim_tracker_get(6,0,0,0),11);assert.equal(c.sim_tracker_get(6,0,0,1),140);
op('play',{value:1});let energy=0;
for(let i=0;i<1000;i++){
 const ptr=c.sim_render(),audio=new Float32Array(c.memory.buffer,ptr,256);
 for(const x of audio){assert(Number.isFinite(x)&&Math.abs(x)<=1);energy+=Math.abs(x);}
}
assert(energy>100);assert(c.sim_tracker_state(7)>0);op('tempo',{value:133});assert.equal(c.sim_tracker_state(6),1);
const stateBefore=c.sim_tracker_get(1,0,0,0);const invalid=original.slice();invalid.fill(0);
assert.throws(()=>core.command({type:'tracker-import',data:invalid}));assert.equal(c.sim_tracker_get(1,0,0,0),stateBefore);assert.equal(c.sim_tracker_state(6),1);
const snapshot=c.memory.buffer.slice(0),clone=new FM1SimulatorCore(wasm,null,snapshot);
for(let n=0;n<30;n++){
 const a=new Float32Array(c.memory.buffer,c.sim_render(),256).slice();
 const b=new Float32Array(clone.c.memory.buffer,clone.c.sim_render(),256).slice();assert.deepEqual(a,b);
}
// Extended per-instrument sound fields and pre-ADSR project migration.
op('select',{page:4,track:0,row:0,field:31,object:2});
assert.equal(core.frame(true).tracker.rows[0].length,75);
for(const [field,value] of [[0,7],[9,1],[10,44],[12,180],[14,230],[15,3],[19,2],[20,128],[21,12],[26,3],[31,250]])op('set',{page:4,object:2,row:0,field,value});
const modSaved=core.command({type:'tracker-export'});core.command({type:'tracker-import',data:modSaved});assert.equal(c.sim_tracker_get(4,2,0,31),250);assert.equal(c.sim_tracker_get(4,2,0,0),7);
assert.throws(()=>op('set',{page:4,object:2,row:0,field:19,value:4}));
const mixOnly=modSaved.slice(0,c.sim_tracker_mix_bytes());core.command({type:'tracker-import',data:mixOnly});assert.equal(c.sim_tracker_get(4,2,0,9),0);assert.equal(c.sim_tracker_get(4,2,0,21),128);assert.equal(c.sim_tracker_get(6,0,0,1),140);
core.command({type:'tracker-import',data:modSaved});
// Previous 32-field projects preserve both synthesis and mixer while new data defaults.
op('set',{page:4,object:2,row:0,field:32,value:1});op('set',{page:4,object:2,row:0,field:37,value:220});op('set',{page:6,object:0,row:0,field:8,value:1});
const ambientSaved=core.command({type:'tracker-export'});core.command({type:'tracker-import',data:ambientSaved});assert.equal(c.sim_tracker_get(4,2,0,37),220);assert.equal(c.sim_tracker_get(6,0,0,8),1);
const previousMod=ambientSaved.slice(0,c.sim_tracker_mod_bytes());core.command({type:'tracker-import',data:previousMod});assert.equal(c.sim_tracker_get(4,2,0,31),250);assert.equal(c.sim_tracker_get(4,2,0,32),0);assert.equal(c.sim_tracker_get(4,2,0,37),128);assert.equal(c.sim_tracker_get(6,0,0,8),0);core.command({type:'tracker-import',data:ambientSaved});
// Global project settings and persistent, transactional flash slots.
op('select',{page:7,track:0,row:0,field:0,object:0});assert.equal(core.frame(true).tracker.scales.length,10);assert.equal(core.frame(true).tracker.rows[0].length,7);
op('set',{page:7,object:0,row:0,field:0,value:147});op('set',{page:7,object:0,row:0,field:1,value:8});op('set',{page:7,object:0,row:0,field:2,value:9});op('set',{page:7,object:0,row:0,field:3,value:7});
assert.throws(()=>op('set',{page:7,object:0,row:0,field:1,value:10}));op('global-action',{value:1});op('tempo',{value:180});op('global-action',{value:0});assert.equal(c.sim_tracker_get(7,0,0,0),147);assert.equal(c.sim_tracker_get(7,0,0,1),8);assert.equal(c.sim_tracker_get(7,0,0,2),9);
const flashCopy=new Uint8Array(c.memory.buffer,c.sim_flash(),536576).slice();const rebooted=new FM1SimulatorCore(wasm,flashCopy);rebooted.command({type:'tracker',op:'set',page:7,object:0,row:0,field:3,value:7});rebooted.command({type:'tracker',op:'global-action',value:0});assert.equal(rebooted.c.sim_tracker_get(7,0,0,0),147);
const globalProject=core.command({type:'tracker-export'});const preGlobal=globalProject.slice(0,c.sim_tracker_env_bytes());core.command({type:'tracker-import',data:preGlobal});assert.equal(c.sim_tracker_get(7,0,0,1),0);assert.equal(c.sim_tracker_get(4,2,0,37),220);assert.equal(c.sim_tracker_get(6,0,0,8),1);core.command({type:'tracker-import',data:globalProject});
// Append-only engine migration, including previously committed flash slot headers.
const oldMulti=original.slice(0,c.sim_tracker_old_wtlfo_bytes());assert.equal(oldMulti.length,11812);op('set',{page:4,object:0,row:0,field:71,value:255});core.command({type:'tracker-import',data:oldMulti});for(let f=71;f<75;f++)assert.equal(c.sim_tracker_get(4,0,0,f),128);assert.equal(c.sim_tracker_get(4,0,0,38),original[10788]);
const oldBytes=c.sim_tracker_old_engine_bytes(),oldProject=original.slice(0,oldBytes);assert.equal(oldBytes,10788);op('set',{page:4,object:0,row:0,field:38,value:7});core.command({type:'tracker-import',data:oldProject});assert.equal(c.sim_tracker_get(4,0,0,38),0);assert.equal(c.sim_tracker_get(4,0,0,67),128);
const legacyFlash=new Uint8Array(536576).fill(255),base=536576-4096-16*12288+6*24576;let crc=0xffffffff;for(const b of oldProject){crc^=b;for(let j=0;j<8;j++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}const header=new DataView(legacyFlash.buffer,base,24);[0x31505254,1,oldBytes,1,(~crc)>>>0,0].forEach((v,i)=>header.setUint32(i*4,v,true));legacyFlash.set(oldProject,base+24);const migrated=new FM1SimulatorCore(wasm,legacyFlash);migrated.command({type:'tracker',op:'set',page:7,object:0,row:0,field:3,value:6});migrated.command({type:'tracker',op:'global-action',value:0});assert.equal(migrated.c.sim_tracker_get(4,0,0,67),128);assert.equal(migrated.c.sim_tracker_get(7,0,0,0),120);
// Previously committed MultiEngine slot: preserve engines and initialize new depths only.
const priorFlash=new Uint8Array(536576).fill(255);let crc2=0xffffffff;for(const b of oldMulti){crc2^=b;for(let j=0;j<8;j++)crc2=(crc2>>>1)^((crc2&1)?0xedb88320:0);}const h2=new DataView(priorFlash.buffer,base,24);[0x31505254,1,oldMulti.length,3,(~crc2)>>>0,0].forEach((v,i)=>h2.setUint32(i*4,v,true));priorFlash.set(oldMulti,base+24);const priorCore=new FM1SimulatorCore(wasm,priorFlash);priorCore.command({type:'tracker',op:'set',page:7,object:0,row:0,field:3,value:6});priorCore.command({type:'tracker',op:'global-action',value:0});for(let f=71;f<75;f++)assert.equal(priorCore.c.sim_tracker_get(4,0,0,f),128);assert.equal(priorCore.c.sim_tracker_get(4,0,0,38),original[10788]);
core.command({type:'tracker-import',data:globalProject});
// Run the very same AudioWorklet class with an audio-host stub, at 48 kHz.
globalThis.sampleRate=48000;let Processor;
globalThis.AudioWorkletProcessor=class{constructor(){this.port={postMessage(){},onmessage:null};}};
globalThis.registerProcessor=(name,ctor)=>{assert.equal(name,'fm1-engine');Processor=ctor;};
vm.runInThisContext(FM1SimulatorAudioSource);
const processor=new Processor({processorOptions:{wasm,snapshot}});let workletEnergy=0;
for(let n=0;n<400;n++){const outputs=[[new Float32Array(128),new Float32Array(128)]];assert(processor.process([],outputs));for(const x of outputs[0][0]){assert(Number.isFinite(x)&&Math.abs(x)<=1);workletEnergy+=Math.abs(x);}}
assert(workletEnergy>100);
op('play',{value:0});for(let i=0;i<3;i++)c.sim_render();const silence=new Float32Array(c.memory.buffer,c.sim_render(),256);assert(silence.every(x=>x===0));
for(const page of [0,1,2,3,4,5,6,7]){op('select',{page,track:0,row:0,field:0,object:0});frame=core.frame(true);assert.equal(frame.tracker.state[0],page);assert(frame.pixels.length>0);}
const report={wasm_imports:0,sound_models:18,instrument_fields:75,instrument_pages:3,commands:57,project_bytes:original.length,rendered_frames:128000,energy,worklet_sample_rate:48000,worklet_energy:workletEnergy,verified:['32 sound fields, ADSR/filter/LFO parameter persistence and old mixer project migration','eight views including Global, ten scales and transactional slots across reboot','master send FX, musical divisions, mixer/FX project roundtrip, active wet handoff','C edit and validation','project export/import','invalid import leaves active project untouched','tempo edit preserves transport','stereo render bounds and silence','bit-identical handoff of full C memory','AudioWorklet resampling at 48 kHz']};
fs.writeFileSync('build/tracker-web/test-report.json',JSON.stringify(report,null,2)+'\n');console.log('PASS: real C/WebAssembly workbench, project roundtrip, audio, snapshot handoff and 48 kHz worklet');
