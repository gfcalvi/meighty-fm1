/* GPL-3.0-only. Run the shipped page, including its embedded payload. */
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const html=fs.readFileSync(process.argv[2],'utf8'),bytes=fs.readFileSync(process.argv[3]);
function boot(source){
 const elements=new Map();const el=id=>{if(!elements.has(id))elements.set(id,{disabled:true,textContent:'',checked:false,value:0});return elements.get(id);};
 const ctx={document:{getElementById:el,querySelectorAll:()=>[]},navigator:{requestMIDIAccess(){throw Error('No hardware access allowed in bootstrap test');}},isSecureContext:true,Uint8Array,ArrayBuffer,DataView,TextEncoder,TextDecoder,atob:s=>Buffer.from(s,'base64').toString('binary'),btoa:s=>Buffer.from(s,'binary').toString('base64'),console,setTimeout,clearTimeout};
 vm.createContext(ctx);for(const [,script]of source.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g))vm.runInContext(script,ctx);
 return {ctx,el};
}
const ok=boot(html);assert.match(ok.el('support').textContent,/Pacchetto e loader verificati/);assert.equal(ok.el('connect').disabled,false);assert.equal(ok.el('install').disabled,true);
const payload=vm.runInContext('FM1_M8_PACKAGE',ok.ctx);assert.deepEqual(Buffer.from(payload.data,'base64'),bytes);
const badBytes=Buffer.from(bytes);badBytes[5000]^=1;const damaged=boot(html.replace(payload.data,badBytes.toString('base64')));assert.equal(damaged.el('connect').disabled,true);assert.match(damaged.el('error').textContent,/Checksum/);
const noMidi=html.replaceAll('typeof navigator.requestMIDIAccess', 'typeof navigator.nonexistent');const none=boot(noMidi);assert.equal(none.el('connect').disabled,true);assert.match(none.el('error').textContent,/WebMIDI/);
console.log('PASS final HTML: embedded firmware byte-identical, scripts bootstrap, install disabled until consent, damaged firmware and absent WebMIDI refused; no USB commands sent');
