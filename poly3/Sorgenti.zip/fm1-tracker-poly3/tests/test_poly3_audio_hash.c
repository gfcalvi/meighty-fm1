/* Compare this output against the frozen A1 source, not against itself. */
#define main original_poly3_test_main
#include "test_poly3.c"
#undef main
#include <stdint.h>
int main(void){
 for(unsigned model=0;model<18;model++){
  setup(&a,model,8);a.project.bpm=300;
  for(unsigned k=0;k<32;k++){a.project.sound[k][9]=151;a.project.sound[k][13]=149;a.project.sound[k][14]=163;}
  for(unsigned k=0;k<8;k++)for(unsigned r=0;r<16;r++)a.project.phrases[k].step[r]=(TrStep){(uint8_t)(42+k+r%7),0,{{k==7?FX_CHD:FX_PORT,k==7?0x47:12},{FX_MDL,(uint8_t)((model+r)%18)}}};
  tr_transport(&a,1);memset(&work,0,sizeof work);work.submit=submit;work.join=join;
  uint64_t hash=1469598103934665603ULL;int16_t output[186];
  for(unsigned n=0;n<64000;){unsigned frames=64000-n;if(frames>93)frames=93;
   a.project.sound[0][8]=(uint8_t)(n/93*17);a.project.sound[0][7]=(uint8_t)(n/93*29);
   tr_render_stereo(&a,&preview,8,output,frames,&work);
   for(unsigned j=0;j<frames*2;j++)hash=(hash^(uint16_t)output[j])*1099511628211ULL;
   n+=frames;
  }
  printf("%02u %016llx\n",model,(unsigned long long)hash);
 }
 return 0;
}
