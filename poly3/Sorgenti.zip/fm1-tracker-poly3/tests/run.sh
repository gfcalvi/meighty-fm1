#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/tracker-host
${CC:-cc} -std=c11 -DFM1_HOST_TEST -Wall -Wextra -Werror -O1 -g \
 -fsanitize=address,undefined -fno-omit-frame-pointer \
 -Isdk/include -Iapp app/tracker/tracker.c app/tracker/commands.c tests/test_tracker.c \
 -o build/tracker-host/test_tracker
build/tracker-host/test_tracker
${CC:-cc} -std=c11 -DFM1_HOST_TEST -Wall -Wextra -Werror \
 -Isdk/include -Iapp -Iapp/synth -c app/tracker/device.c \
 -o build/tracker-host/device.o
${CC:-cc} -std=c11 -DFM1_HOST_TEST -Wall -Wextra -Werror -O1 -g \
 -fsanitize=address,undefined -fno-omit-frame-pointer \
 -Isdk/include -Iapp -Iapp/synth app/tracker/tracker.c app/tracker/commands.c app/tracker/device.c \
 tests/test_device.c -o build/tracker-host/test_device
build/tracker-host/test_device
${CC:-cc} -std=c11 -DFM1_HOST_TEST -Wall -Wextra -Werror -O1 -g \
 -fsanitize=address,undefined -fno-omit-frame-pointer \
 -Isdk/include -Iapp app/tracker/tracker.c app/tracker/commands.c tests/test_generative.c \
 -o build/tracker-host/test_generative
build/tracker-host/test_generative
${CC:-cc} -std=c11 -DFM1_HOST_TEST -Wall -Wextra -Werror -O1 -g \
 -fsanitize=address,undefined -fno-omit-frame-pointer \
 -Isdk/include -Iapp app/tracker/tracker.c app/tracker/commands.c tests/test_effects.c \
 -o build/tracker-host/test_effects
build/tracker-host/test_effects
${CC:-cc} -std=c11 -DFM1_HOST_TEST -Wall -Wextra -Werror -O1 -g \
 -fsanitize=address,undefined -fno-omit-frame-pointer \
 -Isdk/include -Iapp app/tracker/tracker.c app/tracker/commands.c tests/test_sound.c \
 -o build/tracker-host/test_sound
build/tracker-host/test_sound
${CC:-cc} -std=c11 -DFM1_HOST_TEST -Wall -Wextra -Werror -O1 -g \
 -fsanitize=address,undefined -fno-omit-frame-pointer \
 -Isdk/include -Iapp app/tracker/tracker.c app/tracker/commands.c tests/test_ambient.c \
 -o build/tracker-host/test_ambient
build/tracker-host/test_ambient
${CC:-cc} -std=c11 -DFM1_HOST_TEST -Wall -Wextra -Werror -O1 -g \
 -fsanitize=address,undefined -fno-omit-frame-pointer \
 -Isdk/include -Iapp app/tracker/tracker.c app/tracker/commands.c tests/test_berlin.c \
 -o build/tracker-host/test_berlin
build/tracker-host/test_berlin
${CC:-cc} -std=c11 -DFM1_HOST_TEST -Wall -Wextra -Werror -O1 -g \
 -fsanitize=address,undefined -fno-omit-frame-pointer \
 -Isdk/include -Iapp app/tracker/tracker.c app/tracker/commands.c tests/test_engines.c \
 -o build/tracker-host/test_engines
build/tracker-host/test_engines
${CC:-cc} -std=c11 -Wall -Wextra -Werror -Wno-misleading-indentation -fno-builtin -Dsnprintf=fm1_snprintf -c emulator/format.c -o build/tracker-host/format.o
${CC:-cc} -std=c11 -Wall -Wextra -Werror tests/test_format.c build/tracker-host/format.o -o build/tracker-host/test_format
build/tracker-host/test_format
${CC:-cc} -std=c11 -O1 -g -Wall -Wextra -Werror -Wno-unused-function -Wno-int-to-pointer-cast -Iemulator/hal -fsanitize=address,undefined tests/test_usb_tracker.c -o build/tracker-host/test_usb_tracker
build/tracker-host/test_usb_tracker
${CC:-cc} -std=c11 -DFM1_HOST_TEST -O1 -g -Wall -Wextra -Werror \
 -fsanitize=address,undefined -fno-omit-frame-pointer -Isdk/include -Iapp \
 app/tracker/tracker.c app/tracker/commands.c tests/test_block_render.c \
 -o build/tracker-host/test_block_render
build/tracker-host/test_block_render
${CC:-cc} -std=c11 -DFM1_HOST_TEST -DFM1_BLOCK_RENDER=1 -O1 -g -Wall -Wextra -Werror -Wno-unused-function \
 -fsanitize=address,undefined -fno-omit-frame-pointer -Isdk/include -Iapp -Iapp/synth \
 app/tracker/tracker.c app/tracker/commands.c tests/test_block_device.c \
 -o build/tracker-host/test_block_device
build/tracker-host/test_block_device
${CC:-cc} -std=c11 -DFM1_HOST_TEST -DFM1_BLOCK_RENDER=1 -O1 -g -Wall -Wextra -Werror -Wno-unused-function \
 -fsanitize=address,undefined -fno-omit-frame-pointer -Isdk/include -Iapp -Iapp/synth \
 app/tracker/tracker.c app/tracker/commands.c app/tracker/device.c tests/test_panel_lights.c \
 -o build/tracker-host/test_panel_lights
build/tracker-host/test_panel_lights
