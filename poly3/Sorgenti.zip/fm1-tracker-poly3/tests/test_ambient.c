#include "tracker/tracker.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
static Tracker t;
int main(void){long long late[2]={0,0};unsigned dense[2]={0,0};
 for(unsigned mode=0;mode<2;mode++){tr_init(&t);t.project.reverb_mode=mode;t.project.master[4]=224;t.project.master[5]=90;t.project.master[6]=255;tr_effects_reset(&t);
  long long early=0,end=0;int32_t out[2];for(unsigned n=0;n<TR_FX_RATE*20;n++){
   tr_effects_sample(&t,0,0,n==0?30000:0,0,out);assert(abs(out[0])<65536&&abs(out[1])<65536);
   if(n>=8000&&n<16000){if(out[0]||out[1])++dense[mode];early+=abs(out[0])+abs(out[1]);}
   if(n>=24000&&n<48000)late[mode]+=abs(out[0])+abs(out[1]);if(n>=144000)end+=abs(out[0])+abs(out[1]);
  }assert(early>0&&end<early*2);
  tr_effects_reset(&t);for(unsigned n=0;n<17000;n++){tr_effects_sample(&t,0,0,0,0,out);assert(!out[0]&&!out[1]);}
 }
 printf("Reverb density 1-2s: room %u/8000 ambient %u/8000; late energy room %lld ambient %lld\n",dense[0],dense[1],late[0],late[1]);
 assert(dense[1]>7000&&late[1]>late[0]*2);
 puts("PASS: dense ambient impulse response, extended decaying tail, bounded stereo output and lazy reset");return 0;
}
