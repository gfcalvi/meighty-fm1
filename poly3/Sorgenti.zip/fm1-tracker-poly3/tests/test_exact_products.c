/* Original signed64 product/division and frozen HW26 filter are the oracle. */
#include "../app/tracker/tracker.c"
#include "filter-A10-reference.inc"
#include <assert.h>
#include <stdio.h>
static Tracker t;
static unsigned long long checks;
static void check(int32_t n,uint32_t gain,unsigned bits){
 int32_t original=(int32_t)(((int64_t)n*gain)/(INT64_C(1)<<bits));
 assert(tr_mul_q(n,gain,bits)==original);checks++;
}
int main(void){
 static const int32_t values[]={INT32_MIN,INT32_MIN+1,-131072,-65535,-32768,-1,0,1,32767,65535,131072,INT32_MAX};
 static const uint32_t gains[]={0,1,127,255,256,4092,15064,32767,32768,64000,65535,0x7fffffffU,0x80000000U,UINT32_MAX};
 static const unsigned shifts[]={0,1,8,12,15,16,24,31,32};
 for(unsigned n=0;n<sizeof values/sizeof values[0];n++)for(unsigned g=0;g<sizeof gains/sizeof gains[0];g++)for(unsigned k=0;k<sizeof shifts/sizeof shifts[0];k++)check(values[n],gains[g],shifts[k]);
 uint32_t random=0x5681e3ab;
 for(unsigned i=0;i<1000000;i++){
  random=random*1664525U+1013904223U;int32_t n=(int32_t)random;
  random=random*1664525U+1013904223U;uint32_t gain=random;
  for(unsigned k=0;k<sizeof shifts/sizeof shifts[0];k++)check(n,gain,shifts[k]);
 }
 tr_init(&t);unsigned frames=0;
 for(unsigned modern=0;modern<2;modern++)for(unsigned mode=0;mode<4;mode++)for(unsigned res=0;res<256;res++){
  uint8_t *s=t.project.sound[0];s[0]=(uint8_t)modern;s[1]=2;s[2]=3;s[3]=(uint8_t)res;s[4]=2;s[5]=(uint8_t)res;s[6]=(uint8_t)mode;
  uint8_t *ce=t.project.cutoff_env[0];ce[0]=(uint8_t)(res&1);ce[1]=ce[2]=ce[4]=2;ce[3]=(uint8_t)res;ce[5]=(uint8_t)(255-res);
  TrVoice a,b;tr_audition_on(&t,&a,0,0,60);b=a;
  for(unsigned i=0;i<256;i++){
   if(i==192){tr_release(&t,&a);tr_release(&t,&b);}
   random=random*1664525U+1013904223U;int32_t input=(int32_t)(random&262143U)-131072;
   a.cutoff=b.cutoff=(uint8_t)(res+i);a.mod_cutoff=b.mod_cutoff=(int32_t)(random>>24)-128;
   a.mod_amp=b.mod_amp=(int32_t)((random>>8)&255)-128;
   assert(sound_envelope_filter(&t,&a,input)==sound_envelope_filter_reference(&t,&b,input));
   assert(!memcmp(&a,&b,sizeof a));frames++;
  }
 }
 printf("PASS %llu signed32 x unsigned32 product checks (including INT32_MIN/full gain and9shifts); %u filter frames vs frozen HW26:legacy/ADSR,4modes,256resonances,cutoff envelope,release and full voice state\n",checks,frames);return 0;
}
