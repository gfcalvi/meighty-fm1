// SPDX-License-Identifier: GPL-3.0-only
#include <cstring>
#include "RFMCoreBackend.h"
#include "RFMWasm.h"
#include <cstdio>
#include <vector>
#include <cassert>
#include <chrono>
namespace rfm {bool engineLoad(::rfme *,CoreFactory,std::string *){return false;}}
int main(int argc,char **argv){assert(argc==2);char error[2048];rfmw_info_t info={};if(!rfmw_check(argv[1],&info,error,sizeof error)){fprintf(stderr,"FAIL host loader: %s\n",error);return 1;}printf("PASS official host loader: %s %s abi=%u flash=%u memory=%u\n",info.name,info.version,info.abi,info.flash_size,info.memory_bytes);
 std::string msg;auto file=rfm::wasmOpen(argv[1],&msg);auto c=rfm::wasmCoreFactory(file)(&msg);assert(c);assert(c->flash_stage(nullptr,0));c->options(FM1CORE_FLASH_STAGED,0,0,1);c->boot_options(-1,nullptr,-1);c->panel()->ready=2;c->init(0);auto panel=c->panel();assert(panel->lcd_writes>0);panel->buttons_tap=1u<<12;std::vector<int16_t>pcm(256);long long energy=0;unsigned blocks=0;auto start=std::chrono::steady_clock::now();for(unsigned ms=0;ms<2500;ms++){c->tick(ms);if(ms%15==0)c->frame();else c->idle();while(blocks*128u*1000u/44100u<=ms){c->audio(pcm.data(),128);for(auto v:pcm)energy+=v<0?-(long long)v:v;blocks++;}assert(!c->halted());}double elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();assert(energy>10000);printf("PASS wasm3 demo/audio: blocks=%u energy=%lld elapsed=%.3fs simulated=2.5s LCDwrites=%u\n",blocks,energy,elapsed,panel->lcd_writes);
 panel->buttons=0;panel->buttons_tap=1u<<9;c->tick(2501);assert(c->flash_dirty()>0);std::vector<uint8_t>saved(c->flash(),c->flash()+c->flash_size());c->shutdown();c.reset();auto restored=rfm::wasmCoreFactory(file)(&msg);assert(restored->flash_stage(saved.data(),saved.size()));restored->options(FM1CORE_FLASH_STAGED,0,0,1);restored->panel()->ready=2;restored->init(0);assert(!restored->halted());assert(!memcmp(saved.data(),restored->flash(),saved.size()));printf("PASS wasm3 saved flash/reboot and LCD, no traps\n");}
