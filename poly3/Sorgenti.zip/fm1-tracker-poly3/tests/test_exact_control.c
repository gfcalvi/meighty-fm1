/* Independent original arithmetic is the oracle for all256 rates/levels. */
#include "../app/tracker/tracker.c"
#include <assert.h>
#include <stdio.h>
static Tracker t;
int main(void){
 tr_init(&t);
 for(unsigned rate=0;rate<256;rate++)for(unsigned shape=0;shape<4;shape++){
  TrVoice v={0};v.instrument=0;v.model=17;v.lfo_phase[0]=0xfffffff0U;v.lfo_phase[1]=0x87654321U;
  t.project.sound[0][9]=(uint8_t)rate;t.project.sound[0][16]=(uint8_t)(255-rate);t.project.sound[0][10]=t.project.sound[0][17]=(uint8_t)shape;
  uint32_t p0=v.lfo_phase[0],p1=v.lfo_phase[1];
  for(unsigned k=0;k<17;k++){
   p0+=rate?(uint32_t)(((uint64_t)(64+rate*rate)*4294967296ULL)/(TR_RATE*100ULL)):0;
   unsigned r=255-rate;p1+=r?(uint32_t)(((uint64_t)(64+r*r)*4294967296ULL)/(TR_RATE*100ULL)):0;
   sound_modulate(&t,&v);assert(v.lfo_phase[0]==p0&&v.lfo_phase[1]==p1);
  }
  uint8_t params[6]={0};params[3]=(uint8_t)rate;TrEnvelope env={0};env.stage=2;cutoff_tick(&env,params);
  assert(env.level==(int32_t)(rate*32767U/255U));assert(env.value==(rate*32767U/255U)*65536U);
 }
 puts("PASS all256 LFO rates x4shapes/17ticks including phase wrap, both LFOs and all256 cutoff sustain levels against original uint64/division oracle");return 0;
}
