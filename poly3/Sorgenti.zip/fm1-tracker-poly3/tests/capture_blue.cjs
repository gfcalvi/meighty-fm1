const fs=require('node:fs'),vm=require('node:vm');
const base=fs.readFileSync('tests/test_rfm1.cjs','utf8').split('assert(view().getUint32(field(12)')[0];
const extra=`
function wait(){for(let i=0;i<65;i++)tick();}
function capture(name){wait();const lcd=new Uint8Array(e.memory.buffer,field(11),240*240*2),rgb=Buffer.alloc(240*240*3);for(let i=0;i<240*240;i++){const c=lcd[i*2]*256+lcd[i*2+1];rgb[i*3]=(c>>11)*255/31;rgb[i*3+1]=(c>>5&63)*255/63;rgb[i*3+2]=(c&31)*255/31;}fs.writeFileSync('build/rfm1/blue-'+name+'.ppm',Buffer.concat([Buffer.from('P6\\n240 240\\n255\\n'),rgb]));}
capture('song');tap(3);capture('chain');tap(4);capture('phrase');tap(6);capture('table');tap(5);capture('fm4');enc(5,127);enc(5,-4);tap(13);capture('dual');tap(5);capture('amp');enc(2,5);capture('filter');enc(2,6);capture('lfo');tap(5);capture('engine');tap(8);capture('mixer');tap(11);capture('fx');tap(7);capture('global');tap(5);enc(5,1);capture('presets');
console.log('PASS 14 screenshots of the actual C UI, including eight tracks, both envelopes, LFO and engines.');`;
vm.runInThisContext('(function(require){'+base+extra+'})',{filename:'blue-capture-inline.cjs'})(require);
