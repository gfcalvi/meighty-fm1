/* SPDX-License-Identifier: GPL-3.0-only WITH GPL-3.0-linking-exception */
#include "tracker/tracker.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static Tracker a,b;
static TrStep *setup(Tracker *t){
 tr_init(t);t->project.song[0][0]=0;t->project.chains[0].phrase[0]=0;
 TrStep *s=t->project.phrases[0].step;s[0].note=60;s[0].instrument=0;
 tr_transport(t,1);return s;
}
static void next_row(Tracker *t){for(unsigned n=0;n<6;n++)tr_tick(t);}
static void repeat(void){
 TrStep *s=setup(&a);s[0].fx[0]=(TrFx){FX_CUT,16};s[1].fx[0]=(TrFx){FX_REP,2};
 s[3].fx[0]=(TrFx){FX_RTO,22};
 tr_tick(&a);assert(a.voice[0].cutoff==16);for(unsigned n=0;n<5;n++)tr_tick(&a);
 tr_tick(&a);assert(a.voice[0].cutoff==18&&a.voice[0].lanes[0].running);
 for(unsigned n=0;n<5;n++)tr_tick(&a);tr_tick(&a);assert(a.voice[0].cutoff==20);
 for(unsigned n=0;n<5;n++)tr_tick(&a);tr_tick(&a);assert(a.voice[0].cutoff==22&&!a.voice[0].lanes[0].running);
 s=setup(&a);s[0].fx[0]=(TrFx){FX_VOL,20};s[1].fx[0]=(TrFx){FX_REP,0xff};
 s[2].note=65;s[2].instrument=0;next_row(&a);next_row(&a);tr_tick(&a);
 assert(a.voice[0].volume==18&&a.voice[0].lanes[0].running);
 s[3].fx[0]=(TrFx){FX_REP,0};for(unsigned n=0;n<6;n++)tr_tick(&a);assert(!a.voice[0].lanes[0].running);
}
static void chance(void){
 TrStep *s=setup(&a);s[0].fx[0]=(TrFx){FX_CUT,55};s[0].fx[1]=(TrFx){FX_CHN,0};
 tr_tick(&a);assert(a.voice[0].active&&a.voice[0].cutoff==128);
 s=setup(&a);s[0].fx[0]=(TrFx){FX_CUT,55};s[0].fx[1]=(TrFx){FX_CHN,255};
 tr_tick(&a);assert(a.voice[0].cutoff==55);
 s=setup(&a);s[0].fx[0]=(TrFx){FX_CHA,0x0f};s[0].fx[1]=(TrFx){FX_CUT,55};
 tr_tick(&a);assert(!a.voice[0].active&&a.voice[0].cutoff==55);
 s=setup(&a);s[0].fx[0]=(TrFx){FX_HOP,3};s[0].fx[1]=(TrFx){FX_CHN,0};
 next_row(&a);assert(a.voice[0].chain==0&&a.voice[0].step==1);
}
static void navigation(void){
 TrStep *s=setup(&a);a.project.chains[0].length=2;a.project.chains[0].phrase[1]=1;
 s[0].fx[0]=(TrFx){FX_HOP,3};next_row(&a);assert(a.voice[0].chain==1&&a.voice[0].step==3);
 s=setup(&a);s[0].fx[0]=(TrFx){FX_HOP,255};tr_tick(&a);assert(a.voice[0].stopped&&!a.voice[0].active);
 s=setup(&a);s[0].fx[0]=(TrFx){FX_DEL,2};s[0].fx[1]=(TrFx){FX_CUT,22};
 tr_tick(&a);assert(a.voice[0].cutoff==128);tr_tick(&a);assert(a.voice[0].cutoff==128);
 tr_tick(&a);assert(a.voice[0].cutoff==22&&a.voice[0].active);
}
static void randomization(void){
 TrStep *s=setup(&a);s[0].fx[0]=(TrFx){FX_RNL,0x50};s[0].fx[1]=(TrFx){FX_SED,42};
 for(unsigned n=1;n<16;n++){s[n].note=60;s[n].fx[0]=(TrFx){FX_RNL,0x50};}
 b=a;TrPhrase original=a.project.phrases[0];
 unsigned different=0;
 for(unsigned n=0;n<96;n++){
  tr_tick(&a);tr_tick(&b);assert(a.voice[0].rng==b.voice[0].rng&&a.voice[0].target==b.voice[0].target);
  if(a.voice[0].note!=60)different++;
 }
 assert(different&&memcmp(&original,&a.project.phrases[0],sizeof original)==0);
 /* An unrelated track's random consumption must not affect track zero. */
 b=a;b.voice[1].rng=12345678;for(unsigned n=0;n<96;n++){tr_tick(&a);tr_tick(&b);assert(a.voice[0].rng==b.voice[0].rng);}
 s=setup(&a);s[0].fx[0]=(TrFx){FX_VOL,0x80};s[1].fx[0]=(TrFx){FX_RND,0xff};
 next_row(&a);tr_tick(&a);assert(a.voice[0].lanes[0].last.value==0x80);
}
static void table_and_pitch(void){
 TrStep *s=setup(&a);s[0].fx[0]=(TrFx){FX_ARP,0x37};
 tr_tick(&a);uint32_t base=a.voice[0].target;tr_tick(&a);uint32_t third=a.voice[0].target;
 tr_tick(&a);assert(base<third&&third<a.voice[0].target);
 setup(&a);a.project.instruments[0].table=0;a.project.tables[0].length=3;
 a.project.tables[0].row[1].fx[0]=(TrFx){FX_HOP,0x20};
 tr_tick(&a);assert(a.voice[0].table_row==1);tr_tick(&a);assert(a.voice[0].table_row==0);
 for(unsigned n=0;n<4;n++)tr_tick(&a);assert(a.voice[0].table_row==2);
 setup(&a);a.project.instruments[0].table=0;
 a.project.tables[0].row[0].fx[0]=(TrFx){FX_TIC,3};
 tr_tick(&a);assert(a.voice[0].table_row==1);tr_tick(&a);tr_tick(&a);assert(a.voice[0].table_row==1);
 tr_tick(&a);assert(a.voice[0].table_row==2);
}
static void table_restart_and_release(void){
 setup(&a);a.project.instruments[0].table=0;
 a.project.tables[0].row[0].fx[0]=(TrFx){FX_TBL,1};
 a.project.tables[1].row[0].fx[0]=(TrFx){FX_VOL,33};
 tr_tick(&a);assert(a.voice[0].table_id==1&&a.voice[0].table_row==0);
 tr_tick(&a);assert(a.voice[0].table_row==1&&a.voice[0].volume==33);
 TrStep *s=setup(&a);s[0].fx[0]=(TrFx){FX_OFF,0};tr_tick(&a);assert(a.voice[0].active&&!a.voice[0].attacking);
}
static void fuzz(void){
 unsigned r=12345;setup(&a);
 for(unsigned n=0;n<16;n++){
  TrStep *s=&a.project.phrases[0].step[n];r=r*1664525U+1013904223U;s->note=(uint8_t)(r%128);s->instrument=0;
  for(unsigned f=0;f<2;f++){r=r*1664525U+1013904223U;s->fx[f].command=(uint8_t)(r%FX_COUNT);s->fx[f].value=(uint8_t)(r>>16);}
 }
 for(unsigned n=0;n<200000;n++){if(n%5000==0)tr_transport(&a,1);(void)tr_sample(&a);}
}
int main(void){
 assert(FX_COUNT==57);for(unsigned n=0;n<FX_COUNT;n++){assert(strlen(tr_fx_name(n))==3);assert(tr_fx_help(n));}
 repeat();chance();navigation();randomization();table_and_pitch();table_restart_and_release();fuzz();
 printf("PASS: %u FX entries, REP/RTO persistence, CHN/CHA routing, gated HOP, delayed row, seeded randomness, ARP, table HOP/TIC, command stress\n",FX_COUNT);
}
