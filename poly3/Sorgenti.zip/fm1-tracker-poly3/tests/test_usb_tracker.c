#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#define FELUCCA_OTA 1
#define FELUCCA_CDC 0
#define FELUCCA_USB_AUDIO 0
#define FELUCCA_BLE 0
#define RING_PUBLISH() __asm__ volatile("" ::: "memory")
static uint32_t now;
static uint32_t fm1_ticks(void){return now;}
static void fm1_delay_ms(uint32_t n){now+=n*24000;}
#include "../hardware/vendor/usb.c"
static uint32_t ota_now_ms(void){return now/24000;}
static void ota_idle(void){now+=24000;}
int main(void){const uint8_t *d;uint16_t n;
 assert(get_desc(0x100,&d,&n)&&n==18&&d[4]==0);assert(get_desc(0x200,&d,&n)&&n==101&&d[4]==2);unsigned hid=0;for(unsigned at=0;at<n;at+=d[at]){assert(d[at]>=2&&at+d[at]<=n);if(d[at+1]==4&&d[at+5]==3)hid++;}assert(!hid);
 assert(get_desc(0x302,&d,&n)&&n==26);char name[16]={0};for(unsigned i=2;i<n;i+=2)name[(i-2)/2]=(char)d[i];assert(!strcmp(name,"FM-1 Meighty"));
 const uint8_t request[]={0xf0,0x22,0x24,0x35,0x7f,0xf7};for(unsigned i=0;i<sizeof request;i++)sysex_byte(request[i]);assert(usb.ota_req&&!sx_ready);usb.ota_req=0;
 sysex_byte(0xf0);for(unsigned i=0;i<640;i++)sysex_byte(i&127);sysex_byte(0xf7);const uint8_t *p;uint32_t bytes;assert(ota_frame_get(&p,&bytes)&&bytes==640);for(unsigned i=0;i<640;i++)assert(p[i]==(i&127));ota_frame_done();assert(!ota_frame_get(&p,&bytes));
 sysex_byte(0xf0);for(unsigned i=0;i<641;i++)sysex_byte(i&127);sysex_byte(0xf7);assert(!ota_frame_get(&p,&bytes));
 midi_in_unread=1;for(unsigned i=0;i<200;i++)usb_midi_rx_packet(0x643c9009,0);assert(mi_w==mi_r&&ep1_room());
 puts("PASS: hardware MIDI descriptors, update command, 640-byte SysEx flow, overflow rejection and MIDI flood isolation");}
