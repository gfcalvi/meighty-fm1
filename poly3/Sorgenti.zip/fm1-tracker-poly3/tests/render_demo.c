/* SPDX-License-Identifier: GPL-3.0-only WITH GPL-3.0-linking-exception */
#include "tracker/tracker.h"
#include <stdio.h>
static Tracker t;
static int16_t drum[1024];
static void le32(FILE *f,uint32_t n){for(unsigned i=0;i<4;i++)fputc((int)((n>>(8*i))&255),f);}
static void le16(FILE *f,unsigned n){fputc(n&255,f);fputc((n>>8)&255,f);}
int main(int argc,char **argv){
 if(argc!=2)return 1;FILE *f=fopen(argv[1],"wb");if(!f)return 2;
 tr_init(&t);tr_evolving_demo(&t);uint32_t noise=12345;
 for(unsigned n=0;n<1024;n++){noise^=noise<<13;noise^=noise>>17;noise^=noise<<5;drum[n]=(int16_t)(((int32_t)(noise&65535)-32768)*(1024-(int32_t)n)/1024);}
 for(unsigned n=0;n<8;n++){TrSample s={drum,1024,32000,60};tr_set_sample(&t,n,&s);}
 unsigned frames=32000*8;
 fwrite("RIFF",1,4,f);le32(f,36+frames*2);fwrite("WAVEfmt ",1,8,f);le32(f,16);
 le16(f,1);le16(f,1);le32(f,32000);le32(f,64000);le16(f,2);le16(f,16);
 fwrite("data",1,4,f);le32(f,frames*2);tr_transport(&t,1);
 for(unsigned n=0;n<frames;n++)le16(f,(uint16_t)tr_sample(&t));
 return fclose(f)!=0;
}
