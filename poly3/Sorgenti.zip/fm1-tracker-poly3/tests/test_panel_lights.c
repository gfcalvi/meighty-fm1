#define main previous_device_tests
#include "test_device.c"
#undef main
int main(void){
 memset(store_flash,255,sizeof store_flash);tracker_device_init();tracker_ui_play(0);
 const unsigned page[8]={0,3,1,4,2,7,5,6},button[8]={2,3,4,5,6,7,8,11};
 for(unsigned i=0;i<8;i++){
  controls.buttons=0;tracker_device_control();controls.buttons=1U<<button[i];tracker_device_control();
  assert(tracker_ui_state(0)==page[i]);assert(tracker_ui_button_lights()==(1U<<button[i]));
  controls.buttons=0;tracker_device_control();assert(tracker_ui_button_lights()==(1U<<button[i]));
  tracker_ui_play(1);assert(tracker_ui_button_lights()==((1U<<button[i])|(1U<<12)));tracker_ui_play(0);
 }
 assert(!tracker_ui_select(4,0,0,8,0));controls.buttons=1U<<10;tracker_device_control();
 assert(tracker_ui_state(17));assert(tracker_ui_button_lights()==((1U<<5)|(1U<<10)));
 controls.buttons=0;tracker_device_control();controls.buttons=1U<<10;tracker_device_control();
 assert(!tracker_ui_state(17));assert(tracker_ui_button_lights()==(1U<<5));
 puts("PASS panel LEDs follow all eight physical page buttons, stay on after release, show PLAY and instrument catalog");return 0;
}
