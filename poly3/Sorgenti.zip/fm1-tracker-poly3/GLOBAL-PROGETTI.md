# Global, scale e progetti — Tracker A03

## Mappa aggiornata dei tasti

- **GLO → Global**.
- **HOME → Mixer**.
- **SEQ → Master FX**; disponibile anche dalla pagina Global.
- Instrument mantiene la rotazione fra Suono e Modulazioni.
- In Song, OCT− mute e OCT+ solo restano invariati.

Il BPM compare e si modifica soltanto in Global. Le altre schermate non lo ripetono nell'intestazione e K4 non modifica più il BPM nelle pagine Song/Chain/Phrase/Instrument/Table. K4 conserva le funzioni specifiche del Mixer e di Master FX.

## Parametri globali del progetto

**BPM:** 30–300, valore decimale. Il comando Phrase TPO continua a poterlo automatizzare.

**Scala:**

| Opzione | Intervalli dalla tonica, in semitoni |
|---|---|
| CHROMATIC | Tutte le dodici note; quantizzazione disattivata |
| MAJ/IONIAN | 0, 2, 4, 5, 7, 9, 11 |
| DORIAN | 0, 2, 3, 5, 7, 9, 10 |
| PHRYGIAN | 0, 1, 3, 5, 7, 8, 10 |
| LYDIAN | 0, 2, 4, 6, 7, 9, 11 |
| MIXOLYDIAN | 0, 2, 4, 5, 7, 9, 10 |
| MIN/AEOLIAN | 0, 2, 3, 5, 7, 8, 10 |
| LOCRIAN | 0, 1, 3, 5, 6, 8, 10 |
| MIN PENT | 0, 3, 5, 7, 10 |
| MAJ PENT | 0, 2, 4, 7, 9 |

**Tonica:** C, C#, D, D#, E, F, F#, G, G#, A, A#, B. Sono dodici classi di altezza, senza selezione dell'ottava.

La quantizzazione agisce sul pitch effettivo del sequencer e della tastiera/preview, anche per i sample. Una nota fuori scala viene portata alla nota valida inferiore; al limite MIDI inferiore viene usata la prima nota valida disponibile. Le note memorizzate nelle Phrase non vengono riscritte: cambiando scala puoi provare altre armonie mantenendo il materiale originale. I comandi locali SCA maggiore/minore conservano la precedenza per la loro traccia; senza un SCA locale si usa la scala Global. Gli LFO di pitch restano modulazioni continue.

Le nuove impostazioni si applicano alle note del sequencer al prossimo aggiornamento del pitch e alla preview dal trigger successivo. I progetti precedenti vengono inizializzati in CHROMATIC/C per mantenere il loro suono.

## Otto slot di progetto

Sul pannello FM-1:

1. Premi **GLO**.
2. **K1** seleziona il parametro; **K2** modifica il valore.
3. Seleziona **PROJECT SLOT**, quindi scegli uno slot 1–8.
4. Seleziona **LOAD PROJECT** o **SAVE PROJECT** e premi **REC** per eseguire.
5. Il tasto **SAVE** è anche una scorciatoia per salvare nello slot selezionato.

Il caricamento interrompe il trasporto e ripristina il progetto dello slot. Uno slot vuoto o corrotto lascia intatto il progetto in memoria. Il display mostra l'esito dell'operazione. La selezione dello slot non modifica i dati musicali e non marca il progetto come modificato.

Nel Workbench, Global raccoglie gli stessi parametri e i pulsanti **Salva progetto**, **Carica progetto**, **Importa progetto**, **Esporta progetto**, **Nuovo progetto** e **Demo generativa**. Importazione/esportazione usano il file `.fm1tracker`. Gli slot persistenti sono gestiti dal medesimo codice C tramite la flash simulata, conservata nel browser; dopo un salvataggio/caricamento riuscito viene aggiornata anche la copia del progetto corrente usata alla riapertura. Il file esportato conserva le impostazioni Global e lo slot selezionato. Non sono necessari account o servizi online.

I progetti contengono arrangiamento, strumenti, nomi, mixer, FX e modulazioni; il materiale PCM resta quello già disponibile nel prototipo. Questa modifica non aggiunge un trasferimento di sample esterni o un browser file sul dispositivo fisico.

## Salvataggio protetto

Il backend C usa otto slot con due banchi per slot. Ogni banco occupa tre settori da 4096 byte e contiene firma, versione, dimensione, generazione, CRC32 del progetto e marcatore di commit finale. Si scrive nel banco alternativo e si conserva l'ultima copia valida. L'ordine di cancellazione mantiene la firma di proprietà fino all'ultimo settore, consentendo un nuovo salvataggio dopo le interruzioni simulate fra le operazioni.

La regione riservata esclude l'ultimo settore SDK. Un banco contenente dati di un altro formato non viene cancellato: compare **FLASH OCCUPIED**. La flash del framework è condivisa con il suo formato precedente; non si promette la coesistenza con qualunque immagine di progetti/sample stock. Non esiste una formattazione automatica dei dati sconosciuti.

Le chiamate flash avvengono nel controllo, con interrupt abilitati; solo la copia RAM del progetto usa una breve sezione protetta. Il buffer di lavoro aggiuntivo è di circa 11 KiB. Le strutture già esportate vengono migrate inizializzando soltanto i nuovi dati, preservando ADSR, LFO, riverbero Ambient e mixer precedenti.

## Verifica

- Tutte le dieci opzioni di scala su dodici toniche e 128 note MIDI; preview quantizzata.
- Mappa GLO/HOME/SEQ e rimozione del BPM dal controllo K4 delle altre pagine.
- Salvataggio/caricamento di più generazioni, interruzioni simulate in sei punti di erase/write/commit, recupero e successivo nuovo salvataggio.
- Rifiuto di dati flash sconosciuti, slot vuoto senza alterare il progetto corrente.
- C/WASM: riavvio con flash persistente, nuovi parametri e migrazione dei vecchi progetti.
- Browser: slot 8 salvato a 147 BPM, La pentatonica minore; ripristino dopo modifica e riapertura.
- I 65 file ufficiali SDK sono invariati. Moduli PI32v2 aggiornati compilati sul Mac.

Resta da verificare il comportamento sul FM-1 fisico con il firmware completo collegato e impacchettato. I test di interruzione usano un emulatore della flash e non sostituiscono prove di alimentazione sul dispositivo.
# Aggiornamento Projects, 5 novembre 2026

Questa nota prevale sulle istruzioni storiche sotto. Global ha 14 campi: dopo FX colour trovi Clear song e New project. Scegli con K1; premi e rilascia REC, poi premi REC nuovamente entro sette secondi. Un altro controllo o una nuova nota annulla la conferma.

Clear song svuota solo l'arrangiamento (32 righe × 8 tracce, LENGTH 1), conservando Phrase/Chain/Table/suoni/mix/FX e impostazioni. New project inizializza tutto il progetto musicale (120 BPM, cromatica, C), conservando palette e numero slot; preset e campioni di fabbrica restano disponibili. Entrambe fermano il trasporto e agiscono solo sulla RAM. Per registrare il risultato serve SAVE.

Il numero Project slot è una sorgente/destinazione, non un cambio progetto automatico. Load da uno slot vuoto mostra EMPTY SLOT e lascia in memoria il progetto aperto. Per mantenere il primo brano e iniziarne un secondo: SAVE in slot 1 → seleziona slot 2 → New project → REC, rilascio, REC → SAVE. Poi scegli il numero e usa Load per richiamare ciascun brano. All'avvio si ripristina lo slot 1 se valido.

Save state di RemoteFM1 comprende tutti gli otto slot. Prima salva nel tracker, poi crea lo stato esterno. Importare uno stato E00 o una song sostituisce l'intera memoria attiva: non usarlo per inizializzare un solo slot. Manuale corrente: FM1-M8-Manuale-Italiano.pdf, capitolo 8.

---

