> Controlli aggiornati: **GLO Global · HOME Mixer · SEQ Master FX**. BPM e gestione progetti sono in Global. Vedi [GLOBAL-PROGETTI.md](GLOBAL-PROGETTI.md); queste indicazioni sostituiscono i mapping riportati nelle sezioni storiche.

# Tracker generativo sperimentale per M VAVE FM1

Versione di sviluppo A03 del 25 ottobre 2026. La base è FM1 Open ufficiale, commit `4c7496daac04a95ff10d1afdcc8f9ead2dbabc41`, da https://github.com/m-vave/fm1_open. Sorgenti, driver, SDK e licenze originali sono inclusi. I file dell'SDK sono rimasti invariati e sono stati verificati rispetto a tutti i 65 hash del suo manifest.

Il codice custom è compilato e verificato sul Mac con periferiche simulate. I tre moduli tracker.c, commands.c e device.c sono stati anche compilati per PI32v2 r3 sul Mac tramite Blink e la toolchain Linux già usata per FM-1 Evolver. Gli oggetti prodotti sono ELF32 little endian, macchina 0xF1. Il linking completo con FM1 Open e il collaudo FM1 restano da effettuare. Non è stato prodotto un firmware tracker installabile. Il file `.fwsc` di recupero eventualmente presente nell'SDK è il firmware originale M-VAVE, non questo tracker.

## Priorità del progetto

Il cuore del tracker sono i comandi di riga componibili, con memoria per ogni colonna FX e generazione musicale riproducibile. M8 e picoTracker Advance sono riferimenti funzionali; FM1 Open rimane la piattaforma hardware. Questo firmware non usa codice proprietario M8 e non implementa compatibilità con i file M8 o picoTracker.

Il documento Word è stato usato come specifica. I suoi prompt sequenziali non sono stati eseguiti come messaggi dell'utente. Le ipotesi del documento su GCC e DFU sono state sostituite con il contratto effettivo dell'SDK: Clang PI32v2, target r3 e pacchetti `.fwsc`. I moduli sono C11 perché il builder ufficiale seleziona file `.c` e `.S`.

## Stato delle funzioni

- Otto tracce mono utilizzabili con strumenti SYNTH o SAMPLE PCM16. La demo mantiene quattro synth e quattro sampler.
- Song di massimo 32 righe; 32 Chain da 16 Phrase; 64 Phrase da 16 step; 32 strumenti; 16 Table da 16 righe.
- Due colonne FX per Phrase e tre per Table, come nella specifica e nel modello picoTracker Advance. Ogni parametro FX è un byte, scelta vicina a M8; i parametri a 16 bit del picoTracker non sono importabili direttamente.
- Clock interno 24 PPQN, sei tick per step, tempo interno 30–300 BPM.
- 42 comandi più la voce vuota. Nomi leggibili e aiuto contestuale nelle viste Phrase e Table. Elenco completo e differenze in `COMANDI.md`.
- Probabilità di riga o di singolo comando, condizioni cicliche e PRV, PRNG indipendente per traccia con SED, randomizzazione di note/strumenti e parametri, REP persistente e RTO, retrigger distinto RET, arpeggio, pitch drift, vibrato, salti e controllo delle Table.
- Synth originale in interi: saw, pulse con larghezza regolabile, wavetable sinusoidale, square e noise; Attack/Decay e filtro passa basso a un polo.
- Sampler mono a 22050 o 32000 Hz, interpolazione lineare, pitch, regione start/length e inviluppo. I rapporti di resampling si calcolano ai tick, evitando la divisione del rapporto a ogni campione.
- Motore a 32000 Hz, adattatore sample and hold a 44100 Hz per il driver originale; uscita stereo Q23 con mixer, mandate e ritorni master; saturazione morbida.
- Sette viste editabili sul display 240 × 240: Song, Phrase, Table, Chain e Instrument. Il rendering trasferisce solo righe cambiate, con buffer da 4800 byte.

Il tracker non modifica le Phrase in memoria durante randomizzazione, REP o condizioni: usa copie degli eventi e stato di esecuzione. L'esecuzione di ogni tick ha un numero limitato di operazioni; un salto non causa ricorsione o loop immediati. Nessun malloc e nessun float nei nuovi moduli DSP. Il framework originale conserva il proprio runtime e le proprie allocazioni.

L'oggetto Tracker misura 10888 byte nella build host ARM64; sul target i puntatori hanno dimensione diversa. Il valore include sequencer e descrittori, esclude waveform, lookup table, framebuffer, stack e runtime originale. Non costituisce una verifica del budget RAM PI32.

## Controlli provvisori

| Controllo | Funzione |
| --- | --- |
| PLAY | Avvio/arresto dall'inizio |
| FX / SEL | Song / Chain |
| ENV / LFO / EDIT | Phrase / Instrument / Table |
| HOME | Vista successiva |
| SELECT / ALGORITHM / PRESETS | Traccia / Riga / Vista |
| K1 | Campo (Song: traccia) |
| K2 | Valore |
| K3 | ID (Song: lunghezza) |
| K4 | BPM |
| REC in Phrase | Inserisce C4 e lo strumento associato al numero di traccia |
| Tastiera in Phrase | Inserisce F3–G5 |
| GLO tenuto nella Song | Imposta lunghezza Song alla riga corrente più uno |

Gli ID sono condivisi e si scelgono esplicitamente con K5. `FF` nella Song o nella Chain è uno slot vuoto. Nella Phrase `FF` mantiene la nota, `FE` la interrompe e `00`–`7F` sono note MIDI. Strumento `FF` mantiene quello precedente. Table `FF` nello strumento disabilita la Table. Tutti i valori dei comandi sono mostrati in esadecimale.

## Prova sul Mac

Eseguire `Verifica-Mac.command`, oppure da Terminale nella cartella del progetto:

```sh
sh tests/run.sh
```

Serve il compilatore dei Command Line Tools di Xcode. Lo script usa warning come errori, AddressSanitizer e UndefinedBehaviorSanitizer. Sono presenti tre programmi di test: sequencer/DSP, adattatore device con periferiche simulate, comandi generativi. Il launcher genera anche un WAV in `build/tracker-host/anteprima.wav`.

Sono verificati clock su uno e dieci secondi, stop, avanzamento Song/Chain/Phrase, DEL/KIL/JMP/RET/PSL, regione PCM, otto voci, Table, conversione di uscita, controlli, cinque viste e limiti del display. I test generativi verificano REP su righe vuote e nuovi trigger, RTO, chance sul solo comando di sinistra, HOP condizionato, ritardo di tutta la riga, seed riproducibile, indipendenza dei PRNG, immutabilità delle Phrase, ARP, HOP limitato nelle Table, TIC e uno stress di comandi.

L'anteprima audio è una demo offline del motore custom, con sweep CUT/REP/RTO, melodia randomizzata con seed, arpeggio condizionato e percussioni probabilistiche. Gli otto slot PCM usano per ora lo stesso breve campione di rumore sintetico originale, non una libreria drum definitiva.

## Compilare da Mac senza un PC Windows

La compilazione sul Mac è possibile: FM-1 Evolver usa già il compilatore JieLi Linux tramite Blink e un packager Python. È stata recuperata quella configurazione locale e sono stati compilati correttamente tutti e tre i nuovi moduli per PI32v2 r3; vedere `VERIFICA-PI32-MAC.json`. Questo corregge la precedente conclusione troppo generale sulla necessità di Windows o GitHub. La base FM1 Open di questo progetto rimane invariata: non è stata sostituita con Optimist.

Resta da adattare il linking e il packaging dell'SDK ufficiale e dimostrare la compatibilità della toolchain Linux disponibile (20250324.1) con il contratto del suo SDK 2.5.3. I controlli ufficiali non sono stati disattivati. Non si deve riutilizzare automaticamente il layout Flash/loader di Evolver, che ha una base diversa.

Il builder hardware ufficiale documenta Windows x64 con toolchain JieLi 2.5.3. Clang Apple non supporta PI32v2. È inclusa una proposta di workflow manuale GitHub Actions: `.github/workflows/tracker.yml`, runner Windows 2022. La si può avviare dal browser del Mac dopo aver caricato l'intero progetto in un proprio repository, conservando le licenze. Actions → Experimental tracker firmware → Run workflow.

Il job scarica l'installer ufficiale, individua il Clang con hash corretto e lancia `Build-Tracker.ps1`. Tutti i controlli originali sono preservati; il wrapper aggiunge verifiche SRAM per simboli audio custom. Firmware e report vengono restituiti come artifact, senza pubblicare release. Il workflow non è stato eseguito: installazione silenziosa, compilazione e linking richiedono ancora verifica. Non è stato creato alcun repository né caricato alcun sorgente su GitHub durante questo lavoro.

È stato provato anche Wine già presente sul Mac, in un prefisso isolato nella cartella di lavoro. La sessione ha impedito l'avvio del wineserver con `Can't check in server_mach_port`. Non è stato possibile verificarvi il compilatore. Questo non dimostra che Wine sia incompatibile fuori dalla sessione.

## Parti ancora necessarie prima di un firmware utilizzabile

1. Compilazione e linking reali PI32v2, controlli di integrità, RAM, Flash, heap e dipendenze audio SRAM, inclusi gli helper generati dal compilatore.
2. Verificare CPU/RAM sul dispositivo. Il rendering duplicato del vecchio motore è stato rimosso; mixer ed effetti aggiungono un costo da misurare. Nessuna garanzia attuale di otto voci più effetti in tempo reale sull'FM1.
3. Collaudo e misurazione ISR/underrun su hardware, ricampionatore di uscita filtrato, oscillatori band limited, wavetable estese, PWM modulata e filtro con inviluppo. La sintesi non è un port di Plaits/Braids.
4. Persistenza transazionale del formato tracker e importazione utente dei campioni. L'attuale API PCM collega array residenti; non è un importatore WAV. Il tracker non legge/scrive i progetti ufficiali, ma i servizi di storage originali restano nel runtime.
5. Clock MIDI, microtiming MTT, groove per traccia, Table ausiliarie, rampe FX a tempo definito e comandi MIDI. Le differenze nei comandi sono documentate in `COMANDI.md`.
6. Adeguamento del simulatore web originale: il suo builder non è stato modificato per questi moduli. I test host sono distinti dal simulatore web ufficiale.
7. Identità firmware custom compatibile con l'updater. Il builder mantiene temporaneamente metadati V14 e nome file upstream: il progetto non è una release ufficiale o pronta alla distribuzione.
8. Backup e recupero verificati, quindi collaudo su dispositivo. Nessun flash è stato eseguito.

## Riferimenti

- Base hardware e build: https://github.com/m-vave/fm1_open
- Annuncio ufficiale: https://forum.m-vave.com/topic/4
- Manuale M8, collegato dal produttore: https://dirtywave.com/pages/resources-downloads
- Comandi picoTracker Advance: https://manual.xiphonics.com/advance/commands.html
- Table picoTracker Advance: https://manual.xiphonics.com/advance/tables.html

Le semantiche adattate non sono presentate come emulazione esatta dei due strumenti. Nessun codice picoTracker è stato copiato: sono stati consultati i riferimenti pubblici per progettare un interprete originale.


## Workbench A03: interfaccia e navigazione

Aprire `../FM1-Tracker-A03-Workbench.html` tramite il server locale su http://127.0.0.1:8784/FM1-Tracker-A03-Workbench.html. Il browser esegue il motore C compilato in WebAssembly. Premi PLAY per abilitare l'audio.

La mappa permanente apre Song → Chain → Phrase → Instrument → Table. Evidenzia la vista e mostra gli ultimi ID visitati; non rappresenta automaticamente tutti i riferimenti del progetto. Il doppio clic apre il riferimento della cella; Indietro ripristina la selezione precedente. Cambiare vista dalla mappa conserva la posizione visitata. F1–F5 apre le cinque viste nell'ordine della mappa; Alt+freccia sinistra torna indietro. Le otto tracce hanno pulsanti dedicati. I pulsanti −1/+1 e −10/+10 modificano la cella: 10 è esadecimale, quindi sedici unità. Salva nel browser conserva il progetto locale.

Testo della griglia a 16 px, celle più alte e contrasto aumentato. La disposizione sul browser è più ampia del display fisico 240×240. Il display C ora include la barra SNG/CHN/PHR/INS/TBL con vista attiva evidenziata. I tasti fisici FX/SEL/ENV/LFO/EDIT hanno accesso diretto alle viste nel codice C, verificato con periferiche simulate. Il collaudo hardware resta da fare. Gli encoder mantengono le assegnazioni indicate sopra.

I test WebAssembly verificano import/export dei dati, audio, passaggio al worklet e 48 kHz. In Chrome sono stati verificati modifica di note/FX, BPM durante playback, salvataggio e ripristino, mappa e riferimenti, ritorno e modifica incrementale. La finestra di selezione file/download non è stata verificata dall'automazione del browser.


## Display nativo e quattro rotativi

Il framebuffer C 240×240 usa Barlow Condensed Bold 18 px, lo stesso font di FM-1 Evolver, rasterizzato con copertura a 4 bit. Sette righe scorrono verticalmente con la selezione. Song e Phrase non mostrano numeri di riga, e il footer non ripete posizione o intervallo visibile. Song distingue le tracce con colori e sfondi; Instrument distingue i gruppi di parametri e mostra il nome del preset riconosciuto (CUSTOM se modificato). La barra SNG/CHN/PHR/INS/TBL resta visibile.

Le ultime due righe mostrano K1–K4 e le funzioni. SELECT seleziona la traccia, ALGORITHM la riga, PRESETS la vista. K1 seleziona il campo, K2 modifica il valore, K3 cambia ID dell'oggetto, K4 cambia BPM. Nella Song K1 sceglie la traccia, K2 modifica il riferimento Chain e K3 la lunghezza Song. Nel Workbench i pulsanti +/− sotto il display inviano gli stessi eventi encoder al codice C. Il trasferimento resta in strisce da 10 pixel con buffer 4800 byte. Non sono state misurate prestazioni sul dispositivo fisico.

## Banco Instrument: 24 preset

20 preset SYNTH utilizzabili sulle otto tracce: Round Bass, Saw Bass, Pulse Bass, Sub Square, Acid Bite, Bright Lead, Pulse Lead, Soft Lead, Thin Lead, Chip Lead, Glass Pluck, Saw Pluck, Pulse Pluck, Soft Bell, Slow Wave, Slow Pulse, Noise Tick, Noise Snap, Noise Swish, Dark Noise.

4 preset SAMPLE utilizzabili sulle otto tracce: PCM Click, PCM Dark, PCM Soft, PCM Bright. Usano il medesimo breve campione sintetico dimostrativo, con filtro e inviluppo differenti: non sono una nuova libreria di percussioni.

Il banco di fabbrica è separato dai 32 slot Instrument del progetto. Nella pagina Instrument, K3 sceglie lo slot; ARP apre il banco, K1 sceglie il preset, K3 sceglie lo slot di destinazione e REC sostituisce i parametri di quel solo strumento. ARP richiude senza caricare. Dal Workbench si può anche usare il menu Preset Instrument e Carica nello strumento corrente. Salvare il progetto conserva i parametri caricati. Il formato progetto resta A03; i nomi dei preset caricati sono conservati nello strumento anche dopo modifiche.

I preset non attivano Table e non alterano Phrase, Chain o Song. I motori sono saw, pulse, wavetable sinusoidale, square/chip, noise e sampler PCM; i motori DX7/303/808/Pluck del vecchio framework non sono collegati al tracker. Sintesi originale semplice, non emulazioni dei relativi strumenti.

Test ASan/UBSan: bounds del display, antialias, scrolling, cinque viste, K3 Instrument, K1/K3 Song, caricamento e limiti dei 24 preset, audio non nullo/limitato per ogni preset sulle tracce appropriate, caricamento nativo ARP/K1/REC. Test C/WASM e audio worklet superati. Confermati in Chrome cambio K3 00→01 e caricamento Glass Pluck. Nessun collaudo o flash hardware.


## Tastiera di anteprima e nomi persistenti

Le indicazioni K1–K4 usano Barlow Condensed 13px; il resto del display resta 18px. La tastiera fisica suona un'anteprima monofonica con priorità all'ultimo tasto e ritorno a un tasto ancora premuto. Al rilascio di tutti i tasti l'anteprima termina. Non richiede PLAY. In Instrument usa lo slot selezionato; per i preset riconosciuti usa la relativa sintesi SYN/PCM. In Song usa lo strumento dell'ultima nota eseguita sulla traccia, conservato anche dopo STOP. In Phrase usa lo strumento della riga o dell'ultima riga precedente che ne specifica uno. In Phrase l'inserimento note preesistente resta attivo; Instrument e Song non scrivono eventi quando si prova un suono.

Una voce di anteprima separata usa gli stessi oscillatori/sampler e l'inviluppo AD del motore; non sostituisce le voci del sequencer e non ne fa avanzare il clock. Non esegue la Table o gli FX della Phrase: è un ascolto del timbro base. Sul browser, Z S X D C V G B H N J M suona da C4; Suona C4 esegue una prova breve. La tastiera nel pannello FM-1 invia gli eventi hardware originali. Panic ferma sequencer e anteprima.

I progetti ora includono 16 byte di nome per ciascuno dei 32 strumenti. Il nome viene copiato dal preset e resta visibile anche se si modificano i parametri. Gli strumenti precedenti senza nome ricevono il nome del preset riconosciuto o un'etichetta modello/ID. Gli import A03 precedenti, senza questo campo, sono migrati conservando i parametri e inizializzando i nomi vuoti; il nuovo export mantiene la famiglia A03 ma è più lungo. Le vecchie versioni del Workbench non leggono il nuovo export. Conservare questa build insieme ai progetti.

Verificati con ASan/UBSan: anteprima udibile a STOP, rilascio e silenzio, nessuna modifica al progetto/clock durante l'anteprima in Instrument, ultimo strumento della Song dopo STOP, eventi della tastiera fisica e nome conservato dopo un cambio di cutoff. Verificati nel C/WASM: migrazione A03 precedente, roundtrip del nome, anteprima a STOP. Verificati in Chrome: AUDIO ON senza avviare il sequencer, tasto Z, caricamento/salvataggio e ripristino del nome GLASS PLUCK. Prestazioni e collaudo sul dispositivo fisico restano da fare.

Il Tracker host misura ora 11432 byte, inclusi i nomi; la voce di anteprima e i buffer statici del device sono aggiuntivi. Questo non è una verifica del budget RAM/CPU hardware.


## Source e modello per strumento

Instrument presenta SOURCE come prima riga: SYNTH oppure SAMPLE. La riga MODEL mostra SAW, PULSE, SINE, CHIP o NOISE quando la sorgente è SYNTH e PCM quando è SAMPLE. SAMPLE SLOT sceglie uno degli otto descrittori di campione residenti (attualmente il medesimo campione dimostrativo). Su SAMPLE, Pulse Width non è applicabile e MODEL non modifica l'oscillatore. Cambiando SOURCE vengono mantenuti i parametri dell'altra sorgente per poter tornare alla configurazione precedente.

K1 scorre i campi nell'ordine SOURCE, MODEL, SAMPLE SLOT, TABLE, VOLUME, CUTOFF, PULSE WIDTH, ATTACK, DECAY. K2 cambia il valore, K3 sceglie lo strumento, K4 il BPM. I cambi di sorgente e modello vengono usati al prossimo trigger; l'anteprima usa la stessa sorgente. Il browser offre anche due menu Sorgente Instrument / Modello synth. Le etichette delle tracce ora indicano MONO: il tipo non è più imposto dal numero della traccia. Il caricamento di un preset assegna anche la sua sorgente.

La sorgente è persistente per ciascuno dei 32 strumenti ed è usata dal calcolo del pitch, dal trigger, dal rendering audio e dalla gestione dei campioni. Il buffer di progetto include ora 32 byte aggiuntivi. Sono importabili entrambe le precedenti varianti A03 (senza nomi e con nomi): quando manca la sorgente, gli slot 04–07 vengono inizializzati SAMPLE e gli altri SYNTH, salvo un nome di preset riconosciuto che determina la sorgente corretta. Questo conserva la distribuzione della demo precedente; vecchi progetti che usavano lo stesso strumento su tracce synth e sampler richiedono due slot separati, perché ora la sorgente appartiene allo strumento.

Test audio deterministici confermano PCM sulla traccia 1 e SAW sulla traccia 8, non solo un'etichetta diversa. Verificati validazione del selettore, roundtrip della sorgente, migrazione delle due varianti A03, anteprima e caricamento preset. In Chrome, i rotativi K1/K2 sono stati usati per SYNTH→SAMPLE→SYNTH e SINE→CHIP→SINE, confermando anche MODEL PCM e disabilitazione del selettore synth durante SAMPLE. Nessun test sul dispositivo fisico.


## Mixer, delay e riverbero master

La revisione corrente aggiunge Mixer e Master FX al display C. SEQ apre Mixer: SELECT traccia, K1 livello, K2 pan, K3 delay send, K4 reverb send, REC mute e ARP solo. GLO apre Master FX, con delay musicale normale/puntato/terzinato, feedback, ping-pong e ritorni delay/reverb. LEV/PAN/DSN/RSN automatizzano il mixer dalle Phrase o Table. Le impostazioni vengono salvate; i progetti A03 precedenti ricevono mixer centrato a livello unitario e mandate zero. Il formato è esteso: usare questa build per i nuovi export.

Il Tracker host ora pesa 213120 byte; i valori più piccoli riportati nelle sezioni storiche precedenti non includono i ritorni aggiunti in questa revisione. Gli effetti hanno bus a 8 kHz e sei secondi massimi di delay, mentre il diretto è stereo a 32 kHz. Linking/RAM/CPU completi sull'hardware restano da verificare. Vedere MIXER-FX.md per architettura, controlli, test e limitazioni; build/tracker-web/pi32-mixer-check.json conserva la nuova verifica di compilazione dei tre moduli PI32 sul Mac.

## Aggiornamento: sintesi e modulazioni

Tre nuovi modelli derivati da Braids (FM, feedback FM, VOSIM), ADSR su synth/PCM,
filtri LP/BP/HP con risonanza e due LFO con assegnazioni simultanee e controfase.
30 preset complessivi. Instrument ruota tra due pagine senza cambiare slot;
REC resta indipendente dalla navigazione. Dettagli e limiti in
[SINTESI-MODULAZIONI.md](SINTESI-MODULAZIONI.md). Plaits non è incluso.

## Song: mute e solo

In Song, SELECT o K1 seleziona la traccia; **OCT−** attiva/disattiva il mute e
**OCT+** attiva/disattiva il solo. Sono gli stessi stati del mixer e sono salvati
nel progetto. Più tracce possono essere in solo. Il mute prevale sul solo.
Il display non aggiunge sigle: intestazioni e celle delle tracce escluse vengono
scurite, anche durante la riproduzione. La cella selezionata resta leggibile.
Nel Workbench sono disponibili anche pulsanti Mute/Solo per ciascuna traccia.

## Aggiornamento Ambient e inviluppi grafici

La seconda pagina Instrument ora presenta quattro riquadri grafici nativi:
AMP ENV, CUT ENV, LFO1 e LFO2, con indicatori della nota in corso. Il cutoff ha
un secondo ADSR indipendente con profondità positiva o negativa. Master FX
aggiunge Tipo riverbero ROOM/AMBIENT, conservando il precedente come opzione.
Dettagli e prova rapida in [AMBIENT-ENV-GRAFICI.md](AMBIENT-ENV-GRAFICI.md).
