# Meighty Wavetable v2

La scansione ora attraversa nove forme per banco, con spettri più distanti, invece delle cinque precedenti. Restano i quattro nomi CLASSIC, HOLLOW, GLASS e FORMANT e gli stessi ID: non cambiano il formato dei progetti, le posizioni, i comandi o le assegnazioni LFO. I progetti precedenti si aprono, ma i timbri wavetable cambiano intenzionalmente.

- CLASSIC: da seno a forme ricche di armoniche, onde impulsive e strutture piegate.
- HOLLOW: registri con gruppi di armoniche e combinazioni di parziali molto differenti.
- GLASS: gruppi stretti di armoniche che salgono nello spettro, mantenendo una componente fondamentale.
- FORMANT: due picchi risonanti che cambiano frequenza e distanza.

Le posizioni 00, 20, 40, 60, 80, A0, C0, E0 e FF sono vicine alle nove forme di riferimento. La scansione è interpolata, non a scatti; FF raggiunge l’ultima forma. Le nove posizioni esatte non sono equidistanti in valori interi perché 255 non è divisibile per otto.

Sono presenti sei livelli di limitazione armonica, con 48, 24, 12, 6, 3 e 1 armoniche massime. Prima c’erano solo 48, 12 e 3. Le soglie precedenti riducevano la complessità molto presto: sopra 750 Hz rimanevano tre armoniche. Ora a 1 kHz ne restano dodici. Sugli acuti estremi il contenuto deve comunque ridursi; non si possono mantenere le stesse armoniche del registro grave oltre il limite della frequenza di campionamento. Le tabelle sono generate per questo progetto, non sono una libreria commerciale importata.

## Prova immediata

Nel Workbench aggiornato: Progetti e file → Apri file Workbench dal Mac → **FM1-M8-Wavetable-Random.fm1tracker.json** → PLAY. In FM1 Emulator: Import → **FM1-M8-Wavetable-Random.fm1save** → Start a 240 MHz → PLAY. Il .fm1save include la nuova build.

La demo usa GLASS, OSC1 da solo, filtro aperto, LFO e mandate spenti, una nota C4 tenuta. Ogni riga cambia posizione con i due FX:

```
RIGA NOTE INST FX1 VAL FX2 VAL
00   C-4  00   WTP 88  RNL 88
01   ---  FF   WTP 88  RNL 88
02   ---  FF   WTP 88  RNL 88
... ripeti fino a 0F ...
```

RNL in FX2 randomizza il valore WTP immediatamente a sinistra. Il valore 88 e l’ampiezza 88 consentono di coprire l’intero intervallo 00–FF; i nibble vengono limitati agli estremi, quindi la distribuzione non è perfettamente uniforme. Non varia la nota e non riscrive le celle della Phrase. Per OSC2 usa WT2 e porta OSM a FF; con OSM 00 le modifiche a WT2 non si sentono. LFO POS e Table restano disponibili.

Per valutare i banchi manualmente usa una nota medio-grave, OSM 00, cutoff aperto e risonanza bassa, e spegni le modulazioni POS. Se una Table o un FX sovrascrive WTP, la posizione impostata nello strumento può non essere quella effettivamente suonata.

## Confronto audio

**FM1-M8-Wavetable-Confronto.wav** alterna vecchio e nuovo per ciascun banco, con la stessa nota C4, stessi livelli e nessun effetto. Ogni segmento contiene quattro secondi di scansione avanti e indietro e 0,3 secondi di pausa. Ordine: CLASSIC prima/dopo, HOLLOW prima/dopo, GLASS prima/dopo, FORMANT prima/dopo. Durata totale 34,4 secondi. Il guadagno di ascolto è identico per entrambi, non modifica il firmware.

La figura **FM1-M8-Wavetable-v2.png** mostra le nove forme dei quattro banchi nel registro grave. Questo aggiornamento sostituisce le descrizioni delle cinque forme e dei tre livelli presenti nel manuale precedente.
