/* SPDX-License-Identifier: GPL-3.0-only WITH GPL-3.0-linking-exception */
#ifndef TRACKER_H
#define TRACKER_H
#include "fm1.h"
enum { TR_TRACKS=8, TR_PHRASES=64, TR_CHAINS=32, TR_SONG=32, TR_TABLES=16,
       TR_INSTRUMENTS=32, TR_SAMPLES=33, TR_EMPTY=255, TR_OFF=254, TR_MODELS=18, TR_SOUND_FIELDS=23, TR_RATE=32000 };
enum { FX_NONE, FX_DEL, FX_KIL, FX_HOP, FX_CHA, FX_RND, FX_REP, FX_PORT,
       FX_CND, FX_PRV, FX_CUT, FX_START, FX_LENGTH, FX_RET, FX_RNL, FX_SED,
       FX_RTO, FX_VOL, FX_PIT, FX_ARP, FX_ARC, FX_TBL, FX_THO, FX_TIC,
       FX_TPO, FX_JMP, FX_SNG, FX_INS, FX_OFF, FX_CHN, FX_PBN, FX_PVB,
       FX_PWM, FX_MDL, FX_SCA, FX_SCG, FX_TSP, FX_STP, FX_NTH, FX_LEV, FX_PAN, FX_DSN, FX_RSN, FX_TIM, FX_COL, FX_FAI, FX_FAL, FX_FBK, FX_WTP, FX_WT2, FX_DTN, FX_OSM, FX_SYN, FX_OR1, FX_OR2, FX_OR3, FX_OR4, FX_CHD, FX_COUNT };
#define FX_PSL FX_PORT
typedef struct { uint8_t command,value; } TrFx;
typedef struct { uint8_t note,instrument; TrFx fx[2]; } TrStep;
typedef struct { TrStep step[16]; } TrPhrase;
typedef struct { uint8_t phrase[16],length; } TrChain;
typedef struct { int8_t transpose; uint8_t velocity; TrFx fx[3]; } TrTableRow;
typedef struct { TrTableRow row[16]; uint8_t length; } TrTable;
typedef struct { uint8_t model,table,volume,cutoff,pulse,attack,decay,sample; } TrInstrument;
typedef struct { const int16_t *data; uint32_t frames,rate; uint8_t root; } TrSample;
typedef struct {uint8_t level,pan,delay,reverb;} TrMix;
typedef struct {
 TrPhrase phrases[TR_PHRASES]; TrChain chains[TR_CHAINS];
 uint8_t song[TR_SONG][TR_TRACKS],song_length;
 TrTable tables[TR_TABLES]; TrInstrument instruments[TR_INSTRUMENTS]; uint16_t bpm; char instrument_names[32][16]; uint8_t instrument_source[32]; /* 0 legacy by-track, 1 synth, 2 PCM */
 TrMix mixer[8]; uint8_t mute_mask,solo_mask,master[8],mixer_version;
 uint8_t sound_padding; /* palette: title/selection 4-bit colour indices; preserves project layout */
 uint8_t sound[32][TR_SOUND_FIELDS]; /* UI fields 9..31, appended for migration */
 uint8_t cutoff_env[32][6],reverb_mode,global_padding,global_scale,global_root;
 uint8_t engine[32][32]; /* Append only: FM4 operators and dual wavetable parameters. */
 uint8_t wt_lfo[32][4]; /* LFO1 POS1/POS2, LFO2 POS1/POS2; biased signed depths. */
 uint8_t poly_track,poly_version;uint16_t poly_reserved; /* schema2 append-only; 0/1..8 off/track */
} TrProject;
typedef struct {uint32_t value,left;int32_t step,level;uint8_t stage;} TrEnvelope;
typedef struct {uint32_t phase_;int high_;int16_t parameter_,aux_parameter_,discontinuity_depth_;int32_t next_sample_;} TrAnalog;
typedef struct {int32_t lp,bp,f,damp;unsigned punch,mode;} TrResonator;
typedef struct {int32_t state,level,counter;unsigned decay,delay;} TrExcitation;
typedef struct { TrFx last; int8_t delta; uint8_t running,limit,limited; } TrLane;
typedef struct {
 TrAnalog analog[2]; TrResonator resonator[3];TrExcitation pulse_state[4];
 TrEnvelope op_env[4];uint32_t op_phase[4],osc_phase[2],drum_phase[6];
 int32_t op_gain[4],op_feedback[2],braids_lp,drum_hold;
 uint32_t engine_increment;int32_t engine_pitch;
 uint16_t engine_override;
 uint8_t engine_prepared,engine_model,engine_clock,engine_live[8],engine_ratios[4];
 TrEnvelope cutoff_envelope;
 uint8_t sample_mode,env_stage,mod_clock;
 int16_t mod_position[2];
 uint32_t lfo_phase[2],mod_phase[2],env_left,env_value;
 int32_t env_step,filter_band,model_previous,mod_pan,mod_pitch,mod_cutoff,mod_amp;
 uint8_t song,chain,step,tick,instrument,note,table_row,table_active,previous;
 uint8_t delay,kill,repeat,glide,volume,cutoff,start,length,active;
 uint32_t loops,phase,increment,target,noise,position,index,end;
 int32_t envelope,filter; uint8_t attacking,pending;
 TrLane lanes[2],table_lanes[3]; TrStep deferred;
 uint32_t rng,table_loops,sample_step,sample_target,glide_left;
 int32_t glide_step,sample_glide_step; uint16_t kill_left;
 uint8_t table_hops[16],table_hold,table_generation;
 uint8_t table_id,table_rate,table_wait,table_jump,stopped,hop,jump,song_jump;
 uint8_t ret_clock,ret_period,ret_once,ret_value,model,pulse,arp,arp_rate,arp_clock,arp_pos;
 uint8_t vibrato,vibrato_phase,scale; int8_t transpose,bend,table_transpose;
 int16_t pitch_accum;
 /* Runtime-only exact cache: TrProject / saved data layout is unchanged. */
 uint32_t wt_cached_inc,wt_cached_second;
 uint8_t wt_cached_semi,wt_cached_detune,wt_cache_valid,wt_cached_model,live_note;
 int32_t filter_cache_f,filter_cache_damp;
 uint8_t filter_cache_cut,filter_cache_res,filter_cache_valid;
 uint32_t pitch_cached_input[2],pitch_cached_output[2];
 int32_t pitch_cached_amount[2];
 uint8_t pitch_cache_valid;
 /* Exact FM increments, keyed by pitch and all four raw ratio bytes. */
 uint32_t fm_cached_inc,fm_cached_ratios,fm_step[4];
 uint8_t fm_cache_valid;

} TrVoice;
enum {TR_DELAY_CAP=48001,TR_FX_RATE=8000};
typedef struct {
 int16_t ambient[8][2048],diffuse[2][4][256];
 unsigned ambient_pos[8],ambient_valid[8],diff_pos[2][4],diff_valid[2][4],ambient_blend;int32_t ambient_damp[8];
 int16_t delay[2][TR_DELAY_CAP],comb[2][4][512],allpass[2][2][128];
 uint32_t write,valid,delay_samples,old_delay,bpm,division,fade;
 unsigned comb_pos[2][4],comb_valid[2][4],ap_pos[2][2],ap_valid[2][2];
 int32_t damp[2][4],accum[4],wet[2],previous_wet[2],mix_now[8][4];
 int16_t override[8][4];uint16_t peaks[8],peak_hold[8];unsigned meter_clock,decimate,feedback,ping,decay,damping,delay_return,reverb_return,master_gain;
} TrEffects;
typedef struct {
 TrProject project; TrSample samples[TR_SAMPLES]; TrVoice voice[10];
 uint8_t poly_track,poly_next,poly_chord,poly_live;
 int16_t preview_pan;
 uint32_t rng,clock,ticks; uint8_t playing,song_launch; int8_t transpose; TrEffects effects;
} Tracker;
enum { TR_RENDER_CHUNK=128 };
typedef union {uint8_t value[4];uint32_t packed;} TrMixFrame;
/* Runtime workspace: never serialized. Each worker owns distinct voice rows.
 * The caller must join every submitted job before returning or changing data. */
typedef struct {
 int32_t sample[10][TR_RENDER_CHUNK],preview[TR_RENDER_CHUNK];
 int16_t pan[10][TR_RENDER_CHUNK],preview_pan[TR_RENDER_CHUNK];
 TrMixFrame mix[10][TR_RENDER_CHUNK];uint8_t mix_constant[10];
 int32_t poly_mix_start[4];
 int32_t partial[2][TR_RENDER_CHUNK][6]; /* dry LR, delay LR, reverb LR */
 Tracker *tracker;unsigned frames,channel,split,meter_start;
 unsigned ready __attribute__((aligned(32))); /* worker publishes completed sample groups */
 uint32_t (*clock)(void);uint32_t timing[5]; /* prep, CPU0, CPU1, join wait, FX/final */
 int (*submit)(void (*job)(void *),void *arg);
 void (*join)(void);
} TrRender;
void tr_render_stereo(Tracker *t,TrVoice *preview,unsigned channel,int16_t *out,unsigned frames,TrRender *work);
int tr_poly_select(Tracker *t,unsigned track); /* 0=off, 1..8=logical track */
int tr_poly_note_on(Tracker *t,unsigned instrument,unsigned note);
void tr_poly_note_off(Tracker *t,unsigned note);
const char *tr_scale_name(unsigned scale);
int tr_global_note(const TrProject *p,int note);
unsigned tr_instrument_source(const Tracker *t,unsigned instrument,unsigned channel);
void tr_sound_reset(TrProject *p,unsigned slot);
void tr_sound_defaults(TrProject *p);
void tr_release(Tracker *t,TrVoice *v);
const char *tr_model_name(unsigned model);
const char *tr_engine_name(unsigned model);
int tr_wavetable_preview(unsigned bank,unsigned position,unsigned phase);
void tr_engine_defaults(TrProject *p);
void tr_engine_reset(TrProject *p,unsigned n);
void tr_project_mixer_defaults(TrProject *p);
void tr_effects_reset(Tracker *t);
unsigned tr_mixer_value(const Tracker *t,unsigned track,unsigned field);
unsigned tr_delay_frames(unsigned bpm,unsigned division);
const char *tr_delay_name(unsigned division);
void tr_effects_sample(Tracker *t,int32_t dl,int32_t dr,int32_t rl,int32_t rr,int32_t out[2]);
void tr_sample_stereo(Tracker *t,int32_t preview,unsigned channel,int16_t out[2]);
void tr_init(Tracker *t);
void tr_project_init(TrProject *p);
void tr_demo(Tracker *t);
const char *tr_fx_name(unsigned command);
const char *tr_fx_help(unsigned command);
void tr_evolving_demo(Tracker *t);
void tr_berlin_demo(Tracker *t);
void tr_drum_demo(Tracker *t);
void tr_engine_demo(Tracker *t);
FM1_AUDIO_CODE void tr_transport(Tracker *t,int playing);
int tr_song_start(Tracker *t,unsigned song_row);
int tr_song_launch(Tracker *t,unsigned song_row);
FM1_AUDIO_CODE void tr_tick(Tracker *t);
FM1_AUDIO_CODE int16_t tr_sample(Tracker *t);
FM1_AUDIO_CODE int tr_set_sample(Tracker *t,unsigned slot,const TrSample *sample);
void tr_audition_on(Tracker *t,TrVoice *preview,unsigned channel,unsigned instrument,unsigned note);
int32_t tr_audition_sample(Tracker *t,TrVoice *preview,unsigned channel);
void tracker_device_init(void);
void tracker_device_control(void);
FM1_AUDIO_CODE void tracker_device_render(int32_t *out,unsigned frames);
void tracker_device_worker(int (*submit)(void (*job)(void *),void *arg),void (*join)(void));
void tracker_device_audio_clock(uint32_t (*clock)(void));
void tracker_device_audio_cost(uint32_t ticks[5]);
void tr_benchmark_arithmetic(uint32_t (*clock)(void),uint32_t result[4]);
int tracker_device_diagnostic_buttons(unsigned buttons);
#endif
