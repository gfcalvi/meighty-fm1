/* Emulator interchange: official fm1-emulator-save v1, physical NOR sectors. */
(function(root){'use strict';
const decode=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
function encode(b){let s='';for(let i=0;i<b.length;i+=16384)s+=String.fromCharCode(...b.subarray(i,i+16384));return btoa(s);}
function crc32(b){let c=0xffffffff;for(const x of b){c^=x;for(let n=0;n<8;n++)c=(c>>>1)^(0xedb88320&-(c&1));}return(c^0xffffffff)>>>0;}
async function emulatorSave(project,firmware){
 if(!firmware?.data)throw Error('Pacchetto Emulator non disponibile: ricostruire il Workbench.');
 if(project.format!=='FM1-Tracker-A03')throw Error('Formato progetto non valido.');
 const data=decode(project.data);if(data.length!==11940)throw Error('Versione progetto non compatibile con questa esportazione.');
 const digest=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',data)),x=>x.toString(16).padStart(2,'0')).join('');if(digest!==project.sha256)throw Error('Checksum progetto non valido.');
 const bank=new Uint8Array(12288).fill(255),h=new DataView(bank.buffer);[0x31505254,1,data.length,1,crc32(data),0].forEach((v,i)=>h.setUint32(i*4,v,true));bank.set(data,24);
 return{format:'fm1-emulator-save',version:1,name:'Meighty · '+(project.name||'Progetto'),hash:firmware.sha256,package:firmware.data,sectors:[0,1,2].map(i=>({at:0xb6000+i*4096,data:encode(bank.subarray(i*4096,(i+1)*4096))}))};
}
root.FM1TrackerFiles={emulatorSave,crc32};
})(globalThis);
