/* SPDX-License-Identifier: GPL-3.0-only WITH GPL-3.0-linking-exception */
/* snprintf links WASI stdio helpers, but the simulator has no file descriptors.
 * String formatting stays entirely in memory; real fd requests fail explicitly. */
#ifdef __wasm__
#include <wasi/api.h>
__wasi_errno_t __wrap___wasi_fd_close(__wasi_fd_t fd){(void)fd;return __WASI_ERRNO_BADF;}
__wasi_errno_t __wrap___wasi_fd_seek(__wasi_fd_t fd,__wasi_filedelta_t offset,__wasi_whence_t whence,__wasi_filesize_t *result){(void)fd;(void)offset;(void)whence;if(result)*result=0;return __WASI_ERRNO_BADF;}
__wasi_errno_t __wrap___wasi_fd_write(__wasi_fd_t fd,const __wasi_ciovec_t *iovs,size_t length,__wasi_size_t *result){(void)fd;(void)iovs;(void)length;if(result)*result=0;return __WASI_ERRNO_BADF;}
#endif
