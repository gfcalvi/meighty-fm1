/* SPDX-License-Identifier: GPL-3.0-only WITH GPL-3.0-linking-exception */
#include "tracker/ui.h"
#include <string.h>
#include <stddef.h>
#ifdef __wasm__
#define API(n) __attribute__((export_name(n)))
#else
#define API(n)
#endif
static TrProject project_buffer;
/* The browser adapter has one serialized control/audio owner, no hardware IRQ. */
uint32_t fm1_device_irq_save(void){return 0;}
void fm1_device_irq_restore(uint32_t state){(void)state;}
API("sim_tracker_get") int sim_tracker_get(unsigned p,unsigned o,unsigned r,unsigned f){return tracker_ui_get(p,o,r,f);}
API("sim_tracker_set") int sim_tracker_set(unsigned p,unsigned o,unsigned r,unsigned f,int value){return tracker_ui_set(p,o,r,f,value);}
API("sim_tracker_select") int sim_tracker_select(unsigned p,unsigned t,unsigned r,unsigned f,unsigned o){return tracker_ui_select(p,t,r,f,o);}
API("sim_tracker_state") unsigned sim_tracker_state(unsigned i){return tracker_ui_state(i);}
API("sim_tracker_voice") unsigned sim_tracker_voice(unsigned t,unsigned i){return tracker_ui_voice(t,i);}
API("sim_tracker_play") void sim_tracker_play(int playing){tracker_ui_play(playing);}
API("sim_tracker_demo") void sim_tracker_demo(unsigned demo){tracker_ui_demo(demo);}
API("sim_tracker_name") const char *sim_tracker_name(unsigned command){return tr_fx_name(command);}
API("sim_tracker_help") const char *sim_tracker_help(unsigned command){return tr_fx_help(command);}
API("sim_tracker_count") unsigned sim_tracker_count(void){return FX_COUNT;}
API("sim_tracker_project") void *sim_tracker_project(void){memcpy(&project_buffer,tracker_ui_project(),sizeof project_buffer);return &project_buffer;}
API("sim_tracker_buffer") void *sim_tracker_buffer(void){return &project_buffer;}
API("sim_tracker_bytes") unsigned sim_tracker_bytes(void){return sizeof project_buffer;}
API("sim_tracker_import") int sim_tracker_import(unsigned bytes){
 if(bytes==offsetof(TrProject,instrument_names))memset(project_buffer.instrument_names,0,sizeof project_buffer.instrument_names);
 else if(bytes!=offsetof(TrProject,instrument_source)&&bytes!=offsetof(TrProject,mixer)&&bytes!=offsetof(TrProject,sound)&&bytes!=offsetof(TrProject,cutoff_env)&&bytes!=offsetof(TrProject,global_scale)&&bytes!=offsetof(TrProject,engine)&&bytes!=offsetof(TrProject,wt_lfo)&&bytes!=sizeof project_buffer)return -1;
 if(bytes<offsetof(TrProject,mixer))memset(project_buffer.instrument_source,0,sizeof project_buffer.instrument_source);
 if(bytes<offsetof(TrProject,sound))tr_project_mixer_defaults(&project_buffer);
 if(bytes<offsetof(TrProject,cutoff_env))tr_sound_defaults(&project_buffer);
 if(bytes<offsetof(TrProject,global_scale)){const uint8_t cut[]={0,24,64,0,40,128};for(unsigned i=0;i<32;i++)memcpy(project_buffer.cutoff_env[i],cut,6);project_buffer.reverb_mode=0;}
 if(bytes<offsetof(TrProject,engine))project_buffer.global_scale=project_buffer.global_root=0;
 if(bytes<=offsetof(TrProject,engine))tr_engine_defaults(&project_buffer);
 if(bytes<=offsetof(TrProject,wt_lfo))memset(project_buffer.wt_lfo,128,sizeof project_buffer.wt_lfo);
 return tracker_ui_project_apply(&project_buffer);
}
API("sim_tracker_tempo") int sim_tracker_tempo(unsigned bpm){return tracker_ui_tempo(bpm);}
API("sim_tracker_length") int sim_tracker_length(unsigned rows){return tracker_ui_length(rows);}

API("sim_tracker_preset_count") unsigned sim_tracker_preset_count(void){return tracker_ui_preset_count();}
API("sim_tracker_preset_name") const char *sim_tracker_preset_name(unsigned p){return tracker_ui_preset_name(p);}
API("sim_tracker_preset_pcm") unsigned sim_tracker_preset_pcm(unsigned p){return tracker_ui_preset_pcm(p);}
API("sim_tracker_preset_load") int sim_tracker_preset_load(unsigned i,unsigned p){return tracker_ui_preset_load(i,p);}

API("sim_tracker_legacy_bytes") unsigned sim_tracker_legacy_bytes(void){return offsetof(TrProject,instrument_names);}
API("sim_tracker_audition") int sim_tracker_audition(int note){return tracker_ui_audition(note);}
API("sim_tracker_instrument_name") const char *sim_tracker_instrument_name(unsigned i){return tracker_ui_instrument_name(i);}

API("sim_tracker_named_bytes") unsigned sim_tracker_named_bytes(void){return offsetof(TrProject,instrument_source);}

API("sim_tracker_source_bytes") unsigned sim_tracker_source_bytes(void){return offsetof(TrProject,mixer);}
API("sim_tracker_delay_name") const char *sim_tracker_delay_name(unsigned d){return tr_delay_name(d);}

API("sim_tracker_mix_bytes") unsigned sim_tracker_mix_bytes(void){return offsetof(TrProject,sound);}

API("sim_tracker_mod_bytes") unsigned sim_tracker_mod_bytes(void){return offsetof(TrProject,cutoff_env);}

API("sim_tracker_env_bytes") unsigned sim_tracker_env_bytes(void){return offsetof(TrProject,global_scale);}
API("sim_tracker_global_action") int sim_tracker_global_action(unsigned action){return tracker_ui_global_action(action);}
API("sim_tracker_scale_name") const char *sim_tracker_scale_name(unsigned scale){return tr_scale_name(scale);}

API("sim_tracker_old_wtlfo_bytes") unsigned sim_tracker_old_wtlfo_bytes(void){return offsetof(TrProject,wt_lfo);}
API("sim_tracker_old_engine_bytes") unsigned sim_tracker_old_engine_bytes(void){return offsetof(TrProject,engine);}
API("sim_tracker_model_count") unsigned sim_tracker_model_count(void){return TR_MODELS;}
API("sim_tracker_model_name") const char *sim_tracker_model_name(unsigned m){return tr_model_name(m);}
API("sim_tracker_engine_name") const char *sim_tracker_engine_name(unsigned m){return tr_engine_name(m);}
